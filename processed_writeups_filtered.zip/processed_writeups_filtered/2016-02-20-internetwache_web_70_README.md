## the secret store (web, 70p)

	description: we all love secrets. without them, our lives would be dull. 
	a student wrote a secure secret store, however he was babbling about problems with the database. 
	maybe i shouldn't use the 'admin' account. 
	hint1: account deletion is intentional. 
	hint2: i can't handle long usernames. 
	
###eng
[pl](#pl-version)

in the task we get access to www page which allows us to register a user and set a "secret" value for him.
we expected that we were supposed to login as admin and the secret for the admin would be the flag.
we spent a lot of time on this, trying a lot of stuff including xss (the page was vulnerable), blind sqli and many more.
we have noticed that it was possible to change password for our users if we tried to register them again, but this didn't work for admin user.
the solution turned out to be rather simple - the limit for number of characters in login was 32, however the check for existing accounts took whole input to test.
this means that registering a user with 33 character in login would in fact register this user with only first 32 character as login, but the check for unique login would be performed on whole 33 characters input.

therefore we registered user with login:

```python
payload = 'admin'+(' '*27)+'aa'
```

which meant that in reality we simply changed the password for `admin` user since spaces were omitted.

the flag was: `iw{truncation_is_my_friend}`

###pl version

w zadaniu dostajemy dostęp do strony www która pozwala zarejestrowac użytkownika i ustawić dla niego "sekretną" wartość.
założyliśmy, że musimy zalogować się jako admiin a sekretna wartość będzie flagą.
spędziliśmy nad tym zadaniem bardzo dużo czasu próbując różnych podejść, między innymi xss (strona była podatna), ślepe sqli i wiele innych.
zauważyliśmy że jest możliwość zmiany hasła dla naszych użytkowników poprzez ponowną ich rejestracje, ale to nie działało dla admina.
rozwiązanie okazało się dość proste - limit na długość loginu wynosił 32 znaki, ale test unikalności loginu był przeprowadzany dla całego wejścia.
to oznacza że rejestracja użytkownika z loginem na 33 znaki w rzeczywistości zarejestrowałby użytkownika z pierwszymi 32 znakami jako login, ale sprawdzenie czy taki użytkownik nie istnieje brałoby pod uwagę 33 znaki.

w związku z tym zarejestrowaliśmy użytkownika:

```python
payload = 'admin'+(' '*27)+'aa'
```

co oznacza że w praktyce zmieniliśmy hasło dla `admin`, bo spacje zostały pominięte.

w ten sposób uzyskaliśmy flagę: `iw{truncation_is_my_friend}`
