# bb-8 (crypto, 200p)

## eng
[pl](#pl-version)

in the task we get a [source code](server.py) of service we can connect to.
we also get a lengthly [description](readme.txt) of the protocol we are working with.

it is basically a standard bb-84 quantum key distribution protocol.
the service we can connect to is a man-in-the-middle infrastructure placed between alice and bob.

we know that alice will sent bob 600 qbits with 2 possible bases each, then alice will confirm which bases bob guessed right (statistically about half), then bob will send to alice half of the correct values he got, to make sure no-one modified the data on the way.
finally from the remaining correct bit values bob and alice will take 128 and create aes-ecb-128 key and exchange encrypoted messages.

what we will do here is basically spoofing the entire communication, so that alice and bob in reality agree on the key with us, and not with the expected recipient.

this is trivial to do, since we can simply follow the protocol with both of them independently.
it will, however, not give us the whole flag!
this is because in the end there is the verification phase when parties exchange half of the correct values, and if we agreed on different number with alice and with bob then sadly we will have at some point to send wrong message to one of them (since we have to send one message to alice and one message to bob each time), which will trigger closing the channel.

so what we really want to do is to make sure we agree on the same number of correct values with both parties, using some heurustic and a bit of luck.

the whole idea is:

1. we collect values sent by alice, for simplicity we always try base z.
2. we send to bob only values 1 all encoded in base z, for simplicity :)
3. during the verification phase we verify how many bits we got right from alice, by sending her always base z and checking if she responded with -1 or 1
4. during verification phase we verify how many bits bob got right, by checking if he tried base z (we always encoded our 1 in z when sending to him)
5. we introduce small heuristic to lie to bob if he is getting too many good guesses, to lower his score. we could also lie the other way, as long as we make sure we're doing this on even bits, since only odd bits will be used as aes key, but this was not necessary.
6. now we have set of qbit values agreed with alice and we confirmed bob with all the 1s he got right. hopefully at this point the both counters are equal. it requires a bit of luck so we simply run this multiple times.
7. next phase is trivial, we simply send to alice half of the qbits we got right and we send ack to bob every time.
8. now we agreed to have aes key with bob which contains only 1s and we agreed with alice on the key from the leftover qbits.
9. if the counters were equal both parties will now transmit their part of the flag. if the counters are not equal we will get only half of the flag and we will have to run again to get the other half!
10. we simply decode the results!

```python
import re
from crypto_commons.netcat.netcat_commons import nc, receive_until, send, receive_until_match, interactive


def select_agreed_values(qbits_from_alice, correct_base_guesses_from_alice):
    return [qbits_from_alice[i] for i in range(600) if correct_base_guesses_from_alice[i] == 1]


def main():
    url = 'bb8.chal.pwning.xxx'
    port = 20811
    s = nc(url, port)
    print(receive_until(s, "..."))
    qbits_from_alice = []
    print('spoofing initial communication')
    for i in range(1199):  # 600 qbits from alice to bob and 599 ack from bob to alice
        c = receive_until(s, "?")
        print(i, c)
        if "bob" in c:
            send(s, "y")  # intercept qbit to bob
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            send(s, "1")  # always send value 1
            data = receive_until_match(s, "value 1", 10.0)
            qbits_from_alice.append(int(re.findall("measured (-?\d+)", data)[0]))
        else:
            send(s, "n")  # don't touch acks
    print("alice qbits we got", qbits_from_alice)
    bases_from_bob = []
    correct_base_guesses_from_alice = []
    bob_correct = 0
    alice_correct = 0
    for i in range(1200):  # 600 qbit base guesses from bob to alice and 600 answers from alice to bob
        c = receive_until(s, "?")
        print(i, c)
        if "alice" in c:  # intercept qbit base guess to alice
            send(s, "y")
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            send(s, "-1")  # value -1 indicating z base, we guess only z base
            data = receive_until_match(s, "value -1", 10.0)
            bases_from_bob.append(int(re.findall("measured (-?\d+)", data)[0]))
        else:  # intercept alice answer
            send(s, "y")
            send(s, "z")  # measure in z
            data = receive_until_match(s, "measured (-?\d+)", 10.0)
            alice_answer = int(re.findall("measured (-?\d+)", data)[0])
            correct_base_guesses_from_alice.append(alice_answer)
            if alice_answer == 1:
                alice_correct += 1
            send(s, "y")  # replace
            send(s, "z")  # z axis
            if bases_from_bob[-1] == -1:  # bob guessed z axis
                if i > 1150 and alice_correct > bob_correct:  # slow down bob to get similar result len
                    send(s, "-1")
                else:
                    bob_correct += 1
                    send(s, "1")
            else:
                send(s, "-1")  # bob tried y axis
            data = receive_until_match(s, "value -?\d+", 10.0)
    print("bases from bob", bases_from_bob)
    print("correct base guesses from alice", correct_base_guesses_from_alice)
    agreed_qbit_values = select_agreed_values(qbits_from_alice, correct_base_guesses_from_alice)
    print("agreed qbit values", len(agreed_qbit_values),
          agreed_qbit_values)  # qbit values where we correctly guessed the base
    print("bob was correct", bob_correct)
    print("we were correct with alice", alice_correct)

    alice_key = [agreed_qbit_values[i * 2 + 1] for i in range(128)]
    bob_key = [1 for _i in range(128)]  # we sent only 1 to bob, so all he got right must be 1s
    print('alice key', alice_key)
    print('bob key', bob_key)

    for i in range(max(bob_correct, alice_correct)):
        c = receive_until(s, "?")
        print(i, c)
        if "aborted" in c:
            interactive(s)
        elif "alice" in c:
            send(s, "y")  # intercept bob verification qbit
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            new_value = str(agreed_qbit_values[i])
            send(s, new_value)  # replace with value we got correct from alice
            data = receive_until_match(s, "value " + new_value, 10.0)
        else:
            send(s, "n")  # pass ack along
    c = receive_until(s, "?")
    print(c)
    interactive(s)


main()
```

this code gets us aes messages from both sides which we decode:

```python
def decode_flag():
    ct = '80dc59ce81e30bcd02198059b556731597ce5cf597481229ac9b2d523516c83e0f65896ce3b51cc2eb5b120adca55ed8'.decode(
        "hex")
    cipher = aes.new("\xff" * 16, aes.mode_ecb)
    pt1 = cipher.decrypt(ct)
    ct2 = "34c7bb71814ff4f06e0d586e6f419364faf33270afed759e2593b36ac5b430f1".decode("hex")
    agreed_qbits = [1, -1, 1, 1, -1, -1, -1, 1, 1, -1, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, -1, 1, 1,
                    -1, -1, -1, -1, 1, 1, -1, 1, -1, -1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, -1, -1,
                    -1, 1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1,
                    -1, 1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1,
                    -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, -1,
                    -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, 1, 1,
                    1, 1, 1, -1, 1, 1, -1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, 1,
                    -1, 1, 1, 1, 1, -1, -1, -1, 1, -1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, -1,
                    1, 1, -1, -1, 1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, 1,
                    1, -1, -1, 1, 1, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1,
                    -1, 1, 1, 1, -1, -1, -1, 1, -1, -1, -1, -1, 1]
    key_qbits = [agreed_qbits[i * 2 + 1] for i in range(128)]
    key_bitstring = "".join(['1' if c == 1 else '0' for c in key_qbits])
    print(key_bitstring)
    key = int(key_bitstring, 2)
    k = long_to_bytes(key)
    cipher = aes.new(k, aes.mode_ecb)
    pt2 = cipher.decrypt(ct2)
    print(pt2.strip()+pt1.strip())
```

and we have a flag: `pctf{perhaps_secrecy_aint_the_same_thing_as_authentication}`

## pl version

w zadaniu dostajemy [kod](server.py) serwisu do którego możemy się połączyć.
dostajemy też długi [opis](readme.txt) protokołu z którym pracujemy.

to jest standardowy protokół bb-84 kwantowej wymiany klucza.
serwis z którym się komunikujemy pozwala na atak man-in-the-middle pomiędzy alice i bobem.

wiemy że alice wyśle do boba 600 qbitów, każdy w jednej z 2 baz, następnie alice potwierdzi bobowi które bazy zgadł poprawnie (statystycznie połowę), następnie bob wyśle do alice połowę poprawnych wartości które uzyskał, żeby upewnić się że nikt nie zmienił danych po drodze.
na koniec z pozostałych poprawnych wartości bob i alice wezmą 128 bitów i utworzą z nich wspólny klucz aes-ecb-128 którym zaszyfrują swoje wiadomości.

my zamierzamy spoofować całą komunikacje, tak że w rzeczywistości alice i bob zgodzą się na klucze z nami a nie ze sobą nawzajem.

to generalnie jest trywialne, bo możemy po prostu postępować zgodnie z protokołem dla każdego z nich z osobna.
to niestety nie da nam całej flagi!
jest tak, ponieważ na końcu jest faza weryfikacji kiedy bob wysyła połowę poprawnych wartości do alice i jeśli uzgodnimy  znimi różną liczbę poprawnych wartości to w pewnej chwili będziemy musieli do jednej ze stron wysłać nieoczekiwaną wartość (ponieważ możemy wysyłać jedynie qbity raz do alice i raz do boba), a to spowoduje zerwanie połączenia przez jedną ze stron.

chcemy więc mieć pewność że uzgodnimy taką samą liczbę poprawnych wartości z obiema stronami, stosując trochę heurystyk i szczęścia.

idea jest taka:

1. pobieramy wartości od alice, dla ułatwienia zawsze próbujemy bazę z.
2. wysyłamy do boba same 1 w bazie z, dla ułatwienia :)
3. podczas weryfikacji uzgadniamy ile bitów od alice wyznaczyliśmy poprawnie, wysyłając jej zawsze bazę z i sprawdzając czy odpowiedziała -1 czy 1
4. podczas weryfikacji sprawdzamy ile bitów bob dobrze odkodował, testujac czy użył bazy z (zawsze wysyłaliśmy mu 1 w bazie z).
5. wprowadzamy heurystykę, żeby kłamać bobowi jeśli idzie mu za dobrze, żeby obniżyć jego wynik. możemy kłamać też w drugą stronę, ale musimy uważać żeby robić to tylko dla parzystych bitów, bo te nie trafią potem do klucza aes, ale nie było to finalnie konieczne.
6. teraz mamy listę qbitów od alice które odczytaliśmy dobrze i wiemy też ile 1 bob odczytał dobrze. miejmy nadzieje że obie wartości są sobie równe. wymaga to trochę szczęścia więc uruchomiliśmy solver kilka razy dla pewności.
7. następna faza jest trywialna, po prostu wysyłamy do alice połowę qbitów które dobrze od niej odczytaliśmy a do boba wysyłamy ack za każdym razem.
8. teraz uzgodniliśmy z bobe klucz złożony z samych 1 a z alice ten z pozostałych bitów.
9. jeśli liczniki były równe to teraz bob i alice wymienią się wiadomościami szyfrowanymi aesem. jeśli liczniki nie były równe to dostaniemy tylko połowę flagi, bo jedna ze stron zerwie połączenie i będziemy musieli uruchomić to jeszcze raz.
10. na koniec deszyfrujemy aesa!.

```python
import re
from crypto_commons.netcat.netcat_commons import nc, receive_until, send, receive_until_match, interactive


def select_agreed_values(qbits_from_alice, correct_base_guesses_from_alice):
    return [qbits_from_alice[i] for i in range(600) if correct_base_guesses_from_alice[i] == 1]


def main():
    url = 'bb8.chal.pwning.xxx'
    port = 20811
    s = nc(url, port)
    print(receive_until(s, "..."))
    qbits_from_alice = []
    print('spoofing initial communication')
    for i in range(1199):  # 600 qbits from alice to bob and 599 ack from bob to alice
        c = receive_until(s, "?")
        print(i, c)
        if "bob" in c:
            send(s, "y")  # intercept qbit to bob
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            send(s, "1")  # always send value 1
            data = receive_until_match(s, "value 1", 10.0)
            qbits_from_alice.append(int(re.findall("measured (-?\d+)", data)[0]))
        else:
            send(s, "n")  # don't touch acks
    print("alice qbits we got", qbits_from_alice)
    bases_from_bob = []
    correct_base_guesses_from_alice = []
    bob_correct = 0
    alice_correct = 0
    for i in range(1200):  # 600 qbit base guesses from bob to alice and 600 answers from alice to bob
        c = receive_until(s, "?")
        print(i, c)
        if "alice" in c:  # intercept qbit base guess to alice
            send(s, "y")
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            send(s, "-1")  # value -1 indicating z base, we guess only z base
            data = receive_until_match(s, "value -1", 10.0)
            bases_from_bob.append(int(re.findall("measured (-?\d+)", data)[0]))
        else:  # intercept alice answer
            send(s, "y")
            send(s, "z")  # measure in z
            data = receive_until_match(s, "measured (-?\d+)", 10.0)
            alice_answer = int(re.findall("measured (-?\d+)", data)[0])
            correct_base_guesses_from_alice.append(alice_answer)
            if alice_answer == 1:
                alice_correct += 1
            send(s, "y")  # replace
            send(s, "z")  # z axis
            if bases_from_bob[-1] == -1:  # bob guessed z axis
                if i > 1150 and alice_correct > bob_correct:  # slow down bob to get similar result len
                    send(s, "-1")
                else:
                    bob_correct += 1
                    send(s, "1")
            else:
                send(s, "-1")  # bob tried y axis
            data = receive_until_match(s, "value -?\d+", 10.0)
    print("bases from bob", bases_from_bob)
    print("correct base guesses from alice", correct_base_guesses_from_alice)
    agreed_qbit_values = select_agreed_values(qbits_from_alice, correct_base_guesses_from_alice)
    print("agreed qbit values", len(agreed_qbit_values),
          agreed_qbit_values)  # qbit values where we correctly guessed the base
    print("bob was correct", bob_correct)
    print("we were correct with alice", alice_correct)

    alice_key = [agreed_qbit_values[i * 2 + 1] for i in range(128)]
    bob_key = [1 for _i in range(128)]  # we sent only 1 to bob, so all he got right must be 1s
    print('alice key', alice_key)
    print('bob key', bob_key)

    for i in range(max(bob_correct, alice_correct)):
        c = receive_until(s, "?")
        print(i, c)
        if "aborted" in c:
            interactive(s)
        elif "alice" in c:
            send(s, "y")  # intercept bob verification qbit
            send(s, "z")  # measure in z
            send(s, "y")  # replace
            send(s, "z")  # z axis
            new_value = str(agreed_qbit_values[i])
            send(s, new_value)  # replace with value we got correct from alice
            data = receive_until_match(s, "value " + new_value, 10.0)
        else:
            send(s, "n")  # pass ack along
    c = receive_until(s, "?")
    print(c)
    interactive(s)


main()
```

to daje nam wiadomości szyfrowanego aesem oraz klucze:

```python
def decode_flag():
    ct = '80dc59ce81e30bcd02198059b556731597ce5cf597481229ac9b2d523516c83e0f65896ce3b51cc2eb5b120adca55ed8'.decode(
        "hex")
    cipher = aes.new("\xff" * 16, aes.mode_ecb)
    pt1 = cipher.decrypt(ct)
    ct2 = "34c7bb71814ff4f06e0d586e6f419364faf33270afed759e2593b36ac5b430f1".decode("hex")
    agreed_qbits = [1, -1, 1, 1, -1, -1, -1, 1, 1, -1, 1, 1, 1, 1, 1, -1, -1, -1, 1, 1, -1, 1, -1, 1, -1, -1, -1, 1, 1,
                    -1, -1, -1, -1, 1, 1, -1, 1, -1, -1, -1, 1, -1, -1, 1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, -1, -1,
                    -1, 1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, 1, -1, 1, 1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, 1,
                    -1, 1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, -1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1,
                    -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, 1, -1, 1, 1, -1, -1, -1, 1, 1, 1, 1, -1, 1, -1, 1, -1, -1, -1,
                    -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, 1, -1, 1, 1,
                    1, 1, 1, -1, 1, 1, -1, 1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, -1, 1, -1, 1, -1, 1, -1, 1, -1, 1, 1,
                    -1, 1, 1, 1, 1, -1, -1, -1, 1, -1, -1, -1, 1, -1, 1, -1, 1, -1, -1, 1, -1, -1, -1, -1, 1, 1, 1, -1,
                    1, 1, -1, -1, 1, -1, 1, 1, -1, -1, -1, 1, -1, 1, 1, 1, -1, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, 1,
                    1, -1, -1, 1, 1, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 1, 1, -1, -1, 1, 1, 1, 1, -1,
                    -1, 1, 1, 1, -1, -1, -1, 1, -1, -1, -1, -1, 1]
    key_qbits = [agreed_qbits[i * 2 + 1] for i in range(128)]
    key_bitstring = "".join(['1' if c == 1 else '0' for c in key_qbits])
    print(key_bitstring)
    key = int(key_bitstring, 2)
    k = long_to_bytes(key)
    cipher = aes.new(k, aes.mode_ecb)
    pt2 = cipher.decrypt(ct2)
    print(pt2.strip()+pt1.strip())
```

i dostajemy flagę: `pctf{perhaps_secrecy_aint_the_same_thing_as_authentication}`
