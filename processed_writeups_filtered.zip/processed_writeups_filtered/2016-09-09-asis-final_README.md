# writeup asis ctf finals 2016

team: akrasuski, c7f.m0d3, cr019283, ppr, nazywam, rev, msm, shalom



[image extracted text: onlyg
380
dsa
333
dam
srpp
231
races
psa
113
the imitation game
crypto
crypto
ppc
crypto
crypto
crypto
crypto
crypto
warm-up
semanager
heapstar
alegria
car market
diapers simulator
shadow
secuprim !
pwn
pwn
pwn
pwn
pwn
pwn
warm-up
ppc
warm-up
typo
one bad son
ping
121
raw veganism
sky blue
oracle
my cat
forensic
misc
forensic
forensic
forensic
warm-up
forensic
reverse
reverse
trinity
internet of what?
pretty shallow
licensable
php-asm
366
master page  315
pentest
reverse
reverse
reverse
reverse
warm-up
reverse
web
crypto
reverse
crypto
web
web
smallest mds
ctf 101 3,
trivia
trivia
warm-up]



[image extracted text: team name
country
score
dcua
4508
tokyowesterns
4070
tasteless
3565
dragon_
sector
3447
p4team
3300
odaysober
3269
217
2757
int3pids
2739
lcbc
2562
scryptos
2402
{simulat
shallow
mds
bad s0n
: page]


### table of contents

* [secu prim (ppc)](secu_prim)
* [rsa (crypto)](rsa)
* [dam (crypto)](dam)
* [races (crypto)](races)
* [srpp (crypto)](srpp)
* [p1ng (forensics)](p1ng)
* [dsa (crypto)](dsa)
* [one bad son (forensics)](one_bad_son)
* [master page(rev/web/crypto)](master_page)
