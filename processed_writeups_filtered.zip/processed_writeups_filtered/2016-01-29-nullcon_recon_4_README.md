﻿##nullcon youtube (recon, 400p)

	one of the nullcon vidoes talked about a marvalous russian gift. the vidoe was uploaded on [may of 2015] what is the id of that youtube video.

###pl
[eng](#eng-version)

wchodzimy na youtube, wyszukujemy filmy z maja i testujemy id po kolei.
w końcu okazuje się, że poprawny film to:
https://www.youtube.com/watch?v=a4_pvn_a1ts
a flaga to `a4_pvn_a1ts`


###eng version

we go to youtube, look for all videos from may and test all ids.
finally the right video is:
https://www.youtube.com/watch?v=a4_pvn_a1ts
and flag is `a4_pvn_a1ts`