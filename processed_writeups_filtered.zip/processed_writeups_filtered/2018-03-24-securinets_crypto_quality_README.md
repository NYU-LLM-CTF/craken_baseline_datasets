# improve the quality (crypto)

in the task we get a [lengthly description](description.txt).
short version is:

1. we have ecc encryption.
2. the curve is `y^2 = x^3 + 658974*x + b` with most significat decimal digit of `b` being `6`
3. prime field is based on `p = 962280654317`
4. we get generator point `p = (518459267012, 339109212996)`
5. we get a set of points `qi` where `qi = ki * p`
6. the final secret value is a combination of `ki` values (this was very unclear, but in the end it was just concatenation of `ki` values treated as decimal strings and this converted to bytes).

we start-off by recovering the missing `b` parameter of the curve.
this is trivial, since we've got points on the curve and we can just solve the equation `y^2 = x^3 + 658974*x + b`.
we transform this to:

`b = (y^2 - x^3 - 658974*x) mod p`

and apply this to `p = (518459267012, 339109212996)` which gives us `618`, and it fits the hint from the description that `6` is the most significant digit of `b`.

```python
prime = 962280654317
x = 518459267012
y = 339109212996
a = 658974
b = (y^2 - x^3 - a*x) %prime
```

now we need to recover the `ki` values.
the prime field is very small, so we can efficiently calculate so-called `discrete logarithm` over the elliptic curve.
fortunately `sage` has all of this already implemented so we just need to do:

```python
k.<z> = gf(prime)
e = ellipticcurve(k,[a,b])
p = e([x,y]) # generator point

solutions = []
for px,py in data:
    q = e([px,py])
    solution = p.discrete_log(q)
    print(px,py, solution)
    solutions.append(solution)
print(solutions)
```

and from this we recover the `ki` values.
we combine them to get the secret `k`:

```python
large_string = "".join([str(ki) for ki in solutions])
print("".join(map(lambda x: chr(int(x)), chunk(large_string, 2))))
```

this gives:

```
convert this to lower case first :
this image contains the flag, try to get it
the submitted flag must be in this format: 
flag-ec[what you'll find in the image]
image url:
http://crypto.ctfsecurinets.com/1/steg-part.png
```

fortunately there is not much of a stegano there really.
the picture is:


[image extracted text: neng]


and can be easily read to get the final flag: `flag-ec[ec_st!e-g1(a)no]`
