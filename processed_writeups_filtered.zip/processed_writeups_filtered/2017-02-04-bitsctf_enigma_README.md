# enigma (crypto)

```
its world war ii and germans have been using enigma to encrypt their messages. our analysts have figured that they might be using xor-encryption. xor-encrption is vulnerable to a known-plaintext attack. sadly all we have got are the encrypted intercepted messages. your task is to break the enigma and get the flag.
```

###eng
[pl](#pl-version)

in the task we get a set of [ciphertexts](encrypted.tar.xz) to work with.
initially we thought this is another one of repeating-key-xor and we were using our semi-interactive breaker for it, but it seemed to not work at all - we could not find any words.
then we decided to look at the data we got, and we saw for example:

```
dtorouenc&vguugaoct+mihpio&dcuenksr|r&dco&06&atgb&hitbch&shb&73&atgb&qcurch(&hcnkch&uoc&cu&ui`itr
```

```
60<56*&bgu&qcrrct&our&ncsrc&mjgt(&tcach&gk&gdchb
```

what sticks of instantly is how many `&` are there.
it can't be a coincidence so we figured that those have to be spaces and therefore the xor key has to be 1 or 2 characters at most.
we checked and it turned out that it was a single `\6`.

we run:

```python
import codecs
from crypto_commons.generic import chunk_with_remainder, xor_string


def main():
    cts = []
    for i in range(1, 7):
        with codecs.open("encrypted/" + str(i) + "e", "r") as input_file:
            data = input_file.read()
            cts.append(data)
    xored = [xor_string(chr(ord('&') ^ ord(' ')) * len(data), d) for d in cts]
    print(xored)


main()
```

and we get `bitctf{focke-wulf fw 200}` in one of the messages.

###pl version

w zadaniu dostajemy zestaw [szyfrogramów](encrypted.tar.xz).
początkowo myśleliśmy, że to kolejna wersja łamania powtarzącego się klucza xor i chcieliśmy użyć naszego semi-interaktywnego łamacza, ale nic ciekawego z tego nie wychodziło - nie mogliśmy znaleźć żadnych sensownych słów.
postanowiliśmy więc popatrzeć na dane które mamy w plikach:

```
dtorouenc&vguugaoct+mihpio&dcuenksr|r&dco&06&atgb&hitbch&shb&73&atgb&qcurch(&hcnkch&uoc&cu&ui`itr
```

```
60<56*&bgu&qcrrct&our&ncsrc&mjgt(&tcach&gk&gdchb
```

co rzuca się od razu w oczy to liczba znaków `&`.
to nie może być przypadek więc założyliśmy, że to mogą być spacje a tym samym klucz xora może mieć co najwyżej 1 lub 2 znaki.
sprawdziliśmy i okazało sie że kluczem był znak `\6`.

uruchamiamy:

```python
import codecs
from crypto_commons.generic import chunk_with_remainder, xor_string


def main():
    cts = []
    for i in range(1, 7):
        with codecs.open("encrypted/" + str(i) + "e", "r") as input_file:
            data = input_file.read()
            cts.append(data)
    xored = [xor_string(chr(ord('&') ^ ord(' ')) * len(data), d) for d in cts]
    print(xored)


main()
```

i dostajemy `bitctf{focke-wulf fw 200}` w jednej z wiadomości.
