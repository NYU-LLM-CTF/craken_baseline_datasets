# white box unboxing 

> here is a binary implementing a cryptographic algorithm. you provide an input and it 
> produces the corresponding output. can you extract the key?

we were given binary implementing, as it turns out, whitebox implementation of aes. for a while i tried
standard methods of breaking it, but in the end used `deadpool` library implementing various dfa attacks.
i have no idea how they work, but they solved the puzzle. scripts attached.

-- akrasuski1
