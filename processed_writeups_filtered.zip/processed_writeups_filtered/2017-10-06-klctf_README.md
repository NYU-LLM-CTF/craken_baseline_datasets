# kasperskylab industrial ctf quals 2017

team: c7f.m0d3, akrasuski1, nazywam, shalom, rev

### table of contents

* [bad computations (crypto)](bad_computations)
* [security home cameras (crypto)](cameras)
* [decrypt the message (crypto)](decrypt_message)
* [smart heater 1 (re/web)](heater_1)