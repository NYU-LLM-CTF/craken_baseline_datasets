## brute with force (ppc, 80p)

	description: people say, you're good at brute forcing... have fun! 
	hint: you don't need to crack the 31. character (newline). 
	try to think of different (common) time representations. 
	hint2: time is cet 
	
###eng
[pl](#pl-version)

server sends input as:

	hint: format is time:char
	char 0: time is 22:02:54, 052th day of 2016 +- 30 seconds and the hash is: ae3c4c0487d14dd3314facdc2d4408a845da947f
	
and our task is to find the right timestamp and the right character which will hash to given value. 
each character we find is part of the flag.
we had some problems with getting the right epoch value (timezones etc) so we hardcoded the current epoch and were looking from that point.
the hash has 160 bits so we assume it's sha-1.
the solution is quite simple: we loop over possible timestamps and printable characters and we test if hashing them together will give the hash value we look for. once we find the proper hash we send the response to the server and collect another hash for another character of the flag.

```python
import hashlib
import re
import socket
import string


def brute_result(hashval):
    timestamp = 1455987261
    i = 0
    while true:
        for c in string.printable:
            brute = str(timestamp + i) + ":" + c
            h = hashlib.sha1(brute).digest().encode("hex")
            if hashval == h:
                return str(timestamp + i)+":"+c
        i += 1
    print ":("


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11117))
    regex = "char \d+: time is (\d+):(\d+):(\d+), .* hash is: (.+)"
    chars = []
    initial_data = str(s.recv(4096))
    print(initial_data)
    try:
        while true:
            task = str(s.recv(4096))
            print(task)
            m = re.match(regex, task)
            hour = m.group(1)
            minute = m.group(2)
            sec = m.group(3)
            hashval = m.group(4)
            print(hour, minute, sec, hashval)
            result = brute_result(hashval)
            print(result)
            s.sendall(result + "\n")
            chars.append(result.split(":")[1])
            s.recv(4096)
    except:
        print "".join(chars)


main()
```

after some time we get: `iw{m4n_y0u_c4n_b3_bf_m4t3rial!}`

###pl version

serwer przysyła dane w postaci:

	hint: format is time:char
	char 0: time is 22:02:54, 052th day of 2016 +- 30 seconds and the hash is: ae3c4c0487d14dd3314facdc2d4408a845da947f
	
a naszym zadaniem jest znaleźć właściwy timestamp oraz właściwy znak które razem hashują się do podanej wartości.
każdy znaleziony znak to fragment flagi.
mieliśmy pewne problemy z ustaleniem poprawnej wartości epoch (strefy czasowe etc) więc finalnie hardkodowaliśmy aktualną wartość epoch i szukaliśmy od tego punktu.
hash ma 160 bitów więc założyliśmy że to sha-1.
rozwiązanie jest dość proste: pętlimy po wszystkich możliwych timestampach oraz znkach i sprawdzamy czy hashując je razem dostaniemy podany w zadaniu hash. kiedy znajdziemy odpowiednie wartości wysyłamy odpowiedź do serwera i pobieramy kolejny hash dla kolejnego znaku flagi.

```python
import hashlib
import re
import socket
import string


def brute_result(hashval):
    timestamp = 1455987261
    i = 0
    while true:
        for c in string.printable:
            brute = str(timestamp + i) + ":" + c
            h = hashlib.sha1(brute).digest().encode("hex")
            if hashval == h:
                return str(timestamp + i)+":"+c
        i += 1
    print ":("


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11117))
    regex = "char \d+: time is (\d+):(\d+):(\d+), .* hash is: (.+)"
    chars = []
    initial_data = str(s.recv(4096))
    print(initial_data)
    try:
        while true:
            task = str(s.recv(4096))
            print(task)
            m = re.match(regex, task)
            hour = m.group(1)
            minute = m.group(2)
            sec = m.group(3)
            hashval = m.group(4)
            print(hour, minute, sec, hashval)
            result = brute_result(hashval)
            print(result)
            s.sendall(result + "\n")
            chars.append(result.split(":")[1])
            s.recv(4096)
    except:
        print "".join(chars)


main()
```

po kilkunastu zadaniach dostajemy: `iw{m4n_y0u_c4n_b3_bf_m4t3rial!}`