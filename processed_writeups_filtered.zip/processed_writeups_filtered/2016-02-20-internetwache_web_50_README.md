## mess of hash (web, 50p)

	students have developed a new admin login technique. i doubt that it's secure, but the 
	hash isn't crackable. i don't know where the problem is...
	
###eng
[pl](#pl-version)

in this task, we got a hash of password and are asked to log into the account. the hash was as
follows: 0e408306536730731920197920342119. we can notice it is pretty strange: only one 'e' letter,
and the rest of characters are digits. we can guess that the hash is incorrectly compared to
the stored one, and it gets interpreted as number 0. we could generate another password with
such property in a reasonable amount of time using attached script.

###pl version

w tym zadaniu dostaliśmy hash hasła: 0e408306536730731920197920342119. wygląda on dość nietypowo,
gdyż ma tylko jedną literę 'e', a reszta znaków to cyfry. jeśli zinterpretować go jako liczbę
z wykładnikiem, dostaniemy 0. korzystając z załączonego skryptu, generujemy dowolne hasło z 
hashem o takiej własności w sensownym czasie.
