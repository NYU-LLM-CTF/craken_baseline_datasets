# full compromise, re, 250pts

> an attacker managed to hack our ci server and sign+encrypt his malicious code in a ecu firmware, that is now running in millions of cars and doing chaos knows what. to stop the attackers, we must know what the malicious code is doing. we have a history of all binaries signed by the server on the day of the hack, and a device running the attacker's firmware. help us find which sample was provided by the attacker and get access to its management interface.


in this task, we got 1000 samples of unencrypted binaries, and one
encrypted to be flashed on the chip. we did not know which one of
these 1000 is the correct one. after reversing their code, we noticed
that the password check takes very long time (hours), so we cannot
just brute force our way and check all 1000 passwords.

instead, we noticed there's a debug mode in the program, which
outputs some analog data to chip's dac. each of the 1000 samples 
has somewhat different pattern.

we dumped the pattern from our chip using logic analyzer, and
simulated each of the 1000 known ones using `simavr`. one of them
matched ours. typing its password to the chip's uart, we got the flag.