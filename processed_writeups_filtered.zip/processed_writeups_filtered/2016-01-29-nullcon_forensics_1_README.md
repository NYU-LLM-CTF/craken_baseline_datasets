﻿##catchmeifyoucan (forensics, 100p)

	we got this log which is highly compressed. find the intruder's secret.

###pl
[eng](#eng-version)

plik f100 jest pewnego rodzaju matryoshką kompresyjną, plik trzeba kolejno rozkompresowywać różnymi mniej i bardziej znanymi formatami. po chwili okazuje się, że plik jest dosyć "głęboki" i trzeba będzie zautomatyzować rozpakowywanie kolejnych warstw. 

[program](decode.py) jest dosyć prosty w działaniu, sprawdzamy format pliku za pomocą komendy `file`, a następnie rozpakowywujemy go odpowiednim programem. 

ostatnim folderem jest f100.rar z którego dostajemy 2 foldery "log" i "dl" pełne różnych logów i list linków. jak już dostatecznie dużo czasu zmarnujemy na przeszukiwanie śmieci to natrafiamy na ciekawy link: https://gist.github.com/anonymous/ac2ce167c3d2c1170efe z tajemniczym stringiem: 

`$=~[];$={___:++$,$$$$:(
[image extracted text: [image processing failed]]


...który okazuje się javascriptowym skryptem printującym flagę: 

`-s-e-c-r-e-t-f-l-a-g-{d-i-d-y-o-u-r-e-a-l-l-y-f-i-n-d-m-e-}`

###eng version

file f100 is sort of a matryoshka-compression-doll, we have to decompress each file to get to another one. after a while of tinkering with it manually, it appears that the file is quite deep and we're going to need to automatize the process.

[program](decode.py) is pretty straight forward, we check the file's format using `file` and then decompress it using appropriate algorithm/program.

the last folder we get is f100.rar which contains 2 folders "log" and "dl" full of different logs and links. after a *while* of searching, we stubmle into an interesting link: https://gist.github.com/anonymous/ac2ce167c3d2c1170efe with a mysterious string:

`$=~[];$={___:++$,$$$$:(
[image extracted text: [image processing failed]]


...which appears to be a javascript program that prints the flag:

`-s-e-c-r-e-t-f-l-a-g-{d-i-d-y-o-u-r-e-a-l-l-y-f-i-n-d-m-e-}`
