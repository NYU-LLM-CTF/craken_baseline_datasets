## catch me if you can (forensics, 100points)
	tl;dr concact even and odd data packets and read the flag from the table

download [usb.pcap](usb.pcap), load it into wireshark. there is some data being sent(i don't know what is actually going on, you can tell me, i'd love to find out :).

`leftover captue data` hold the raw data we want, filter the packets and the export them in order.

there are 22 files, `file` and `du` commands are extremly helpful here:


[image extracted text: test
opendocument
spreadsheet
test
test1
opendocument
spreadsheet
2
test1
test10
data
test
test11
data
2
test
test12
data
test
test13
data
test13
test14
data
test14
test15:
data
2
test
test16
data
test
test17
data
test1
test18=
data
test
test19
data
2
test
test2
data
test
testzo
data
testzo
test2l
data
test21
test3
data
test3
test4
data
2
test4
test5
data
test5
test6
data
test6
test7
data
2
test
test8
data
test8
test9
data
test9]


2 beginnings and 2 cut-offs, so we are now 99% sure that there are only 2 files being sent and maybe they are in order?

after noticing some intersecting texts and images that connect for example, `1-3-5` we try concacting odd files and even files together.

we're left with [even.ods](even.ods) and [odd.ods](odd.ods)

odd.ods has an interesting table in it:

[image extracted text: 1
2]



it looks like a lookup table, so now we have to find the second half of the message.

after unpacking odd.ods we spot an interesting hex string in `content.xml`: `g6d5g5f2b6g5d3e4d4b3c5b6k2j5j5g4l2`

if we now use it with the lookup table we get: `ndh[wh3re1sw@lly]`

bingo!

 * fun fact, the hex string is actually in the spreadsheet in the bottom right corner ;)

