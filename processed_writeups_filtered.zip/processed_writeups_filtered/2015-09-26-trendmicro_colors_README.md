## colors (ppc/programming, 100p)

### pl version
`for eng version scroll down`

system wyświetlał na stronie internetowej obrazek złożony z kwadratów. wsystkie kwadraty oprócz jednego miały taki sam kolor - jeden z nich miał lekko inny odcień. celem zadania było kliknięcie w ten odmienny kwadrat. system rejestrował gdzie kliknęliśmy i na tej podstawie oceniał poprawność rozwiązania i prezentował kolejny przykład.
celem było rozwiązanie kilkudziesieciu przykładów pod rząd w celu uzyskania flagi.


[image extracted text: ]


aby rozwiązać zadany problem przygotowaliśmy skrypt w pythonie z użyciem python images library dostępny [tutaj](colors.py).
skrypt pobiera zadany obraz, wylicza rozkład kolorów pikseli i na tej podstawie wybiera najrzadziej występujący kolor (pomiajając biały, który oddziela kwadarty od siebie). następnie skanujemy obraz w poszukiwaniu jakiegoś piksela tego koloru i zwracamy pozycję tego piksela jako rozwiązanie.

	def getpixel(picture_path):
		fd = urllib.urlopen(picture_path)
		image_file = io.bytesio(fd.read())
		im = image.open(image_file)
		colors_distribution = im.getcolors()
		non_white = [color for color in colors_distribution if color[1] != (255, 255, 255)]
		ordered = sorted(non_white, key=lambda x: x[0], reverse=false)
		print(ordered[0])
		width, height = im.size
		for index, color in enumerate(im.getdata()):
			if color == ordered[0][1]:
				y = index / width
				x = index % width
				return x, y

po rozwiązaniu kilkudziesięciu przykładów otrzymujemy: `tmctf{u must have r0807 3y3s!}`

### eng version

the system displays on a webpage an image consisting of squares. all but one have the same color - one has a slighly different shade. the task was to click in on the square with different color. the system would register the click location and decide if our solution is correct. we had to solve multiple consecutive examples in order to get the flag.


[image extracted text: ]


to solve the task we prepared a python script using python images library available [here](colors.py).
the script downloads the picture, calculates the colors disitrbution and base don this selects the least frequent color (omitting white, which separates the squares). next we can the picture looking for a pixel with this color and we return this pixel position as the solution.

	def getpixel(picture_path):
		fd = urllib.urlopen(picture_path)
		image_file = io.bytesio(fd.read())
		im = image.open(image_file)
		colors_distribution = im.getcolors()
		non_white = [color for color in colors_distribution if color[1] != (255, 255, 255)]
		ordered = sorted(non_white, key=lambda x: x[0], reverse=false)
		print(ordered[0])
		width, height = im.size
		for index, color in enumerate(im.getdata()):
			if color == ordered[0][1]:
				y = index / width
				x = index % width
				return x, y

after few dozens of examples we finally get: `tmctf{u must have r0807 3y3s!}`