# pound (pwnable, 290pts, 20 solves)

in this task, we were given service running `host.py`. it had two functions:
- printing some tweets stored as files
- compiling a binary using user supplied two macros.

we quickly noticed that we could exploit the first function: giving it
`../pound.c` gave us source of compiled binary. in general, we were able
to read any file in the system (readable by our user).

looking at `pound.c`, we do not see any obvious vulnerabilities. however, since
we control two macros, we were able to create a buffer overflow in this structure:
```
const int n=1024;

const int l1_len = l1;
const int l2_len = l2;

#define state_size_len 512

struct global_s {
    int s1_citizens[l1_len];
    int s2_citizens[l2_len];
    char s1_name[state_size_len]; // name of state 1
    char s2_name[state_size_len]; // name of state 2
    char *announcement;
    int announcement_length;
    int secret;
} global;
```
we were able to define l1 and l2 as any strings, up to 3 characters long. this turned up
to be quite problematic when generating a vulnerable binary. however, with l1 defined as
`n^9` and l2 as `n*n`, the following line had an error:
```
    int length_diff = l2 - l1;
```
this was supposed to calculate difference beween these two constants, but with c operator
precedence, `n*n - n^9` actually meant `(n*n - n)^9`, which gave us an overflow allowing us
to control the `announcement` field in the global structure.

i created a script (`get_binary.py`) downloading their compiled version of the binary 
(`their_binary`), in case their compilation process differs from the one on our machine.

at this point, i gave the task to another team member, so no final exploit is given here. 
as far as i know, he was able to overwrite that `announcement` field and then use program
code to overwrite got entry and eventually exploit the binary to the end.
