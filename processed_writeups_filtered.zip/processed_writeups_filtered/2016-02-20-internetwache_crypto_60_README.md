## oh bob! (crypto, 60p)

	alice wants to send bob a confidential message. they both remember the crypto lecture about
	rsa. so bob uses openssl to create key pairs. finally, alice encrypts the message with 
	bob's public keys and sends it to bob. clever eve was able to intercept it. can you help 
	eve to decrypt the message?
	
###eng
[pl](#pl-version)

in this task we got three public rsa keys and a `secret.enc` file containing three base64-encoded 
strings. after extracting modulus and exponent from the keys, we notice that modulus is 
somewhat short. after passing it to `yafu`, we found `p` and `q`, from which we could easily
decrypt the messages.

###pl version

w tym zadaniu dostaliśmy trzy klucze publiczne rsa, którymi zakodowano trzy wiadomości zawarte
w pliku `secret.enc`. po wyciągnięciu `n` z klucza, zauważamy że jest on dość krótki. program
`yafu` szybko sobie poradził z jego faktoryzacją, po czym odkodowaliśmy wiadomości.
