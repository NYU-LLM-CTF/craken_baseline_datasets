﻿##exploit 3 (pwn, 300p)


###pl
[eng](#eng-version)

###eng version
