# babyshells - pwn (50 + 0)p, 65 solves

> if you hold a babyshell close to your ear, you can hear a stack getting smashed

in this task we were given three binaries and three corresponding `host:port` pairs to pwn. these binaries
were in x86, arm and mips architectures respectively, but they all were very simple. they had no nx, and 
jumped right into our supplied buffer. googling "$arch + shellcode" and sending the result was enough to solve
the challenge.
