﻿## crypto 50 (crypto, 50p)

### pl

[eng](#eng-version)

bardzo przyjemne (dla autora tego writeupa) zadanie. dostajemy 10 tekstów zaszyfrowanych tym samym stream cipher (z tym samym iv/kluczem), i mamy za zadanie rozszyfrować 11.

teksty w pliku [input.txt](input.txt)

orientujemy się od razu, że to sytuacja podobna do tego gdy wszystkie teksty zostały zaszyfrowane tym samym one time padem. a na to są sposoby.

oczywiście jeden sposób to napisanie masę skomplikowanego kodu bruteforcującego różne możliwości i wybierający najlepszy plaintext (np. taki który mieści sie w wymaganym charsecie). to rozwiązanie dobre do specjalistycznych zastosowań/mechanicznego łamania, ale my mamy znacznie _zabawniejszy_ sposób, do zapisania w kilkunastu linijkach pythona:

    dat = open('input.txt').readlines()
    dat = [x.strip().decode('hex') for x in dat]

    def xor(a, b):
        return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

    def interactive_hack(xored):
        while true:
            print ">", 
            i = raw_input()
            for x in xored:
                print " -> ", xor(i, x)

    xored = [xor(dat[0], d) for d in dat[1:]]
    interactive_hack(xored)

i tyle. co nam to daje? otóż możemy zgadywać w ten sposób hasło "interaktywnie" - na przykład jest spore prawdopodobieństwo że któryś z plaintextów zaczyna się od "you" - spróbujmy więc:

    > you
     ->  {&j&
     ->  nn`h
     ->  nnl;
     ->  {&v<
     ->  {&v<
     ->  sh%)
     ->  s`)h
     ->  {hj<
     ->  xok)
     ->  mn`&

meh. to może "the "?

    > the
     ->  v!z&
     ->  ciph
     ->  ci|;
     ->  v!f<
     ->  v!f<
     ->  ~o5)
     ->  ~g9h
     ->  voz<
     ->  uh{)
     ->  `ip&

strzał w dziesiątkę. widać początek słowa "cipher", więc próbujemy:

    > cipher
     ->  a one-'
     ->  the ke*
     ->  this m2
     ->  a stre2
     ->  a stre2
     ->  in a s*
     ->  if, ho$
     ->  anothe!
     ->  binarys
     ->  when u

ostatni znak nie ma sensu nigdzie, więc podejrzewamy że to jednak miało być inne słowo (np. ciphers). ale idziemy dalej, i tak aż do końca:


[image extracted text: ipher
ne
the
this
sire
maru
the
key
z&k:
phet
p&_by
toners
ne
keys
this mak
siteam
stream
howe
another
nary
ime pad
phers _
z&k:
zv+in!
f"
kwn skd
lrr
<2mn
38h0p
prh:
iot>
qgr&
zv+in!
u!zh
cni#r
iphers
ne
me
pad
keystr
this
makes
the
siteam
ipher
siteam
ipher
synchronou
howevet
another
approac
nary
tream
another
approach
prh
mot
vozkfrxs
kgb > xeacmbb
lhor
lhor
ki?}
dxnay
ckbmibl7
laxexvett
ciphers
vid81
1ng
sp5
can]


flaga: `when using a stream cipher, never use the key more than once!`

### eng version

very nice (at least for the auther of the writeup) task. we get 10 ciphertexts encoded with the same stream cipher (with the same iv and key) and we have to decode 11th.

input texts in [input.txt](input.txt)

we realise that this is a similar case to encoding all the texts with the same one time pad. but this can be handled.

of course we could have written a lot of complex brute-force code testing multiple possibilities and choosing the best plaintext (eg. the one that fits into selected charset). this is a good task for automatic code breaking, but we came up with a more `fun` idea, which could have been written in just few lines of code:

    dat = open('input.txt').readlines()
    dat = [x.strip().decode('hex') for x in dat]

    def xor(a, b):
        return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

    def interactive_hack(xored):
        while true:
            print ">", 
            i = raw_input()
            for x in xored:
                print " -> ", xor(i, x)

    xored = [xor(dat[0], d) for d in dat[1:]]
    interactive_hack(xored)

and that's it. what does it give us? we can try to break the code in an "interactive" way. we just try to guess the begining of one of the plaintexts - we assume that there is possibility that it starts with "you" so we try:

    > you
     ->  {&j&
     ->  nn`h
     ->  nnl;
     ->  {&v<
     ->  {&v<
     ->  sh%)
     ->  s`)h
     ->  {hj<
     ->  xok)
     ->  mn`&

not this time, so maybe "the "?

    > the
     ->  v!z&
     ->  ciph
     ->  ci|;
     ->  v!f<
     ->  v!f<
     ->  ~o5)
     ->  ~g9h
     ->  voz<
     ->  uh{)
     ->  `ip&

bingo! we can see a "ciph" word prefix so we try "cipher":

    > cipher
     ->  a one-'
     ->  the ke*
     ->  this m2
     ->  a stre2
     ->  a stre2
     ->  in a s*
     ->  if, ho$
     ->  anothe!
     ->  binarys
     ->  when u

last character does not make sense so we assume this must be a different word (eg. ciphers). we proceed until the end:


[image extracted text: ipher
ne
the
this
sire
maru
the
key
z&k:
phet
p&_by
toners
ne
keys
this mak
siteam
stream
howe
another
nary
ime pad
phers _
z&k:
zv+in!
f"
kwn skd
lrr
<2mn
38h0p
prh:
iot>
qgr&
zv+in!
u!zh
cni#r
iphers
ne
me
pad
keystr
this
makes
the
siteam
ipher
siteam
ipher
synchronou
howevet
another
approac
nary
tream
another
approach
prh
mot
vozkfrxs
kgb > xeacmbb
lhor
lhor
ki?}
dxnay
ckbmibl7
laxexvett
ciphers
vid81
1ng
sp5
can]


flaga: `when using a stream cipher, never use the key more than once!`