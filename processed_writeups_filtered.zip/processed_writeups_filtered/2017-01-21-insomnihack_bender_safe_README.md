# bender safe (re, 50 points)

binary provided in challenge is 32bit mips, which is a bit unusual, and makes reversing harder.

we can connect to challenge server, but it wants us to provide some otp key:

    $ nc bender_safe.teaser.insomnihack.ch 31337
    welcome to bender's passwords storage service
    here's your otp challenge : 
    imytsaaaui87yiqu

after a while of reverse-engineering, we have found that there is only one function that matter (named aptly `validate`).

checks are performed one-by-one, but characters are checked out-of-order (so naively bruteforcing password by tracing program and counting instructions will not work).

for example, second check looks like this:

```asm
.text:00401e0c loc_401e0c:                              # code xref: validate+184
.text:00401e0c                 lw      $v1, 0x60+dead($fp)
.text:00401e10                 lw      $v0, 0x60+babe($fp)
.text:00401e14                 mult    $v1, $v0
.text:00401e18                 mflo    $v0
.text:00401e1c                 sw      $v0, 0x60+deadxbabe($fp)
.text:00401e20                 lw      $v1, 0x60+defe($fp)
.text:00401e24                 lw      $v0, 0x60+cate($fp)
.text:00401e28                 mult    $v1, $v0
.text:00401e2c                 mflo    $v0
.text:00401e30                 sw      $v0, 0x60+defexcate($fp)
.text:00401e34                 lw      $v1, 0x60+dead2($fp)
.text:00401e38                 lw      $v0, 0x60+beef($fp)
.text:00401e3c                 mult    $v1, $v0
.text:00401e40                 mflo    $v0
.text:00401e44                 sw      $v0, 0x60+deadxbeef($fp)
.text:00401e48                 lw      $v1, 0x60+deadxbabe($fp)
.text:00401e4c                 lw      $v0, 0x60+babe($fp)
.text:00401e50                 divu    $v1, $v0
.text:00401e54                 teq     $v0, $zero  #7
.text:00401e58                 mfhi    $v1
.text:00401e5c                 mflo    $v0
.text:00401e60                 sw      $v0, 0x60+var_24($fp)
.text:00401e64                 lw      $v1, 0x60+defexcate($fp)
.text:00401e68                 lw      $v0, 0x60+cate($fp)
.text:00401e6c                 divu    $v1, $v0
.text:00401e70                 teq     $v0, $zero  #7
.text:00401e74                 mfhi    $v1
.text:00401e78                 mflo    $v0
.text:00401e7c                 sw      $v0, 0x60+var_20($fp)
.text:00401e80                 lw      $v1, 0x60+deadxbeef($fp)
.text:00401e84                 lw      $v0, 0x60+beef($fp)
.text:00401e88                 divu    $v1, $v0
.text:00401e8c                 teq     $v0, $zero  #7
.text:00401e90                 mfhi    $v1
.text:00401e94                 mflo    $v0
.text:00401e98                 sw      $v0, 0x60+var_1c($fp)
.text:00401e9c                 lw      $v1, 0x60+var_24($fp)
.text:00401ea0                 lw      $v0, 0x60+dead($fp)
.text:00401ea4                 divu    $v1, $v0
.text:00401ea8                 teq     $v0, $zero  #7
.text:00401eac                 mfhi    $v1
.text:00401eb0                 mflo    $v0
.text:00401eb4                 move    $v1, $v0
.text:00401eb8                 lw      $v0, 0x60+var_20($fp)
.text:00401ebc                 mult    $v1, $v0
.text:00401ec0                 mflo    $v1
.text:00401ec4                 lw      $v0, 0x60+defe($fp)
.text:00401ec8                 move    $at, $at
.text:00401ecc                 divu    $v1, $v0
.text:00401ed0                 teq     $v0, $zero  #7
.text:00401ed4                 mfhi    $v1
.text:00401ed8                 mflo    $v0
.text:00401edc                 move    $v1, $v0
.text:00401ee0                 lw      $v0, 0x60+var_1c($fp)
.text:00401ee4                 mult    $v1, $v0
.text:00401ee8                 mflo    $v1
.text:00401eec                 lw      $v0, 0x60+dead2($fp)
.text:00401ef0                 move    $at, $at
.text:00401ef4                 divu    $v1, $v0
.text:00401ef8                 teq     $v0, $zero  #7
.text:00401efc                 mfhi    $v1
.text:00401f00                 mflo    $v0
.text:00401f04                 sw      $v0, 0x60+deadxbabe($fp)
.text:00401f08                 lw      $v1, 0x60+arg_4($fp)
.text:00401f0c                 lw      $v0, 0x60+deadxbabe($fp)
.text:00401f10                 addu    $v0, $v1, $v0
.text:00401f14                 lb      $v1, 0($v0)
.text:00401f18                 lw      $v0, 0x60+arg_0($fp)
.text:00401f1c                 addiu   $v0, 0xf
.text:00401f20                 lb      $v0, 0($v0)
.text:00401f24                 beq     $v1, $v0, loc_401f5c
.text:00401f28                 move    $at, $at
.text:00401f2c                 lui     $v0, 0x48  # 'h'
.text:00401f30                 addiu   $a0, $v0, (anope_0 - 0x480000)  # "nope!"
.text:00401f34                 la      $v0, puts
.text:00401f38                 move    $t9, $v0
.text:00401f3c                 jalr    $t9 ; puts
.text:00401f40                 move    $at, $at
.text:00401f44                 lw      $gp, 0x60+var_50($fp)
.text:00401f48                 li      $a0, 1
.text:00401f4c                 la      $v0, exit
.text:00401f50                 move    $t9, $v0
.text:00401f54                 jalr    $t9 ; exit
.text:00401f58                 move    $at, $at
```

this looks overwhelming, but most of the opcodes are useless.

checks was rather trivial, so instead of trying to be smart, we've just reverse engineered everything the traditional way (using ida pro + qemu remote debugger), and came out with this otp generator (challenge in argv[1]):

```python
import sys

mychars = "abcdefghijklmnopqrstuvwxyz0123456789"

ss = sys.argv[1]

out = ''

out += ss[0]

out += ss[15]

if ord(ss[7]) >= 65:
    out += chr(ord(ss[7]) ^ 0x20)
else:
    out += chr(ord(ss[7]) ^ 0x40)

if ord(ss[3]) >= 65:
    ndx = mychars.find(ss[3])
    ndx = (ndx + 10) % len(mychars)
    out += mychars[ndx]
else:
    ndx = mychars.find(ss[3])
    ndx = (ndx - 10) % len(mychars)
    out += mychars[ndx]

if ord(ss[4]) >= 65:
    ndx = mychars.find(ss[4])
    ndx = (ndx + 10) % len(mychars)
    out += mychars[ndx]
else:
    ndx = mychars.find(ss[4])
    ndx = (ndx - 10) % len(mychars)
    out += mychars[ndx]

v25 = ord(ss[1]) - ord(ss[2])
if v25 >= 0:
    v26 = v25
else:
    v26 = -v25
out += mychars[v26 % (len(mychars) - 1)]

v25 = ord(ss[5]) - ord(ss[6])
if v25 >= 0:
    v26 = v25
else:
    v26 = -v25
out += mychars[v26 % (len(mychars) - 1)]

if ord(ss[8]) >= 65:
    out += chr(ord(ss[8]) ^ 0x20)
else:
    out += chr(ord(ss[8]) ^ 0x40)

print out
```
