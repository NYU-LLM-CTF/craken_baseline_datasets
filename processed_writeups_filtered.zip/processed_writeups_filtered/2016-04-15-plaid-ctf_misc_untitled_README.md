# untitled-1.pdf (misc, 50pts, 286 solves)
	this pdf has a flag on it, but i can't find it... can you?

in this task we were given a pdf file. running `pdftotext untitled.pdf` gave us flag.
