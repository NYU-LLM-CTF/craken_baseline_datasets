# writeup seccon ctf 2015

uczestniczyliśmy (cr019283, c7f.m0d3, msm, rev, other019, nazywam i shalom) w seccon ctf 2015, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).


[image extracted text: [image not found]]


### spis treści:
* [start seccon ctf (exercises)	50](start_seccon_50)
* [seccon wars 2015 (stegano) 100](seccon_wars_100)
* [unzip the file (crypto) 100]
* [fragment2 (web/network) 200]
* [connect the server (web/network) 100](connect_web_100)
* [command-line quiz (misc) 100](quiz_100)
* [entry form (web/network) 100](entry_form_web_100)
* [bonsai xss revolutions (web/network) 200](bonsai_xss_revolutions_web_200)
* [exec dmesg (binary/reverse) 300]
* [decrypt it (crypto) 300]
* [qr puzzle: web (misc) 400](qr_web_400)
* [qr puzzle: nonogram (misc) 300](qr_nonogram_300)
* [qr puzzle: windows (unknown) 200](qr_windows_200)
* [reverse-engineering android apk 1 (misc) 400]
* [find the prime numbers (crypto) 200](paillier_crypto_200)
* [micro computer exploit code challenge (exploit) 300]
* [gdb remote debugging (binary/reverse) 200]
* [fsb: treewalker (exploit) 200]
* [steganography 1 (stegano) 100](stegano_1_100)
* [steganography 2 (stegano) 100]
* [steganography 3 (stegano) 100](stegano_3_100)
* [4042 (misc/crypto) 100](4042_crypto_100)
* [individual elebin (binary/reverse) 200]
* [last challenge (thank you for playing) (exercises/crypto) 50](last_crypto_50)

