# backdoor ctf 2018

team: ak, c7, eternal, msm, naz, rev, rodbert, shalom

### table of contents

* [random noise (stegano)](random_noise)
* [awesome mix 1 (crypto)](crypto_mix1)
* [captcha revenge (web)](web_captcha)
* [array list (pwn)](pwn_array)
* [evil website (forensics)](evil_website)
