# writeup backdoor ctf 2016

team: rev, msm, akrasuski, nazywam, ppr, shalom, c7f.m0d3

### table of contents

* [offensive 300](offensive_300)
* [offensive 400](offensive_400)
