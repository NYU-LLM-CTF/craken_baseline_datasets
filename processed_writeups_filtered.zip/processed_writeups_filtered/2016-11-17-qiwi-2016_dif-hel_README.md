# diffie-hellman 1 (crypto 300)

###eng
[pl](#pl-version)

in the task we want to generate a shared secret via diffie hellman protocol.
we have 3 participants, but we know all the parameters only for 2 of them.
we are given:

```
p = 8986158661930085086019708402870402191114171745913160469454315876556947370642799226714405016920875594030192024506376929926694545081888689821796050434591251
g = 6
gc =  5361617800833598741530924081762225477418277010142022622731688158297759621329407070985497917078988781448889947074350694220209769840915705739528359582454617 # g^c mod p
a = 230
b = 250
```

so we know the secret values for participants `a` and `b` but for participant `c` we know only the public part of his secret - `g^c mod p`.
forunately this is all we need to establish the shared key.
after all this is how it's done in real life - everyone gets only this public secret.

the shared secret is simply `g^abc mod p`, and for this we don't need `c` if we already have `g^c mod p`:


```python
secret = pow(pow(gc, a, p), b, p)
```

and the first 20 characters are the flag: ```38058349620867258480```
###pl version

w zadaniu chcemy wygenerować wspólny klucz za pomocą protokołu diffiego hellmana.
mamy 3 uczestników ale znamy wszystkie parametry tylko dla 2 z nich.
znamy:

```
p = 8986158661930085086019708402870402191114171745913160469454315876556947370642799226714405016920875594030192024506376929926694545081888689821796050434591251
g = 6
gc =  5361617800833598741530924081762225477418277010142022622731688158297759621329407070985497917078988781448889947074350694220209769840915705739528359582454617 # g^c mod p
a = 230
b = 250
```

więc mamy sekretne wartości dla uczestników `a` oraz `b` ale dla `c` znamy tylko publiczną cześć jego sekretu - `g^c mod p`.
szczęśliwie to jest wszystko co potrzebujemy aby ustanowić wspólny klucz.
generalnie tak przebiega to w prawdziwym życiu - każdy inny uczestnik zna tylko publiczny sekret.

wspólny sekret to po prostu: `g^abc mod p`, a do tego nie potrzeba nam wartości `c` jeśli znamy już `g^c mod p`:

```python
secret = pow(pow(gc, a, p), b, p)
```

i pierwsze 20 znaków daje flage: ```38058349620867258480```
