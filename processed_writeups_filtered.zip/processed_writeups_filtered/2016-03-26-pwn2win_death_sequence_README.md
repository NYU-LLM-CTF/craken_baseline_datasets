## death sequence (ppc-m)
	tl;dr use matrixes with fastpow to get the desired results in o(logn) time

in this chall, we're given a series of numbers:

`1 1 1 1 10 46 217 1027 4861 23005 108874 515260 2438533 11540665`

it turns out that each numbers satisfies such formula that: inline equation:

`fn = f(n-1) * 4 + f(n-2) * 3 + f(n-3) * 2 + f(n-4)`

this looks strangely fimilar to fibonacii definition and we know, that we can calculate n'th fibonacii number in o(logn) time by using fast matrix exponentiation and [q-matrix](http://mathworld.wolfram.com/fibonacciq-matrix.html) 

after a **lot** of thought, we came up with a solution: 

declare *init* matrix as: 

|**4**|**1**|**0**|**0**|
|:--:|:--:| :--:| :--:|
|**3**|**0**|**1**|**0**|
|**2**|**0**|**0**|**1**|
|**1**|**0**|**0**|**0**|

and *begin* matrix as:

|**1**|**1**|**1**|**1**|
|:--:|:--:| :--:| :--:|
|**1**|**1**|**1**|**0**|
|**1**|**1**|**0**|**0**|
|**1**|**0**|**0**|**0**|


if we raise the begin matrix to the power of n and then multiply the init matrix with the result we'll get nth (more or less*) desired number in the left top record. 

	* we'll actually get n+4th number so we have to subtract the offset

of course, if n is more than 10 we'll start getting really big results, so we have to modulo the field during multiplication. 

the sum was a little bit trickier, write down fn, f(n-1), f(n-2), f(n-3) and f(n-4) then recognise common paterns and you get:

`sn = (f(n+4)-3f(n+3)-6f(n+2)-8f(n+1)+16)/9`

wrapping that all up we get [this](solve.py) scripts which allows us to get the flag: `ctf-br{it-was-just-a-recursive-sequence-to-be-coded-in-logn-xwmibvyz5qec}`


