# johnnyboy (re, 223p)

> this looks retro but somewhat futuristic! i always lose though, can you win? my friends solved this without ida! https://youtu.be/dem8fq6hkaw

> chall.ino.hex

well, this challenge was very frustrating to me. we were given a compiled avr code,
which meant we were not able to use ida's decompiler or anything similar.

i spent hours reversing the actual logic in the code, only to notice that the game win
screen function is called with a specific argument. at the address pointed by that argument,
there was a mysterious buffer of random-looking bytes. interpreting them as black&white image
gives us flag:


[image extracted text: conuratwlatiomsi
cif jjwmmitt rbmenwbrs
lny]

