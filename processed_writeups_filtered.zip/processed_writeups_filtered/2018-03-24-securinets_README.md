# securinets ctf quals 2018

team: shalom, akrasuski1, psrok1, nazywam, sasza

### table of contents

* [the worst rsa joke (crypto)](crypto_worst_rsa)
* [looser (crypto)](crypto_looser)
* [improve the quality (crypto)](crypto_quality)
* [notice me (forensics)](for_notice)
* [magic test (web)](web_magic)
* [special (pwn)](pwn_special)
* [tic tac toe (web/misc)](web_tictactoe)
* [no mercy (pwn)](pwn_no_mercy)
* [lone author (forenics)](for_lone)
