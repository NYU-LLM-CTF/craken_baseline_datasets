﻿##repeating xor (crypto, 400p)

	after entring the luxurious condomium,you get the feel that you are in home of a yester star. the extravagant flooring and furnishings shows the richness of this star. but where is she? there she is, lying peacefuly on her couch. see what envy has done to her...with a perfectly well maintained attractive body she still looks sex diva, except for her face beyond recogniton. her identity is crucial to know who killed her and why? in absence of any personal data around there is only a file. with a cryptic text in it. preity sure she has used her own name to xor encrypt the file. and challenge is to know her name.

###pl
[eng](#eng-version)

###eng version
