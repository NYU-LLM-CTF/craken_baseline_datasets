## lily.flac (misc, 2 points, 28 solves)
	more than just a few bleebs ;)

in this task we were given a flac file containg a, somewhat weird, music. looking at it
in audacity, we noticed that there is a very different spectrum in the beginning and end of
the file - so there was probably some data hidden. we converted the file to wav, since it's 
easier to work with uncompressed data.

looking at the first couple of hundred of bytes, we notice there are a lot of 0x80 and 0x7f
bytes. in 8-bit wav, they mean a very quiet sound, but since we suspected the file to contain
hidden binary data, we thought they would mean 0x00 and 0xff bytes, respectively - as though 
they got xored with 0x80 (in the hindsight, it seems to be just the fact that wav files contain
*signed* data, which shifts all the values by aforementioned 0x80).

xoring the wav with 0x80, we found that the first bytes of sound data are now: 
`\x7felf\x02\x01\x01\x00\x00\x00\x00\x00` - an elf! we stripped wav header from the file and
ran the elf, which in turn gave us the flag.
