## strange pdf(forensics, 150 points, 61 solves)


[image extracted text: eharfctf
aljj
44
6
e
1
4ljiui
slsfctf
4ljja]



dumping the contains of the pdf results in a set of strange streams:

```
7 0 obj
<</length 283>>
stream
2 w 

120 650 m 140 650 l 
140 645 m 140 625 l 
120 620 m 140 620 l 
120 615 m 120 595 l 
120 590 m 140 590 l 

s
endstream
endobj
```

it turns out to that it's a list of starting and ending points of lines, if we'd want to save that as postscript:


```
%%page: 1 1
newpath

120 650 moveto
140 650 lineto 
140 645 moveto
140 625 lineto 
120 620 moveto
140 620 lineto 
120 615 moveto
120 595 lineto 
120 590 moveto
140 590 lineto 

2 setlinewidth
stroke
fill

showpage
```

that way each stream is printed on a new page, we get:


[image extracted text: of 35
1.ps
15,08%
thumbnails
123
hbb
10
11
12
13
14
15
16
19
20
21
23
24
25]


which decodes to:

`sharifctf{d1242d2d0969741dde7ed79c3c409c46}`
