# writeup boston key party ctf 2016

team: akrasuski1, cr019283, c7f.m0d3, other019, rev, msm, shalom, nazywam, ppr 

### table of contents
* cookbook (pwn_6)
* simple calc (pwn_5)
* hmac_crc (crypto_5)
* [frog fractions 2 (reversing_5)](re_5_frog_fractions_2)
* segsh (pwn_6)
* found it? (misc_1)
* [good morning (web_3)](web_3_good_morning)
* gsilvis counting magic (crypto_9)
* [des ofb (crypto_2)](crypto_2_des_ofb)
* [unholy (reversing_4)](re_4_unholy)
* spacerex (pwn_8)
* [lily.flac (misc_2)](misc_2_lily_flac)
* complex calc (pwn_5)
* [bug bounty (web_3)](web_3_bug_bounty)
* more like zkp (crypto_4)
* qwn2own (pwn_10)
* feistel (crypto_5)
* optiproxy (web_2)
* bob's hat (crypto_4)
* [jit in my pants (reversing_3)](re_3_jit_in_my_pants)
* [ltseorg (crypto_4)](crypto_4_ltseorg)
