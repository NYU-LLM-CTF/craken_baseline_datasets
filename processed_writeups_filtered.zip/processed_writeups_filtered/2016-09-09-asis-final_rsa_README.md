## rsa (crypto, 113p)

###eng
[pl](#pl-version)

in the task we get source code of encryption routine, a public key and encrypted flag.
the source code is quite simple:

```python
import gmpy
from crypto.util.number import *
from crypto.publickey import rsa
from crypto.cipher import pkcs1_v1_5

flag = open('flag', 'r').read() * 30

def ext_rsa_encrypt(p, q, e, msg):
    m = bytes_to_long(msg)
    while true:
        n = p * q
        try:
            phi = (p - 1)*(q - 1)
            d = gmpy.invert(e, phi)
            pubkey = rsa.construct((long(n), long(e)))
            key = pkcs1_v1_5.new(pubkey)
            enc = key.encrypt(msg).encode('base64')
            return enc
        except:
            p = gmpy.next_prime(p**2 + q**2)
            q = gmpy.next_prime(2*p*q)
            e = gmpy.next_prime(e**2)

p = getprime(128)
q = getprime(128)
n = p*q
e = getprime(64)
pubkey = rsa.construct((long(n), long(e)))
f = open('pubkey.pem', 'w')
f.write(pubkey.exportkey())
g = open('flag.enc', 'w')
g.write(ext_rsa_encrypt(p, q, e, flag))
```

initially the algorithm generates a very small 128 bit primes and constructs modulus from them.
this is the modulus value from the public key we get.
however the algoritm is not using this small value for encryption since the data are too long - it uses `gmpy.next_prime()` to get bigger prime numbers. 
the problem is that `next_prime` is deterministic so if we can get the initial `p` and `q` values we can simply perform the same kind of iteration to get the `p` and `q` used for encrypting the flag.

since the initial modulus is just 256 bit we can factor it with yafu to get the initial primes.
we then simply perform the same loop to get final primes, we use modinv to get decryption exponent and then simply decrypt the flag:

```python
import base64
import codecs
import gmpy
import math
from crypto.publickey import rsa
from crypto.cipher import pkcs1_v1_5

n = 98099407767975360290660227117126057014537157468191654426411230468489043009977
p = 311155972145869391293781528370734636009 # from yafu
q = 315274063651866931016337573625089033553
e = 12405943493775545863


def long_to_bytes(flag):
    return "".join([chr(int(flag[i:i + 2], 16)) for i in range(0, len(flag), 2)])


def bytes_to_long(str):
    return int(str.encode('hex'), 16)


with codecs.open("./flag.enc") as flag:
    data = flag.read()
    msg = base64.b64decode(data)
    print('msg', math.log(bytes_to_long(msg), 2))
    while true:
        print("looping")
        try:
            print('p*q', math.log(long(p), 2)+math.log(long(q), 2))
            phi = (p - 1) * (q - 1)
            d = gmpy.invert(e, phi)
            key = rsa.construct((long(n), long(e), long(d)))
            algo = pkcs1_v1_5.new(key)
            decrypted = algo.decrypt(msg, 0x64)
            print(decrypted)
            print(p, q, e)
            print(long_to_bytes(decrypted))
        except exception as ex:
            print(ex)
            p = gmpy.next_prime(p ** 2 + q ** 2)
            q = gmpy.next_prime(2 * p * q)
            e = gmpy.next_prime(e ** 2)
            n = long(p)*long(q)
```

###pl version

w zadaniu dostajemy kod źródłowy szyfrowania, klucz publiczny oraz zaszyfrowaną flagę.
kod jest dość prosty:

```python
import gmpy
from crypto.util.number import *
from crypto.publickey import rsa
from crypto.cipher import pkcs1_v1_5

flag = open('flag', 'r').read() * 30

def ext_rsa_encrypt(p, q, e, msg):
    m = bytes_to_long(msg)
    while true:
        n = p * q
        try:
            phi = (p - 1)*(q - 1)
            d = gmpy.invert(e, phi)
            pubkey = rsa.construct((long(n), long(e)))
            key = pkcs1_v1_5.new(pubkey)
            enc = key.encrypt(msg).encode('base64')
            return enc
        except:
            p = gmpy.next_prime(p**2 + q**2)
            q = gmpy.next_prime(2*p*q)
            e = gmpy.next_prime(e**2)

p = getprime(128)
q = getprime(128)
n = p*q
e = getprime(64)
pubkey = rsa.construct((long(n), long(e)))
f = open('pubkey.pem', 'w')
f.write(pubkey.exportkey())
g = open('flag.enc', 'w')
g.write(ext_rsa_encrypt(p, q, e, flag))
```

początkowo algorytm generuje bardzo małe 128 bitowe liczby pierwsze i buduje z nich modulusa.
to jest wartość modulusa w kluczu publicznym, który dostajemy.
niemniej jednak algorytm nie używa tych małych liczb do szyfrowania ponieważ liczba danych jest za duża - zamiast tego używa `gmpy.next_prime()` żeby znaleźć większe liczby pierwze.
problem z tym rozwiązaniem polega na tym, że `next_prime` jest deterministyczne więc jeśli znamy początkowe wartości `p` oraz `q` możemy wykonać taką samą iteracje i wyzaczyć finalne `p` oraz `q` użyte do szyfrowania flagi.


ponieważ znany modulus ma tylko 256 bitów możemy go faktoryzować za pomocą yafu aby dostać początkowe wartości liczb pierwszyh.
następnie po prostu wykonujemy identyczną pętlę jak w kodzie z zadania aby wyznaczyć finalne wartości liczb pierwszych, używamy modinv żeby wyliczyć wykładnik deszyfrujący a następnie dekodujemy flagę:

```python
import base64
import codecs
import gmpy
import math
from crypto.publickey import rsa
from crypto.cipher import pkcs1_v1_5

n = 98099407767975360290660227117126057014537157468191654426411230468489043009977
p = 311155972145869391293781528370734636009 # from yafu
q = 315274063651866931016337573625089033553
e = 12405943493775545863


def long_to_bytes(flag):
    return "".join([chr(int(flag[i:i + 2], 16)) for i in range(0, len(flag), 2)])


def bytes_to_long(str):
    return int(str.encode('hex'), 16)


with codecs.open("./flag.enc") as flag:
    data = flag.read()
    msg = base64.b64decode(data)
    print('msg', math.log(bytes_to_long(msg), 2))
    while true:
        print("looping")
        try:
            print('p*q', math.log(long(p), 2)+math.log(long(q), 2))
            phi = (p - 1) * (q - 1)
            d = gmpy.invert(e, phi)
            key = rsa.construct((long(n), long(e), long(d)))
            algo = pkcs1_v1_5.new(key)
            decrypted = algo.decrypt(msg, 0x64)
            print(decrypted)
            print(p, q, e)
            print(long_to_bytes(decrypted))
        except exception as ex:
            print(ex)
            p = gmpy.next_prime(p ** 2 + q ** 2)
            q = gmpy.next_prime(2 * p * q)
            e = gmpy.next_prime(e ** 2)
            n = long(p)*long(q)
```
