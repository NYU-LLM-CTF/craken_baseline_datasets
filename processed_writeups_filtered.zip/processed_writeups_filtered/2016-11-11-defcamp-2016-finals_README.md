# writeup defcamp d-ctf 2016 finals

team: akrasuski1, nazywam, msm, rev, shalom


[image extracted text: [image not found]]



### table of contents

* [lecrypto (crypto 250)](lecrypto)
* [shredder (misc 100)](shredder)
