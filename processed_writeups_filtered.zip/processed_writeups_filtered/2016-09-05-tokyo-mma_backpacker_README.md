## backpacker's copher (crypto, 200p)

###eng
[pl](#pl-version)

todo when i get home

###pl version

