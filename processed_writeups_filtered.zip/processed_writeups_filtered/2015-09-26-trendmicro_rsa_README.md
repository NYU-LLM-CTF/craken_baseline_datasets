## rsa (crypto, 100p)

### pl version
`for eng version scroll down`

zadanie polegało na odszyfrowaniu wiadomości szyfrowanej za pomocą rsa mając dostęp do klucza publicznego. wiadomość to:

`kpmdflk5b/torg53sthwweenm0aipeqek0rvg3vcttc=`

a klucz:

	-----begin public key-----
	mdwwdqyjkozihvcnaqebbqadkwawkaihalytzp8lgwnxi9trgi8s8eacvudlxdrl
	nsnudja26nv8agmbaae=
	-----end public key-----

zadanie wspomniało też, że klucz publiczny nie jest całkiem poprawny i brakuje mu jakiegoś bitu. 
dekodujemy klucz publiczny i uzyskujemy:

	n = 82401872610398250859431855480217685317486932934710222647212042489320711027708
	e = 65537

widzimy od razu że wartość `n` jest niepoprawna bo nie jest iloczynem 2 liczb pierwszych (dzieli się przez 4). zamieniamy więc ostatni bit z 0 na 1 uzyskując liczbę `82401872610398250859431855480217685317486932934710222647212042489320711027709`

klucz jest bardzo krótki - ma tylko 256 bitów co oznacza, że jest podatny na faktoryzację. dokonujemy jej za pomocą narzędzia `yafu`:


[image extracted text: pharisaeus@phar
saeus
yatu
x64
09/27/15 02:23:02 vl.34.5
pharisaeus-pc ,
system/build
info:
using gmp-ecm
powered by gmp
~1.1
detected intel(r) core(tm)
duo
cpu
p8400
26ghz
detected
32768
bytes
3145728
bytes
bytes
mmeasured
cpu frequency
2244
686800
ing
fandom
witnesses
for
rabin-miller
prp checks
welcome
yafu (yet another factoring utility)
bbuhrowagmai
co
type help
time
quit to
quit
cached
78498 primes
qulua
999983
factor(824018726103982508594318554802176853174869329347102226472120424893207-
1027709)
ac:
factoring 8240187261039825085943185548021768531748693293471022264721204248
320711027709
using
etesting
plan:
horma
ac:
tune
info:
gnts
crossovet
95 digits
div:
than
a5' 18006'
j?
100oooo
tenata
ons
san
stant
ng 1000
iterations
starting
1000 iterations
san
starting
1000
iterations
starting
150k,
gmp-ecm
detau
on (77
ecm:
30/30
ll nr
ble2k
edm
detault
ecm:
74/74
curyes
(77
bl-l1k
b2-gmp-ecm default_
ema
149/149
curyes
b1-5ok, bz-gmp-=
default, eta:
sec
starting siqs
c77
824018726103982508594318554802176853174869329347102226472
2042489320711027709
eving
progress
(1 thread)
36224 relations needed
press
755rfuix
to abort
ardm
save
state
36239
rels
found:
18759
17480
186574 partial,
(1105
46 rels/sec)
elapsed
time
189
2838 seconds_
total factoring
time
233.5174
seconds
factors
founde "
p39
295214597363242917440342570226980714417
p39
279125332373073513017147096164124452877
ans
pnl
62-gmp
877 ,
sios]


na tej podstawie uzyskujemy liczby `p` oraz `q` potrzebne do odtworzenia klucza prywatnego. dokonujemy tego za pomocą rozszerzonego algorytmu euklidesa:

	def egcd(a, b):
		u, u1 = 1, 0
		v, v1 = 0, 1
		while b:
			q = a // b
			u, u1 = u1, u - q * u1
			v, v1 = v1, v - q * v1
			a, b = b, a - q * b
		return a, u, v

    q = 295214597363242917440342570226980714417
    p = 279125332373073513017147096164124452877
    e = 65537
    n = 82401872610398250859431855480217685317486932934710222647212042489320711027709
    phi = (p - 1) * (q - 1)
    gcd, a, b = egcd(e, phi)
    d = a
    if d < 0:
        d += phi
    print("n:  " + str(d))

mając liczbę `d` możemy teraz dokonać dekodowania wiadomości. zamieniamy wiadomość na liczbę:

`ct = 65573899802596942877560813284504892432930279657642337826069076977341847221975`

a następnie wykonujemy:

    pt = pow(ct, d, n)
    print("pt: " + long_to_bytes(pt))
	
i uzyskujemy flagę: `tmctf{$@!zbo4+qt9=5}`

### eng version

the task was to crack rsa encoded message based on provided public key. the message was:

`kpmdflk5b/torg53sthwweenm0aipeqek0rvg3vcttc=`

and the key was:

	-----begin public key-----
	mdwwdqyjkozihvcnaqebbqadkwawkaihalytzp8lgwnxi9trgi8s8eacvudlxdrl
	nsnudja26nv8agmbaae=
	-----end public key-----

the task description mentioned that there is something wrong with public key and there is a bit missing.
we decode the public key and we get:

	n = 82401872610398250859431855480217685317486932934710222647212042489320711027708
	e = 65537

we can clearly see that the `n` is incorrect since it's not a product of 2 prime numbers (it is divisible by 4). we swtich last bit from 0 to 1 and we get `82401872610398250859431855480217685317486932934710222647212042489320711027709`

the key is very short - only 256 bits so we can factor it. we do it using `yafu`:


[image extracted text: pharisaeus@phar
saeus
yatu
x64
09/27/15 02:23:02 vl.34.5
pharisaeus-pc ,
system/build
info:
using gmp-ecm
powered by gmp
~1.1
detected intel(r) core(tm)
duo
cpu
p8400
26ghz
detected
32768
bytes
3145728
bytes
bytes
mmeasured
cpu frequency
2244
686800
ing
fandom
witnesses
for
rabin-miller
prp checks
welcome
yafu (yet another factoring utility)
bbuhrowagmai
co
type help
time
quit to
quit
cached
78498 primes
qulua
999983
factor(824018726103982508594318554802176853174869329347102226472120424893207-
1027709)
ac:
factoring 8240187261039825085943185548021768531748693293471022264721204248
320711027709
using
etesting
plan:
horma
ac:
tune
info:
gnts
crossovet
95 digits
div:
than
a5' 18006'
j?
100oooo
tenata
ons
san
stant
ng 1000
iterations
starting
1000 iterations
san
starting
1000
iterations
starting
150k,
gmp-ecm
detau
on (77
ecm:
30/30
ll nr
ble2k
edm
detault
ecm:
74/74
curyes
(77
bl-l1k
b2-gmp-ecm default_
ema
149/149
curyes
b1-5ok, bz-gmp-=
default, eta:
sec
starting siqs
c77
824018726103982508594318554802176853174869329347102226472
2042489320711027709
eving
progress
(1 thread)
36224 relations needed
press
755rfuix
to abort
ardm
save
state
36239
rels
found:
18759
17480
186574 partial,
(1105
46 rels/sec)
elapsed
time
189
2838 seconds_
total factoring
time
233.5174
seconds
factors
founde "
p39
295214597363242917440342570226980714417
p39
279125332373073513017147096164124452877
ans
pnl
62-gmp
877 ,
sios]


based on this we get `p` and `q` numbers required for private key recovery. we do this with extended euclidean algorithm:

	def egcd(a, b):
		u, u1 = 1, 0
		v, v1 = 0, 1
		while b:
			q = a // b
			u, u1 = u1, u - q * u1
			v, v1 = v1, v - q * v1
			a, b = b, a - q * b
		return a, u, v

    q = 295214597363242917440342570226980714417
    p = 279125332373073513017147096164124452877
    e = 65537
    n = 82401872610398250859431855480217685317486932934710222647212042489320711027709
    phi = (p - 1) * (q - 1)
    gcd, a, b = egcd(e, phi)
    d = a
    if d < 0:
        d += phi
    print("n:  " + str(d))

with the `d` number we can now decode the message. we change the message into a number:

`ct = 65573899802596942877560813284504892432930279657642337826069076977341847221975`

execute:

    pt = pow(ct, d, n)
    print("pt: " + long_to_bytes(pt))
	
and get the flag: `tmctf{$@!zbo4+qt9=5}`