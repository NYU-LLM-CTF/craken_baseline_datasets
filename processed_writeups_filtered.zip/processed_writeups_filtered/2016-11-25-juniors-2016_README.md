# writeup juniors 2016 ctf

team: 

### table of contents

