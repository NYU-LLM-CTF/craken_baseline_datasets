------------------------
[steganography] d3lc1d10 - 25 points
------------------------

> we found an abandoned file on an old club’s server. our informant said it was possible to extract a phone ( xxxx xxxx ) number from it. get the number and find out the address that he belongs.

> note: the flag is in this format: ctf-br{address with space and comma}

in this task we were given a small file. hexdump on it was not very useful, but `cat`ting it showed some emoji.
admins gave hint on irc: "esolang", so we searched for esoteric languages using emoji as code. not much time later,
we found `emojicode`. downloading compiler and running the code, we got 8 digits as the output. since task's description
asaked for address, we googled those 8 digits and found out it was phone number of some brazil place. we searched their
website and found their location. pasting the address as a flag we got another 25 points.
