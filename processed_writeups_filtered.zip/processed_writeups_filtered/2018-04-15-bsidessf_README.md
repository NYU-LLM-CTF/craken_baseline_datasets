# bsidessf ctf 2018

team: shalom, nazywam, chivay

### table of contents

* [rotaluklak (pwn)](pwn_rotaluklak)
