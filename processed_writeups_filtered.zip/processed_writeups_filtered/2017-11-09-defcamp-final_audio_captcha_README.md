# audio captcha (misc/ppc)

this was a funny challenge, since we've done 2-3 of those some years ago.

we get a link to a webpage where we are supposed to listen to a [voice captcha](captcha.wav) and solve it.
we need to solve a number of them without failure to get a flag.
sounds are distorted and actually it's pretty hard to solve those even manually, and things like google speech api are useless here.


however, we had a pretty good idea how to work with this.
the audio data we got was wav, which means basically a raw sound stream.
the upside of this is that we can simply cut this stream into pieces and play them or work with them separately.

it was also pretty clear to us, that the sounds, although distorted, are actually always "the same".
it looked like the captcha was basically glued from the same inputs every time, without any random distortions.

this means we could do a simple pattern matching on the bytes!
the approach was simple:

1. download some captchas and solve them by hand.
2. split the captcha into 10 pieces (there were always 10 symbols)
3. cut a bunch of bytes from the piece and place it in our patterns list, alongside the symbol we take it for

now that we have the list of patterns we can simply start solving the task:

1. download a captcha
2. cut into pieces
3. for each piece go through the patterns list and try to get matchings
4. if more than one pattern fits skip this captcha
5. if only a single pattern matches the sample then add this symbol to the list
6. if all symbols were found send the answer to the server.

complete solver can be found [here](captcha.py)
