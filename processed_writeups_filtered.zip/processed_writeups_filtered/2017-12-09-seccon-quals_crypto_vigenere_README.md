# vigenere 3d (crypto, 100p)

in the task we get the code:

```python
import sys
def _l(idx, s):
    return s[idx:] + s[:idx]
def main(p, k1, k2):
    s = "abcdefghijklmnopqrstuvwxyz0123456789abcdefghijklmnopqrstuvwxyz_{}"
    t = [[_l((i+j) % len(s), s) for j in range(len(s))] for i in range(len(s))]
    i1 = 0
    i2 = 0
    c = ""
    for a in p:
        c += t[s.find(a)][s.find(k1[i1])][s.find(k2[i2])]
        i1 = (i1 + 1) % len(k1)
        i2 = (i2 + 1) % len(k2)
    return c
print main(sys.argv[1], sys.argv[2], sys.argv[2][::-1])
```

and a call log:

```
$ python vigenere3d.py seccon{**************************} **************
por4dnytlhbfwbxaazhe}}oczr3cxcftw9
```

we know that the flag has format: `seccon{**************************}`, key has 14 characters and ciphertext is `por4dnytlhbfwbxaazhe}}oczr3cxcftw9`.

first thing to prepare is decryption function, to use once we manage to recover the key:

```python
def decrypt(ct, k1, k2):
    s = "abcdefghijklmnopqrstuvwxyz0123456789abcdefghijklmnopqrstuvwxyz_{}"
    t = [[_l((i + j) % len(s), s) for j in range(len(s))] for i in range(len(s))]
    i1 = 0
    i2 = 0
    decrypted = ""
    for a in ct:
        for c in s:
            if t[s.find(c)][s.find(k1[i1])][s.find(k2[i2])] == a:
                decrypted += c
                break
        i1 = (i1 + 1) % len(k1)
        i2 = (i2 + 1) % len(k2)
    return decrypted
```

this is a very naive brute-force decryptor, but we don't need anything more fancy.
now we need to somehow recover the encryption key.

it's easy to notice that this enryption can generate identical ciphertexts for many different keys.
in fact for any chosen key character at position `x` there is a corresponding character at position `13-x` which will produce the right ciphertext character from the plaintext. 
this is simply because array `t` contains all possible combinations.
this means we actually need to recover only 7 characters of the key, because they will automatically fix the other 7 characters.

we can run:
```python
def recover_key(known_prefix, ciphertex):
    final_key = ['*'] * 14
    for pos in range(7):
        for c in s:
            partial_candidate_key = ['*'] * 14
            partial_candidate_key[pos] = c
            partial_candidate_key[13 - pos] = c
            key = "".join(partial_candidate_key)
            res = encrypt(known_prefix, key, key[::-1])
            if res[pos] == ciphertex[pos]:
                final_key[pos] = c
                final_key[13 - pos] = c
                print "".join(final_key)
    return "".join(final_key)
```

to generate a key which will be a palindrome.
we could just as well always set `partial_candidate_key[13 - pos] = 'a'` or any other fixed character.

once we run this, we recover the key and can decrypt the flag: `seccon{welc0me_to_seccon_ctf_2017}`

full solver [here](vigenere.py)
