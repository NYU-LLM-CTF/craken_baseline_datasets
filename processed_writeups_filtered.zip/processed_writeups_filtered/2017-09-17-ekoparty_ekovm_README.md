# ekovm (vm, 465 points, 22 solves)

lets try to solve another challenge blackbox-ish-ly.


[image extracted text: hds@hds-vm: /tmp
hds@hds-vn: [tnps
uname
tv
tr
4.8.0-59-generic #64-ubuntu smp
thu
jun
29
19:38:34 utc 2017
hdsdhds-vn: [tmps
date
sab
sep
00:20:41
cot
2017
hds@hds-vn: [tnps
iekovm
=[
secure
generator
j=
[+]
type
your  flag:
[+]
securing
your
[+]
secured:
064325164070762714074006534
135340214127270554045162244
072374624125051700122026060
046574154042136424131507430
122633024136752124007461350
flag
flag
flag]


upon inspecting the binary we discover two important facts:

the random generator inside the cipher is seeded with time:

``` c++
__int64 (__fastcall *__fastcall sub_48a0(__int64 a1))()
{
  unsigned int v1; // eax@1
  _qword *v2; // rax@1
  __int64 (__fastcall *result)(); // rax@3

  v1 = time(0ll);
  srand(v1);
  v2 = (_qword *)(a1 + 272);
  do
  {
    *v2 = sub_1450;
    ++v2;
  }
  while ( v2 != (_qword *)(a1 + 2320) );
...
```

if we now "freeze" the time and execute the program with a constant seed, another thing becomes obvious:

```
input	output
a 	062540210007630520
ab 	062540210063357420007630520
abc 	062540210063357420064176630007630520
abcd 	062540210063357420064176630065016040007630520
abcde 	062540210063357420064176630065016040065635250007630520
```

the encryption happens only one byte at a time, which means that we can easily bruteforce the flag byte by byte.


let's start off by brute-forcing the seed, as we can see in the screenshot the time is probably equal to a few seconds after 1504329641.

we're going to use a cool ld_preload trick to set the returned time to whatever we want. ideally this would be done by returning a environmental value instead of compiling the library each time, but this works too:

``` python

required = "064325164070762714074006534135340214127270554045162244072374624125051700122026060046574154042136424131507430122633024136752124007461350"
			
for i in range(100):

	patched = """#include <time.h>

	time_t time(time_t *t){
		return %d;
	}""" % (1504329641 + i)

	f = open("time.c","wb")
	f.write(patched)
	f.close()

	flag = "e"
	f = open("/tmp/b", "wb")
	f.write(flag)
	f.close()

	os.system("gcc -fpic -c time.c -o time.o; gcc -shared -o time.so time.o")
	os.system("ld_preload=\"./time.so\" ./ekovm < /tmp/b > /tmp/a")

	out = open("/tmp/a").read()
	output = ''.join(out.split("\n")[4:])

	if required.startswith(output):
		print("correct seed %d" % (1504329641 + i))
		break
```

`correct seed: 1504329734`

using that value we can write a simple script to solve the rest of the challenge:

``` python


password = "eko"
while true:
	for i in string.printable:

		flag = password + i
		f = open("/tmp/b", "wb")
		f.write(flag)
		f.close()

		os.system("ld_preload=\"./time.so\" ./ekovm < /tmp/b > /tmp/a")

		out = open("/tmp/a").read()
		output = ''.join(out.split("\n")[4:])
		if output in required:
			password += i
			print(password)
			break
```

and get the flag without reversing the vm at all: `eko{s1mpl3-vm}`


