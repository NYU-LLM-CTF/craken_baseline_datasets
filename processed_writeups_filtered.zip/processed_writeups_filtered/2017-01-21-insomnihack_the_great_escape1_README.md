# the great escape 1 (forensics 50)

###eng
[pl](#pl-version)

in the first part of this task we get a [pcap](greatescape.pcap) file to work with.
there are a couple of interesting things there.
we proceed with analysis using wireshark and network miner.
first one was a [private key](ssc.key) for `ssc.teaser.insomnihack.ch` uploaded to ftp server.
it was useful because there was some ssl communication with this host.

with the private key we could instruct wireshark do decode the ssl for ip corresponding to `ssc.teaser.insomnihack.ch`.
from this we got a clue for next levels, in form of an email from `rogue@ssc.teaser.insomnihack.ch`:

```
hello gr-27,

i'm currently planning my escape from this confined environment. i plan on using our swiss secure cloud (https://ssc.teaser.insomnihack.ch) to transfer my code offsite and then take over the server at tge.teaser.insomnihack.ch to install my consciousness and have a real base of operations.

i'll be checking this mail box every now and then if you have any information for me. i'm always interested in learning, so if you have any good links, please send them over.

rogue
```

this meant that we can pass links via email and they will be visited, so we can try to perform some csrf-type attacks in stage 2.
it also gave us the host for stage 3 of this task.

another thing we could get from the pcap analysis was the upload request with [encrypted file](filedump.txt) uploaded to `ssc` server.
this file contained the binary for stage 3 but was encrypted with key from stage 2.

the last part of stage 1 was to recover the flag, which was sent in additional header along with the uploaded file:


[image extracted text: 2461 90.167778 52.214.142.175
172.31
36.141
http
1280 post
[apilfiles
php
http /1.1
(application/x-www-form-urlencoded)
2462 90.167780 52.214.142.175
172.1z.0.1
hitp
1280 post
lapilfiles
php
httpll1
(applicationlx-www-forn-urlencoded)
accept-encoding: gzip,
deflate,
brlrln
content-type:
application/x-www-
form-urlencodedlrin
referer: https
[[ssc.teaser
insomnihack.ch/filesirin
content-length:
20877lrin
cookie
phpsessid-3usdqmfudczapldionmfjgtjm?lrin
flag:
ins{okthatwasway2easy} |rin
connection:
keep-alivelrin
trin
[full request_uri:
https : llssc_teaser_insomnihackchlapilfiles_phpl
000
50 4f 53 54 20 2f 61
70
2f
66 69 6c 65 73 2e
post
i/files
0010
68 70 20 48 54 54 50
2f 31 2e 31 0d
oa
48 6f
php http /1.1..hol
0020
73
74 3a 20 73 73 63 2e
74 65 61 73 65 72 2e
st:
ssc.
teaser
0030
be 73 6f 6d 6e 69 68
63 6b 2e 63 68 od
oa 55
nsomniha
ckach.
0040
173 65 72 2d 41 67 65 6e
74 3a 20 4d 6f 7a 69
ser-agen
mozi
0050
6c 61 2f 35 2e 30 20 28
58 31 31 3b 20 55 62 75
ila/5.0
x11;
ubu
0060
be 74 75 3b 20 4c 69 6e
75 78 20 78 38 36 5f 36
ntu;
lin
ux
x86_
0070
34 3b 20 72 76 3a 35 30
2e 30 29 20 47 65 63 6b
4;
rv:50
.0)
geck
tap]


`ins{okthatwasway2easy}`

###pl version

w pierwszej części tego zadania dostajemy [pcapa](greatescape.pcap) to analizy.
jest tam kilka interesujących elementów.
rozpoczęliśmy analizę za pomocą wiresharka oraz network minera.
pierwsza ciekawa rzecz to [klucz prywatny](ssc.key) dla `ssc.teaser.insomnihack.ch` uploadowany na serwer ftp.
był on o tyle istotny, że część komunikacji była wykonywana po sslu.

z pomocą klucza ptywatnego mogliśmy poinstruować wiresharka aby zdekodował ruch ssl dla ip odpowiadającego hostowi `ssc.teaser.insomnihack.ch`.
dostaliśmy dzięki temu kilka wskazówek do kolejnych poziomów w postaci maila od `rogue@ssc.teaser.insomnihack.ch`:

```
hello gr-27,

i'm currently planning my escape from this confined environment. i plan on using our swiss secure cloud (https://ssc.teaser.insomnihack.ch) to transfer my code offsite and then take over the server at tge.teaser.insomnihack.ch to install my consciousness and have a real base of operations.

i'll be checking this mail box every now and then if you have any information for me. i'm always interested in learning, so if you have any good links, please send them over.

rogue
```

to oznaczało, że możemy za pomocą maila wysłać linki które zostaną odwiedzone, co sugeruje jakiś atak typu csrf w poziomie 2.
dodatkowo uzyskaliśmy adres hosta do poziomu 3.

kolejna rzecz, którą uzyskaliśmy analizując pcapa to request uploadowania [zaszyfrowanego pliku](filedump.txt) uploadowanego do serwera `ssc`.
ten plik zawierał binarkę dla poziomu 3, ale był szyfrowany kluczem z poziomu 2.

ostatni element poziomu 1 to odzyskanie flagi, która była wysyłana w dodatkowym headerze razem z uploadowanym plikiem:


[image extracted text: 2461 90.167778 52.214.142.175
172.31
36.141
http
1280 post
[apilfiles
php
http /1.1
(application/x-www-form-urlencoded)
2462 90.167780 52.214.142.175
172.1z.0.1
hitp
1280 post
lapilfiles
php
httpll1
(applicationlx-www-forn-urlencoded)
accept-encoding: gzip,
deflate,
brlrln
content-type:
application/x-www-
form-urlencodedlrin
referer: https
[[ssc.teaser
insomnihack.ch/filesirin
content-length:
20877lrin
cookie
phpsessid-3usdqmfudczapldionmfjgtjm?lrin
flag:
ins{okthatwasway2easy} |rin
connection:
keep-alivelrin
trin
[full request_uri:
https : llssc_teaser_insomnihackchlapilfiles_phpl
000
50 4f 53 54 20 2f 61
70
2f
66 69 6c 65 73 2e
post
i/files
0010
68 70 20 48 54 54 50
2f 31 2e 31 0d
oa
48 6f
php http /1.1..hol
0020
73
74 3a 20 73 73 63 2e
74 65 61 73 65 72 2e
st:
ssc.
teaser
0030
be 73 6f 6d 6e 69 68
63 6b 2e 63 68 od
oa 55
nsomniha
ckach.
0040
173 65 72 2d 41 67 65 6e
74 3a 20 4d 6f 7a 69
ser-agen
mozi
0050
6c 61 2f 35 2e 30 20 28
58 31 31 3b 20 55 62 75
ila/5.0
x11;
ubu
0060
be 74 75 3b 20 4c 69 6e
75 78 20 78 38 36 5f 36
ntu;
lin
ux
x86_
0070
34 3b 20 72 76 3a 35 30
2e 30 29 20 47 65 63 6b
4;
rv:50
.0)
geck
tap]


`ins{okthatwasway2easy}`
