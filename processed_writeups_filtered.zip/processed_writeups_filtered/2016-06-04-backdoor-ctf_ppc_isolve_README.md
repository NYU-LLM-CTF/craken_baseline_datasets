## isolve (ppc)

###eng
[pl](#pl-version)

the task was pretty obvious: the server provides us with a regular expression and we need to supply a string which can be matched by this regex.
since we're lazy we checked if someone has not done this already, and of course they did: https://bitbucket.org/leapfrogdevelopment/rstr/

so we simply write a short parser for the communication with server, and use `xeger` to get answers.
we had to modify the xeger code a bit because it was generating `\n` in place of whitespace placeholders and the server was not handling this well, so we forced the library to use `\t` always for `\s`.
there was also some issue with non-alphanumeric characters so we also forced those to a single chosen character.
rest was just the communication with the server:

```python
import rstr
import socket
import re
from time import sleep

def recvuntil(s, pattern, tryouts):
    data = ""
    for i in range(tryouts):
        sleep(1)
        data += s.recv(9999)
        if pattern in data:
            return data
    return data


def main():
    url = "hack.bckdr.in"
    port = 7070
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    while true:
        task = recvuntil(s, "pass your solution:", 10)
        print(task)
        to_solve = re.findall("your regex:\s+(.*)\s+pass your solution", task)
        if len(to_solve) == 0:
            print(task)
        else:
            print("to solve = '%s'" % to_solve[0])
            solution = rstr.xeger(to_solve[0])
            print("solution  = %s" % solution)
            s.sendall(solution + "\n")


main()
```

which gave:

```
passed regex! way to go.
################################
#######     round 47        #####
################################


your regex:
ab*


pass your solution:

to solve = 'ab*'
solution  = ab
passed regex! way to go.
congratulations, you can now say isolve
flag{...}
```

###pl version

zadanie było dość oczywiste koncepcyjnie: serwer podaje nam wyrażenie regularne a my mamy zwrócić ciąg znaków, który będzie przez to wyrażenie przyjęty.
jako, że jesteśmy leniwi z natury, sprawdziliśmy czy ktoś już czegoś podobnego nie napisał i oczywiście ktoś taki się znalazł: https://bitbucket.org/leapfrogdevelopment/rstr/

w związku z tym napisalismy krótki parser do komunikacji z serwerem i użylismy `xegera` do uzyskiwania odpowiedzi.
musieliśmy lekko zmodyfikować kod biblioteki ponieważ generowała znaki `\n` jako białe znaki, a serwer sobie z tym nie radził zbyt dobrze, w związku z tym wymusiliśmy używanie `\t` zawsze dla `\s`.
były też jakieś problemy ze znakami nie-alfanumerycznymi i te także sprowadziliśmy do jednego wybranego znaku.
reszta to już tylko komunikacja z serwerem:

```python
import rstr
import socket
import re
from time import sleep

def recvuntil(s, pattern, tryouts):
    data = ""
    for i in range(tryouts):
        sleep(1)
        data += s.recv(9999)
        if pattern in data:
            return data
    return data


def main():
    url = "hack.bckdr.in"
    port = 7070
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    while true:
        task = recvuntil(s, "pass your solution:", 10)
        print(task)
        to_solve = re.findall("your regex:\s+(.*)\s+pass your solution", task)
        if len(to_solve) == 0:
            print(task)
        else:
            print("to solve = '%s'" % to_solve[0])
            solution = rstr.xeger(to_solve[0])
            print("solution  = %s" % solution)
            s.sendall(solution + "\n")


main()
```

co dało:

```
passed regex! way to go.
################################
#######     round 47        #####
################################


your regex:
ab*


pass your solution:

to solve = 'ab*'
solution  = ab
passed regex! way to go.
congratulations, you can now say isolve
flag{...}
```