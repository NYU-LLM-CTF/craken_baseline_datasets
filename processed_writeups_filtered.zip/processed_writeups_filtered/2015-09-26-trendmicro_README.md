# writeup trendmicro ctf 2015

uczestniczyliśmy (shalom, msm, rev, other019, nazywam i graszka22) w trendmicro ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:

* zadania były podzelone na nietypowe kategorie, niemniej same zadania specjalnie nie odbiegały od standardu. utrudniało to jednak wybranie "swoich" zadań. organizatorzy nie chcieli pewnie, żeby ich klienci widzieli że w konkursie są kategorie typu "binary exploitation" czy "web hacking" więc nazwali je bp. "analysis-offensive"
* organizatorzy zrobili zadanie za 100p z krzyżówką gdzie wszystkie pytania dotyczyły ich firmy, np. "jak nazywa sie ceo", "w którym roku powstała", "jak sie nazywa produkt do..." ;]

w spisie treci umieszczamy 2 klasyfikacje typu zadania - standardową (eg. forensics, reverse, pwn, web, ppc, crypto) oraz tą proponowaną przez organizatorów (analysis-others, analysis-defensive, analysis-offensive, programming, misc, cryptography).

# spis treści:

* [calculator (ppc/programming 200)](calculator)
* [colors (ppc/programming 100)](colors)
* [captcha (ppc/misc 300)](captcha)
* [rsa (crypto/cryptography 100)](rsa)
* [aes (crypto/cryptography 200)](aes)
* [maze (ppc/programming 300)](maze)
* [offensive 100 (web/analysis-offensive 100)](offensive100)
* [defense 100(reverse/analysis-defensive 100)](defense100)
* [other 100 (forensics/analysis-other 100)](other100)


# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
