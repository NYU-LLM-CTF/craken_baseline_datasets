#old but gold (misc, 250 points, solved by 76)

this chall involves parsing and decoding old recording medium - [punch cards](https://en.wikipedia.org/wiki/punched_card)


[image extracted text: 11110111111111111111111
u
lle
22222]
222220222220222222202222[2222222222222222222222222222222222222222222222222
33888
8338330333
33333333
833833[33833833333
08882
388888888888888888888888833
4444444444444444444444444444444444444444 4444 44444444444444
555555555
555555055551
5555555550
555555555505555555555555555
5555555555
66666666666666666
66666666666
6666 6 6
4666 6
666666666666
7777777777777
777777777777777777
77777
777777777777777777777777
7777777777
88888888
888888888 8 88888888
888888888888888888
8888888888888888888888888888888
099999999999
444444444446
4444444g
44444g]


we used pillow to detect if a given box is ticked or not:

``` python
for x in range(2, 82):
		column = ""
		for y in range(2, 25, 2):
			if(iswhite(pix[x*7 + 4, y*10 + 5])):
				column += ("o")
			else:
				column += (" ")
		sys.stdout.write(ibm_model_029_keypunch[0][find(column)])
	print("")
```

the decoding part is done simply by using a template such as this one:

```
ibm_model_029_keypunch = [
"    /&-0123456789abcdefghijklmnopqr/stuvwxyz:#@'=x`.<(+|!$*);^~,%_>? |",
"12 / o           ooooooooo                        oooooo             |",
"11|   o                   ooooooooo                     oooooo       |",
" 0|    o                           ooooooooo                  oooooo |",
" 1|     o        o        o        o                                 |",
" 2|      o        o        o        o       o     o     o     o      |",
" 3|       o        o        o        o       o     o     o     o     |",
" 4|        o        o        o        o       o     o     o     o    |",
" 5|         o        o        o        o       o     o     o     o   |",
" 6|          o        o        o        o       o     o     o     o  |",
" 7|           o        o        o        o       o     o     o     o |",
" 8|            o        o        o        o oooooooooooooooooooooooo |",
" 9|             o        o        o        o                         |",
"  |__________________________________________________________________|",
]

def getrow(q):
	out = ""
	for i in range(len(ibm_model_029_keypunch)):
		out += ibm_model_029_keypunch[i][q]
	return out

def check(n, need):
	for i in range(len(need)):
		if(need[i] != getrow(n)[i+1]):
			return false
	return true
```

output of the [script](punched.py):

```
once upon a teme, there was a young hacker called mj
it was the sixties, he was trykng to figure out how to
use those ponched cards, he likes to program in fortran
and cobol, b(t even after all those years he doesnt know
how to properly mrite secure code in those languages
in those days your only option w4s read large books and
manuals try1ng to learn how to program and spend a lot
of time punching those nards, can you imagine what could
happen if you fake a small mistake in on of those punched
cards? after those hours waiting ror a result, then it says
error due to a small and almost insignificant mist4ke but
that will take more time to mebug and figure out where was
the bug, but those wer3 the old days. can you find the flag
using this old technology? good luck, you will need it)
```

the flag is a concatenation of typos in the text:
`eko(m41nfr4m3)`