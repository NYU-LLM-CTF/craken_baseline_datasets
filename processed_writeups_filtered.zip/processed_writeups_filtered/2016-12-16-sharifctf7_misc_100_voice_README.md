# lost voice (misc 100)

###eng
[pl](#pl-version)

we get [mp3](ls.mp3) file to work with.
from the sound we can recover the numbers `95cd605bea9065f44530` (which required some skill because `a` and `8` can sound similar and so did `e` and `d`).

then someone noticed that there is actually some video here, which very fade numbers `cb13bbb59dde`

the flag was just concatenation: `sharifctf{cb13bbb59dde95cd605bea9065f44530}`

###pl version

dostajemy [mp3](ls.mp3) do analizy.
z dźwięków odzyskujemy liczbe `95cd605bea9065f44530` (co nie było takie proste bo `a` mogło być `8` a `e` mogło być `d`).

następnie ktoś zauważył że jest tam też video, z ledwo dostrzegalnymi `cb13bbb59dde`.

flaga wymagała sklejenia tych 2 elementów: `sharifctf{cb13bbb59dde95cd605bea9065f44530}`
