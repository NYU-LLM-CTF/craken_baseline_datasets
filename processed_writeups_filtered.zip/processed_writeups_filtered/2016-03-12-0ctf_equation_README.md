## equation (crypto, 2p)

	here is a rsa private key with its upper part masked. can your recover the private key and decrypt the file?

###eng
[pl](#pl-version)

we have the picture:


[image extracted text: user@alice ~/playground>
cat key_pen
begin rsa private key
os9mhoordqwzcwvrnnizzdlcaxpxujihgwjbanwi jcdugxzpnerxvw7s0913wxnt
v4gqdxczgopgsehthtotrbyxoaqrpau/hogtrosodmbn+3hpitsnbcy67vkcobm4
xzpttukm6xi+16vtunfvs9e4rqwiqcdaxnguuvmbxlxzcloxogufacshitrxzwof
7lvsseizr63cyrcpovmcoodvynbcwdzn88mhzjujkusrhjot7wccarmtgeij6tku
8nwtibvjr4jvkzzeqndokzidqpukeynpclldekixyaqx
end rsa private
key]


from which we can extract the base64 of the private key part:

```
os9mhoqrdqw2cwvrnni72dlcaxpxuj1hgwjbanwijcdugxzpnerxvw7s0913wxnt
v4gqdxczg0pg5ehthtotrbyx0aqrp4u/hq9trosodmbn+3hpitsnbcy67vkcqbm4
xzpttukm6xi+16vtunfvs9e4rqwiqcdaxn9uuvmbxlx2cl0xoguf4c5hitrx2wof
7lvs5eizr63cyrcpovmcqqdvynbcwd7n88mhzjujkusrhjot7wccarmtgeij6tku
8nwt9bvjr4jvkz2eqnd0kzwdqpukeynpclldekixyaqx
```

next we read a bit about ans1 der ( https://en.wikipedia.org/wiki/abstract_syntax_notation_one#example_encoded_in_der ) format and what are the values in the rsa private key file.
it turns out that that the file contains:

```
rsaprivatekey ::= sequence {
  version           version,
  modulus           integer,  -- n
  publicexponent    integer,  -- e
  privateexponent   integer,  -- d
  prime1            integer,  -- p
  prime2            integer,  -- q
  exponent1         integer,  -- d mod (p-1)
  exponent2         integer,  -- d mod (q-1)
  coefficient       integer,  -- (inverse of q) mod p
  otherprimeinfos   otherprimeinfos optional
}
```

and the extraction is quite simple - we need to find byte `02` which denotes start of an integer and then the next byte specifies number of bytes that follow.
we wrap this in a short script:

```python
def get_dp_dq_qinv(key64):
    result = []
    key_tab = list(b64decode(key64))
    print(key_tab)
    i = 0
    while i < len(key_tab):
        x = key_tab[i]
        if x == 0x2:  # integer start
            length = key_tab[i + 1]
            octets = key_tab[i + 2: i + 2 + length]
            value = int.from_bytes(octets, byteorder="big")
            result.append(value)
            print(value)
            i += 2 + length
        else:
            i += 1
    return tuple(result)


dp, dq, qinv = get_dp_dq_qinv(key64)
```

and thus we get 3 integers, which are (accoring for private key der format): dp, dq and qinv. 

dp = 11188888442779478492506783674852186314949555636014740182307607993518479864690065244102864238986781155531033697982611187514703037389481147794554444962262361

dq = 1006725509429627901220283238134032802363853505667837273574181077068133214344166038422298631614477333564791953596600001816371928482096290600710984197710579

qinv = 11196804284042107547423407831525890933636414684075355664222816007929037065463409676450144484947842399975707117057331864113464711778199061912128258484839473


we also know a bunch of lower bytes of the `q` prime factor, however we didn't need it after all.
instead we follow the algorithm proposed in https://eprint.iacr.org/2004/147.pdf and implement the recovery algorithm:

```python
def recover_parameters(dp, dq, qinv, e):
    results = []
    d1p = dp * e - 1
    for k in range(3, e):
        if d1p % k == 0:
            hp = d1p // k
            p = hp + 1
            if is_prime(p):
                d1q = dq * e - 1
                for m in range(3, e):
                    if d1q % m == 0:
                        hq = d1q // m
                        q = hq + 1
                        if is_prime(q):
                            if (qinv * q) % p == 1 or (qinv * p) % q == 1:
                                results.append((p, q, e))
                                print(p, q, e)
    return results
```

which returns a single solution:

p= 12883429939639100479003058518523248493821688207697138417834631218638027564562306620214863988447681300666538212918572472128732943784711527013224777474072569 

q = 12502893634923161599824465146407069882228513776947707295476805997311776855879024002289593598657949783937041929668443115224477369136089557911464046118127387

e = 65537

and now it's just a matter of recovering the `d` exponent via standard egcd algoritm and decrypting rsa:

```python
def egcd(a, b):
    u, u1 = 1, 0
    v, v1 = 0, 1
    while b:
        q = a // b
        u, u1 = u1, u - q * u1
        v, v1 = v1, v - q * v1
        a, b = b, a - q * b
    return u


def get_d(p, n, e):
    q = n / p
    phi = (p - 1) * (q - 1)
    d = egcd(e, phi)
    if d < 0:
        d += phi
    return d


with open("flag.enc", "rb") as input_file:
    n = p * q
    data = input_file.read()
    ct = bytes_to_long(data)
    d = get_d(p, n, e)
    pt = pow(ct, d, n)
    print("pt: " + long_to_bytes(pt))
```

which gives us `0ctf{keep_ca1m_and_s01ve_the_rsa_eeeequati0n!!!}`

###pl version

dostajemy obrazek:


[image extracted text: user@alice ~/playground>
cat key_pen
begin rsa private key
os9mhoordqwzcwvrnnizzdlcaxpxujihgwjbanwi jcdugxzpnerxvw7s0913wxnt
v4gqdxczgopgsehthtotrbyxoaqrpau/hogtrosodmbn+3hpitsnbcy67vkcobm4
xzpttukm6xi+16vtunfvs9e4rqwiqcdaxnguuvmbxlxzcloxogufacshitrxzwof
7lvsseizr63cyrcpovmcoodvynbcwdzn88mhzjujkusrhjot7wccarmtgeij6tku
8nwtibvjr4jvkzzeqndokzidqpukeynpclldekixyaqx
end rsa private
key]


z którego możemy odczytać base64 części klucza prywatnego rsa:

```
os9mhoqrdqw2cwvrnni72dlcaxpxuj1hgwjbanwijcdugxzpnerxvw7s0913wxnt
v4gqdxczg0pg5ehthtotrbyx0aqrp4u/hq9trosodmbn+3hpitsnbcy67vkcqbm4
xzpttukm6xi+16vtunfvs9e4rqwiqcdaxn9uuvmbxlx2cl0xoguf4c5hitrx2wof
7lvs5eizr63cyrcpovmcqqdvynbcwd7n88mhzjujkusrhjot7wccarmtgeij6tku
8nwt9bvjr4jvkz2eqnd0kzwdqpukeynpclldekixyaqx
```

następnie doczytaliśmy trochę na temat kodowania ans1 der ( https://en.wikipedia.org/wiki/abstract_syntax_notation_one#example_encoded_in_der ) oraz na temat zawartości klucza prywatnego rsa w podanym formacie.
wygląda na to że cały klucz zawiera:

```
rsaprivatekey ::= sequence {
  version           version,
  modulus           integer,  -- n
  publicexponent    integer,  -- e
  privateexponent   integer,  -- d
  prime1            integer,  -- p
  prime2            integer,  -- q
  exponent1         integer,  -- d mod (p-1)
  exponent2         integer,  -- d mod (q-1)
  coefficient       integer,  -- (inverse of q) mod p
  otherprimeinfos   otherprimeinfos optional
}
```

a sama ekstracja danych jest dość prosta - znajdujemy bajt `02` który oznacza początek integera a następny bajt oznacza liczbę bajtów składajacych się na liczbę.
przytowaliśmy więc prosty skrypt:

```python
def get_dp_dq_qinv(key64):
    result = []
    key_tab = list(b64decode(key64))
    print(key_tab)
    i = 0
    while i < len(key_tab):
        x = key_tab[i]
        if x == 0x2:  # integer start
            length = key_tab[i + 1]
            octets = key_tab[i + 2: i + 2 + length]
            value = int.from_bytes(octets, byteorder="big")
            result.append(value)
            print(value)
            i += 2 + length
        else:
            i += 1
    return tuple(result)


dp, dq, qinv = get_dp_dq_qinv(key64)
```

który dał nam 3 integery, które (zgodnie z formatem klucza prywatnego) oznaczają dp, dq i qinv.

dp = 11188888442779478492506783674852186314949555636014740182307607993518479864690065244102864238986781155531033697982611187514703037389481147794554444962262361

dq = 1006725509429627901220283238134032802363853505667837273574181077068133214344166038422298631614477333564791953596600001816371928482096290600710984197710579

qinv = 11196804284042107547423407831525890933636414684075355664222816007929037065463409676450144484947842399975707117057331864113464711778199061912128258484839473

znamy też co prawda część niskich bajtów czynnika pierwszego `q`, ale nie jest nam to potrzebne.
postępujemy zgodnie z algorytmem zaproponowanym w https://eprint.iacr.org/2004/147.pdf i implementujemy algorytm odzyskiwania klucza:

```python
def recover_parameters(dp, dq, qinv, e):
    results = []
    d1p = dp * e - 1
    for k in range(3, e):
        if d1p % k == 0:
            hp = d1p // k
            p = hp + 1
            if is_prime(p):
                d1q = dq * e - 1
                for m in range(3, e):
                    if d1q % m == 0:
                        hq = d1q // m
                        q = hq + 1
                        if is_prime(q):
                            if (qinv * q) % p == 1 or (qinv * p) % q == 1:
                                results.append((p, q, e))
                                print(p, q, e)
    return results
```

który zwraca jedno rozwiązanie:

p= 12883429939639100479003058518523248493821688207697138417834631218638027564562306620214863988447681300666538212918572472128732943784711527013224777474072569 

q = 12502893634923161599824465146407069882228513776947707295476805997311776855879024002289593598657949783937041929668443115224477369136089557911464046118127387

e = 65537

i teraz pozostaje już tylko odzyskać wykładnik deszyfrujący `d` przez standardoy algorytm egcd i odkodować rsa:

```python
def egcd(a, b):
    u, u1 = 1, 0
    v, v1 = 0, 1
    while b:
        q = a // b
        u, u1 = u1, u - q * u1
        v, v1 = v1, v - q * v1
        a, b = b, a - q * b
    return u


def get_d(p, n, e):
    q = n / p
    phi = (p - 1) * (q - 1)
    d = egcd(e, phi)
    if d < 0:
        d += phi
    return d


with open("flag.enc", "rb") as input_file:
    n = p * q
    data = input_file.read()
    ct = bytes_to_long(data)
    d = get_d(p, n, e)
    pt = pow(ct, d, n)
    print("pt: " + long_to_bytes(pt))
```

co daje nam: `0ctf{keep_ca1m_and_s01ve_the_rsa_eeeequati0n!!!}`
