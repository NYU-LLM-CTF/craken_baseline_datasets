# writeup defcamp ctf quals 2016

team: psrok1, seikendev, c7f.m0d3, cr019283, nazywam, rev, msm, akrasuski1, shalom


[image extracted text: web
revcrypt
exploit
misc
web 100(27)
revcrypt 100(76)
exploit 100(67)
misc 100(9)
web 200(83)
revcrypt 200(9)
exploit 200(59)
misc 150(13)
web 300(26)
revcrypt 300(15)
exploit 300(6)
misc 200(11)
web 400(4)
revcrypt 400(1)
exploit 400(0)
misc
400(3)]



[image extracted text: 2   3  4  5  6  7 | 8
17
18
4000
3750
3500
3250
3000
2750
2500
2250
2000
1750
500
250
1000
750
500
250
6
6
6
6
6
6
6
6
6
6
6
6
6
6
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8
8]


### table of contents

* [f4ceb00k 60s (web 100)](web100)
* [url anonymizer (web 200)](web200)
* [bad otpxploited (revcrypt 100)](revcrypt100)
* [rucksack  (revcrypt 200)](revcrypt200)
* [decoy (revcrypt 300)](revcrypt300)
* [dctfizer (revcrypt 400)](revcrypt400)
* [warm heap (exploit 100)](exp100)
* [the nospecial virus (misc 100)](misc100)
* [b4s14l (misc 150)](misc150)
* [musicetry (misc 200)](musicetry_misc_200)
* [evil farmers (misc 400)](misc400)
