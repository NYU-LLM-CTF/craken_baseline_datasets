## rsa? (crypto, 2p)
	
###eng
[pl](#pl-version)

we get a ciphertext that seems to be encrypted via rsa from openssl commandline.
we also have access to the public key, and therefore we proceed like with standard rsa cipher, by recovering parameters:

`e = 3`

`n = 23292710978670380403641273270002884747060006568046290011918413375473934024039715180540887338067`

and using yafu we factor the modulus into:

`p = 26440615366395242196516853423447`

`q = 27038194053540661979045656526063`

`r = 32581479300404876772405716877547`

we get 3 prime numbers. this is still fine, this could simply be multiprime rsa. 
there is nothing fancy about it, the totient is simply `(p-1)(q-1)(r-1)` and rest of the calculation goes as usual.
but it doesn't, because we find that modular multiplicative inverse does not exist. 
reason for this is apparent: `gcd(e, totient) = 3` and it should be 1.
this is not the first time we encounter similar case (see https://github.com/p4-team/ctf/tree/master/2015-10-18-hitcon/crypto_314_rsabin#eng-version ) so we have some idea of how to approach this.

we need to get rid of this 3 before we could apply rsa decoding.
this means the encryption is:

`ciphertext = plaintext^e mod n = (plaintext^e')^3 mod n`

so if we could peform a modular cubic root (mod n) of both sides of the equation we could then apply rsa decoding with `e' = e/3`.
here is't even easier since `e=3` and therefore `e' = e/3 = 1` which means our encryption is simply:

`ciphertext = plaintext^3 mod n`

so the whole decryption requires modular cubic root (mod n) from ciphertext.

some reading about modular roots brings us to conclusion that it's possible to do, but only in finite fields.
so it can't be done for `n` that is a composite number, which we know it is since it's `p*q*r`.

this problem brings to mind chinese reminder theorem ( https://en.wikipedia.org/wiki/chinese_remainder_theorem )
we consider this for a while and we come up with the idea that if we could calculate cubic modular root from ciphertext (mod prime) for each of our 3 primes, we could then calcualte the combined root.
we can to this with gauss algorithm ( http://www.di-mgt.com.au/crt.html#gaussalg )

so we proceed and calculate:

`pt^3 mod p = ciperhtext mod p = 20827907988103030784078915883129`

`pt^3 mod q = ciperhtext mod q = 19342563376936634263836075415482`

`pt^3 mod r = ciperhtext mod r = 10525283947807760227880406671000`

and then it took us a while to come up with solving this equations for pt (publications mention only some special cases for those roots...)
finally we figured that wolframalpha had this implemented, eg:

http://www.wolframalpha.com/input/?i=x^3+%3d+20827907988103030784078915883129+%28mod+26440615366395242196516853423447%29

this gives us a set of possible solutions:

```python
roots0 = [5686385026105901867473638678946, 7379361747422713811654086477766, 13374868592866626517389128266735]
roots1 = [19616973567618515464515107624812]
roots2 = [6149264605288583791069539134541, 13028011585706956936052628027629, 13404203109409336045283549715377]
```

we apply gauss algoritm to those roots:

```python
def extended_gcd(aa, bb):
    lastremainder, remainder = abs(aa), abs(bb)
    x, lastx, y, lasty = 0, 1, 1, 0
    while remainder:
        lastremainder, (quotient, remainder) = remainder, divmod(lastremainder, remainder)
        x, lastx = lastx - quotient * x, x
        y, lasty = lasty - quotient * y, y
    return lastremainder, lastx * (-1 if aa < 0 else 1), lasty * (-1 if bb < 0 else 1)

def modinv(a, m):
    g, x, y = extended_gcd(a, m)
    if g != 1:
        raise valueerror
    return x % m

def gauss(c0, c1, c2, n0, n1, n2):
    n = n0 * n1 * n2
    n0 = n / n0
    n1 = n / n1
    n2 = n / n2
    d0 = modinv(n0, n0)
    d1 = modinv(n1, n1)
    d2 = modinv(n2, n2)
    return (c0*n0*d0 + c1*n1*d1 + c2*n2*d2) % n

roots0 = [5686385026105901867473638678946, 7379361747422713811654086477766, 13374868592866626517389128266735]
roots1 = [19616973567618515464515107624812]
roots2 = [6149264605288583791069539134541, 13028011585706956936052628027629, 13404203109409336045283549715377]


for r0 in roots0:
    for r1 in roots1:
        for r2 in roots2:
            m = gauss(r0, r1, r2, p, q, r)
            print long_to_bytes(m)
```

which gives us the flag for one of the combinations: `0ctf{haha!thi5_1s_n0t_rsa~}`

###pl version

dostajemy zaszyfrowany tekst oraz informacje która wskazywałaby że szyfrowano go za pomocą rsa przy pomocy openssl.
dostajemy także klucz publiczny, więc postępujemy tak jak w klasycznym rsa, zaczynając od odzyskania parametrów klucza:

`e = 3`

`n = 23292710978670380403641273270002884747060006568046290011918413375473934024039715180540887338067`

a za pomocą yafu dokonujemy faktoryzacji modulusa:

`p = 26440615366395242196516853423447`

`q = 27038194053540661979045656526063`

`r = 32581479300404876772405716877547`

dostajemy 3 liczby pierwsze. to jeszcze nie problem, to może nadal być zwykłe rsa oparte o wiele liczb pierwszych (multiprime rsa).
nie ma tu nic skomplikowanego, po prostu funkcja totien to teraz `(p-1)(q-1)(r-1)` a cała reszta obliczeń postępuje tak jak zawsze.
niestety nie w tym przypadku - okazuje sie że modinv nie istnieje.
powód jest dość oczywisty: `gcd(e, totient) = 3` a powinien wynosić 1.
to nie pierwszy raz kiedy spotykamy się z podobną sytuacją (patrz: https://github.com/p4-team/ctf/tree/master/2015-10-18-hitcon/crypto_314_rsabin#eng-version ) więc mamy pewne pojęcie jak dalej postępować.

potrzebujemy pozbyć się tej 3 zanim będziemy mogli dekodować rsa.
to oznacza że nasze szyfrowanie to:

`ciphertext = plaintext^e mod n = (plaintext^e')^3 mod n`

więc jeśli wykonamy pierwiastkowanie trzeciego stopnia (modulo n) obu stron równania, dostaniemy wartość którą będzie można zdekodować przy użyciu rsa dla `e' = e/3`.
w naszym przypadku jest nawet prościej bo `e = 3` więc `e' = e/3 = 1` co oznacza że szyfrowanie to tutaj po prostu:

`ciphertext = plaintext^3 mod n`

więc cała operacja deszyfrowania wymaga jedynie pierwiastka trzeciego stopnia (mod n) z tekstu zaszyfrowanego.

trochę czytania na temat pierwiastkowania modularnego pozwala nam stwierdzić, że taka operacja jest możliwa w zasadzie tylko dla ciał skończonych (finite field). więc w szczególności nie może być wykonane dla naszego `n`, które jest liczbą złożoną bo wiemy, że wynosi `p*q*r`.

ten problem przywodzi na myśl chińskie twierdzenie o resztach ( https://en.wikipedia.org/wiki/chinese_remainder_theorem )
po rozważeniu tego problemu przez pewien czas, doszliśmy do wniosku, że jeśli możemy policzyć pierwiastek trzeciego stopnia (mod liczba pierwsza) dla każdej z naszych 3 liczb, będziemy mogli wyliczyć też pierwiastek złożony.
możemy to zrobić przy użyciu algorytmu gaussa ( http://www.di-mgt.com.au/crt.html#gaussalg ).

przystępujemy więc do działania i wyliczamy:

`pt^3 mod p = ciperhtext mod p = 20827907988103030784078915883129`

`pt^3 mod q = ciperhtext mod q = 19342563376936634263836075415482`

`pt^3 mod r = ciperhtext mod r = 10525283947807760227880406671000`

wyliczenie tych pierwiastków zajęło nam trochę czasu ponieważ wiekszość publikacji wspomina jedynie o metodach pierwiastkowania mających zastosowanie dla wąskiego grona przypadków.
w końcu wpadliśmy na pomysł, że wolframalpha ma to już zaimplementowane:

http://www.wolframalpha.com/input/?i=x^3+%3d+20827907988103030784078915883129+%28mod+26440615366395242196516853423447%29

to daje nam potencjalne zbiory rozwiązań:

```python
roots0 = [5686385026105901867473638678946, 7379361747422713811654086477766, 13374868592866626517389128266735]
roots1 = [19616973567618515464515107624812]
roots2 = [6149264605288583791069539134541, 13028011585706956936052628027629, 13404203109409336045283549715377]
```

stosujemy algorytm gaussa dla tych pierwiastków:

```python
def extended_gcd(aa, bb):
    lastremainder, remainder = abs(aa), abs(bb)
    x, lastx, y, lasty = 0, 1, 1, 0
    while remainder:
        lastremainder, (quotient, remainder) = remainder, divmod(lastremainder, remainder)
        x, lastx = lastx - quotient * x, x
        y, lasty = lasty - quotient * y, y
    return lastremainder, lastx * (-1 if aa < 0 else 1), lasty * (-1 if bb < 0 else 1)

def modinv(a, m):
    g, x, y = extended_gcd(a, m)
    if g != 1:
        raise valueerror
    return x % m

def gauss(c0, c1, c2, n0, n1, n2):
    n = n0 * n1 * n2
    n0 = n / n0
    n1 = n / n1
    n2 = n / n2
    d0 = modinv(n0, n0)
    d1 = modinv(n1, n1)
    d2 = modinv(n2, n2)
    return (c0*n0*d0 + c1*n1*d1 + c2*n2*d2) % n

roots0 = [5686385026105901867473638678946, 7379361747422713811654086477766, 13374868592866626517389128266735]
roots1 = [19616973567618515464515107624812]
roots2 = [6149264605288583791069539134541, 13028011585706956936052628027629, 13404203109409336045283549715377]


for r0 in roots0:
    for r1 in roots1:
        for r2 in roots2:
            m = gauss(r0, r1, r2, p, q, r)
            print long_to_bytes(m)

```

co daje nam flagę dla jednej z kombinacji: `0ctf{haha!thi5_1s_n0t_rsa~}`
