## hidden in plain sight (forensics)
	tl;dr read the file before it's been decrypted

in this task, we're only given a mega download link.(https://mega.nz/#!6n0gmrlk!vsn9gldiybxmvta-adsrjsvezmpdeqir9ngwrs6gr7k)

the hint is: `you need to know the basic principle behind how mega works in order to solve this challenge. flag.txt is the flag, but it is hidden... in plain sight ;)`

mega doesn't store keys to decrypt your data, you are given them with the url, in our case it's `adsrjsvezmpdeqir9ngwrs6gr7k`. the files are download to a sandbox using *filesystem api*.

after the download is complete, the file is then decrypted using aes and passed to the normal download folder.

the downloaded flag looks like gibberish: `}żv#ęö›{qřčxjzzń\m÷2ž¸ić&n˛<­z´ŕ´„ľĺ*‹—ýk/ăăµ`

let's then try viewing the flag before it's been decrypted by using chrome developer tools.


[image extracted text: polski
logowanie
utworz konto
menu
50 gb za darmo
utworz swoje konto
megasync: latwa i zautomatyzowana
aplikacje mobilne: chmura
twojej
synchronizacja danych pomiedzy
kieszeni. udostepniaj pliki ze swojego
komputerami
twoim mega dyskiem_
telefonu lub tableta _
flag txt
53 b
100 %
zakonczone
elements
console
sources
network
timeline
profiles
resources
security
audits
https everywhere
editthiscookie
viev:
preserve log
disable cache
no throttling
filter
fide data url:
xhr
css
media
font
doc
ws
manifest
other
iooc ne
jooo ms
6on2 ms
3690ms
iocon ms
120cm
140c0 m
16d00 m}
18020 m}
name
headers
preview | response
timing
clid=-237363608-&&lang-pl&domain=meganz
ctf-br{o_club3_
c0s7um-_u54r_crypte_
mas
nem_sempre}
0-32
decrypterjs
aesasmjs
sync-clent gif
mobi
~ppgif
mobil
~sprite-ve pnglv=l
requests
25.1 kb transferred
im9]


bingo!