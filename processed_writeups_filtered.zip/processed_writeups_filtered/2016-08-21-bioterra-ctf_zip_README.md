# zip (300, coding)

> we found a strange zip file. sadly the content is encrypted. as only criminals encrypt their stuff we need to decrypt this urgently.
> flag format is flagb**************s.

in this task we got a zip file containing a couple of other small zip files. all of them were encrypted, but their size
was only up to 5 bytes - just like in recent 
[backdoor ctf task](https://github.com/p4-team/ctf/tree/master/2016-06-04-backdoor-ctf/crypto_crc). see that writeup for
details.

after decrypting, this is what we got:

```
1 main(
2 ){int
3 n=24
4 ;whil
5 e(n--
6 ){put
7 char(
8 
9 
10 ]^n);
11 }}
```
files 8 and 9 were missing. however, basing on flag format from task description, we could guess what should go in these
empty places:
```
in [1]: s="flagb"

in [2]: for i, c in zip(range(23,0,-1), s):
   ...:     print chr(ord(c)^i)
   ...:     
q
z
t
s
q
```
it might be a bit of guess, but we see that the last letter is the same as the first one, indicating period equal to 4.
if we put `"stzq` in file 8, and `"[n%4` in file 9, then both files have size equal to 5, just like the others, and
the output of compiled program matches flag format.
```
main(){int n=24;while(n--){putchar("stzq"[n%4]^n);}}
// prints flagbhec^ty_zp][v\qwrxus
```
