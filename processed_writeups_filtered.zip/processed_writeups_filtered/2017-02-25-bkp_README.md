# writeup boston key party 2017

team: c7f.m0d3, cr01283, akrasuski1, nazywam, shalom, msm, rev

### table of contents

* [rsa buffet(crypto)](rsa_buffet)
* [vimjail (pwn)](vimjail)
* [artisinal shoutboxes (web)](cloud_200_artisinal_shoutboxes)
* [minesweeper (crypto)](minesweeper)
* [signed shell server (pwn)](signed_shell_server)
* [slow (re)](slow)
* [sponge (crypto)](sponge)
