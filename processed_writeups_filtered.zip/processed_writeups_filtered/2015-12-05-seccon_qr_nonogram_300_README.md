##qr puzzle (nonogram) (misc, 300p)

>solve a puzzle 30 times  
>http://qrlogic.pwn.seccon.jp:10080/game/

###pl
[eng](#eng-version)

zadanie było proste: dostajemy losowo wygenerowany nonogram, rozwiązujemy go otrzymując qrcode, dekodujemy go i przechodzimy do następnej rundy. jeżeli uda nam się dotrzeć do końca to otrzymujemy flagę.


[image extracted text: stage
answee
submit]


sama gra nie jest tutaj bardzo ważna: miało dla nas znaczenie tylko to, że było dostępnych kilka gotowych solverów. losowo użyliśmy tego: http://jwilk.net/software/nonogram.

jako że było sporo rund zdecydowaliśmy się napisać w pełni automatyczny solver. pierwszym zadaniem było sparsowanie strony i pobranie liczb nonogramu.

```python
import requests
from bs4 import beautifulsoup
import re

session = requests.session()

source = session.post('http://qrlogic.pwn.seccon.jp:10080/game/').content
soup = beautifulsoup(source)

print re.findall('stage: (\d+) / 30', source)

def parse(cls):
	return [[span.contents[0] for span in th.find_all('span')] for th in soup.find_all('th', class_=cls)]

rows = parse('rows')
cols = parse('cols')
```

następna część to przekazanie tych danych do faktycznego solvera:

```python
from pwn import *

solver = process('nonogram-0.9/nonogram')
solver.sendline("%d %d" % (len(cols), len(rows)))

for row in rows:
	solver.sendline(' '.join(row))

for col in cols:
	solver.sendline(' '.join(col))

solver.shutdown()
```

i otrzymanie wyniku:

```python
qr_text = []
for i in range(0, len(rows)):
	solver.recvuntil('|')
	qr_text.append(solver.recvuntil('|')[:-1])
```

który na tym etapie wyglądał tak:


[image extracted text: ##########
######
##############
######
######
######
######
######
####
######
######
######
##############
##############
#####iiiri
######
####
########
####
######
######
######
####
####
######
####
######
########
####
####
##############
########
####
####
############
######
####
####
######
####
######
######
####
########
########
##############
########
######]


to tekst, a my musimy skonwertować go na faktyczny obrazek z qrcode:

```python
from pil import image, imagedraw

size = 20
image = image.new('rgb', ((len(qr_text) * size), (len(qr_text[0]) * size) / 2))
draw = imagedraw.draw(image)

for i in range(0, len(qr_text)):
	for j in range(0, len(qr_text[0]) / 2):
		pos = ((j * size, i * size), (j * size + size, i * size + size))
		draw.rectangle(pos, 'black' if qr_text[i][j * 2] == '#' else 'white')

image.save('qrcode.png')
```

możemy go teraz przeczytać:

```python
import qrtools

qr = qrtools.qr()
qr.decode('qrcode.png')
return qr.data
```

wysłać i powtórzyć cały proces.
```python
answer = ''
for i in range(0, 100):
    get_image(answer)
    answer = get_qrcode()
    print answer
```

solver nie był idealny - musieliśmy go uruchomić kilka razy, ale po kilku minutach otrzymaliśmy flagę.

`seccon{yes_we_really_love_qr_code_because_of_its_clever_design}`

### eng version

task details are simple: we get a randomly generated nonogram, we solve it and with that get a qr code, we decode it and get to the next round. if we manage to get to the end we're given the flag.


[image extracted text: stage
answee
submit]


the game itself isn't very important here: all that mattered to us was that there were several solvers available. we randomly chose this one: http://jwilk.net/software/nonogram.

as there were many stages we opted in for a fully automated solver. first task was to parse the webpage and get the nonogram numbers.

```python
import requests
from bs4 import beautifulsoup
import re

session = requests.session()

source = session.post('http://qrlogic.pwn.seccon.jp:10080/game/').content
soup = beautifulsoup(source)

print re.findall('stage: (\d+) / 30', source)

def parse(cls):
	return [[span.contents[0] for span in th.find_all('span')] for th in soup.find_all('th', class_=cls)]

rows = parse('rows')
cols = parse('cols')
```

next part was to pass these to the actual solver:

```python
from pwn import *

solver = process('nonogram-0.9/nonogram')
solver.sendline("%d %d" % (len(cols), len(rows)))

for row in rows:
	solver.sendline(' '.join(row))

for col in cols:
	solver.sendline(' '.join(col))

solver.shutdown()
```

and get the result:

```python
qr_text = []
for i in range(0, len(rows)):
	solver.recvuntil('|')
	qr_text.append(solver.recvuntil('|')[:-1])
```

which at this point looked like this:


[image extracted text: ##########
######
##############
######
######
######
######
######
####
######
######
######
##############
##############
#####iiiri
######
####
########
####
######
######
######
####
####
######
####
######
########
####
####
##############
########
####
####
############
######
####
####
######
####
######
######
####
########
########
##############
########
######]


that's text and we need to convert it to a proper qrcode image:

```python
from pil import image, imagedraw

size = 20
image = image.new('rgb', ((len(qr_text) * size), (len(qr_text[0]) * size) / 2))
draw = imagedraw.draw(image)

for i in range(0, len(qr_text)):
	for j in range(0, len(qr_text[0]) / 2):
		pos = ((j * size, i * size), (j * size + size, i * size + size))
		draw.rectangle(pos, 'black' if qr_text[i][j * 2] == '#' else 'white')

image.save('qrcode.png')
```

we can now read it:

```python
import qrtools

qr = qrtools.qr()
qr.decode('qrcode.png')
return qr.data
```

send it and repeat the whole process:
```python
answer = ''
for i in range(0, 100):
    get_image(answer)
    answer = get_qrcode()
    print answer
```

the solver wasn't perfect: we had to rerun it several times, but after few minutes we got the flag.

`seccon{yes_we_really_love_qr_code_because_of_its_clever_design}`
