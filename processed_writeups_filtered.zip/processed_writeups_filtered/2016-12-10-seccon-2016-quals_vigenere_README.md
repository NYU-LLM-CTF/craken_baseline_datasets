# vigenere (crypto 100)

###eng
[pl](#pl-version)

in the task we get a ciphertext:

```
lmig}rpedoeewkjiqiwkjwmndtsr}tfvufwyocbajbq
```

and information that this is vigener cipher with alphabet:

```
abcdefghijklmnopqrstuvwxyz{}
```

and the md5 of plaintext is `f528a6ab914c1ecf856a1d93103948fe`

we of course know the flag prefix `seccon{` so we can instantly recover the prefix of the key:

```python
def get_key_prefix(alphabet, ct, known_pt):
    result = ""
    for i in range(len(known_pt)):
        plain = known_pt[i]
        cipher = ct[i]
        key = alphabet[alphabet.index(cipher) - alphabet.index(plain)]
        result += key
    return result
```

which gives us `vigener`

next we can just brute-force the missing 4 bytes of the key:

```python
def decode(alphabet, ct, key):
    result = ""
    for i in range(len(ct)):
        c = ct[i]
        k = key[i % len(key)]
        if k != "?":
            p = alphabet[alphabet.index(c) - alphabet.index(k)]
        else:
            p = "?"
        result += p
    return result


def worker(data):
    c, alphabet, ct, key = data
    key += c
    for suffix in itertools.product(alphabet, repeat=4):
        new_key = key + "".join(suffix)
        pt = decode(alphabet, ct, new_key)
        if hashlib.md5(pt).hexdigest() == "f528a6ab914c1ecf856a1d93103948fe":
            print(pt)
            return pt


def main():
    alphabet = "abcdefghijklmnopqrstuvwxyz{}"
    ct = "lmig}rpedoeewkjiqiwkjwmndtsr}tfvufwyocbajbq"
    key_prefix = get_key_prefix(alphabet, ct, "seccon{")
    print('key prefix ', key_prefix)
    print(brute(worker, [(c, alphabet, ct, key_prefix) for c in alphabet]))


if __name__ == '__main__':
    freeze_support()
    main()
```

which gives us almost instantly `seccon{abababcdedefghijjklmnopqrsttuvwxyyz}`

###pl version

w zadaniu dostajemy zaszyfrowany tekst:

```
lmig}rpedoeewkjiqiwkjwmndtsr}tfvufwyocbajbq
```

i informacje że to szyfr vigenera z alfabetem:

```
abcdefghijklmnopqrstuvwxyz{}
```

mamy też md5 plaintextu: `f528a6ab914c1ecf856a1d93103948fe`

i oczywiście znamy prefix flagi `seccon{` więc możemy od razu odzyskać prefix klucza:

```python
def get_key_prefix(alphabet, ct, known_pt):
    result = ""
    for i in range(len(known_pt)):
        plain = known_pt[i]
        cipher = ct[i]
        key = alphabet[alphabet.index(cipher) - alphabet.index(plain)]
        result += key
    return result
```

co daje nam `vigener`

następnie możemy brute-forcować brakujące 4 bajty klucza:

```python
def decode(alphabet, ct, key):
    result = ""
    for i in range(len(ct)):
        c = ct[i]
        k = key[i % len(key)]
        if k != "?":
            p = alphabet[alphabet.index(c) - alphabet.index(k)]
        else:
            p = "?"
        result += p
    return result


def worker(data):
    c, alphabet, ct, key = data
    key += c
    for suffix in itertools.product(alphabet, repeat=4):
        new_key = key + "".join(suffix)
        pt = decode(alphabet, ct, new_key)
        if hashlib.md5(pt).hexdigest() == "f528a6ab914c1ecf856a1d93103948fe":
            print(pt)
            return pt


def main():
    alphabet = "abcdefghijklmnopqrstuvwxyz{}"
    ct = "lmig}rpedoeewkjiqiwkjwmndtsr}tfvufwyocbajbq"
    key_prefix = get_key_prefix(alphabet, ct, "seccon{")
    print('key prefix ', key_prefix)
    print(brute(worker, [(c, alphabet, ct, key_prefix) for c in alphabet]))


if __name__ == '__main__':
    freeze_support()
    main()
```

co od razu daje nam `seccon{abababcdedefghijjklmnopqrsttuvwxyyz}`
