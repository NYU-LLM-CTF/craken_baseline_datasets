#old times(rev, 100 points, solved by 174)

we're given a ibm as/400 save file. use [the program](http://www.juliansoft.com/), get the flag: `eko{0ld_t1m3s_n3v3r_c0m3_b4ck}`