# fibonacci (ppc 400)

###eng
[pl](#pl-version)

the task is pretty simple.
the server asks us how many recursions we need to compute n-th fibonacci number (using recursive algorithm).
for some reason we could spend 25s on each question, which was a bit silly considering we could just pre-compute the results instantly in a fraction of a second.

we can compute this using a dynamic algorithm.
first two fibonacci numbers require 0 recursions, and k-th number require as many recursions as calculating k-2-th number + 1 (1 because we are calling fib(k-2)), plus calculating k-1-th number plus 1 (again 1 because we are calling fib(k-1)).
and we can compute this iteratively from the bottom.
so in general:

```python
calls = [0, 0] + [0] * (n + 1)
for i in range(2, n + 1):
	calls[i] = calls[i - 1] + calls[i - 2] + 2
```

we started by pre-computing results for the first 1000 numbers, but this as already an overkill because the largest tests were less than 500.
running this on 100 tests gives the flag: `3ds{g00d4lgorithmsc4nsaveyourtime}`

###pl version

zadanie było dość proste.
serwer pytał ile wywołań rekurencyjnych potrzeba zeby policzyć n-tą liczbę fibonacciego (używając algorytmu rekurencyjnego).
z jakiegoś powodu mogliśmy użyć aż 25s na jedno pytanie, co było dość dziwne biorąc pod uwagę że można było wyliczyć sobie wcześniej tablicę rozwiązań w ułamku sekundy.

możemy policzyć rozwiązanie algorytmem dynamicznym.
pierwsze dwie liczby wymagają 0 rekurencji a k-ta liczba wymaga tyle rekurencji ile policzenie liczby k-2 plus 1 (1 bo wywołujemy fib(k-2)), plus ile policzenie liczby k-1 plus 1 (znowu 1 bo wywyłujemy fib(k-1)).
czyli generalnie:

```python
calls = [0, 0] + [0] * (n + 1)
for i in range(2, n + 1):
	calls[i] = calls[i - 1] + calls[i - 2] + 2
```

zaczęliśmy przez wyliczenie rozwiazań dla pierwszego 1000 liczb bo okazało się przeszacowaniem, ponieważ największy test miał nie więcej niż 500.
uruchomienie tego dla 100 testów dało nam flagę: `3ds{g00d4lgorithmsc4nsaveyourtime}`
