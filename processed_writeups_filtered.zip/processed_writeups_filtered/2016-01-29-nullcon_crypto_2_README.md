﻿##caesar (crypto, 400p)

	some one was here, some one had breached the security and had infiltrated here. 
	all the evidences are touched, logs are altered, records are modified with key as a text from book.
	the operation was as smooth as caesar had conquested gaul. 
	after analysing the evidence we have some extracts of texts in a file. 
	we need the title of the book back, but unfortunately we only have a portion of it...

###pl
[eng](#eng-version)

dostajemy [plik](the_extract.txt) a z treści zadania wynika, że może być on szyfrowany za pomocą szyfru cezara.
uruchamiamy więc prosty skrypt:

```python
import codecs

with codecs.open("the_extract.txt") as input_file:
    data = input_file.read()
    for i in range(26):
        text = ""
        for x in data:
            c = ord(x)
            if ord('a') <= c < ord('z'):
                text += chr((c - ord('a') + i) % 26 + ord('a'))
            elif ord('a') <= c < ord('z'):
                text += chr((c - ord('a') + i) % 26 + ord('a'))
            else:
                text += chr(c)
        print(text)
```

który wypisuje wszystkie możliwe dekodowania, wśród których mamy:

	dr. sarah tu races against time to block the most dangerous internet malware ever created, a botnet called qualnto. while sarah is closed off in her comzuter lab, her sister, hanna, is brutally attacked and left in a coma. as sarah reels with guilt over not being there for her sister, a web of deceztion closes in, threatening her and everyone she loves.

	hanna’s condition is misleading. in her coma state, she is able to build a zsychic bridge with fbi szecial agent jason mcneil. her cryztic messages zlague jason to keez sarah safe.

	tough and street-smart jason mcneil doesn’t believe in visions or telezathic messages, and he fights the voice inside his head. his first imzression of dr. sarah tu is another stiletto wearing ice-dragon on the war zath―until he witnesses her façade crumble after seeing her sister’s bloody, tortured body. jason’s zrotective instinct kicks in. he falls for sarah―hard. 

	when an extremenly dangerous arms dealer and cybercriminal discovers that sarah blocked his botnet, he kidnzs sarah. zlaced in an imzossible zosition, will she destroy the botnet to zrotect national security or release it to save the man she loves

pochodzące z książki `in the shadow of greed` co jest flagą.
	
###eng version

we get a [file](the_extract.txt) and the task description suggests that the encryption is caesar.
therefore we run a simple script:

```python
import codecs

with codecs.open("the_extract.txt") as input_file:
    data = input_file.read()
    for i in range(26):
        text = ""
        for x in data:
            c = ord(x)
            if ord('a') <= c < ord('z'):
                text += chr((c - ord('a') + i) % 26 + ord('a'))
            elif ord('a') <= c < ord('z'):
                text += chr((c - ord('a') + i) % 26 + ord('a'))
            else:
                text += chr(c)
        print(text)
```

which prints all possible decryptions where we can find:

	dr. sarah tu races against time to block the most dangerous internet malware ever created, a botnet called qualnto. while sarah is closed off in her comzuter lab, her sister, hanna, is brutally attacked and left in a coma. as sarah reels with guilt over not being there for her sister, a web of deceztion closes in, threatening her and everyone she loves.

	hanna’s condition is misleading. in her coma state, she is able to build a zsychic bridge with fbi szecial agent jason mcneil. her cryztic messages zlague jason to keez sarah safe.

	tough and street-smart jason mcneil doesn’t believe in visions or telezathic messages, and he fights the voice inside his head. his first imzression of dr. sarah tu is another stiletto wearing ice-dragon on the war zath―until he witnesses her façade crumble after seeing her sister’s bloody, tortured body. jason’s zrotective instinct kicks in. he falls for sarah―hard. 

	when an extremenly dangerous arms dealer and cybercriminal discovers that sarah blocked his botnet, he kidnzs sarah. zlaced in an imzossible zosition, will she destroy the botnet to zrotect national security or release it to save the man she loves

coming from `in the shadow of greed` book, which is the flag.
