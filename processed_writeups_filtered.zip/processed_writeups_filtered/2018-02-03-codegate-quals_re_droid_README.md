# welcome to droid (re, 635p, 24 solved)

[pl](#pl-version)

in the task we get [android application](droid.apk) to work with.
once we reverse the sources, it seems we need to pass some checks to reach the flag.
however one of the checks is:

```java
public string m4832k() {
	char[] carr = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	stringbuffer stringbuffer = new stringbuffer();
	random random = new random();
	for (int i = 0; i < 20; i++) {
		stringbuffer.append(carr[random.nextint(carr.length)]);
	}
	return stringbuffer.tostring();
}
```

and sice it's using random values, it's very unlikely we can pass it.
we could try to patch the code, but it's a lot of fuss.
if we could pass all the checks the code that shows the flag is:

```java
this.f3092l = (edittext) findviewbyid(r.id.edittext);
this.f3092l.settext(stringfromjni());
```

so it calls a single function from the native library shipped with the app.
the function is pretty much unreversable, way to complex, but we don't need that.
we can simply load this library and call the function, without all silly checks!

in order to do that we create a new android project (we actually used ndk example) with android studio, create a new activity, but keeping all the names and packages the same, and write code:

```java
package com.example.puing.a2018codegate;

import android.support.v7.app.appcompatactivity;
import android.os.bundle;
import android.widget.textview;

import java.util.logging.logger;

public class main4activity extends appcompatactivity {
    static {
        system.loadlibrary("hello-libs");
    }

    @override
    protected void oncreate(bundle savedinstancestate) {
        super.oncreate(savedinstancestate);
        textview tv = new textview(this);
        string flagstring = stringfromjni();
        tv.settext(flagstring);
        setcontentview(tv);
        logger.getlogger("flaglogger").info(flagstring);
    }

    public native string stringfromjni();
}
```

we modify the build.gradle for libs to include our .so files:

```
sourcesets {
	main {
		// let gradle pack the shared library into apk
		jnilibs.srcdirs = ['../distribution/gperf/lib', '../distribution/droid/lib']
	}
}
```

and we're good to go.
we can just run the app and get:


[image extracted text: app
stc
main
java
com
example
puing
a2018codegate
main4activity
oid
main4activity java
main4activity
oncreate()
android emulator
nexus_sx_api_27_x86.5554
manifests
package
com. example
puing
a2018codegate
java
com example puing.a2o18codegate
import android support
77
app
appcompa
import
android
bundle;
main4activity
import
android
widget
textview;
0 3.-03
cpp
inilibs
ort
java
util
logging.logger;
hello-libs
res
wolll awesomell flag{w3
back_70_s3v3n7eenll}
adle scripts
public
class main4activity
extends appc
nahahahll
static
build gradle (project: hello-libs)
system
loadbibrary
libname:
"hell
build gradle (module: app)
gradle-wrapper properties (gradle versic 13
proguard-rules pro (proguard
for
@override
gradle properties (project properties)
protected
void
oncreate (bundle
saver
settings gradle (project settings)
super
oncreate (savedinstancesta
@
textview
new textview
conte
local properties (sdk location)
string flagstring
stringfromji
ternal build files
tv
settext (flaggtring)
setcontentview (tv)
main4activity
03/12
20:02:40: launching main4activity
adb
shell
am
start
com.example.hellolibs/com-example-puing
a2018codega
tent
categ
client
not
ready
waiting
for
proce3s
come
online
connected
process
4139
device
emulator
5554
capturing
and
displaying
logcat
me33ages
from
application.
this
behavior
can
settings
ilinstantrun:
starting
instant
run
server:
13 main
process
i/flaglogger:
wol
awesome
flag {w3
w3r3
back
53v3n7een
hahahah !
dl openglrenderer:
hwui
gl
pipeline
ilzygote:
android::hardware:
configstore::vl
0::isurfacerlingerconfigs::haswi
ilopenglrenderer:
initialized egl,
version
1.4
d/ openglrenderer:
swap
behavior
w/ openglrenderer:
failed
to
choose
config
with
egl
smap_behavior_preserved
dl openglrenderer:
swap
behavior
diegl_
emulation:
eglcreatecontext
oxa61974c0:
maj
min
rcv
di egl
emulation:
eglmakecurrent:
oxa61974c0:
ver
(tinfo
oxaf6b8720)
diegl_
emulation:
kecurrent
oxa61974c0:
ver
(tinfo
oxaf6b8720)
impe
w3r3
rules
yet
eglma)]


so the flag is: `flag{w3_w3r3_back_70_$3v3n7een!!!}`

### pl version

w zadaniu dostajemy [aplikację androidową](droid.apk).
po zdekompilowaniu i analizie źródeł widać, że musimy przejść kilka testów żeby dostać flagę.
niestety jeden z nich to:

```java
public string m4832k() {
	char[] carr = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
	stringbuffer stringbuffer = new stringbuffer();
	random random = new random();
	for (int i = 0; i < 20; i++) {
		stringbuffer.append(carr[random.nextint(carr.length)]);
	}
	return stringbuffer.tostring();
}
```

a skoro używa losowych wartości to jest mała szansa że uda się go przejść.
moglibyśmy spróbować patchować ten kod, ale to dużo roboty.
gdybyśmy przeszli testy to za wyświetlenie flagi odpowiada:

```java
this.f3092l = (edittext) findviewbyid(r.id.edittext);
this.f3092l.settext(stringfromjni());
```

więc wołana jest jedna funkcja z natywnej biblioteki dostarczonej z aplikacją.
sama funkcja jest praktycznie nie do zreversowania, zbyt skomplikowana, ale nie musimy tego robić.
możemy po prostu załadować sobie tą bibliotekę i wywołać funkcje, bez żadnych testów!

żeby to zrobić stworzyliśmy nowy projekt androidowy (użyliśmy jako szablonu przykładowego kodu z ndk) w android studio, stworzyliśmy własne activity, pozostawiając takie same nazwy klas i pakietów i napisaliśmy kod:

```java
package com.example.puing.a2018codegate;

import android.support.v7.app.appcompatactivity;
import android.os.bundle;
import android.widget.textview;

import java.util.logging.logger;

public class main4activity extends appcompatactivity {
    static {
        system.loadlibrary("hello-libs");
    }

    @override
    protected void oncreate(bundle savedinstancestate) {
        super.oncreate(savedinstancestate);
        textview tv = new textview(this);
        string flagstring = stringfromjni();
        tv.settext(flagstring);
        setcontentview(tv);
        logger.getlogger("flaglogger").info(flagstring);
    }

    public native string stringfromjni();
}
```

musieliśmy też zmodyfikować build.gradle dla bibliotek, żeby uwzględnić nasze pliki .so:

```
sourcesets {
	main {
		// let gradle pack the shared library into apk
		jnilibs.srcdirs = ['../distribution/gperf/lib', '../distribution/droid/lib']
	}
}
```

i pozostało już tylko uruchomić aplikację i dostać:


[image extracted text: app
stc
main
java
com
example
puing
a2018codegate
main4activity
oid
main4activity java
main4activity
oncreate()
android emulator
nexus_sx_api_27_x86.5554
manifests
package
com. example
puing
a2018codegate
java
com example puing.a2o18codegate
import android support
77
app
appcompa
import
android
bundle;
main4activity
import
android
widget
textview;
0 3.-03
cpp
inilibs
ort
java
util
logging.logger;
hello-libs
res
wolll awesomell flag{w3
back_70_s3v3n7eenll}
adle scripts
public
class main4activity
extends appc
nahahahll
static
build gradle (project: hello-libs)
system
loadbibrary
libname:
"hell
build gradle (module: app)
gradle-wrapper properties (gradle versic 13
proguard-rules pro (proguard
for
@override
gradle properties (project properties)
protected
void
oncreate (bundle
saver
settings gradle (project settings)
super
oncreate (savedinstancesta
@
textview
new textview
conte
local properties (sdk location)
string flagstring
stringfromji
ternal build files
tv
settext (flaggtring)
setcontentview (tv)
main4activity
03/12
20:02:40: launching main4activity
adb
shell
am
start
com.example.hellolibs/com-example-puing
a2018codega
tent
categ
client
not
ready
waiting
for
proce3s
come
online
connected
process
4139
device
emulator
5554
capturing
and
displaying
logcat
me33ages
from
application.
this
behavior
can
settings
ilinstantrun:
starting
instant
run
server:
13 main
process
i/flaglogger:
wol
awesome
flag {w3
w3r3
back
53v3n7een
hahahah !
dl openglrenderer:
hwui
gl
pipeline
ilzygote:
android::hardware:
configstore::vl
0::isurfacerlingerconfigs::haswi
ilopenglrenderer:
initialized egl,
version
1.4
d/ openglrenderer:
swap
behavior
w/ openglrenderer:
failed
to
choose
config
with
egl
smap_behavior_preserved
dl openglrenderer:
swap
behavior
diegl_
emulation:
eglcreatecontext
oxa61974c0:
maj
min
rcv
di egl
emulation:
eglmakecurrent:
oxa61974c0:
ver
(tinfo
oxaf6b8720)
diegl_
emulation:
kecurrent
oxa61974c0:
ver
(tinfo
oxaf6b8720)
impe
w3r3
rules
yet
eglma)]


więc flaga to `flag{w3_w3r3_back_70_$3v3n7een!!!}`
