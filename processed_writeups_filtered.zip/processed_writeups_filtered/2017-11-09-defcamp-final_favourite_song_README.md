# caesar's favourite song (misc/crypto/stegano)

in the task we get a [song](killthegauls.mp3).
we also know that the flag format is `dctfxxxdctf`.

we start off by translating the song into [notes](killthegauls.xml) by some free software.
one we have the transcription we parse this and store in a single list.
initially we didn't take octave into consideration and we couldn't get this to work, but fortunately at some point we remembered that there were sounds in a different octave. we marked this different octave sounds as lowercase, to keep track of them.

we noticed that if we combine pairs of sounds next to one another we get identical sequence of length 4 at the start and end, which would fit the flag format:

`['aa', 'ag', 'ba', 'ac', 'gd', 'gd', 'gd', 'ab', 'af', 'ge', 'gc', 'ab', 'gd', 'gd', 'ga', 'gb', 'gb', 'aa', 'ae', 'gd', 'ag', 'gf', 'ga', 'ab', 'ga', 'gg', 'ab', 'gg', 'ge', 'ac', 'aa', 'ge', 'ag', 'ge', 'aa', 'gd', 'gf', 'gd', 'ge', 'gd', 'aa', 'ag', 'ba', 'ac']`

now we need to somehow "decrypt" rest of the flag.
we knew that `aa` should become `d`, `ag` should be `c`, `ba` should be `t` and `ac` should be `f`.

looking at bits of the expected symbol we noticed that bit sequences of the `a` are the same, but in case of `ba` they're shifted by 4.
we guessed that there is a simple arithmetic encoding here -> first character in the pair is translated into some number and shifter by 4 bits to the left, and then added to the translated second character.
from the flag format we could devise that `a` has to translate to `4`, `g` translate to `3`, `b` translate to `5` and `c` translate to `6`.

we expected that those are not just some random values, since otherwise we could not decrypt this in an unique way.
since this was all about music, we thought that maybe it's an actual music scale, we looked at some and finally we found one that fit -> `d major`.
we applied the whole scale and decrypted the flag.

whole solver [here](caesar.py)
