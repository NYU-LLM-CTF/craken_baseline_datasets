# botpanel - pwn (300 + 0), 17 solves

> these cyber criminals are selling shells like hot cakes off thier new site. pwn their botpanel for us so we can stop them

in this task we were given a binary and `host:port` where it is running. connecting there we get a banner
and password prompt. after analyzing the binary, we notice that there is a format string bug - typing `%s` would 
either crash or print garbage.

it turns out the expected password is stored in a local variable, so we could use `%7$s` to get the correct password echoed:

```
		panel password: %7$s
		incorrect! 4 attempts left
		your attempt was: >@!admin!@<
```
logging in, we get a simple menu, but anything we try is restricted due to running in "trial mode". analyzing the binary, it
seems the boolean holding the current mode is initialized in the login function - since there's the format bug, we could
overwrite it using `%6$n`.

after doing this, we get "registered mode" menu. it allows to send invites to arbitrary host:port - which spawn a new
thread which connects back to specified ip. the invited menu in turn allows to send feedback. the feedback option
first asks for length, then the feedback string. it is immediately suspicious, but there are checks for the length
being in reasonable size, so no obvious buffer overflow is there. however, the read buffer length is a global variable,
meaning we can send normal length in one connection, get it to pass the checks, then send large length in second connection,
and finally send large buffer in the first one. this allows us to overflow the buffer, overwriting the return address and
allowing the rop.

there were a couple of other roadblocks still. first of all, there was a stack cookie. thankfully, on linux the stack
cookie is constant for the whole process duration, so we were able to leak it during the login phase at the start,
using `%15$x`. second problem was that the aslr was turned on, so we had to find the address the binary was loaded at.
we did it in the same way, via leaking return address during login procedure: `%19$x`.

the binary was rather small, so there was not enough gadgets to easily make a reliable exploit - our solution
increments (bytewise) `puts` function got entry so that it points to `system`. because it is bytewise incrementation,
the possible carry is ignored, so the result may be wrong. still, the exploit works about half the time.
the whole code is available in `doit.py`.
