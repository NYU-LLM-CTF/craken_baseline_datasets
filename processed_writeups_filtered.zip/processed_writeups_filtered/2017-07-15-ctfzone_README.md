# writeup ctfzone 2017 quals

team: akrasuski1, msm, nazywam, rev, c7f.m0d3, cr019283, shalom


[image extracted text: rank
team name
from
score
lchbc
russia
13597
codisec
poland
7807
poland
7014
oops
china
6910
thebushwhackers
russia
6223
lights out
russia
5989
suslo pas
russia
5989
eatsleeppwnrpt
germany
5253
dragon sector
poland
4405
10
shellphish
united states
3867]


### table of contents

* [battleships (ppc / re)](battleships)
* [crackme3000 (re)](crackme3000)
* [decrypt_the_undecryptable (re)](decrypt_the_undecryptable)
* [fireplace (re)](fireplace)
* [paged_out (misc/forensics)](paged_out)
* [mprsa (crypto)](mprsa)
