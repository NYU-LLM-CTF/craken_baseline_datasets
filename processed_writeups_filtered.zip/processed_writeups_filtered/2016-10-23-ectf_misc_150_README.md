# number_place (misc 150)

###eng
[pl](#pl-version)

in the task we get hint about sudoku and address of remote server which sends us inputs in form:

```
.418.5..9..9.7..58.3............26..3...6..25...5...97.....69.2.1..4......7......
```

it's quite clear that this is definition of sudoku grid and we need to solve it to get the flag.
in some later stages the inputs were also containing roman numbers, binary numbers and base-64 decoded numbers.

so we grabbed first sudoku solver from internet, coded data parsing and communication with the server and used the script:

```python
import base64
import socket
import re
from time import sleep


def findnextcelltofill(grid, i, j):
    for x in range(i, 9):
        for y in range(j, 9):
            if grid[x][y] == 0:
                return x, y
    for x in range(0, 9):
        for y in range(0, 9):
            if grid[x][y] == 0:
                return x, y
    return -1, -1


def isvalid(grid, i, j, e):
    rowok = all([e != grid[i][x] for x in range(9)])
    if rowok:
        columnok = all([e != grid[x][j] for x in range(9)])
        if columnok:
            # finding the top left x,y co-ordinates of the section containing the i,j cell
            sectopx, sectopy = 3 * (i / 3), 3 * (j / 3)
            for x in range(sectopx, sectopx + 3):
                for y in range(sectopy, sectopy + 3):
                    if grid[x][y] == e:
                        return false
            return true
    return false


def solvesudoku(grid, i=0, j=0):
    i, j = findnextcelltofill(grid, i, j)
    if i == -1:
        return true
    for e in range(1, 10):
        if isvalid(grid, i, j, e):
            grid[i][j] = e
            if solvesudoku(grid, i, j):
                return true
            # undo the current cell for backtracking
            grid[i][j] = 0
    return false


def stringify(arrays):
    return "".join("".join([str(c) for c in x]) for x in arrays)


def solve(s):
    arrays = [[int(c) for c in s[i * 9:(i + 1) * 9]] for i in range(9)]
    solvesudoku(arrays)
    result = stringify(arrays)
    return result


def parse_bin(s):
    bins = re.findall("\(.+?\)", s)
    for found in bins:
        s = s.replace(found, str(int(found[1:-1], 2)))
    return s


def parse_base64(s):
    bins = re.findall("\[.+?\]", s)
    for found in bins:
        s = s.replace(found, str(base64.b64decode(found[1:-1])))
    return s


def parse_roman(s):
    s = s.replace('<i>', '1')
    s = s.replace('<ii>', '2')
    s = s.replace('<iii>', '3')
    s = s.replace('<iv>', '4')
    s = s.replace('<v>', '5')
    s = s.replace('<vi>', '6')
    s = s.replace('<vii>', '7')
    s = s.replace('<viii>', '8')
    s = s.replace('<ix>', '9')
    return s


def parse(s):
    s = s.replace('.', '0')
    s = parse_roman(s)
    s = parse_bin(s)
    s = parse_base64(s)
    return s


def main():
    url = '35.161.87.33'
    port = 10101
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    while true:
        sleep(1)
        received = s.recv(9999)[:-1]
        print(received)
        received = parse(received)
        result = solve(received)
        print(result)
        s.sendall(result + "\n")


main()

```

finally we got `ectf{jk_w3_41n7_s0rry}`

###pl version

w zadaniu dostajemy hint na temat sudoku oraz adres serwera który wysyła dane w formie:

```
.418.5..9..9.7..58.3............26..3...6..25...5...97.....69.2.1..4......7......
```

jest dość jasne, że to opis planszy sudoku a my mamy ją rozwiązać aby dostać flagę.
w dalszych poziomach dane zawierały również liczby rzymskie, liczby binarne oraz liczby enkodowane jako base-64.

w związku z tym ściągnęliśmy pierwszy lepszy solver sudoku z internetu, napisalismy parser dla danych oraz komunikacje z serwerem:

```python
import base64
import socket
import re
from time import sleep


def findnextcelltofill(grid, i, j):
    for x in range(i, 9):
        for y in range(j, 9):
            if grid[x][y] == 0:
                return x, y
    for x in range(0, 9):
        for y in range(0, 9):
            if grid[x][y] == 0:
                return x, y
    return -1, -1


def isvalid(grid, i, j, e):
    rowok = all([e != grid[i][x] for x in range(9)])
    if rowok:
        columnok = all([e != grid[x][j] for x in range(9)])
        if columnok:
            # finding the top left x,y co-ordinates of the section containing the i,j cell
            sectopx, sectopy = 3 * (i / 3), 3 * (j / 3)
            for x in range(sectopx, sectopx + 3):
                for y in range(sectopy, sectopy + 3):
                    if grid[x][y] == e:
                        return false
            return true
    return false


def solvesudoku(grid, i=0, j=0):
    i, j = findnextcelltofill(grid, i, j)
    if i == -1:
        return true
    for e in range(1, 10):
        if isvalid(grid, i, j, e):
            grid[i][j] = e
            if solvesudoku(grid, i, j):
                return true
            # undo the current cell for backtracking
            grid[i][j] = 0
    return false


def stringify(arrays):
    return "".join("".join([str(c) for c in x]) for x in arrays)


def solve(s):
    arrays = [[int(c) for c in s[i * 9:(i + 1) * 9]] for i in range(9)]
    solvesudoku(arrays)
    result = stringify(arrays)
    return result


def parse_bin(s):
    bins = re.findall("\(.+?\)", s)
    for found in bins:
        s = s.replace(found, str(int(found[1:-1], 2)))
    return s


def parse_base64(s):
    bins = re.findall("\[.+?\]", s)
    for found in bins:
        s = s.replace(found, str(base64.b64decode(found[1:-1])))
    return s


def parse_roman(s):
    s = s.replace('<i>', '1')
    s = s.replace('<ii>', '2')
    s = s.replace('<iii>', '3')
    s = s.replace('<iv>', '4')
    s = s.replace('<v>', '5')
    s = s.replace('<vi>', '6')
    s = s.replace('<vii>', '7')
    s = s.replace('<viii>', '8')
    s = s.replace('<ix>', '9')
    return s


def parse(s):
    s = s.replace('.', '0')
    s = parse_roman(s)
    s = parse_bin(s)
    s = parse_base64(s)
    return s


def main():
    url = '35.161.87.33'
    port = 10101
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    while true:
        sleep(1)
        received = s.recv(9999)[:-1]
        print(received)
        received = parse(received)
        result = solve(received)
        print(result)
        s.sendall(result + "\n")


main()

```

co dało nam `ectf{jk_w3_41n7_s0rry}`
