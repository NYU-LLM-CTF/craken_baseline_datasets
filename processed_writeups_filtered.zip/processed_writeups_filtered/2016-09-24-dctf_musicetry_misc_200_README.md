# musicetry (misc 200)

```
they should have forbidden this from the moment they hear abou the idea! damn circles, rectangles is all we needed! 
```

###eng
[pl](#pl-version)

in the task we get a webpage with a cd picture.
we thought this might be stegano, but the picture was `.jpg` and it was hotlinked from a legitimate webpage so we figured it can't be it.
we noticed also a strange `data` cookie set by the webpage.
there were 4 different cookies we could get:

```
## %%
```

```
## %% %++ %++ %++ %++ @* %++ @* #% %# %++ %++ %++ %++ %++ @** %% %++ %++ @* %# ## #% %++ %++ %++ %++ @** %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @** ## %% %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @*
```

```
## %% %++ %++ %++ %++ %++ %++ %++ %++ @* %++ @* %++ %++ %++ %++ %++ @* %++ %++ %++ %++ %++ %++ @* %% ##
```

```
## %% %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @* %# %++ @** %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @** %# %++ %++ %++ %++ %++ @***
```

one of our friends spent once a few hours on a ctf reversing a certain brainfuck-like language from scratch, using only the code which should print a flag (we know the flag prefix).
later it turned out that this was an actual esoteric language with a specification... 
anyway, our friend instantly recognized `data` payload as code for tapebagel language.
and we already had interpreter for it:

https://github.com/p4-team/ctf/tree/master/2016-02-20-internetwache/re_80

so we used the interpreter to decode the inputs, getting `hint`, `tape`, `defceso`.
this was a big wtf for us, because we were sure this is just a hint for the task solution, so we were trying to google anything related, to no avail.
in the end one of our friends just checked if md5 of `defceso` is not a flag, and it was...


###pl version

w zadaniu dostajemy linkkdo strony z obrazkiem płyty cd.
myśleliśmy początkowo że może to być stegano, ale obrazek był `.jpg` i był linkowany z prawdziwej strony, więc uznaliśmy że to raczej nie to.
zauważyliśmy także dziwne cookie `data` ustawiane przez stronę.
były 4 różne wartości które mogliśmy dostać:

```
## %%
```

```
## %% %++ %++ %++ %++ @* %++ @* #% %# %++ %++ %++ %++ %++ @** %% %++ %++ @* %# ## #% %++ %++ %++ %++ @** %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @** ## %% %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @*
```

```
## %% %++ %++ %++ %++ %++ %++ %++ %++ @* %++ @* %++ %++ %++ %++ %++ @* %++ %++ %++ %++ %++ %++ @* %% ##
```

```
## %% %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @* %# %++ @** %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ %++ @** %# %++ %++ %++ %++ %++ @***
```

jeden z naszych kolegów spędził kiedyś kilka godzin na ctfie reversując język podobny do brainfucka, korzystając jedynie z kodu który miał wypisać flagę (znalism prefix flagi).
później okazało się, że to jest opisany język ezoteryczny z istniejącą specyfikacją...
niemniej nasz kolega od razu rozpoznał zawartość cookie `data` jako kod języka tapebagel.
mamy juz do niego interpreter:

https://github.com/p4-team/ctf/tree/master/2016-02-20-internetwache/re_80

użyliśmy interpretera do odkodowania danych, dostając `hint`, `tape`, `defceso`.
dalsza część to mocny wtf, ponieważ byliśmy pewni, że to tylko hint dla dalszej części zadania i próbowalismy googlować cokolwiek związanego, bez efektów.
na koniec jeden z naszych kolegów sprawdzić czy aby czasem md5 z `defceso` nie jest po prostu flagą i był...
