# minesweeper (crypto, 350)

> find which bombs are real and which are duds---without exploding any of them!

> for those wondering why this is cryptography: this technique can be used to
> detect eavesdropping on a quantum channel, without tipping the eavesdroppers
> off.

this time we were given source code of a go simulation of over 100 bombs, that can be dud or live, similar to 
[this experiment](https://en.wikipedia.org/wiki/elitzur%e2%80%93vaidman_bomb_tester).
we have to guess all of them without detonating any. for this, we can use two photons and a number of quantum gates.
wikipedia article describes how it can be done in 33% probability,
but we need far more than that if we want to guess 100 times correctly.

i found a [kwiat article](http://www.rle.mit.edu/qem/documents/kwiat-prl-74-4763.pdf), which describes a physical process
that could be used in this problem. although i'm not an expert at quantum physics, my basic understanding of the principle
is that you shine a photon on polarizer rotated just a bit from the original 
photon polarization. about `sin^2(theta)` of the intensity appears on the other side, and the rest (`cos^2(theta)`) 
reflects back. now, if the other side contains a bomb, it will be tipped off with probability of (`sin^2(theta)`), which
for small `theta` is approximately equal to `theta^2`. if it does not detonate, we are back at square one - photon is
definitely on the original side.

if we repeat this experiment a number of times (`pi/theta`), then if the bomb wasn't there, the photon will finally 
rotate phase by the whole pi, but if the bomb was there, it will stay at original phase (provided the bomb didn't explode,
which it can do with probability on the order of `theta/pi`).

still, i had to implement this experiment using given gates. i found 
[another article](http://www.arturekert.org/quantum/lecturenotes/note2.pdf), which shows how to build a polarizer
using hadamard and phase rotator gates - use sequence hadamard:rotate:hadamard. see `conn.py` for details. 
anyway, running the code a couple of times (it fails randomly) gave us a flag.
