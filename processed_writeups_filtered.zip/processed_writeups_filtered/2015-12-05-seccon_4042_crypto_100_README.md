##4042 (misc/crypto, 100p)

```
unknown document is found in ancient ruins, in 2005.
could you figure out what is written in the document?
```

###pl
[eng](#eng-version)

dostajemy [plik](no-network.txt) który mamy zdekodować. podpowiedź stanowi `4042` oraz rok `2005`. pozwala nam to dotrzeć do rfc4042: https://www.ietf.org/rfc/rfc4042.txt które w ramach żartu opisuje kodowanie utf-9.
domyślamy się, że właśnie z takim kodowaniem mamy do czynienia i w celu odczytania flagi musimy napisać dekoder.
każdy znak jest kodowany na 9 bitach, gdzie najstarszy bit oznacza że znak jest kontynuowany na kolejnym bajcie. pozostałe bity określają znak.
piszemy więc prosty kod:

```python
def convert_single_char(start_pos, bits):
    end_pos = 9
    continuation = int(bits[start_pos])
    character = bits[start_pos + 1:start_pos + 9]
    c = int(character, 2)
    if continuation:
        character = bits[start_pos + 9:start_pos + 18]
        c <<= 8
        c += int(character, 2)
        end_pos += 9
    return unichr(c), end_pos
```
który dla ciągu bitów oraz pozycji startowej zwraca zdekodowany znak oraz ostanią użytą pozycję.
dane wejściowe traktujemy jako liczbę w systemie ósemkowym a następnie dekodujemy za pomocą przygotowanego [skryptu](4042.py).
w efekcie dostajemy flagę:


[image extracted text: lnrem ipaum
dclor 3it umet
consectetu
adipiaicingelit
ged
do eiuamod
tempor
incididuntut laboreetdclore magno uliqua
enimadminim
veniam;
noatrud exercitatinn ullamco
laborianiaiut aliquip edea commodo conaequat:
dui3 @ute irure
dolor in reprehenderitin
vcluptate
velit
e33e
cillum
dolore
fugiat nullaporiatur
exceoteur
3int occuecat
cudidatat nonoroident
3unt
culpa quiofficic degeruntmollit
@nim id
eat
aborum:
the
flag i3: secoon {a
group_of_nine
blis_is_
called_nonet
please send
the flag
innormalascil code
quia]


czyli:

`seccon{a_group_of_nine_bits_is_called_nonet}`

### eng version

we get [a file](no-network.txt) which we are supposed to decode. 
a starting point is `4042` and year `2005`. this leads us to rfc4042: https://www.ietf.org/rfc/rfc4042.txt which is a joke describing utf-9 encoding.
we assume we will have to decode input file using this strange encoding so we need a decoder.
each character is encoded on 9 bits, where the most significant bit signals that the character is continued on another byte. rest of the bits are left for the data itself.

we make a simple decoder:

```python
def convert_single_char(start_pos, bits):
    end_pos = 9
    continuation = int(bits[start_pos])
    character = bits[start_pos + 1:start_pos + 9]
    c = int(character, 2)
    if continuation:
        character = bits[start_pos + 9:start_pos + 18]
        c <<= 8
        c += int(character, 2)
        end_pos += 9
    return unichr(c), end_pos
```
which takes a list of bits and start position and returns a chracter and index of last used position.
we treat input data as a large oct number and decode with prepared [script](4042.py).
as a result we get:


[image extracted text: lnrem ipaum
dclor 3it umet
consectetu
adipiaicingelit
ged
do eiuamod
tempor
incididuntut laboreetdclore magno uliqua
enimadminim
veniam;
noatrud exercitatinn ullamco
laborianiaiut aliquip edea commodo conaequat:
dui3 @ute irure
dolor in reprehenderitin
vcluptate
velit
e33e
cillum
dolore
fugiat nullaporiatur
exceoteur
3int occuecat
cudidatat nonoroident
3unt
culpa quiofficic degeruntmollit
@nim id
eat
aborum:
the
flag i3: secoon {a
group_of_nine
blis_is_
called_nonet
please send
the flag
innormalascil code
quia]


which is:

`seccon{a_group_of_nine_bits_is_called_nonet}`