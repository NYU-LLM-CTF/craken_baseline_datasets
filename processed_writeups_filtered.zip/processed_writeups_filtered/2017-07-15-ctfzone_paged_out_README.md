# we got paged out, mr president! (forensic, misc, 973p)

> we got some important data paged out.
> can you recover it?

> pagefile.sys.gz

> hints:

> the first key is named 'ct', the second one - 'fz'. find out the remaining keys.

this was an exercise in good linux-fu. the file we had was 1gb large, so impossible to search by hand. 
given the hint, we could deduce though that there should be `ct` and `fz` strings somewhere.
since `ct` is pretty common digraph (`action`, `direct`, and others), we decided to look for far rarer `fz`. since this
was a windows dump, we searched for utf-16 strings. and... done:
```bash
λ strings -e l pagefile.sys | grep fz
computer\hkey_local_machine\software\ct\fz\one\{\r3g_\h4x\0r}
```

the flag is `ctfzone{r3g_h4x0r}`
