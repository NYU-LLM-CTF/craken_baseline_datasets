# internet of fail - 400p, 10 solves

> the machines are already here, lurking in your things. they've learned to fool humans
> by speaking a strange language. can you find their secret password? this is running 
> at http://iof.teaser.insomnihack.ch

in this task we got a strange elf file. running `readelf -a iof.elf` on it gives us some basic information -
it seems it's a binary for tensilica xtensa processor - from some strings in the binary, we concluded it's
esp32 chip (a pretty new successor to popular esp8266). unfortunately, this being a very unpopular architecture,
there were almost no tools we could use for analysis - ida does not support xtensa out of the box, and even adding
some plugins we found on the internet didn't help (apparently they were meant for reversing original espressif 
chips).

in the end, we used good old radare2. it turned out the task was pretty challenging - although elf mentioned entry
point, it was far away from the actual `main` of the application. we were also stumped by some calls to memory
that didn't exist in the elf - it turns out esp32 maps rom in here. this gave us an idea to google some of the
called functions' addresses - and we found 
[this little gem.](https://raw.githubusercontent.com/espressif/esp-idf/master/components/esp32/ld/esp32.rom.ld)

it contains entries of the form `function - address`, which significantly helped in initial reversing. still, 
we had to get through the rtos boilerplate code - it didn't even call the main function directly, but rather created
a new task running it. in the end, we found some public esp32 http 
[server code.](https://github.com/feelfreelinux/myesp32tests/blob/master/examples/http_server.c)
it seemed to match most of the code nicely, with only slight modifications. the only sinificant difference was
in the `serve` function, which contained code responsible for checking the password.

it called around 20 of different functions, each of which had a similar form:
```
if(condition(password)){ g_state^=const; }
```
the conditions were somewhat annoying to reverse, not having access to anything more than assembly, we had to 
analyze them by hand. they used various techniques, including, but not limited to, multiplication, division,
summing of mac address bytes, xoring, etc. after running all the functions, the `g_state` variable was compared
to `0xffff`. we brute forced all the possible subsets of conditions that yielded that result, and filtered
those that didn't make sense (such as `s[3]&17 == 104`). in the end, combining all the conditions using pen and
paper, we got the final password, which worked on the challenge website: `g0t_you_xt3ns4!`
