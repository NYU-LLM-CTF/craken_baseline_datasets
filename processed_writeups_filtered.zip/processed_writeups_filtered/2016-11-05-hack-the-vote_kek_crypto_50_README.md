# top kek (crypto 50)


###eng
[pl](#pl-version)

in the task we get encrypted data:

```
kek! top!! kek!! top!! kek!! top!! kek! top!! kek!!! top!! kek!!!! top! kek! top!! kek!! top!!! kek! top!!!! kek! top!! kek! top! kek! top! kek! top! kek!!!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top! kek! top! kek!!!!! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek!! top!! kek!!! top! kek! top!! kek! top!! kek! top! kek! top! kek! top!!!!! kek! top!! kek! top! kek!!!!! top!! kek! top! kek!!! top! kek! top! kek! top!! kek!!! top!! kek!!! top! kek! top!! kek! top!!! kek!! top! kek!!! top!!! kek! top! kek! top!!!!! kek! top! kek!!! top!! kek!! top!!! kek! top! kek! top! kek! top! kek!! top!!! kek!! top! kek! top!!!!! kek! top!!! kek!! top! kek!!! top!! kek!!! top! kek! top!! kek!! top!!! kek! top! kek!! top! kek!!!! top!!! kek! top! kek!!! top! kek! top!!!!! kek! top!! kek! top!!! kek!!! top!! kek!!!!! top! kek! top! kek! top!!! kek! top! kek! top!!!!! kek!! top!! kek! top! kek!!! top! kek! top! kek!! top! kek!!! top!! kek!! top!! kek! top! kek! top!!!!! kek! top!!!! kek!! top! kek!! top!! kek!!!!! top!!! kek! top! kek! top! kek! top! kek! top!!!!! kek! top!! kek! top! kek!!!!! top!! kek! top! kek!!! top!!! kek! top!! kek!!! top!! kek!!! top! kek! top!! kek! top!!! kek!! top!! kek!! top!!! kek! top! kek! top!!!!! kek! top!! kek!! top!! kek!! top!!! kek! top! kek! top! kek! top!! kek! top!!! kek!! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek!! top! kek! top!! kek!! top!! kek!! top!! kek! top! kek!! top! kek! top!! kek!! top! kek!!!! top! kek!! top! kek!!!! top! kek!! top! kek!!!! top! kek! top!!!!! kek! top!
```

we initially thought this is some kind of esolang similar to ook! but then we figured that it has to be simpler - there is only alternating `top` and `kek` and `!` after them.
after a while we finally guessed that this can be simply binary code with `top` or `kek` signaling 0/1 and `!` signaling repeats.

so we prepared a code:

```python
import codecs

with codecs.open("data.txt") as input_file:
    data = input_file.read()
    result = ""
    for entry in data.split(" "):
        repeat = len(entry) - 3
        if entry[0] == "t":
            result += "1" * repeat
        else:
            result += "0" * repeat
    print(result)
    chunked = [result[i:i + 8] for i in range(0, len(result) - 7, 8)]
    print(chunked)
    converted = [chr(int(c, 2)) for c in chunked]
    print("".join(converted))
```

which gave us the flag: `flag{t0o0o0o0o0p______1m_h4v1ng_fun_r1ght_n0w_4r3_y0u_h4v1ng_fun______k3k!!!}`

###pl version

w zadaniu dostajemy zakodowane dane:

```
kek! top!! kek!! top!! kek!! top!! kek! top!! kek!!! top!! kek!!!! top! kek! top!! kek!! top!!! kek! top!!!! kek! top!! kek! top! kek! top! kek! top! kek!!!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top!! kek! top!!!! kek!! top!! kek!!!!! top! kek! top! kek!!!!! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek!! top!! kek!!! top! kek! top!! kek! top!! kek! top! kek! top! kek! top!!!!! kek! top!! kek! top! kek!!!!! top!! kek! top! kek!!! top! kek! top! kek! top!! kek!!! top!! kek!!! top! kek! top!! kek! top!!! kek!! top! kek!!! top!!! kek! top! kek! top!!!!! kek! top! kek!!! top!! kek!! top!!! kek! top! kek! top! kek! top! kek!! top!!! kek!! top! kek! top!!!!! kek! top!!! kek!! top! kek!!! top!! kek!!! top! kek! top!! kek!! top!!! kek! top! kek!! top! kek!!!! top!!! kek! top! kek!!! top! kek! top!!!!! kek! top!! kek! top!!! kek!!! top!! kek!!!!! top! kek! top! kek! top!!! kek! top! kek! top!!!!! kek!! top!! kek! top! kek!!! top! kek! top! kek!! top! kek!!! top!! kek!! top!! kek! top! kek! top!!!!! kek! top!!!! kek!! top! kek!! top!! kek!!!!! top!!! kek! top! kek! top! kek! top! kek! top!!!!! kek! top!! kek! top! kek!!!!! top!! kek! top! kek!!! top!!! kek! top!! kek!!! top!! kek!!! top! kek! top!! kek! top!!! kek!! top!! kek!! top!!! kek! top! kek! top!!!!! kek! top!! kek!! top!! kek!! top!!! kek! top! kek! top! kek! top!! kek! top!!! kek!! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek! top!!!!! kek! top! kek!! top! kek! top!! kek!! top!! kek!! top!! kek! top! kek!! top! kek! top!! kek!! top! kek!!!! top! kek!! top! kek!!!! top! kek!! top! kek!!!! top! kek! top!!!!! kek! top!
```

początkowo myśleliśmy że to jakiś ezoteryczny język programowania podobny do ook! ale potem doszliśmy do wniosku, że musi być jeszcze prościej - mamy w końcu tylko naprzemienne `top` i `kek` oraz `!` za każdym z nich.
po pewnym czasie zgadliśmy wreszcie, że to może być po prostu kod binarny gdzie `top` lub `kek` określają 0/1 a `!` oznacza powtórzenia.

napisaliśmy prosty skrypt:

```python
import codecs

with codecs.open("data.txt") as input_file:
    data = input_file.read()
    result = ""
    for entry in data.split(" "):
        repeat = len(entry) - 3
        if entry[0] == "t":
            result += "1" * repeat
        else:
            result += "0" * repeat
    print(result)
    chunked = [result[i:i + 8] for i in range(0, len(result) - 7, 8)]
    print(chunked)
    converted = [chr(int(c, 2)) for c in chunked]
    print("".join(converted))
```

który dał nam flagę: `flag{t0o0o0o0o0p______1m_h4v1ng_fun_r1ght_n0w_4r3_y0u_h4v1ng_fun______k3k!!!}`
