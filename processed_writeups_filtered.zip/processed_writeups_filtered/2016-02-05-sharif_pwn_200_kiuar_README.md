## kiuar (pwn, 200p)

    telnet ctf.sharif.edu 12432

###eng
[pl](#pl-version)

first thing we receive in this task is request for proof of work - so we had to write a quick script calculating it for us.
after submitting it, we receive some non-ascii bytes and a message telling us we have 10s to reply.

saving those unknown bytes to file and checking it using `file` command, we find it's a zlib-compressed data: `send your
qr code:`.

sending anything afterwards tells us that we need to send exactly 200 bytes - and if we do it, the message tells us that
the input is not properly compressed. finally, when we send zlib-compressed string "aaa" padded with zeros to 200 bytes,
we receive `sorry, no decode delegate for this image :|`. googling this message tells us that it's a generic imagemagick
error message - apparently we need to send an image. at this point we were prertty certain it has to be zlib-compressed
image file containing qr code. sending qr with "aaa" text gives us:
```
processing the received command...
the output of your command is large, i only send 18 bytes of it :p 
sorry, command not
```
so probably our text was executed as a command. sending qr with `ls` confirms that - there was a `flag` file.
we still had to work around limitation of command size (200 bytes limit for qr image) and output limit of 18 bytes.
finally, using `tail -c 40 flag` we were able to get the flag chunk by chunk.

###pl version

pierwsze co dostajemy po połączeniu się z serwerem, to prośba o `proof of work`. napisaliśmy więc skrypt realizujący ją,
po czym otrzymaliśmy trochę bajtów spoza ascii i wiadomość, że mamy 10s na odpowiedź.

po zapisaniu tych nieznanych bajtów do pliku i sprawdzeniu ich poleceniem `file` dowiedzieliśmy się, że to dane
skompresowane zlibem: `send your qr code:`.

wysłanie czegokolwiek mówi nam, że należy wysłac maksymalnie 200 bajtów. po wysłaniu takiej właśnie ilości danych,
dowiadujemy się, że dane nie są poprawnie skompresowane. no to wysyłamy skompresowany zlibem tekst "aaa" z dorzuconymi
bajtami zerowymi na koniec, po czym otrzymujemy wiadomość `sorry, no decode delegate for this image :|`. 
wygooglanie tego tekstu mówi, że to zwykły błąd imagemagick - w tym momencie domyśliliśmy się, że należy wysłać
skompresowany obrazek z qr. wysyłamy więc qr z "aaa":
```
processing the received command...
the output of your command is large, i only send 18 bytes of it :p 
sorry, command not
```
tekst jest więc pewnie wykonywany jako komenda. potwierdziliśmy to wysyłając qr z `ls` - wylistowaliśmy plik `flag`.
nadal trzeba było obejść ograniczenie wielkości komendy (200 bajtów na obrazek z qr) i na odpowiedź serwera (18
bajtów). ostatecznie, używając `tail -c 40 flag` udało nam się kawałek po kawałku wyciągnąć flagę.
