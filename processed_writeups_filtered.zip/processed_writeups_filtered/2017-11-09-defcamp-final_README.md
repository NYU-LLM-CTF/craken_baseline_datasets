# defcamp ctf finals 2017

team: c7f.m0d3, psrok1, rev, shalom, lacky

### table of contents

* [state agency (web)](state_agency)
* [caesar favourite song (misc/crypto)](favourite_song)
* [audio captcha (misc)](audio_captcha)
* [adversarial (misc)](adversarial)
* [hack tac toe (web/crypto)](hack_tac_toe)
* [fedora shop (web)](fedora_shop)
