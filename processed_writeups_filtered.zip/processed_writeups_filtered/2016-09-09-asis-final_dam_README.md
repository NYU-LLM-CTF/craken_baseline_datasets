## dam (crypto, 277p)

###eng
[pl](#pl-version)

in the task we get access to a service providing some form of encryption.
the server challenges us for a pow before we can interact, so first we had to solve the pow, but it was the same as for some others tasks (prefix for string giving some hash value).
after beating the pow we could query the server for encryption code, key generation code, encrypted flag with current session key, current public session key and we could also encrypt something.

the encryption code is:

```python
def encrypt(msg, pubkey):
    n, g, u = pubkey
    u += 1
    r = getrandomrange(1, n ** u - 1)
    enc = pow(g, msg, n ** u) * pow(r, n ** u, n ** u) % n ** u
    return enc
```

it looked very much like paillier cryptosystem so a little googling told us that this is actually a generalized version known as damgård–jurik cryptosystem: https://en.wikipedia.org/wiki/damgård–jurik_cryptosystem

it looks almost as the textbook implementation so we didn't expect vulnerability here.

the key generation scheme was:

```python
def get_keypair(kbit, u):
    l = getrandomrange(kbit >> 4, kbit)
    p = long(gmpy.next_prime(2 << l))
    q = long(getprime(kbit - l - 1))
    n = p * q
    d = (p - 1) * (q - 1) / gcd(p - 1, q - 1)
    r = getrandomrange(1, n - 1)
    while true:
        t = getrandomrange(1, n - 1)
        if gcd(t, n) == 1:
            break
    g = pow(n + 1, t, n ** (u + 1)) * r % n ** (u + 1)
    pubkey = (n, g, u)
    privkey = (n, d)
    return pubkey, privkey
```

at first glance it also looked fine, but after a while we noticed an interesting issue.
the estimated `kbit` value, judging by some public keys we got, was just 512 bits.
this means that `kbit >> 4` is actually `32`! 
so the range for the first prime is between 32 and 512 bits, and for the second prime between 0 and 479 bits!

this doesn't sound very safe, when the primes are not similar in size.
since for every connection we get a new key, we can expect that at some point we will get a key with reasonably small factor.
for this we wrote a script to grab some public keys and corresponding encrypted flags for them:

```python
import codecs
import hashlib
import re
import socket
import itertools
import string
from time import sleep


def recvuntil(s, tails):
    data = ""
    while true:
        for tail in tails:
            if tail in data:
                return data
        data += s.recv(1)


def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha512(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c


def grab_data(s):
    s.sendall("g\n")  # get public key
    sleep(1)
    public = recvuntil(s, "\n") + recvuntil(s, "\n")
    s.recv(99999)
    s.sendall("s\n")  # get flag
    sleep(1)
    encflag = recvuntil(s, "\n")
    s.recv(99999)
    return public, encflag


def main():
    while true:
        try:
            url = "dam.asis-ctf.ir"
            port = 34979
            s = socket.socket(socket.af_inet, socket.sock_stream)
            s.connect((url, port))
            x = proof_of_work(s)
            print(x)
            s.sendall(x + "\n")
            sleep(2)
            data = s.recv(9999)
            print(data)
            public, encflag = grab_data(s)
            with codecs.open("data.txt", "a") as keys_data:
                keys_data.write(public)
                keys_data.write(encflag + "\n")
        except:
            pass


main()
```

this way we got quite a few keys after a while.
next step was to find the appropriate modulus with small factor - we simply passed the data to yafu with some timeout and hoped for the best.
fortunately we got the data we hoped for:

```
p = 531457043239
q = 24388660549343689307668728357759111763660922989570087116087163747073216709529418907189891430183531024686147899385989241370687309994439728955541
n = 12961525424113842581457481341117729721726176698202598934475332596021163792495193687500962257794764397492324080568328705801930173334863551881104393545637299
g = 2132051839750573299754854507364380969444028499581423474830053011031379601163074792669440458939453573346412661307966491517309566840273475971253252815424138851541945813878339754880371934727997401840883756793174023026387912833787561873964774343104161427421558277429398462610380913199026766005036911561111911498015614446521644547923419768095811788791898552705927717854674901759443511325189376351325806917211560457327283300074902178726201347950069589670988213859630524059734789901571017367997352139514205408014889400527318603702898182503607166931422225113192039575979803468157633585201622512457745586383739179657894475772
u = 3
flag = 16146846956417499078189378495360455759223869595378485457630764561369105704825747347552639327825348858161202688846334168331082417561328878910128831138772951255714265696309304528530025841643933748756877476450078970791315331759262515894580524581915667726800504296931313616859751122921688756817297843797340121021959810015729726300012075071651090158205135737206806416627610169333331691704947002581388291641532314716891417238670535879838292937496483821606837803344591931921999217676036196239569436244254894652087250116786992703898654314284929464910202202816397917119926061000276191503543076180026132619912576609446737065690
```

we got a modulus with a very small factor, just 39 bits in size.
this means we could now recover the private key, which in this case was lcm.

with the private key now the last thing to do was to decrypt the flag corresponding to our broken key.
this proved to be a problem since we couldn't find an implementation for this algorithm, which would not be a simplified version.

so we ended up grabbing the paper: http://www.brics.dk/rs/00/45/brics-rs-00-45.pdf and coding this on our own:

```python
def l(x):
    return (x - 1) / n


def decrypt(ct, d, n, s):
    ns1 = pow(n, s + 1)
    a = pow(ct, d, ns1)
    i = 0
    for j in range(1, s + 1):
        t1 = l(a % pow(n, j + 1))
        t2 = i
        for k in range(2, j + 1):
            i -= 1
            t2 = (t2 * i) % pow(n, j)
            factorial = long(gmpy2.factorial(k))
            up = (t2 * pow(n, k - 1))
            down = gmpy2.invert(factorial, pow(n, j))
            t1 = (t1 - up * down) % pow(n, j)
        i = t1
    return i
```

with this function we could now decrypt the flag ciphertext to get `jmd mod n^s` and by decrypting `g` value we could get `jd mod n^s` and modinv of this value to get plain `m`:

```python
ns = pow(n, u)
jd = decrypt(g, d, n, u)
jd_inv = gmpy2.invert(jd, ns)
jmd = decrypt(flag, d, n, u)
f = (jd_inv * jmd) % ns
print("decrypted flag = " + long_to_bytes(f))
```

###pl version

w zadaniu dostajemy dostęp do serwisu umożliwiającego jakąś formę szyfrowania.
serwer wymaga od nas rozwiązania pow aby móc z niego korzystać, więc musieliśmy najpierw rozwiązać pow, niemniej było takie samo jak dla innych zadań (prefix dla stringu dającego odpowiednią wartość hasha).
po pokonaniu pow mogliśmy uzyskać od serwisu algorytm szyfrowania, algorytm generacji klucza sesji, zaszyfrowaną kluczem sesji flagę, aktualny klucz publiczny sesji oraz mogliśmy też sami coś zaszyfrować.

kod szyfrowania:

```python
def encrypt(msg, pubkey):
    n, g, u = pubkey
    u += 1
    r = getrandomrange(1, n ** u - 1)
    enc = pow(g, msg, n ** u) * pow(r, n ** u, n ** u) % n ** u
    return enc
```

wyglądał bardzo podobnie do kryptosystemu pailliera i po chwili googlowania znaleźliśmy informacje że jest to wersja uogóliona, znana jako kryptosystem damgård–jurik: https://en.wikipedia.org/wiki/damgård–jurik_cryptosystem

implementacja wyglądała na książkową, więc nie spodziewaliśmy się tutaj podatności.

algorytm generacji klucza:

```python
def get_keypair(kbit, u):
    l = getrandomrange(kbit >> 4, kbit)
    p = long(gmpy.next_prime(2 << l))
    q = long(getprime(kbit - l - 1))
    n = p * q
    d = (p - 1) * (q - 1) / gcd(p - 1, q - 1)
    r = getrandomrange(1, n - 1)
    while true:
        t = getrandomrange(1, n - 1)
        if gcd(t, n) == 1:
            break
    g = pow(n + 1, t, n ** (u + 1)) * r % n ** (u + 1)
    pubkey = (n, g, u)
    privkey = (n, d)
    return pubkey, privkey
```

na pierwszy rzut oka wygląda ok, ale po chwili zastanowienia zauważliśmy interesujący fakt.
szacowana przez nas wartość `kbit`, na podstawie kluczy publicznych które wyciagnęliśmy, wynosiła tylko 512 bitów.
to oznacza że `kbit >> 4` to raptem `32`!
więc zsięg dla jednej z liczb to pomiędzy 32 a 512 bitów a dla drugiej pomiędzy 0 a 479 bitów!

to nie brzmi zbyt bezpiecznie kiedy liczby pierwsze nie są podobnego rozmiaru.
ponieważ co połączenie dostajemy nowy klucz sesji, możemy oczekiwać, że kiedyś trafi nam się taki z względnie małym czynnikiem.
w związku z tym napisaliśmy skrypt do pobrania kluczy publicznych i pasujących do nich flag:

```python
import codecs
import hashlib
import re
import socket
import itertools
import string
from time import sleep


def recvuntil(s, tails):
    data = ""
    while true:
        for tail in tails:
            if tail in data:
                return data
        data += s.recv(1)


def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha512(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c


def grab_data(s):
    s.sendall("g\n")  # get public key
    sleep(1)
    public = recvuntil(s, "\n") + recvuntil(s, "\n")
    s.recv(99999)
    s.sendall("s\n")  # get flag
    sleep(1)
    encflag = recvuntil(s, "\n")
    s.recv(99999)
    return public, encflag


def main():
    while true:
        try:
            url = "dam.asis-ctf.ir"
            port = 34979
            s = socket.socket(socket.af_inet, socket.sock_stream)
            s.connect((url, port))
            x = proof_of_work(s)
            print(x)
            s.sendall(x + "\n")
            sleep(2)
            data = s.recv(9999)
            print(data)
            public, encflag = grab_data(s)
            with codecs.open("data.txt", "a") as keys_data:
                keys_data.write(public)
                keys_data.write(encflag + "\n")
        except:
            pass


main()
```

w ten sposób pobraliśmy trochę kluczy po jakimś czasie.
następny krok to znalezienie odpowiedniego modulusa z małym czynnikiem - po prostu wysłaliśmy uzyskane modulusu do yafu z timeoutem i trzymaliśmy kciuki.
na szczęście udało się dość szybko i dostaliśmy:

g = 2132051839750573299754854507364380969444028499581423474830053011031379601163074792669440458939453573346412661307966491517309566840273475971253252815424138851541945813878339754880371934727997401840883756793174023026387912833787561873964774343104161427421558277429398462610380913199026766005036911561111911498015614446521644547923419768095811788791898552705927717854674901759443511325189376351325806917211560457327283300074902178726201347950069589670988213859630524059734789901571017367997352139514205408014889400527318603702898182503607166931422225113192039575979803468157633585201622512457745586383739179657894475772
u = 3
flag = 16146846956417499078189378495360455759223869595378485457630764561369105704825747347552639327825348858161202688846334168331082417561328878910128831138772951255714265696309304528530025841643933748756877476450078970791315331759262515894580524581915667726800504296931313616859751122921688756817297843797340121021959810015729726300012075071651090158205135737206806416627610169333331691704947002581388291641532314716891417238670535879838292937496483821606837803344591931921999217676036196239569436244254894652087250116786992703898654314284929464910202202816397917119926061000276191503543076180026132619912576609446737065690

więc mieliśmy modulus z małym czynnikiem, raptem 39 bitów.
to oznacza że mogliśmy teraz odzyskać klucz prywatny za pomocą lcm.

z kluczem prywatnym pozostało nam już tylko odszyfrować flagę pasującą do złamanego klucza.
to okazało się problematyczne, bo nie mogliśmy nigdzie znaleźć implementacji tego algorytmu w wersji nie-uproszczonej.

więc finalnie wzięliśmy publikacje: http://www.brics.dk/rs/00/45/brics-rs-00-45.pdf i zaimplementowaliśmy kod samodzielnie:

```python
def l(x):
    return (x - 1) / n


def decrypt(ct, d, n, s):
    ns1 = pow(n, s + 1)
    a = pow(ct, d, ns1)
    i = 0
    for j in range(1, s + 1):
        t1 = l(a % pow(n, j + 1))
        t2 = i
        for k in range(2, j + 1):
            i -= 1
            t2 = (t2 * i) % pow(n, j)
            factorial = long(gmpy2.factorial(k))
            up = (t2 * pow(n, k - 1))
            down = gmpy2.invert(factorial, pow(n, j))
            t1 = (t1 - up * down) % pow(n, j)
        i = t1
    return i
```

z tą funkcja mogliśmy teraz odszyfrować flagę dostając `jmd mod n^s` a deszyfrując `g` dostaliśmy `jd mod n^s` z którego wyliczyliśmy modinv aby uzyskać wartość `m`:

```python
ns = pow(n, u)
jd = decrypt(g, d, n, u)
jd_inv = gmpy2.invert(jd, ns)
jmd = decrypt(flag, d, n, u)
f = (jd_inv * jmd) % ns
print("decrypted flag = " + long_to_bytes(f))
```