# vimjail (pwn)

###eng
[pl](#pl-version)

in the task we get credentials to log-in on the server via ssh.
we are `ctfuser` user and we can see that there is `flagreader` binary in our home, but with it's only executable for `secretuser`.
the binary also has guid bit set, so it can read flag in the `/.flag`.

by checking sudoers we notice that, as expected from the task name, we can sudo on secretuser when running `rvim`:

```
sudo -u secretuser rvim
```

the problem is that rvim restricts shell commands execution, so we can't simply run the `flagreader`.
it took us a lot of time to figure this out but finally we noticed that we can use a custom `.vimrc` file when starting rvim, and commands in such file will be executed with the current user provileges!

so by using file:

```
python3 import os
python3 os.system("/home/ctfuser/flagreader /.flag")
```

and running: 

```
sudo -u secretuser rvim -u ourvimrcfile
```

gives the flag `flag{rvim_is_no_silverbullet!!!111elf}`

###pl version

w zadaniu dostajemy dane do logowania na serwer po ssh.
logujemy się jako `ctfuser` i możemy zobaczyć ze ` home jest binarka `flagreader`, ale można jej użyć tylko jako `secretuser`.
binarka dodatkowo ma ustawiony guid i może odczytać flagę z `/.flag`.

po sprawdzeniu listy sudoers widzimy, że, zgodnie z oczekiwaniami po nazwie zadania, możemy zrobić sudo na secretusera uruchamiając `rvim`:

```
sudo -u secretuser rvim
```

problem polega na tym, że rvim nie pozwala na uruchamianie komend shell więc nie możemy po prostu uruchomić `flagreader`.
zajęło nam dość sporo czasu wpadnięcie na rozwiązanie, ale finalnie zauważyliśmy, że można przy starcie podać własny plik `.vimrc` a komendy z tego pliku zostaną wykonane z uprawnieniami aktualnego użytkownika!

więc używając pliku:

```
python3 import os
python3 os.system("/home/ctfuser/flagreader /.flag")
```

i uruchamiając:

```
sudo -u secretuser rvim -u ourvimrcfile
```

dostajemy flagę `flag{rvim_is_no_silverbullet!!!111elf}`
