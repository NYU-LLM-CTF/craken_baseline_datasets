#  the nospecial virus (misc 100)

> i have been infected with a virus like cryptolocker and now they ask for money to give me the password to this archive so i can get the password required to decrypt all my files. please help! 

> format response: dctf{md5(solution)} 

> https://dctf.def.camp/quals-2016/decrypt_files.rar

this task had an encrypted rar archive with a single 7-byte file stored in it. similar tasks happened in the past, for
instance: [here](https://github.com/p4-team/ctf/tree/master/2016-06-04-backdoor-ctf/crypto_crc) or
[there](https://github.com/p4-team/ctf/blob/820f3215e3c45f18e3073d55c7c3e745d37fb878/2016-08-21-bioterra-ctf/zip/readme.md).
we simply modified code used in these tasks, and it turned out one of the contents found using `a-z0-9` alphabet was
the correct one.
