## yacs2 - yet another captcha solver (ppc)

###eng
[pl](#pl-version)

the task looks very similar to the one from last year - we have a captcha recorded in a .wav file.
the captcha contains only numbers.
we are supposed to solve 3000 of them to get the flag.
apart from that the captcha is distorted by a constant background noise.

example: [captcha](captcha.wav)

we solved this with very little effort, using solver we developed last year.
the fun part is that this solver was not good enough last year and we had to make a different one, but this time it worked out-of-the-box.

instead of trying to remove the noise and then match some byte patterns for numbers, we just used google speech recognition :)

so we just download the captcha, solve it, send response and repeat this 3000 times to get the flag.

```python
import codecs
import os
import urllib
import urllib2
import speech_recognition as sr

url = 'http://yacst2.2016.volgactf.ru:8090/captcha'

opener = urllib2.build_opener()
opener.addheaders.append(('cookie', 'jsessionid=s4re0bja4po1o8wps9ygxf9fkxo4afqenjbhhjiz'))

post_opener = urllib2.build_opener(urllib2.httphandler())
post_opener.addheaders.append(('cookie', 'jsessionid=s4re0bja4po1o8wps9ygxf9fkxo4afqenjbhhjiz'))


def download_wav():
    wav = opener.open(url).read()
    with codecs.open("captcha.wav", mode="wb") as output:
        output.write(wav)


def convert_to_speech2():
    r = sr.recognizer()
    with sr.wavfile('captcha.wav') as source:
        audio = r.record(source)
        return r.recognize(audio)

def send_response(result):
    try:
        data = urllib.urlencode({'captcha': result})
        return post_opener.open(url, data=data).read()
    except:
        pass


def removefile():
    os.remove("captcha.wav")


def main():
    for i in range(3000):
        try:
            print(i)
            download_wav()
            result = convert_to_speech2()
            print(result)
            removefile()
            response = send_response(result)
        except:
            pass

main()
```

after the last one we are redirected to the flag:

`volgactf{sound is l1ke m@th if a+b=c then c-b=a}`

###pl version

zadanie jest bardzo podobne do zadania z zeszłego roku - mamy dźwiękowy kod captcha zapisany w pliku .wav.
captcha zawiera tylko liczby.
mamy do rozwiązania 3000 kodów aby uzyskać flagę.
dodatkowo captcha jest zniekształcona poprzez dodanie stałego dźwięku w tle.

przykład: [captcha](captcha.wav)

rozwiązaliśmy to zadanie bardzo niewielkim nakładem pracy, używając solvera napisanego rok temu.
co ciekawe, rok temu ten solver nie był wystarczająco dobry i musieliśmy zrobić inny, ale tym razem zadziałał od razu.

zamiast próbować usuwać zniekształcenie a następnie dopasowywać wzorce bajtów do numerów w captchy, użyliśmy google speech recognition :)

pobieramy więc captche, rozwiązujemy ją i odsyłamy wynik, to wszystko powtarzamy 3000 razy i dostajemy flagę.

```python
import codecs
import os
import urllib
import urllib2
import speech_recognition as sr

url = 'http://yacst2.2016.volgactf.ru:8090/captcha'

opener = urllib2.build_opener()
opener.addheaders.append(('cookie', 'jsessionid=s4re0bja4po1o8wps9ygxf9fkxo4afqenjbhhjiz'))

post_opener = urllib2.build_opener(urllib2.httphandler())
post_opener.addheaders.append(('cookie', 'jsessionid=s4re0bja4po1o8wps9ygxf9fkxo4afqenjbhhjiz'))


def download_wav():
    wav = opener.open(url).read()
    with codecs.open("captcha.wav", mode="wb") as output:
        output.write(wav)


def convert_to_speech2():
    r = sr.recognizer()
    with sr.wavfile('captcha.wav') as source:
        audio = r.record(source)
        return r.recognize(audio)

def send_response(result):
    try:
        data = urllib.urlencode({'captcha': result})
        return post_opener.open(url, data=data).read()
    except:
        pass


def removefile():
    os.remove("captcha.wav")


def main():
    for i in range(3000):
        try:
            print(i)
            download_wav()
            result = convert_to_speech2()
            print(result)
            removefile()
            response = send_response(result)
        except:
            pass

main()
```

po ostatnim kodzie zostajemy przekierowani do flagi:

`volgactf{sound is l1ke m@th if a+b=c then c-b=a}`
