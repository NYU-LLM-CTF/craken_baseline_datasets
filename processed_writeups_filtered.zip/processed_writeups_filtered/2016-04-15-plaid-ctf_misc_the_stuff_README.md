# the stuff (misc, 50pts, 219 solves)
	can you believe ryan uses bing?

the pcap file we got, contained a mail exchange. in one of the mails, there was
a password, and the other one contained an attached zip file. opening it using
password we had, gave us flag.


[image extracted text: oey
lop
54 20. 833249000
192. 168. 120. 138
192.168.120.1
imf
71 subject:
the stuff
from:
john
doe
doe@example
com>
(text/plain)
(application/zip)
5212 123.198114000
192.168 . 120. 138
192.168.120
imf
356 subject:
wait
hang on ,
rom:
john doe
doe@example
com>
you '1l need
this
too:
super
passwordl
annannna
168
120
192
168
120
755
npns
110 refrech
wrfn<aa>
yo ,]

