# woodstock (forensics)

###eng
[pl](#pl-version)

in the task we get a [pcap](ws1_2.pcapng).
if we just run strings or search on it we can get the first flag `bitsctf{such_s3cure_much_w0w}`.

the second flag is more complex to get here.
in the pcap we can see that there are 2 users interacting over some dc++/adc hub and exchanging a `fl3g.txt` file.
after analysing the input file and reading on the adc protocol we finally figured out that the file transfer part is actually missing from the pcap.
the only thing we can recover (eg. with binwalk, or by decoding zlib streams transferred) are file lists:

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<filelisting version="1" cid="iw27tt3cmx5nkvcsvj2cfjysvuuc6cb43ff3xla" base="/" generator="eiskaltdc++ 2.2.9">
<directory name="cadence">
</directory>
<directory name="dsp">
</directory>
<directory name="dc">
	<file name="defcon 19 - the art of trolling (w speaker)-ahqgv5wjs4w.mp4" size="98273830" tth="kevj3ebnse6xxltpvcb5wudms5kr7p32mjqcgwy"/>
	<file name="fallen kingdom - the complete minecraft music video series-ayl3uxkph1g.mp4" size="511422768" tth="m5pwqcu5auv5l4a367blgwwayd5u3nuavdtdqmi"/>
	<file name="fl3g.txt" size="14" tth="ca4cmf34shruqibg6mnrdai5bvt7hqqrtgc7tba"/>
	<file name="man punches a kangaroo in the face to rescue his dog (original hd)-firt7lf8byw.mkv" size="69864590" tth="soq7ecdj6ywm5f5z3xlxgofm6j23foknkww5pxy"/>
	<file name="poster.jpeg" size="89139" tth="iplzj2e4vjc4q5x5nq5d43cofau3cgsz5nqwjva"/>
	<file name="small2.jpg" size="669170" tth="k53v57zppjuot5caup6dm3bazi4ymuu536oyd3q"/>
	<file name="this week in stupid (04_12_2016)-m8ljl98_h60.mkv" size="252235314" tth="56ujjz32ldk7v7qr5pzkpt7n2vokpcy6wbzx3ja"/>
	<file name="trump up the jams! - the fallout of the 2016 election-jplqh70gnra.mkv" size="274708751" tth="yxpu6lcxah5ay6i63ktj4i3q36ymzexyepgs6mq"/>
	<file name="when leftists attack - sjws confront man over maga shirt-l4l-fk1dwhs.mp4" size="122011301" tth="b3w7ezgs2vmug6b773wcqkpq24g77r2eddasjii"/>
</directory>
</filelisting>
```

and 

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<filelisting version="1" cid="ah3kwvya5dawja7havhxc6bclpng34pvqvmpxpy" base="/" generator="eiskaltdc++ 2.2.9">
<directory name="dcpp">
	<file name="text" size="14" tth="ca4cmf34shruqibg6mnrdai5bvt7hqqrtgc7tba"/>
</directory>
</filelisting>
```

we notice that the file size if 14 bytes, and we know that the flag contains `bitsctf{}`, so in fact we're missing only 5 bytes.
fortunately admin disclosed that there is a trailing `\n` in the file, so in fact we're missing only 4 bytes!
and we know the tth hash of the flag file, so we can now brute-force the contents.

we had some issues with finding a proper code for this task, because different tools/libs were giving different hash results but we finally found a tool http://directory.fsf.org/wiki/tthsum which seemed to do the trick.

we used ramdisk to create temp files with potential flags and tested if the resulting hashes match the hash we have.
after a while we finally got the flag `bitsctf{sw3g}`

###pl version

w zadaniu dostajemy [pcapa](ws1_2.pcapng).
jeśli tylko uruchomimy na nim strings albo wyszukiwarke to znajdujemy pierwszą flagę `bitsctf{such_s3cure_much_w0w}`.

druga flaga była trochę bardziej skomplikowana.
w pcapie mamy interakcje dwóch użytkowników za pomocą huba dc++/adc i wymianę pliku `fl3g.txt`.
po dogłębnej analizie pcapa i protokołu adc doszliśmy do tego, że transferu pliku w pcapie nie ma.
jedyne co możemy odzyskać to listy plików (np. przez binwalka lub dekodując transferowane strumienie zlib):

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<filelisting version="1" cid="iw27tt3cmx5nkvcsvj2cfjysvuuc6cb43ff3xla" base="/" generator="eiskaltdc++ 2.2.9">
<directory name="cadence">
</directory>
<directory name="dsp">
</directory>
<directory name="dc">
	<file name="defcon 19 - the art of trolling (w speaker)-ahqgv5wjs4w.mp4" size="98273830" tth="kevj3ebnse6xxltpvcb5wudms5kr7p32mjqcgwy"/>
	<file name="fallen kingdom - the complete minecraft music video series-ayl3uxkph1g.mp4" size="511422768" tth="m5pwqcu5auv5l4a367blgwwayd5u3nuavdtdqmi"/>
	<file name="fl3g.txt" size="14" tth="ca4cmf34shruqibg6mnrdai5bvt7hqqrtgc7tba"/>
	<file name="man punches a kangaroo in the face to rescue his dog (original hd)-firt7lf8byw.mkv" size="69864590" tth="soq7ecdj6ywm5f5z3xlxgofm6j23foknkww5pxy"/>
	<file name="poster.jpeg" size="89139" tth="iplzj2e4vjc4q5x5nq5d43cofau3cgsz5nqwjva"/>
	<file name="small2.jpg" size="669170" tth="k53v57zppjuot5caup6dm3bazi4ymuu536oyd3q"/>
	<file name="this week in stupid (04_12_2016)-m8ljl98_h60.mkv" size="252235314" tth="56ujjz32ldk7v7qr5pzkpt7n2vokpcy6wbzx3ja"/>
	<file name="trump up the jams! - the fallout of the 2016 election-jplqh70gnra.mkv" size="274708751" tth="yxpu6lcxah5ay6i63ktj4i3q36ymzexyepgs6mq"/>
	<file name="when leftists attack - sjws confront man over maga shirt-l4l-fk1dwhs.mp4" size="122011301" tth="b3w7ezgs2vmug6b773wcqkpq24g77r2eddasjii"/>
</directory>
</filelisting>
```

oraz

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<filelisting version="1" cid="ah3kwvya5dawja7havhxc6bclpng34pvqvmpxpy" base="/" generator="eiskaltdc++ 2.2.9">
<directory name="dcpp">
	<file name="text" size="14" tth="ca4cmf34shruqibg6mnrdai5bvt7hqqrtgc7tba"/>
</directory>
</filelisting>
```

możemy zauważyć że rozmiar pliku z flagą to 14 bajtów a wiemy że flaga zawiera `bitsctf{}` więc brakuje nam jedynie 5 bajtów.
szczęśliwie admin wspomniał że plik kończy się znakiem `\n` więc brakuje już tylko 4 bajtów!
a znamy hash pliku, więc możemy brutować jego zawartość.

mieliśmy trochę problemów ze znalezieniem kodu do tego zadania ponieważ różne narzędzia/biblioteki dawały różne wyniki hasha. koniec końcówk znaleźliśmy narzędzie http://directory.fsf.org/wiki/tthsum które dawało dobre wyniki.

użyliśmy ramdisku żeby tworzyć tymczasowe pliku z potencjalnymi flagami i testowaliśmy czy wynikowe hashe pasują do pliku z flagą i finalnie dostaliśmy `bitsctf{sw3g}`
