﻿##exploit 1 (pwn, 100p)

###pl
[eng](#eng-version)

###eng version
