## meowmeow 75 (misc, 75p)


[image extracted text: downloads
bash
101*24
michas-macbook-air:downloac;
michals
meoymeoy
michas-macbook-air:download;
michals]


### pl
[eng](#eng-version)

dostajemy [dziwny plik tekstowy](meowmeow) z różnymi wyrażeniami typu `((_____ << __) + _)`

jeśli ktoś robił cokolwiek w c to pewnie rozpozna syntax tego języka.

`a << b` odpowiada przesunięciu `a` o `b` bitów w lewo, a `a + b` i `(...)` chyba nie muszę tłumaczyć :)

tak więc za dane podkreślenie podstawiamy jego długość i [wszystko uruchamiamy](solve.py). dostajaemy długą liczbę `0xa7d30363063346262616338356133653036663535303863343836616531653138397b53495341l`, zamieniamy ją na text i dostajemy `}060c4bbac85a3e06f5508c486ae1e189{sisa`

### eng version

in this task, we're presented with a [weird-looking text file](meowmeow) with various expressions like `((_____ << __) + _)`

if you've done almost anything in c then you should notice that this is a valid c code.

`a << b` corresponds to left bitwise shift, i don't think i have to explain how `a + b` and `(...)` work :)

so we swap each underline with it's length and try to run [the code](solve.py). we get this quite long hex number:`0xa7d30363063346262616338356133653036663535303863343836616531653138397b53495341l`, covert it to text and you get a reversed flag `}060c4bbac85a3e06f5508c486ae1e189{sisa`
