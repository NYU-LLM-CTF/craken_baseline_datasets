# private local comment (ppc)


in this ppc task we have 3 levels of python challenges where we need to extract some data in unusual way.
there is sandbox around all of the tasks so we can't spawn a shell or do anything like that, we need to use legit python code.

### private 

here we have code:

```python
import sys
from restrict import restrict

r = restrict()
# r.set_timeout()

class private:
    def __init__(self):
        pass

    def __flag(self):
        return "twctf{censored}"

p = private()
private = none

d = sys.stdin.read()
assert d is not none
assert "private" not in d, "private found!"
d = d[:24]

r.seccomp()

print eval(d)
```

so we have only instance of the class and we need to call a private method to get the flag.
this is trivial for anyone who knows python at least a little bit, or know how to use `dir()`.
in python there is no such thing as "private" really, the prefix `__` only causes the interpreter to rewrite the method name to `classname__methodname` so in our case `private__flag`.
there is still the second check, so we can't use `private` in our input and we have only 24 character to use, so we can't play around with extracting the class name from object.

as i mentioned, the `dir()` functions is useful here, it returns list of fields and methods of the objects, and in our case `dir(p)[0]` will return the name of method we want.
now we need some reflection to call the method from the string name, and we can use `getattr` for this.
the solution finally is: `getattr(p,dir(p)[0])()` and we get flag `twctf{__private is not private}`

### local

this time we get:

```python
import sys
from restrict import restrict

r = restrict()
# r.set_timeout()

def get_flag(x):
    flag = "twctf{censored}"
    return x

d = sys.stdin.read()
assert d is not none
d = d[:30]

r.seccomp()

print eval(d)
```

this time we need to extract value of local variable defined in a function.
people with some experience in refection in python will know that you can actually construct functions in the code just like any objects, and you can also decostruct them, because they are simply objects like any other.
each function has property `func_code` which contains details about the code of the function.
there we can find `co_const` property, which stores list of constant used in the function, just like our flag.

so we can simply send: `get_flag.func_code.co_consts` to recover the flag ` twctf{func_code is useful for metaprogramming}`

### comment

in the last taks we have code:

```python
import sys
from restrict import restrict

r = restrict()
# r.set_timeout()

d = sys.stdin.read()
assert d is not none
d = d[:20]

import comment_flag
r.seccomp()

print eval(d)
```

and the imported `comment_flag` module is:

```python
'''
welcome to unreadable area!
flag is twctf{censored}
'''
```

the trick here is that the comment defined at the very top of the module is actually treated by python as module documentation docstring.
as such it can be accessed via `__doc__` property of the module, so by sending `comment_flag.__doc__` we can recover the last flag: `twctf{very simple docstring}`
