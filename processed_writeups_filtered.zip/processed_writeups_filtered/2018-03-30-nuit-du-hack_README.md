# nuit du hack ctf quals 2018

team: shalom, akrasuski1, chivay, nazywam, eternal, rev, c7f.m0d3

### table of contents

* [basex (pwn)](basex)
* [rescue-shell (pwn)](rescue-shell)
* [shreddinger (ppc)](shreddinger)
* [assemblyme (re)](re_assembly)
* [linkedout (web)](web_linkedout)
* [pixeditor (web)](web_pixeditor)
* [where is my purse (for)](for_purse)
* [cryptolol (crypto/web)](cryptolol)