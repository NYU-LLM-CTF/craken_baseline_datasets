﻿##twitter search (recon, 200p)

	so you reached delhi and now the noise in your head is not allowing you to think rationally. the nosise in your head has origin its origin in your stomach. and this is a big hunger. you can finish one or probably 2 tandoori chicken. so where can you get the best tandoori chicken in delhi? this place tweeted last week that the tandoori chicken it servers is like never b4. you got its twitter handle?


###pl
[eng](#eng-version)

###eng version
