# fireplace (reverse, ppc, 763p)

> as it is in love and war, all is fair during the elections, especially when it comes to an opportunity to get rid of a candidate who is three points ahead of you. your secret agent in this candidate’s campaign office informed you of some secret documents which prove that your rival is guilty of bribery. unfortunately, one of his assistants noticed these documents and threw it into the fireplace before leaving the office, but your agent managed to damp down the fire and grab the pieces. restore the document and help you candidate to win!

> fireplace.tar

in this task we were given a binary and a random-looking bmp picture. the binary accepted a single command line 
argument - filename. when given any bmp picture, it would encrypt it somehow and overwrite the original picture.

reverse engineering the binary showed it generates an internal square picture using windows standard `rand` function
for pixel values. the input image, when interpreted as a matrix of 24-bit rgb values is then multiplied (as in
matrix multiplication) with that square image and saved as the output. all operations are done modulo `2**24`.

so, we get the following equation: `input * square = output`. since we know the output matrix (it's the 
random-looking bmp) and square (windows `rand` is deterministic - lcg), we can multiply both sides of the equation
by modular inverse of square matrix to get: `input = output * modinv(square)`. we implemented this in mixture
of python and sage and retrieved the original image.
