# counting (re, 246p)

> this strange program was found, which apparently specialises in counting. in order to find the flag, you need to output find what the output of ./counter 9009131337 is.

> code

> counter


in this challenge we were given two files: an elf binary, and a small unknown file.

running the binary with some small arguments gives the following results:

```
$ for i in 20 25 30; do time ./counter $i; done
ctf{0000000000000065}

real	0m0,015s
user	0m0,012s
sys	0m0,000s
ctf{000000000000000d}

real	0m0,096s
user	0m0,092s
sys	0m0,000s
ctf{000000000000013a}

real	0m1,015s
user	0m1,012s
sys	0m0,000s
```

ok, so running the file with argument as small as 30 already takes 30 seconds. that's too
bad, since we need to find the result of running `./counter 9009131337`. we need to find 
another way.

thankfully, the `counter` binary was pretty small and quite simple to analyze. it seemed
to be opening the `code` file and reading its contents to 16-byte sized structures.
the second part of the binary was a virtual machine - it executed the instructions encoded
in those structures. the virtual machine had 26 registers - apparently one per each letter
of the alphabet. the argument given in the command line was put in the first one (ra).
when the instruction pointer reaches the point after last instruction, the interpreter
exits, and the flag is printed containg the value in first register in hexadecimal format.

there were only three types of instructions:
- 0: increment rx, then jump to instruction y.
- 1: if rx is 0, jump to instruction y, otherwise decrement rx and jump to instruction z.
- 2: "fork" to instruction x, then copy first y registers from fork.

the last instruction could be also interpreted as function call, while saving all
the registers except for ones making up the return value.

we wrote a simple parser in python and used it to disassemble the file:

```
00: if (ra!=0){ ra--; jmp 01;} else jmp 02;
01: rb++; jmp 00;
02: rc++; jmp 03;
03: rc++; jmp 04;
04: rc++; jmp 05;
05: rc++; jmp 06;
06: rc++; jmp 07;
07: rc++; jmp 08;
08: rc++; jmp 09;
09: rc++; jmp 10;
10: rc++; jmp 11;
11: rc++; jmp 12;
12: rc++; jmp 13;
13: fork @ 108; copy up to rb; jmp 14;
14: if (ra!=0){ ra--; jmp 119;} else jmp 15;
15: fork @ 20; copy up to rb; jmp 16;
16: if (rc!=0){ rc--; jmp 16;} else jmp 17;
17: if (ra!=0){ ra--; jmp 18;} else jmp 19;
18: rc++; jmp 17;
19: fork @ 64; copy up to rb; jmp 119;
20: if (rc!=0){ rc--; jmp 20;} else jmp 21;
21: fork @ 29; copy up to rb; jmp 22;
22: if (ra!=0){ ra--; jmp 23;} else jmp 24;
23: rc++; jmp 22;
24: if (rb!=0){ rb--; jmp 25;} else jmp 26;
25: if (rz!=0){ rz--; jmp 00;} else jmp 21;
26: if (ra!=0){ ra--; jmp 26;} else jmp 27;
27: if (rc!=0){ rc--; jmp 28;} else jmp 119;
28: ra++; jmp 27;
29: if (rc!=0){ rc--; jmp 29;} else jmp 30;
30: fork @ 84; copy up to rb; jmp 31;
31: if (rd!=0){ rd--; jmp 31;} else jmp 32;
32: if (ra!=0){ ra--; jmp 33;} else jmp 34;
33: rd++; jmp 32;
34: if (rd!=0){ rd--; jmp 35;} else jmp 42;
35: if (rd!=0){ rd--; jmp 36;} else jmp 42;
36: fork @ 45; copy up to rb; jmp 37;
37: rc++; jmp 38;
38: if (rb!=0){ rb--; jmp 38;} else jmp 39;
39: if (ra!=0){ ra--; jmp 40;} else jmp 41;
40: rb++; jmp 39;
41: if (rz!=0){ rz--; jmp 00;} else jmp 30;
42: if (ra!=0){ ra--; jmp 42;} else jmp 43;
43: if (rc!=0){ rc--; jmp 44;} else jmp 119;
44: ra++; jmp 43;
45: if (rc!=0){ rc--; jmp 45;} else jmp 46;
46: fork @ 84; copy up to rb; jmp 47;
47: if (ra!=0){ ra--; jmp 48;} else jmp 49;
48: rc++; jmp 47;
49: fork @ 92; copy up to rc; jmp 50;
50: if (rb!=0){ rb--; jmp 51;} else jmp 119;
51: if (ra!=0){ ra--; jmp 51;} else jmp 52;
52: if (rb!=0){ rb--; jmp 52;} else jmp 53;
53: if (rc!=0){ rc--; jmp 54;} else jmp 55;
54: rb++; jmp 53;
55: fork @ 84; copy up to rb; jmp 56;
56: if (ra!=0){ ra--; jmp 57;} else jmp 58;
57: rc++; jmp 56;
58: fork @ 84; copy up to rb; jmp 59;
59: if (rb!=0){ rb--; jmp 60;} else jmp 61;
60: ra++; jmp 59;
61: if (rc!=0){ rc--; jmp 62;} else jmp 63;
62: ra++; jmp 61;
63: ra++; jmp 119;
64: fork @ 84; copy up to rb; jmp 65;
65: if (rd!=0){ rd--; jmp 65;} else jmp 66;
66: if (ra!=0){ ra--; jmp 67;} else jmp 68;
67: rd++; jmp 66;
68: if (rd!=0){ rd--; jmp 69;} else jmp 119;
69: ra++; jmp 70;
70: if (rd!=0){ rd--; jmp 71;} else jmp 119;
71: if (rb!=0){ rb--; jmp 72;} else jmp 119;
72: fork @ 64; copy up to rb; jmp 73;
73: if (re!=0){ re--; jmp 73;} else jmp 74;
74: if (ra!=0){ ra--; jmp 75;} else jmp 76;
75: re++; jmp 74;
76: if (rb!=0){ rb--; jmp 77;} else jmp 119;
77: fork @ 64; copy up to rb; jmp 78;
78: if (ra!=0){ ra--; jmp 79;} else jmp 80;
79: re++; jmp 78;
80: if (rb!=0){ rb--; jmp 80;} else jmp 81;
81: if (re!=0){ re--; jmp 82;} else jmp 83;
82: rb++; jmp 81;
83: fork @ 99; copy up to rb; jmp 119;
84: if (ra!=0){ ra--; jmp 84;} else jmp 85;
85: if (rb!=0){ rb--; jmp 86;} else jmp 119;
86: ra++; jmp 85;
87: if (ra!=0){ ra--; jmp 87;} else jmp 88;
88: if (rb!=0){ rb--; jmp 89;} else jmp 90;
89: ra++; jmp 88;
90: if (rc!=0){ rc--; jmp 91;} else jmp 119;
91: ra++; jmp 90;
92: if (ra!=0){ ra--; jmp 92;} else jmp 93;
93: if (rb!=0){ rb--; jmp 93;} else jmp 94;
94: if (rc!=0){ rc--; jmp 95;} else jmp 119;
95: if (rc!=0){ rc--; jmp 96;} else jmp 98;
96: ra++; jmp 97;
97: if (rz!=0){ rz--; jmp 00;} else jmp 94;
98: rb++; jmp 119;
99: fork @ 108; copy up to rb; jmp 100;
100: if (ra!=0){ ra--; jmp 101;} else jmp 103;
101: if (rb!=0){ rb--; jmp 102;} else jmp 119;
102: ra++; jmp 101;
103: fork @ 113; copy up to rb; jmp 104;
104: if (rb!=0){ rb--; jmp 104;} else jmp 105;
105: if (ra!=0){ ra--; jmp 106;} else jmp 107;
106: rb++; jmp 105;
107: if (rz!=0){ rz--; jmp 00;} else jmp 99;
108: if (ra!=0){ ra--; jmp 108;} else jmp 109;
109: if (rc!=0){ rc--; jmp 110;} else jmp 119;
110: if (rb!=0){ rb--; jmp 111;} else jmp 112;
111: if (rz!=0){ rz--; jmp 00;} else jmp 108;
112: ra++; jmp 119;
113: if (rc!=0){ rc--; jmp 114;} else jmp 116;
114: if (rb!=0){ rb--; jmp 115;} else jmp 119;
115: if (rz!=0){ rz--; jmp 00;} else jmp 113;
116: if (ra!=0){ ra--; jmp 116;} else jmp 117;
117: if (rb!=0){ rb--; jmp 118;} else jmp 119;
118: ra++; jmp 117;
```

hmm. that's quite a bit of arcane instructions. 

we implemented a simple interpreter (in python too) running the code to make sure
we understood the opcodes correctly. and yep, it returned the same result as the original
binary (though a couple of times slower).

we definitely need to optimize the code a bit, but it's a bit hard to read. we can improve
readability by skipping the `jmp xxx` bit if the target of the jump is the next instruction.
also, there are some instructions like:
```
108: if (ra!=0){ ra--; jmp 108;} else jmp 109;
```
we can easily translate it to:
```
108: ra=0;
```
this also improves performance! i also added empty line before each fork target, to 
visually separate "subroutines".

new, slightly more readable code:
```
00: if (ra!=0){ ra--; } else jmp 02
01: rb++; jmp 00;
02: rc++; 
03: rc++; 
04: rc++; 
05: rc++; 
06: rc++; 
07: rc++; 
08: rc++; 
09: rc++; 
10: rc++; 
11: rc++; 
12: rc++; 
13: fork @ 108; copy up to rb; jmp 14;
14: if (ra!=0){ ra--; jmp 119;} else 
15: fork @ 20; copy up to rb; jmp 16;
16: rc=0; 
17: if (ra!=0){ ra--; } else jmp 19
18: rc++; jmp 17;
19: fork @ 64; copy up to rb; jmp 119;

20: rc=0; 
21: fork @ 29; copy up to rb; jmp 22;
22: if (ra!=0){ ra--; } else jmp 24
23: rc++; jmp 22;
24: if (rb!=0){ rb--; } else jmp 26
25: if (rz!=0){ rz--; jmp 00;} else jmp 21
26: ra=0; 
27: if (rc!=0){ rc--; } else jmp 119
28: ra++; jmp 27;

29: rc=0; 
30: fork @ 84; copy up to rb; jmp 31;
31: rd=0; 
32: if (ra!=0){ ra--; } else jmp 34
33: rd++; jmp 32;
34: if (rd!=0){ rd--; } else jmp 42
35: if (rd!=0){ rd--; } else jmp 42
36: fork @ 45; copy up to rb; jmp 37;
37: rc++; 
38: rb=0; 
39: if (ra!=0){ ra--; } else jmp 41
40: rb++; jmp 39;
41: if (rz!=0){ rz--; jmp 00;} else jmp 30
42: ra=0; 
43: if (rc!=0){ rc--; } else jmp 119
44: ra++; jmp 43;

45: rc=0; 
46: fork @ 84; copy up to rb; jmp 47;
47: if (ra!=0){ ra--; } else jmp 49
48: rc++; jmp 47;
49: fork @ 92; copy up to rc; jmp 50;
50: if (rb!=0){ rb--; } else jmp 119
51: ra=0; 
52: rb=0; 
53: if (rc!=0){ rc--; } else jmp 55
54: rb++; jmp 53;
55: fork @ 84; copy up to rb; jmp 56;
56: if (ra!=0){ ra--; } else jmp 58
57: rc++; jmp 56;
58: fork @ 84; copy up to rb; jmp 59;
59: if (rb!=0){ rb--; } else jmp 61
60: ra++; jmp 59;
61: if (rc!=0){ rc--; } else jmp 63
62: ra++; jmp 61;
63: ra++; jmp 119;

64: fork @ 84; copy up to rb; jmp 65;
65: rd=0; 
66: if (ra!=0){ ra--; } else jmp 68
67: rd++; jmp 66;
68: if (rd!=0){ rd--; } else jmp 119
69: ra++; 
70: if (rd!=0){ rd--; } else jmp 119
71: if (rb!=0){ rb--; } else jmp 119
72: fork @ 64; copy up to rb; jmp 73;
73: re=0; 
74: if (ra!=0){ ra--; } else jmp 76
75: re++; jmp 74;
76: if (rb!=0){ rb--; } else jmp 119
77: fork @ 64; copy up to rb; jmp 78;
78: if (ra!=0){ ra--; } else jmp 80
79: re++; jmp 78;
80: rb=0; 
81: if (re!=0){ re--; } else jmp 83
82: rb++; jmp 81;
83: fork @ 99; copy up to rb; jmp 119;

84: ra=0; 
85: if (rb!=0){ rb--; } else jmp 119
86: ra++; jmp 85;
87: ra=0; 
88: if (rb!=0){ rb--; } else jmp 90
89: ra++; jmp 88;
90: if (rc!=0){ rc--; } else jmp 119
91: ra++; jmp 90;

92: ra=0; 
93: rb=0; 
94: if (rc!=0){ rc--; } else jmp 119
95: if (rc!=0){ rc--; } else jmp 98
96: ra++; 
97: if (rz!=0){ rz--; jmp 00;} else jmp 94
98: rb++; jmp 119;

99: fork @ 108; copy up to rb; jmp 100;
100: if (ra!=0){ ra--; } else jmp 103
101: if (rb!=0){ rb--; } else jmp 119
102: ra++; jmp 101;
103: fork @ 113; copy up to rb; jmp 104;
104: rb=0; 
105: if (ra!=0){ ra--; } else jmp 107
106: rb++; jmp 105;
107: if (rz!=0){ rz--; jmp 00;} else jmp 99

108: ra=0; 
109: if (rc!=0){ rc--; } else jmp 119
110: if (rb!=0){ rb--; } else jmp 112
111: if (rz!=0){ rz--; jmp 00;} else jmp 108
112: ra++; jmp 119;

113: if (rc!=0){ rc--; } else jmp 116
114: if (rb!=0){ rb--; } else jmp 119
115: if (rz!=0){ rz--; jmp 00;} else jmp 113
116: ra=0; 
117: if (rb!=0){ rb--; } else jmp 119
118: ra++; jmp 117;
```

now, we needed to slowly analyze what each function does. we can either do this black
box style (using a lot of inputs and analyzing output to guess a function), or white box
(just analyze each instruction properly). we ended up doing it the latter way, as functions
are short enough not to be painful to analyze.

we started at leaf functions, i.e. ones without forks in themselves. for example function
at 113:
```
113: if (rc!=0){ rc--; } else jmp 116
114: if (rb!=0){ rb--; } else jmp 119
115: if (rz!=0){ rz--; jmp 00;} else jmp 113
116: ra=0; 
117: if (rb!=0){ rb--; } else jmp 119
118: ra++; jmp 117;
```
it can be literally transcribed to:
```
while true:
  if rc != 0:   # 113
    rc--
    if rb != 0: # 114
      rb--
    else:
      return
    continue
  else:
    break

ra = 0       # 116
while true:
  if rb != 0:
    rb--
    ra++
  else:
    break
```
it's pretty weird code, but putting loop-ending conditions in the `while` condition 
and ignoring useless assignments makes it better:
```
while rc != 0:
  rc--
  rb--
ra = 0
while rb != 0:
  ra++
  rb--
```
with code written as such, we can recognize the function as subtraction - `ra = rb-rc`.
the `ra` register is then copied to the main, non-forked function as a return value.

now that we know what this function does, we can patch our interpreter to make it run 
faster by adding a special case to its main loop:
```python
if pc == 113:
    regs[0] = regs[1]-regs[2]
    break
```
this has somewhat sped up calculations. without reversing all the functions though,
the calculation is still way too slow.

i won't write up how to reverse all the functions - i'll just summarize what each of them does
(roughly in the order i reversed them):

```
113: return rb-rc;
108: return rc>rb;
99: return rb mod rc;  (this was calculated by repeated subtraction of rc from rb)
84: return rb;         (this might seem unnecessary, but it's used as a means 
                        of copying a register)
92: return rc/2, rc%2; (this function is unique in that it returns two values in ra and rb)
45: if rb%2 == 0:
      return rb/2;
    else:
      return rb*3+1;   (a.k.a. collatz sequence)
29: return total_stopping_time(rb); (a.k.a. number of iterations we need to apply
                                     collatz function, until we get a 1)
20: return sum(total_stopping_time(i) for i in 1..n)
64: return fibonacci(rb) % rc (originally calculated in exponential time - recursively)
0: return fibmod(arg, sumcollatz(arg))
```

we implemented all of these shortcuts in our interpreter, but it was still very slow.
we were able to calculate an answer up to maybe a couple millions, but after that it was 
too much waiting. instead, we rewrote the final function to c++ code. we also memoized
all the collatz stopping times for all integers up to a billion - it took 2gb of ram, but
sped up calculations significantly. in the end, the c++ code printed the flag after just
a couple of minutes.

the disassembler and sped up interpreter is in `parse.py` file, while the final c++
solver is in `fast.cpp` file. python code gets its argument as command line argument,
while c++ one reads it from stdin.
