# the worst rsa joke (crypto)

in the task we get [public key](public.pem) and [ciphertext](flag.enc).
the description of the task states that someone decided to use a single prime as modulus for rsa encryption.

the difficulty of breaking rsa is based on the fact that the number of co-prime numbers to the modulus (so-called euler's totient function) is secret.
for a prime number this value is known and is simply `p-1`.
for product of two co-prime numbers it is `(p-1)*(q-1)`, and here is the strength of rsa - in order to calculate this value we need to know prime factors of the modulus, and finding those is hard.

in our case this whole problem doesn't exist, since we know `p` and therefore we know `p-1` as well.
therefore we can simply calculate the private key exponent as `modinv(e,p-1)` and decrypt the ciphertext.

```python
import codecs

from crypto.publickey import rsa

from crypto_commons.generic import bytes_to_long
from crypto_commons.rsa.rsa_commons import modinv, rsa_printable


def main():
    with codecs.open("public.pem", "r") as input_file:
        pub = input_file.read()
        pub = rsa.importkey(pub)
        print(pub.e, pub.n)
        with codecs.open("flag.enc", 'r') as input_flag:
            data = input_flag.read().decode("base64")
            d = modinv(pub.e, pub.n-1)
            print(rsa_printable(bytes_to_long(data), d, pub.n))


main()
```

and we get `flag{s1ngl3_pr1m3_m0dulus_att4ck_tak3d_d0wn_rsa_t0_a_sym3tr1c_alg0r1thm}`
