﻿## android (reverse, 100p)

> find the flag!!
> [download](sharif_ctf.apk)

###eng
[pl](#pl-version)

we download android application given to us by challenge creators.
first think we do is packing it into java decompiler (http://www.javadecompilers.com/apk).

most of code is boring and uninteresting, but one of functions is clearly more interesting:

```java
public void onclick(view view) {
    string str = new string(" ");
    str = this.f5a.f1b.gettext().tostring();
    log.v("edittext", this.f5a.f1b.gettext().tostring());
    string str2 = new string("");
    int processobjectarrayfromnative = this.f5a.processobjectarrayfromnative(str);
    int iscorrect = this.f5a.iscorrect(str);
    str = new stringbuilder(string.valueof(this.f5a.f3d + processobjectarrayfromnative)).append(" ").tostring();
    try {
        messagedigest instance = messagedigest.getinstance("md5");
        instance.update(str.getbytes());
        byte[] digest = instance.digest();
        stringbuffer stringbuffer = new stringbuffer();
        for (byte b : digest) {
            stringbuffer.append(integer.tostring((b & 255) + 256, 16).substring(1));
        }
        if (iscorrect == 1 && this.f5a.f4e != "unknown") {
            this.f5a.f2c.settext("sharif_ctf(" + stringbuffer.tostring() + ")");
        }
        if (iscorrect == 1 && this.f5a.f4e == "unknown") {
            this.f5a.f2c.settext("just keep trying :-)");
        }
        if (iscorrect == 0) {
            this.f5a.f2c.settext("just keep trying :-)");
        }
    } catch (nosuchalgorithmexception e) {
        e.printstacktrace();
    }
}
```

as you can see, this function gets text from button and uses "iscorrect" method to check input validity. if input is valid, flag is given to the user.

fortunately, iscorrect is native function, so we have to disassemble arm library to get our hands on the flag.

[libadnjni.so](libadnjni.so)

function iscorrect is very long, but most of it is not important. in fact, everything it does is calling strcmp on constant input.
to be precise, input from user is compared to hardcoded string 'ef57f3fe3cf603c03890ee588878c0ec'.

it's enough to enter this string into application as password and we get the flag.

###pl version

pobieramy androidową aplikację którą dają nam twórcy zadania. pierwsze co robimy, to pakujemy ją do dekompilera javy (http://www.javadecompilers.com/apk).

wiekszość kodu to jak zwykle śmieci, ale znajdujemy jedną ciekawą funkcję:

```java
public void onclick(view view) {
    string str = new string(" ");
    str = this.f5a.f1b.gettext().tostring();
    log.v("edittext", this.f5a.f1b.gettext().tostring());
    string str2 = new string("");
    int processobjectarrayfromnative = this.f5a.processobjectarrayfromnative(str);
    int iscorrect = this.f5a.iscorrect(str);
    str = new stringbuilder(string.valueof(this.f5a.f3d + processobjectarrayfromnative)).append(" ").tostring();
    try {
        messagedigest instance = messagedigest.getinstance("md5");
        instance.update(str.getbytes());
        byte[] digest = instance.digest();
        stringbuffer stringbuffer = new stringbuffer();
        for (byte b : digest) {
            stringbuffer.append(integer.tostring((b & 255) + 256, 16).substring(1));
        }
        if (iscorrect == 1 && this.f5a.f4e != "unknown") {
            this.f5a.f2c.settext("sharif_ctf(" + stringbuffer.tostring() + ")");
        }
        if (iscorrect == 1 && this.f5a.f4e == "unknown") {
            this.f5a.f2c.settext("just keep trying :-)");
        }
        if (iscorrect == 0) {
            this.f5a.f2c.settext("just keep trying :-)");
        }
    } catch (nosuchalgorithmexception e) {
        e.printstacktrace();
    }
}
```

jak widać, jest jest na czymś wywoływana funkcja iscorrect, i jeśli wywołanie zakończy sie sukcesem, flaga jest przekazywana użytkownikowi.

niestety (albo na szczęście), iscorrect jest funkcją natywną, więc żeby ją przeanalizować musimy disasemblować armową bibliotekę

[libadnjni.so](libadnjni.so)

funkcja iscorrect zawiera bardzo dużo kodu, ale większośc jest niepotrzebna. tak naprawdę wywołuje tylko strcmp ze stałym napisem.
konkretnie input użytkownika jest porównywany z 'ef57f3fe3cf603c03890ee588878c0ec'.

wystarczy wprowadzić tą wartość w aplikacji androidowej, i dostajemy flagę. 100 punktów do przodu.
