# codegate ctf 2018 quals

team: akrasuski1, shalom, pwn.m0d3, msm, nazywam

### table of contents

* [droid (re)](re_droid)
