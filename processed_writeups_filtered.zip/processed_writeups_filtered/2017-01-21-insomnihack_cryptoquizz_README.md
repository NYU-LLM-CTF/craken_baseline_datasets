# cryptoquizz (crypto/misc 50)

###eng
[pl](#pl-version)

the task was marked as crypto but it was a misc if anything.
in the task the server ask us about a year of birth of some famous cryptographer and after a while sends a flag.
we made a script which was taking data from google and wikipedia for this.
since the timeout was very short we cached all results we had and stored in a dict for later reuse:

```python
import re
import requests
from crypto_commons.netcat.netcat_commons import nc, receive_until_match


def get_birth_year(name):
    url = "https://www.google.pl/search?q=" + (name.replace(" ", "+"))
    content = requests.get(url).content
    reg = "data i miejsce urodzenia:.+?(\d{4})"
    potential = re.findall(reg, content)
    if len(potential) > 0:
        return potential[0]
    reg = "data urodzenia:.+?(\d{4})"
    potential = re.findall(reg, content)
    if len(potential) > 0:
        return potential[0]
    else:
        url = "https://en.wikipedia.org/wiki/" + (name.replace(" ", "_"))
        content = requests.get(url).content
        reg = "\(.*born.*(\d{4})\)"
        return re.findall(reg, content)[0]


def main():
    dictionary = {'david chaum': '1955', 'paul kocher': '1973', 'jean-jacques quisquater': '1945',
                  'gilles brassard': '1955', 'david naccache': '1967', 'claus-peter schnorr': '1943',
                  'oded goldreich': '1957', 'scott vanstone': '1947', 'douglas stinson': '1956',
                  'vincent rijmen': '1970', 'yehuda lindell': '1971', 'daniel bleichenbacher': '1964',
                  'rafail ostrovsky': '1963', 'wang xiaoyun': '1966', 'donald davies': '1924', 'claude shannon': '1916',
                  'daniel j. bernstein': '1971', 'neal koblitz': '1948', 'tatsuaki okamoto': '1952',
                  'horst feistel': '1915', 'paul van oorschot': '1962', 'whitfield diffie': '1944',
                  'kaisa nyberg': '1948', 'lars knudsen': '1962', 'alan turing': '1912', 'markus jakobsson': '1968',
                  'silvio micali': '1954', 'nigel p. smart': '1967', 'ivan damgard': '1956', 'jacques patarin': '1965',
                  'serge vaudenay': '1968', 'jacques stern': '1949', 'ron rivest': '1947', 'yvo desmedt': '1956',
                  'arjen k. lenstra': '1956'}
    s = nc("quizz.teaser.insomnihack.ch", 1031)
    reg = "what is the birth year of (.*) \?\n\n"
    try:
        while true:
            data = receive_until_match(s, reg, 1000)
            print(data)
            name = re.findall(reg, data)[0]
            print(name)
            if name in dictionary:
                year = dictionary[name]
            else:
                year = get_birth_year(name)
                dictionary[name] = year
            print(year)
            s.sendall(year + "\n")
            print(dictionary)
    except:
        print(data)
        print(dictionary)


main()
```

and this got us instantly: `ins{genuine_cryptographer_but_not_yet_a_proven_skilled_one}`

###pl version

zadanie było oznaczone jako crypto, ale ewidentnie był to misc.
w zadaniu serwer pyta nas o rok urodzenia sławnych kryptografów a po kilku udanych próbach zwraca flagę.
napisaliśmy skrypt który za pomocą google i wikipedii wyszukiwał odpowiedź.
timeout był bardzo krótki więc wyniki zbieraliśmy w mapie żeby móc je ponownie wykorzystać.

```python
import re
import requests
from crypto_commons.netcat.netcat_commons import nc, receive_until_match


def get_birth_year(name):
    url = "https://www.google.pl/search?q=" + (name.replace(" ", "+"))
    content = requests.get(url).content
    reg = "data i miejsce urodzenia:.+?(\d{4})"
    potential = re.findall(reg, content)
    if len(potential) > 0:
        return potential[0]
    reg = "data urodzenia:.+?(\d{4})"
    potential = re.findall(reg, content)
    if len(potential) > 0:
        return potential[0]
    else:
        url = "https://en.wikipedia.org/wiki/" + (name.replace(" ", "_"))
        content = requests.get(url).content
        reg = "\(.*born.*(\d{4})\)"
        return re.findall(reg, content)[0]


def main():
    dictionary = {'david chaum': '1955', 'paul kocher': '1973', 'jean-jacques quisquater': '1945',
                  'gilles brassard': '1955', 'david naccache': '1967', 'claus-peter schnorr': '1943',
                  'oded goldreich': '1957', 'scott vanstone': '1947', 'douglas stinson': '1956',
                  'vincent rijmen': '1970', 'yehuda lindell': '1971', 'daniel bleichenbacher': '1964',
                  'rafail ostrovsky': '1963', 'wang xiaoyun': '1966', 'donald davies': '1924', 'claude shannon': '1916',
                  'daniel j. bernstein': '1971', 'neal koblitz': '1948', 'tatsuaki okamoto': '1952',
                  'horst feistel': '1915', 'paul van oorschot': '1962', 'whitfield diffie': '1944',
                  'kaisa nyberg': '1948', 'lars knudsen': '1962', 'alan turing': '1912', 'markus jakobsson': '1968',
                  'silvio micali': '1954', 'nigel p. smart': '1967', 'ivan damgard': '1956', 'jacques patarin': '1965',
                  'serge vaudenay': '1968', 'jacques stern': '1949', 'ron rivest': '1947', 'yvo desmedt': '1956',
                  'arjen k. lenstra': '1956'}
    s = nc("quizz.teaser.insomnihack.ch", 1031)
    reg = "what is the birth year of (.*) \?\n\n"
    try:
        while true:
            data = receive_until_match(s, reg, 1000)
            print(data)
            name = re.findall(reg, data)[0]
            print(name)
            if name in dictionary:
                year = dictionary[name]
            else:
                year = get_birth_year(name)
                dictionary[name] = year
            print(year)
            s.sendall(year + "\n")
            print(dictionary)
    except:
        print(data)
        print(dictionary)


main()
```

to prawie od razu dało nam: `ins{genuine_cryptographer_but_not_yet_a_proven_skilled_one}`
