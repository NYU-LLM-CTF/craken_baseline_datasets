## p1ng (forensics, 121p)

###eng
[pl](#pl-version)

we are given interesting file, that looks like regular png file.


[image extracted text: [image not found]]


though your browser may or may not support it. because (surprise!) it's not regular png file - it's so called apng file (animated png). after we discovered it (using tweakpng) we tried to unpack all the frames with available tools. unfortunately, no ready-to-use program was able to unpack this image (i'm not sure why). so we hacked something in php, using stackoverflow of course:

```php
<?php

function splitapng($data) {
  $parts = array();

  // save the png signature   
  $signature = substr($data, 0, 8);
  $offset = 8;
  $size = strlen($data);
  while ($offset < $size) {
    // read the chunk length
    $length = substr($data, $offset, 4);
    $offset += 4;

    // read the chunk type
    $type = substr($data, $offset, 4);
    $offset += 4;

    // unpack the length and read the chunk data including 4 byte crc
    $ilength = unpack('nlength', $length);
    $ilength = $ilength['length'];
    $chunk = substr($data, $offset, $ilength+4); 
    $offset += $ilength+4;

    if ($type == 'ihdr')
      $header = $length . $type . $chunk;  // save the header chunk
    else if ($type == 'iend')
      $end = $length . $type . $chunk;     // save the end chunk
    else if ($type == 'idat') 
      $parts[] = $length . $type . $chunk; // save the first frame
    else if ($type == 'fdat') {
      // animation frames need a bit of tweaking.
      // we need to drop the first 4 bytes and set the correct type.
      $length = pack('n', $ilength-4);
      $type = 'idat';
      $chunk = substr($chunk,4);
      $parts[] = $length . $type . $chunk;
    }
  }

  // now we just add the signature, header, and end chunks to every part.
  for ($i = 0; $i < count($parts); $i++) {
    $parts[$i] = $signature . $header . $parts[$i] . $end;
  }

  return $parts;
}

$filename = 'p1ng';

$handle = fopen($filename, 'rb');
$filesize = filesize($filename);
$data = fread($handle, $filesize);
fclose($handle);

$parts = splitapng($data);

for ($i = 0; $i < count($parts); $i++) {
  $handle = fopen("part-$i.png",'wb');
  fwrite($handle,$parts[$i]);
  fclose($handle);
}
```

to be honest, we have stolen this script from so almost completely.

nevertheless, after execution we had a lot of chunks on disk:


[image extracted text: asis]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


(if you see only first chunk, that's because your browser rejects chunks with invalid crc. tell your browser to chill out).

and, with a bit of determination, we could just read a flag from them:

`asis{as_l0n9_4s_ctf_3x1sts_th3r3_w1ll_b3_asis_4nd_4s_l0n9_4s_asis_3x1sts_th3r3_w1ll_b3_png!}`

###pl version

dostajemy w zadaniu ciekawy plik, który wygląda jak obrazek png:


[image extracted text: [image not found]]


powinniście go zobaczyć, jeśli wasza przeglądarka go obsługuje, bo - niespodzianka - to nie jest zwykły plik png. plik jest w formacie apng (animated png). kiedy to odkryliśmy (używając programu tweakpng), spróbowaliśmy go odpakować na poszczególne ramki, używajac gotowych narzędzi znalezionych w internecie. niestety, wszystkie poległy - nie jestem pewien dlaczego. dlatego napisaliśmy na szybko skrypt w php:

```php
<?php

function splitapng($data) {
  $parts = array();

  // save the png signature   
  $signature = substr($data, 0, 8);
  $offset = 8;
  $size = strlen($data);
  while ($offset < $size) {
    // read the chunk length
    $length = substr($data, $offset, 4);
    $offset += 4;

    // read the chunk type
    $type = substr($data, $offset, 4);
    $offset += 4;

    // unpack the length and read the chunk data including 4 byte crc
    $ilength = unpack('nlength', $length);
    $ilength = $ilength['length'];
    $chunk = substr($data, $offset, $ilength+4); 
    $offset += $ilength+4;

    if ($type == 'ihdr')
      $header = $length . $type . $chunk;  // save the header chunk
    else if ($type == 'iend')
      $end = $length . $type . $chunk;     // save the end chunk
    else if ($type == 'idat') 
      $parts[] = $length . $type . $chunk; // save the first frame
    else if ($type == 'fdat') {
      // animation frames need a bit of tweaking.
      // we need to drop the first 4 bytes and set the correct type.
      $length = pack('n', $ilength-4);
      $type = 'idat';
      $chunk = substr($chunk,4);
      $parts[] = $length . $type . $chunk;
    }
  }

  // now we just add the signature, header, and end chunks to every part.
  for ($i = 0; $i < count($parts); $i++) {
    $parts[$i] = $signature . $header . $parts[$i] . $end;
  }

  return $parts;
}

$filename = 'p1ng';

$handle = fopen($filename, 'rb');
$filesize = filesize($filename);
$data = fread($handle, $filesize);
fclose($handle);

$parts = splitapng($data);

for ($i = 0; $i < count($parts); $i++) {
  $handle = fopen("part-$i.png",'wb');
  fwrite($handle,$parts[$i]);
  fclose($handle);
}
```

tak szczerze mówiąc, to bardziej ukradliśmy ten skrypt z so niż `napisaliśmy`.

tak czy inaczej, po wykonaniu tego skryptu otrzymaliśmy wiele chunków na dysku:


[image extracted text: asis]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


[image extracted text: [image processing failed]]


(jeśli widzisz tylko jeden obrazek, to dlatego że twoja przeglądarka odrzuca obrazy z nieprawidłowym crc. powiedz swojej przeglądarce żeby wyluzowała.)

i, z odpowiednią determinacją, byliśmy w stanie odczytać flagę:

`asis{as_l0n9_4s_ctf_3x1sts_th3r3_w1ll_b3_asis_4nd_4s_l0n9_4s_asis_3x1sts_th3r3_w1ll_b3_png!}`
