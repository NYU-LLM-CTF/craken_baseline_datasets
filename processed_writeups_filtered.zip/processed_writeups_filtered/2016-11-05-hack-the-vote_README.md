# writeup hack the vote ctf 2016

team: akrasuski1, c7f.m0d3, cr019283, nazywam, seikendev, ppr, other019, msm, rev, psrok1, shalom


[image extracted text: top 10 teams
00o
odaysober
asis
5000
dragon sector
lab rats
4000
ppp
tasteless
3000
dcua
p4team
2000
pdgn
cbic
1000
nov 5 ooh
nov 5 06h
nov 5 12h
nov 5 18h
nov 6 ooh
nov 6 06h
nov 6 12h
nov 6 18h
nov
ooh
2016
place
team
score
dragon sector
5651
tasteless
5551
odaysober
5151
ppp
4651
dcua
4651
pateam
4201]



### table of contents

* [top kek (crypto 50)](kek_crypto_50)
* [trump trump (crypto 100)](trump_crypto_100)
* [boxes of ballots (crypto 200)](ballots_crypto_200)
* [the best rsa (crypto 250)](rsa_crypto_250)
* [baby hands (crypto 300)](hands_crypto_300)
* [smtpresident (crypto 400)](smtp_crypto_400)
