# shreddinger, 500p, dev

> the infamous shredder tried to destroy important documents ! please, help us recover them and prevents their evil scheme.

in this task we were given a simulated piece of paper cut into a hundred strips,
as though it went through idealized shredding machine. we were supposed to
piece them together to obtain original image, then read the written message -
all within ten seconds.

our solution was based on simulated annealing - basicly start with a random
permutation of pieces, then try to randomly swap two of them and check if 
the resulting picture is better than previous one - if not, keep the old
configuration, else the new. with small probability we also mutated it anyway,
to escape local minima. another kind of move was 180 degree rotation of random
subsequence of strips.

score of a configuration was defined as sum of differences of pixels on seams.
since this is a pretty expensive operation to calculate, we preprocessed the
pieces and calculated partial scores of each pair of strips assuming they're
neighbours. this was still too slow, so we rewrote the sa part to c++.

finally, when we stitched together the image, we still had to ocr it. usual
tools - tesseract and friends - were useless for this font, so we manually
created the font images and wrote our own ocr in python.

the whole script was rather hacky and kind of slow (it was usually taking 
almost the full 10 seconds), it was failing randomly, but after a couple of 
tries, we managed to pass the checks.
