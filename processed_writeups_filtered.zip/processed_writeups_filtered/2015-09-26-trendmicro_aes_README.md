## aes (crypto, 200p)

### pl version
`for eng version scroll down`

zadanie polegało na odzyskaniu wektora inicjalizacyjnego iv dla szyfru aes na podstawie znajomości wiadomości, części klucza oraz części zaszyfrowanego tekstu. dane były przekazane za pomocą pomazanego zdjęcia kodu:


[image extracted text: encryptpy
#wusr /bin/env
from crypto cipher import aes
import sys
import binascii
#predefine
key="5d6[9pfrzc1jqt
#replace with random number
iv="
encrypt function
def encrypt(message, passphrase):
aes =
aes.new(passphrase, aes mode_cbc, iv)
return aes_
s.encrypt(message)
# check argument
liflen(sysargv) < 2:
print "please input your datal"
sysexit
result
print "encrypted data:
-binascihexlifycencrypt(sysargv[!}, key))
python
'the
protected by
encrypted
python
output =
dry "
run:
encryptpy
message
aesv"
data:
jec3307df037c689300bbf2812ff89bc0b49]


wynika z nich że dysponujemy:

* częścią klucza `5d6i9pfr7c1jqt` z brakującymi ostatnimi 2 bajtami
* wiadomością `the message is protected by aes!`
* fragmentem zaszyfrowanego tekstu `fe000000000000000000000000009ec3307df037c689300bbf2812ff89bc0b49` (przez 0 oznaczam padding nieznanych elementów)

pierwszy krokiem, po zapoznaniu się z zasadą działania szyfrowania aes w zadanej konfiguracji, było odzyskanie całego klucza. warto zauważyć że nasza wiadomość stanowi 2 bloki dla szyfru, każdy po 16 bajtów:

	the message is p
	rotected by aes!

a szyfrowanie odbywa się blokami, więc nasz zaszyfrowany tekst także możemy podzielić na bloki:

	fe000000000000000000000000009ec3
	307df037c689300bbf2812ff89bc0b49
		
do szyfrowania pierwszego bloku aes używa wektora iv oraz klucza, ale do szyfrowania kolejnego bloku użyty jest tylko poprzedni zaszyfrowany blok oraz klucz. dodatkowo szyfrowane odbywa się bajt po bajcie co oznacza, że deszyfrowanie 1 bajtu 2 bloku wymaga znajomości jedynie klucza oraz 1 bajtu 1 bloku. 

to oznacza, że dla danych:

	xx000000000000000000000000000000
	yy000000000000000000000000000000

deszyfrowanie za pomocą poprawnego klucza pozwoli uzyskać poprawnie odszyfrowany 16 bajt wiadomości (licząc od 0), niezależnie od wektora iv.
w związku z tym próbujemy przetestować wszystkie możliwości ostatnich 2 znaków klucza, sprawdzając dla których deszyfrowany tekst zawiera odpowiednie wartości w drugim bloku na pozycjach na których w pierwszym bloku mamy ustawione poprawne wartości (pierwszy bajt oraz dwa ostatnie):

	key = "5d6i9pfr7c1jqt"
	iv = "0000000000000000"
	
	def valid_key(correct_bytes, decrypted):
    for byte_tuple in correct_bytes:
        if decrypted[byte_tuple[0]] != byte_tuple[1]:
            return false
    return true
	
	def break_key(key_prefix, encoded_message_part, correct_bytes):
		final_key = ""
		encrypted = encoded_message_part
		for missing1 in range(0, 256):
			key = key_prefix + chr(missing1)
			for missing2 in range(0, 256):
				real_key = key + chr(missing2)
				decrypted = decrypt(real_key, iv, binascii.unhexlify(encrypted))
				if valid_key(correct_bytes, decrypted):
					final_key = real_key
		return final_key

	real_key = break_key(key, "fe000000000000000000000000009ec3307df037c689300bbf2812ff89bc0b49", [(16, "r"), (30, "s"), (31, "!")])

uzyskujemy w ten sposób klucz: `5d6i9pfr7c1jqt7$`

wektor iv którego poszukujemy służy do szyfrowania 1 bloku i opiera się na podobnej zasadzie jak szyfrowanie kolejnych bloków przedstawione wyżej - pierwszy bajt pierwszego bloku zależy od pierwszego bajtu wektora iv, drugi od drugiego itd. żeby móc w takim razie odzyskać wektor iv potrzebujemy znać pierwszy blok zaszyfrowanej wiadomości. w tym celu stosujemy zabieg identyczny jak powyżej, ale tym razem próbujemy dopasować kolejne bajty zaszyfrowanego pierwszego bloku wiadomości, sprawdzając kiedy deszyfrowanie daje nam poprawnie deszyfrowany bajt z drugiego bloku:

	iv = "0000000000000000"
	message = "the message is protected by aes!"
	ciphertext = ""
	encrypted = "00000000000000000000000000000000307df037c689300bbf2812ff89bc0b49"
	data = binascii.unhexlify(encrypted)
	for position in range(16): # going through first block
		encrypted_sub = list(data)
		for missing in range(0, 256):
			encrypted_sub[position] = chr(missing) #encrypted message with single byte in first block set to tested value
			decrypted = decrypt(real_key, iv, "".join(encrypted_sub))
			if decrypted[position + 16] == message[position + 16]:
				print("%d %d" % (position, missing))
				print(decrypted[position + 16])
				ciphertext += chr(missing)
	print(binascii.hexlify(ciphertext))

co daje nam: `fe1199011d45c87d10e9e842c1949ec3` i jest to pierwszy zakodowany blok.

ostatnim krokiem jest odzyskanie wektora iv. robimy to identycznym schematem, tym razem testujemy kolejne bajty wektora iv sprawdzając kiedy deszyfrowanie daje nam poprawnie odszyfrowane wartości z 1 bloku:

	iv_result = ""
	encrypted = "fe1199011d45c87d10e9e842c1949ec3"
	for position in range(16):
		iv = list(iv)
		for missing in range(0, 256):
			iv[position] = chr(missing) # iv with single byte set to tested value
			decrypted = decrypt(real_key, "".join(iv), binascii.unhexlify(encrypted))
			if decrypted[position] == message[position]:
				print("%d %d" % (position, missing))
				iv_result += chr(missing)
	print(iv_result)

co daje nam `key:rvfvn9kleyr6` więc zgodnie z treścią zadania flagą jest `tmctf{rvfvn9kleyr6}`

### eng version

the task was to recover initialization vector iv for aes cipher based on knowledge of the message, part of the key and part of ciphertext. the data were proviede as a photo of crossed-out code:


[image extracted text: encryptpy
#wusr /bin/env
from crypto cipher import aes
import sys
import binascii
#predefine
key="5d6[9pfrzc1jqt
#replace with random number
iv="
encrypt function
def encrypt(message, passphrase):
aes =
aes.new(passphrase, aes mode_cbc, iv)
return aes_
s.encrypt(message)
# check argument
liflen(sysargv) < 2:
print "please input your datal"
sysexit
result
print "encrypted data:
-binascihexlifycencrypt(sysargv[!}, key))
python
'the
protected by
encrypted
python
output =
dry "
run:
encryptpy
message
aesv"
data:
jec3307df037c689300bbf2812ff89bc0b49]


from this we can get:

* part of the key: `5d6i9pfr7c1jqt` with missing 2 bytes
* message: `the message is protected by aes!`
* part of ciphertext: `fe000000000000000000000000009ec3307df037c689300bbf2812ff89bc0b49` (0s in the first block are missing part)

first step, after reading about aes in given configuration, was to extract the whole ciper key. it is worth noting that our message is separated into 2 blocks for this cipher, each with 16 bytes:

	the message is p
	rotected by aes!

and the cipher works on blocks, so our ciphertext can also be split into blocks:

	fe000000000000000000000000009ec3
	307df037c689300bbf2812ff89bc0b49
		
for encoding the first block aes uses iv vector and the key, but to encode second block only previous block and the key is used. on top of that the cipher works byte-by-byte which means that deciphering 1 byte of 2 block requires knowledge only of the key and of the 1 byte of 1 block.

it means that for input:

	xx000000000000000000000000000000
	yy000000000000000000000000000000

deciphering usign a proper key will give us properly decoded 16th byte (counting from 0), regardless of iv vector used.
therefore, we test all possible values for the missing 2 key characters, testing for which of them the decipered text has proper values in the second block on the positions where in the first block we have proper values (first byte and last two bytes):

	key = "5d6i9pfr7c1jqt"
	iv = "0000000000000000"
	
	def valid_key(correct_bytes, decrypted):
    for byte_tuple in correct_bytes:
        if decrypted[byte_tuple[0]] != byte_tuple[1]:
            return false
    return true
	
	def break_key(key_prefix, encoded_message_part, correct_bytes):
		final_key = ""
		encrypted = encoded_message_part
		for missing1 in range(0, 256):
			key = key_prefix + chr(missing1)
			for missing2 in range(0, 256):
				real_key = key + chr(missing2)
				decrypted = decrypt(real_key, iv, binascii.unhexlify(encrypted))
				if valid_key(correct_bytes, decrypted):
					final_key = real_key
		return final_key

	real_key = break_key(key, "fe000000000000000000000000009ec3307df037c689300bbf2812ff89bc0b49", [(16, "r"), (30, "s"), (31, "!")])

this way we get the key: `5d6i9pfr7c1jqt7$`

iv vector we are looking for is used to encode 1 block and it is used on the same principle as encoding next blocks decribed above - encoded 1 byte of 1 block depends on 1 byte of 1 block of iv vector, 2 depends on 2 etc. therefore, to be able to get the iv vector we need to know the whole first encoded block. to get it we use a very similar approach as the one we used to get the key, but this time we test bytes of the encoded 1 block, checking which value after decoding gives us properly decoded byte from 2 block:

	iv = "0000000000000000"
	message = "the message is protected by aes!"
	ciphertext = ""
	encrypted = "00000000000000000000000000000000307df037c689300bbf2812ff89bc0b49"
	data = binascii.unhexlify(encrypted)
	for position in range(16): # going through first block
		encrypted_sub = list(data)
		for missing in range(0, 256):
			encrypted_sub[position] = chr(missing) #encrypted message with single byte in first block set to tested value
			decrypted = decrypt(real_key, iv, "".join(encrypted_sub))
			if decrypted[position + 16] == message[position + 16]:
				print("%d %d" % (position, missing))
				print(decrypted[position + 16])
				ciphertext += chr(missing)
	print(binascii.hexlify(ciphertext))

which gives us: `fe1199011d45c87d10e9e842c1949ec3` and this is the encoded 1 block.

last step is to recover iv vector. we use the same principle, this time testing iv vector bytes, checking when deciphering gives us properly decoded values from 1 block:

	iv_result = ""
	encrypted = "fe1199011d45c87d10e9e842c1949ec3"
	for position in range(16):
		iv = list(iv)
		for missing in range(0, 256):
			iv[position] = chr(missing) # iv with single byte set to tested value
			decrypted = decrypt(real_key, "".join(iv), binascii.unhexlify(encrypted))
			if decrypted[position] == message[position]:
				print("%d %d" % (position, missing))
				iv_result += chr(missing)
	print(iv_result)

which gives us: `key:rvfvn9kleyr6` so according to the task rules the flag is `tmctf{rvfvn9kleyr6}`
