# primitive, crypto


this was quite an interesting challenge. we were given a python code of a server running on their host.
it generated and sent a random permutation of 256 bytes and treated it as substitution cipher. our task was to supply
a sequence of operations, that when applied to any byte `c`, would give `perm[c]`. the allowed operations
were:
- `add n`, `0 <= n < 256`,
- `rol n`, `0 <= n < 8`,
- `xor n`, `0 <= n < 256`.

all of these were modulo 256.

for example, let's say the the permutation was `(1, 2, 0, 3)` (for simplicity of the example, we use 2-bit numbers).
then one of the solutions would be: `add 3, rol 1, xor 2`, since number 0 after these operations would give 1,
1 maps to 2, 2 to 0, and 3 stays 3.

it is hard to instantly think of a general algorithm to generate the needed sequence, so we had to split the
task into simpler ones. the first thing we can do is rewriting the permutation as product of transpositions.
for the example given above, this would be `swap(0, 1); swap(1, 2)`:
```
0 1 2 3
 x
1 0 2 3
   x
1 2 0 3
```

now we need to just write a function that generates a sequence of operations that swaps two arbitrary numbers `x` and `y`,
leaving the rest of the permutation as it was. this is still a pretty hard problem, so we again decomposed it
into a set of simpler ones: we can first find operations `p(x, y)` that will map `x` to `0` and `y` to `1`
with the other numbers allowed to move freely, then swap `0` and `1` (with other numbers in constant positions),
then apply the first set of operations in inverse (that is, `p^-1(x, y)`).

thus we have reduced original problem to finding `swap(0, 1)` and `p(x, y)` for any `x` and `y`.

we implemented a c++ code that brute forces possible solutions to these. the minimal `swap(0, 1)` implementation is
`add 254, rol 7, add 1, rol 1`.

while trying to search for `p(x, y)`, we noticed there are too many possible solution candidates for unoptimized
brute force to be feasible. we first ran it on smaller `n` (number of bits in the numbers), and then noticed that
it is enough to consider sets of operations of the following form: `add a, rol b, xor c, add d`. this massively
reduced the search space. after this and a few smaller optimizations, we managed to fit all possible candidates in memory
and calculated all `p(x, y)` (using `doit.cpp`) and saved them as python array (in file `tab.py`).

the final script, combining the above insights, is available in `doit.py`.
