# logarithms are hard (misc, 10p)

## eng
[pl](#pl-version)

```
what is e^(1.000000001)?
please enter in decimal with 7 places.
(for example, if the answer was 2.71828183... the flag would be 2.7182818 )
```

as in previous editions of plaid ctf we have a misc task regarding some bug in numerical computation.
this time it is calculation is exponent function.
quick googling gets us to: http://www.datamath.org/story/logarithmbug.htm which says that some calculators would get the result wrong and instead of `2.7182818` give `2.7191928`.
we submit the latter as a flag and get 10 points.

## pl version

```
what is e^(1.000000001)?
please enter in decimal with 7 places.
(for example, if the answer was 2.71828183... the flag would be 2.7182818 )
```

tak jak w poprzednich edycjach plajd ctf mamy zadanie związane z błędami w obliczeniach numerycznych.
w tym przypadku chodzi o eksponente.
szybkie googlowanie pozwala nam trafić na http://www.datamath.org/story/logarithmbug.htm gdzie możemy wyczytać, że niektóre kalkulatory zamiast `2.7182818` dawały wynik `2.7191928`.
wysyłamy niepoprawną wartość jako flagę i dostajemy 10p.
