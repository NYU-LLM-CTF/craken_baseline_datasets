# f4ceb00k 60s (web 100)

```
wwwarmup challenge for your soul. http://10.13.37.11 
```

###eng
[pl](#pl-version)

in the task we get a webpage where we can put a user-agent string and it seemingly tells us how many users used the same ua (which seems to be random data).
tampering with our own, real ua string we figure that the application saves logs from our entries in `/ua_logs` directory under the name taken from our ua.
we can access those files, so if we could create a file with `.php` in name, we would get a remote code execution on the server.
ua is sanitized though, so we can't do that, because the filter passes only `a-za-z0-9\-` range (we could confirm this by triggering an error during file creation, eg by passing a too long file name).

after a while the task got `fixed` and it turned out that our approach was totally wrong, and the application was now showing some sql errors for certain inputs.
injection point was `insert into` query.

this of course meant that the attack vector is in fact sqlinjection.
we did some tests and it turned out that our queries are also sanitized, but the filter is just doing simple string replace for words like `select`, so we could bypass this by putting `sselectelect` this way the `select` in the middle would be replaced with empty string, leaving `select` :)

the final payload to get the flag:

`), ((selselectect*frofromm(seselectlect load_load_filefile('/flag')) as a limit 0, 1), '2') #`

this way we tried to pass the loaded flag content as `id` field of the table we were inserting into, and thus causing the sql error:

```
pdo::query(): sqlstate[hy000]: general error: 1366 incorrect integer value: 'dctf{02a61a4c169a1b3987fe8e128cb67c92}\x0a' for column 'id' at row 2
```

###pl version


w zadaniu dostajemy stronę internetową na której możemy podać string user-agent a strona mówi nam ile osób użyło tego sameog ua (dane są raczej losowe).
modyfikacje naszego prawdziwego ua pozwalają stwierdzić że strona loguje wpisywane przez nas dane do `/ua_logs` do plików pod taką nazwą jak nasze prawdziwe ua.
możemy przeglądać te pliki, więc gdyby dało się utworzyć taki z nazwą `.php` moglibyśmy uzyskać remote code execution na serwerze.
niestety nasze ua jest filtrowane i przepuszcza tylko `a-za-z0-9\-` (zweryfikowane poprzez wywołanie błędu przy wysłaniu stringa za długiego na nazwę pliku).

po jakimś czasie zadanie zostało `naprawione` i okazało się że nasze podejście było zupełnie chybione - teraz aplikacja pokazywała błędy sql dla niektórych inputów.
punkt wstrzyknięcia był w zapytaniu `insert into`.

to oczywiście oznaczało że mamy do czynienia z atakiem sqlinjection.
przeprowadziliśmy trochę testów i okazało się że dane są filtrowane poprzez proste string replace dla słów takich jak `select`, więc mogliśmy obejść to wysyłając np. `sselectelect`, gdzie filtr usuwał wewnętrzne `select` zostawiają nam `select` :)

payload do wyciągnięcia flagi:

`), ((selselectect*frofromm(seselectlect load_load_filefile('/flag')) as a limit 0, 1), '2') #`

w ten sposób próbowalismy posłać zawartość flagi jako wartość dla pola `id` w tabeli do której wstawialiśmy dane, a to spowodowało błąd:

```
pdo::query(): sqlstate[hy000]: general error: 1366 incorrect integer value: 'dctf{02a61a4c169a1b3987fe8e128cb67c92}\x0a' for column 'id' at row 2
```
