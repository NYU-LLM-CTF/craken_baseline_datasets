# opencv (ppc 200)

###eng
[pl](#pl-version)

in the task we get an opencv cascade classifier and a lot of images in a [package](task.zip).
each of the images has a small hashcode embedded.
the goal is to see which of the pictures gets selected by opencv.
we simply loaded the classifier and run:

```python
import os
import cv2


def main():
    cascade = cv2.cascadeclassifier('/tmp/task/any.xml')
    basedir = "/tmp/task/images"
    for filename in os.listdir(basedir):
        img = cv2.imread(basedir + "/" + filename)
        gray = cv2.cvtcolor(img, cv2.color_bgr2gray)
        flags = cascade.detectmultiscale(gray, 1.3, 5)
        if len(flags) > 0:
            print(filename)
            for (x, y, w, h) in flags:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
            cv2.imshow('img', img)
            cv2.waitkey(0)
            cv2.destroyallwindows()


main()
```

and we got image 240.bmp with `fwqm5vfokvy0t8t3ho6l`

###pl version

w zadaniu dostajemy klasyfikator opencv i sporo obrazków w [paczce](task.zip).
każdy obrazek zawiera hashcode.
celem jest znalezienie obrazka wybranego przez opencv.
po prostu uruchomiliśmy klasyfikator:

```python
import os
import cv2


def main():
    cascade = cv2.cascadeclassifier('/tmp/task/any.xml')
    basedir = "/tmp/task/images"
    for filename in os.listdir(basedir):
        img = cv2.imread(basedir + "/" + filename)
        gray = cv2.cvtcolor(img, cv2.color_bgr2gray)
        flags = cascade.detectmultiscale(gray, 1.3, 5)
        if len(flags) > 0:
            print(filename)
            for (x, y, w, h) in flags:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
            cv2.imshow('img', img)
            cv2.waitkey(0)
            cv2.destroyallwindows()


main()
```

co wskazało 240.bmp z `fwqm5vfokvy0t8t3ho6l`
