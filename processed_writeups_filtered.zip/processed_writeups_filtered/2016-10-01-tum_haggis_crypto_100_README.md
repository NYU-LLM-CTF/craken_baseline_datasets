# haggis (crypto 100)

###eng
[pl](#pl-version)

in the task we get [source code](haggis.py) using aes cbc.
the code is quite short and straightforward:

```python
pad = lambda m: m + bytes([16 - len(m) % 16] * (16 - len(m) % 16))
def haggis(m):
    crypt0r = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    return crypt0r.encrypt(len(m).to_bytes(0x10, 'big') + pad(m))[-0x10:]

target = os.urandom(0x10)
print(binascii.hexlify(target).decode())

msg = binascii.unhexlify(input())

if msg.startswith(b'i solemnly swear that i am up to no good.\0') \
        and haggis(msg) == target:
    print(open('flag.txt', 'r').read().strip())
```

the server gets random 16 bytes and sends them to us.
then we need to provide a message with a pre-defined prefix.
this message is concatenated with the length of the message and encrypted, and the last block of the this ciphertext has to match the random 16 bytes we were given.

we know that it's aes cbc, we know the key is all `0x0` and so is the `iv`.
we also know that the cipher is using pkcs7 padding scheme.

we start by filling the prefix until the end of 16 bytes aes block.
it's always easier to work with full blocks:

```python
msg_start = b'i solemnly swear that i am up to no good.\x00\x00\x00\x00\x00\x00\x00'
```

we will add one more block after this one.
keeping this in mind we calculate the length of the full message and construct the length block, just as the server will do:

```python
len_prefix = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@'
```

this way we know exactly what the server is going to encrypt.

it's worth to understand how cbc mode works: each block before encryption is xored with previous block ciphertext (and first block with iv).
this means that if we know the ciphertext of encrypted k blocks, we can encrypt additional blocks simply by passing the last block of k as iv.
we are going to leverage this here!
first we calculate the first k blocks (2 to be exact, the length block and the message we got in the task):

```python
encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
prefix_encrypted_block = encryptor.encrypt(len_prefix + msg_start)[-16:]
```

we need only the last block because this is what is going to be xored with our additional payload block before encryption.
we should remember that there is pcks padding here, so by adding a whole block of our choosing, the actual last ciphertext block will be encrypted padding!
so we actually need to make sure this encrypted padding block matches the given target bytes.
we know the padding bytes - they will all be `0x10`, but they will get xored with the ciphertext of the payload block we are preparing before encryption.
let's call ciphertext of our payload block `ct_payload`, and the plaintext of this block as `payload`.

let's look what exactly we need to do:

we want to get: `encrypt(ct_payload xor padding) = target` therefore by applying decryption we get:

`ct_payload xor padding = decrypt(target)`

and since xor twice by the same value removes itself:

`ct_payload = decrypt(target) xor padding`

now let's look where we get the `ct_payload` from:

`ct_payload = encrypt(payload xor prefix_encrypted_block)`

and by applying decryption:

`decrypt(ct_payload) = payload xor prefix_encrypted_block`

and thus:

`payload = decrypt(ct_payload) xor prefix_encrypted_block`

and if we now combine the two we get:

`payload = decrypt(decrypt(target) xor padding) xor prefix_encrypted_block`

and this is how we can calculate the payload we need to send.

we implement this in python:

```python
def solve_for_target(target):
    # enc(ct xor padding) = target
    # ct xor padding = dec(target)
    # ct = dec(target) xor padding
    # ct = enc (pt xor enc_prefix)
    # dec(ct) = pt xor enc_prefix
    # pt = dec(ct) xor enc_prefix
    target = binascii.unhexlify(target)
    encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    data = encryptor.decrypt(target)[-16:]  # ct xor padding
    last_block = b''
    expected_ct_bytes = b''
    for i in range(len(data)):
        expected_ct = (data[i] ^ 0x10)  # ct
        expected_ct_byte = expected_ct.to_bytes(1, 'big')
        expected_ct_bytes += expected_ct_byte
    encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    result_bytes = encryptor.decrypt(expected_ct_bytes)  # dec(ct)
    for i in range(len(result_bytes)):
        pt = result_bytes[i] ^ prefix_encrypted_block[i]  # dec(ct) xor enc_prefix
        last_block += pt.to_bytes(1, 'big')
    return binascii.hexlify(msg_start + last_block)
```

and by sending this to the server we get: `hxp{plz_us3_7h3_ri9h7_prim1tiv3z}`

###pl version

w zadaniu dostajemy [kod źródłowy](haggis.py) używający aesa cbc.
kod jest dość krótki i zrozumiały:

```python
pad = lambda m: m + bytes([16 - len(m) % 16] * (16 - len(m) % 16))
def haggis(m):
    crypt0r = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    return crypt0r.encrypt(len(m).to_bytes(0x10, 'big') + pad(m))[-0x10:]

target = os.urandom(0x10)
print(binascii.hexlify(target).decode())

msg = binascii.unhexlify(input())

if msg.startswith(b'i solemnly swear that i am up to no good.\0') \
        and haggis(msg) == target:
    print(open('flag.txt', 'r').read().strip())
```

serwer losuje 16 bajtów i wysyła je do nas.
następnie musimy odesłać wiadomość z zadanym prefixem.
ta wiadomość jest sklejana z długością wiadomości i następnie szyfrowana, a ostatni block ciphertextu musi być równy wylosowanym 16 bajtom które dostaliśmy.

wiemy że to aes cbc, wiemy że klucz to same `0x0` i tak samo `iv` to same `0x0`.
wiemy też że jest tam padding pkcs7.

zacznijmy od dopełnienia bloku z prefixem do 16 bajtów.
zawsze wygodniej pracuje się na pełnych blokach:

```python
msg_start = b'i solemnly swear that i am up to no good.\x00\x00\x00\x00\x00\x00\x00'
```

dodamy jeszcze jeden blok za tym prefixem.
mając to na uwadze obliczamy długość pełnej wiadomości i tworzymy blok z długością tak samo jak zrobi to serwer:

```python
len_prefix = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00@'
```

w ten sposób wiemy dokładnie co serwer będzie szyfrował.

warto rozumieć jak działa tryb cbc: każdy blok przed szyfrowaniem jest xorowany z ciphertextem poprzedniego bloku (a pierwszy blok z iv).
to oznacza że jeśli znamy ciphertext zakodowanych k bloków, możemy zakodować dodatkowe bloku po prostu poprzez ustawienie jako iv ostatniego bloku znanego ciphertextu.
wykorzystamy tutaj tą własność!

najpierw obliczmy ciphtextex pierwszyh k bloków (dla ścisłości 2 bloków - bloku z długością wiadomości oraz z prefixem):

```python
encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
prefix_encrypted_block = encryptor.encrypt(len_prefix + msg_start)[-16:]
```

potrzebujemy tylko ostatni blok ponieważ tylko on jest wykorzystywany w szyfrowaniu naszego przygotowywanego bloku poprzez xorowanie z nim.
musimy pamiętać że mamy tutaj padding pkcs7 więc w jeśli dodamy pełny blok to ostatni blok szyfrogramu będzie zaszyfrowanym paddingiem!
więc w rzeczywistości chcemy żeby to padding zakodował się do oczekiwanych wylosowanych 16 bajtów.
wiemy ile wynoszą bajty paddingu - wszystkie będą `0x10`, ale są xorowane z ciphertextem naszego przygotowywanego boku.
oznaczmy szyfrogram tego bloku jako `ct_payload` a jego wersje odszyfrowaną jako `payload`.

popatrzmy co chcemy osiągnąć:

chcemy dostać: `encrypt(ct_payload xor padding) = target` więc deszyfrując obustronnie:

`ct_payload xor padding = decrypt(target)`

a ponieważ xor dwa razy przez tą samą wartość się znosi:

`ct_payload = decrypt(target) xor padding`

popatrzmy teraz skąd bierze się `ct_payload`:

`ct_payload = encrypt(payload xor prefix_encrypted_block)`

i deszyfrując obustronnie:

`decrypt(ct_payload) = payload xor prefix_encrypted_block`

więc:

`payload = decrypt(ct_payload) xor prefix_encrypted_block`

i jeśli teraz połączymy te dwa równania mamy:

`payload = decrypt(decrypt(target) xor padding) xor prefix_encrypted_block`

i w ten sposób uzyskaliśmy przepis na wyliczenie bajtów payloadu do wysłania.
implementujemy to w pythonie:

```python
def solve_for_target(target):
    # enc(ct xor padding) = target
    # ct xor padding = dec(target)
    # ct = dec(target) xor padding
    # ct = enc (pt xor enc_prefix)
    # dec(ct) = pt xor enc_prefix
    # pt = dec(ct) xor enc_prefix
    target = binascii.unhexlify(target)
    encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    data = encryptor.decrypt(target)[-16:]  # ct xor padding
    last_block = b''
    expected_ct_bytes = b''
    for i in range(len(data)):
        expected_ct = (data[i] ^ 0x10)  # ct
        expected_ct_byte = expected_ct.to_bytes(1, 'big')
        expected_ct_bytes += expected_ct_byte
    encryptor = aes.new(bytes(0x10), aes.mode_cbc, bytes(0x10))
    result_bytes = encryptor.decrypt(expected_ct_bytes)  # dec(ct)
    for i in range(len(result_bytes)):
        pt = result_bytes[i] ^ prefix_encrypted_block[i]  # dec(ct) xor enc_prefix
        last_block += pt.to_bytes(1, 'big')
    return binascii.hexlify(msg_start + last_block)
```

i po wysłaniu na serwer dostajemy: `hxp{plz_us3_7h3_ri9h7_prim1tiv3z}`
