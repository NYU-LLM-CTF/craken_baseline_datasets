# my first app (web, 399p, 62 solved)

honestly we're not exactly sure what was the idea behind this task.
we get a link to a webapplication which says:

```
after much research, i've found on stackoverflow.com how to protect my framework app.
```

and there is a link to `/getflag`, but there is a password prompt when we try to go there.
it seems the authentication is based on some regex rather than on directory structure since going to `/getflags` also gives us authentication prompt and not 404 error.
additionally we can see that going to `/index.php` and `/index.php/` gives us the same results.

this all suggests some mod_rewrite magic underneath.
we simply tried to see what will happen if we do `/index.php/getflag`, which would depend on the regex rules order, and we got the flag:

`eko{fucking_m0d_r3wr1t3}`
