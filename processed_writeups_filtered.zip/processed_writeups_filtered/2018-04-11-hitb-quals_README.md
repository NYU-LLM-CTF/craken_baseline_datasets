# hitb-xctf gsec ctf 2018 quals

team: shalom, sasza, rev, msm, akrasuski1

### table of contents

* [python revenge (web)](web_python)
* [easy pub (crypto)](crypto_pub)
* [multicheck (re)](re_multicheck)
