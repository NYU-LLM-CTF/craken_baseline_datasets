# state agency (web)

we get access to a webpage for reporting security vulnerabilities.
it seems basically nothing there works, apart from reading two existing reports.
once we click on them we get a link with same get parameters (which are ignored), but the interesting part is that the link is for example `http://5889.state-agency.tux.ro/` where `5589` is the id of article we want to read.
if we change it to some random value we get information that our sql is wrong.

upon further inspection we figure out that in reality we simply need to change `host` header to manipulate this value.
we guessed that there will be some sql injection via the id, but it seemed a lot of stuff was blacklisted by internal waf and not knowing the query layout made this hard.
eventually we managed to get some working injections.
initally a blind one, based on 1 or 2 articles in the result, but eventually we noticed that `union select` is not blacklisted in waf, so we could get a full echo of the query.

we could use the payload: `5880') union select 1,2,3,4,5 -- a` to get the union result.
the problem was that the injection point we had was already after the condition to select only the "public" vulnerabilities, and we could not change this condition any more.
we needed to make a new query using `union select`, but we don't know the table name.
the `information schema` was blacklisted in waf, so were any other useful things.
finally we found out that `procedure analyse` is not in the blacklist!

we could then send `5880') procedure analyse() -- a` and get back information that we're interested in the table `agency.articles` and the column most likely `content`.
but when sending `5880') union select 1,2,3,4,content from articles -- a` we get back `private data exfiltration attempt blocked` so it seems the waf checks if flag is in the response.
but this is not a problem, we can do: `5880') union select 1,2,3,4,to_base64(content) from articles -- a` to encode the flag and bypass the waf.

whole solver [here](sql.py)
