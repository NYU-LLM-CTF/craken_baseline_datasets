# b4s1[4l (misc 150)

```
dive into this, it's a terrorist transmission, they can't know too much about encoding &|| cryptography. 
it was sent hundreds of times to all their supporters. we really think it s actually the same message.
https://dctf.def.camp/b4s1.php

hint1: "what is normal in the challenge title?"
hint 2: strrev(strtoupper($title)) 
```


###eng
[pl](#pl-version)

in the task we have access to webpage with 6 lines of 16 byte strings:

```
fw[tqctfdcoxnepo
hsqd^dninc}_tveg
fyig`ebzdce\sm{x
fiivqemcjo_snc\b
taynwornfgofdrrc
ruke\zeepegovu@h
```

each time you refresh the page the strings change.
even before the hints were posted we did bitwise analysis of the data on the page and it seemed that in our sample of a few hundred strings there was a regularity: the least significant bit of each byte was constant.

so we extracted those bits and tried to decode this in every way possible (by column, by row, inverted, as 6,7,8 bit bytes, xored etc.), failing.
but after admins spoke to some teams about the task, they figured that they made a mistake...

after the task was `fixed` it turned out that the solution was as simple as treating each 8 bits as a ascii byte, and translating the message to `leastnotlast`.


###pl version

w zadaniu dostajemy dostęp do strony internetowej na której wyświetlane jest 6 linii tekstu po 16 bajtów w linii:

```
fw[tqctfdcoxnepo
hsqd^dninc}_tveg
fyig`ebzdce\sm{x
fiivqemcjo_snc\b
taynwornfgofdrrc
ruke\zeepegovu@h
```

za każdym refreshem stringi na stronie są inne.
jeszcze zanim pojawiły się hinty przeprowadziliśmy analizę bitów stringów na stronie, na próbce kilkuset różnych zestawów, i widać było regularność: niski bit każdego bajtu był stały.

wyciągnęliśmy powtarzające się bity i próbowaliśmy dekodować je na wszystkie sposoby (po kolumnie, po wierszu, odwrócone, jako 6,7,8 bitowe bajty, xorowane itd), ale bez efektów.
jakiś czas później admini przeprowadzili wywiad wśród kilku drużyn i zrozumieli że pomylili się w zadaniu...

po tym jak zadanie zostało `naprawione` rozwiązaniem okazało się po prostu potraktowanie każdych 8 bitów jako bajtu ascii co dało wiadomość `leastnotlast`.
