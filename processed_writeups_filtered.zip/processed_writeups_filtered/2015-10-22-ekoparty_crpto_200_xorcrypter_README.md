﻿## xor crypter (crypto 200p)

	description: the state of art on encryption, can you defeat it?
	cjbpewygc2gdd3rpmrnfddcqx3uggmhpbxzhyhflfqa= 

### pl
[eng](#eng-version)

cały kod szyfrujący jest [tutaj](shiftcrypt.py).
szyfrowanie jest bardzo proste, aż dziwne że zadanie było za 200 punktów. szyfrowanie polega na podzieleniu wejściowego tekstu na 4 bajtowe kawałki (po dodaniu paddingu jeśli to konieczne, aby rozmiar wejścia był wielokrotnością 4 bajtów), rzutowanie ich na inta a następnie wykonywana jest operacja `x xor x >>16`. jeśli oznaczymy kolejnymi literami bajty tego inta uzyskujemy: 

`abcd ^ abcd >> 16 = abcd ^ 00ab = (a^0)(b^0)(c^a)(d^b) = ab(c^a)(d^b)`

jak widać dwa pierwsze bajty są zachowywane bez zmian a dwa pozostałe bajty są xorowane z tymi dwoma niezmienionymi. wiemy także że xor jest operacją odwracalną i `(a^b)^b = a` możemy więc odwrócić szyfrowanie dwóch ostatnich bajtów xorując je jeszcze raz z pierwszym oraz drugim bajtem (pamiętając przy tym o kolejności bajtów)

```python
data = "cjbpewygc2gdd3rpmrnfddcqx3uggmhpbxzhyhflfqa="
decoded = base64.b64decode(data)
blocks = struct.unpack("i" * (len(decoded) / 4), decoded)
output = ''
for block in blocks:
	bytes = map(ord, struct.pack("i", block))
	result = [bytes[0] ^ bytes[2], bytes[1] ^ bytes[3],  bytes[2], bytes[3]]
	output += "".join(map(chr, result))
print(output)
```

w wyniku czego uzyskujemy flagę: `eko{unshifting_the_unshiftable}`

### eng version


cipher code is [here](shiftcrypt.py).
the cipher is actually very simple, it was very strange that the task was worth 200 point. the cipher splits the input text in 4 byte blocks (after adding padding if necessary so that the input is a multiply of 4 bytes), casting each block to integer and the performing `x xor x >>16`. if we mark each byte of the single block with consecutive alphabet letters we get:

`abcd ^ abcd >> 16 = abcd ^ 00ab = (a^0)(b^0)(c^a)(d^b) = ab(c^a)(d^b)`

as can be noticed, first two bytes are unchanged and last two are xored with those two unchanged. we also know that xor is reversible and `(a^b)^b = a` so we can revert the cipher of the last two bytes by xoring them again with first and second byte (keeping in mind the byte order).

```python
data = "cjbpewygc2gdd3rpmrnfddcqx3uggmhpbxzhyhflfqa="
decoded = base64.b64decode(data)
blocks = struct.unpack("i" * (len(decoded) / 4), decoded)
output = ''
for block in blocks:
	bytes = map(ord, struct.pack("i", block))
	result = [bytes[0] ^ bytes[2], bytes[1] ^ bytes[3],  bytes[2], bytes[3]]
	output += "".join(map(chr, result))
print(output)
```

as a result we get: `eko{unshifting_the_unshiftable}`
