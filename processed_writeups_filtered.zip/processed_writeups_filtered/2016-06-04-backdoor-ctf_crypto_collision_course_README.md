# collision course

in this task, we were given a hasher binary (`foobar`) and a file, for which we had to find
a collision (`collider`), that is a file, which passed as input to `foobar` gives the same hash.
there could be many solutions, but only one of them makes sense (is an english text).

analyzing the assembly, we can rewrite the binary into the following pseudocode:

```
def hash(block):
	block^=a
	ror(block, 7)
	block+=b
	rol(block, 7)
	block*=c
	return block

state=0
for 4-byte block in input:
	h=hash(block)
	state^=h
	ror(state, 7)
	print state
```

since state is printed out after every iteration, we know every state. let's denote them as
s0, s1 and so on, where s0=0 (initial state).
```
s(i+1)=ror( s(i)^hash(block), 7 )
rol( s(i+1), 7 )=s(i)^hash(block)
hash(block) = s(i) ^ rol( s(i+1), 7 )
```
so, since we know all s(i), we easily calculate all hashes of 4-byte blocks. since 4 bytes are
in the brute-force range (and the search space could be significantly lowered by considering
only printable characters), we implemented the hash in `main.cpp` and brute-forced all fitting
input blocks. output was not unique, but it was easy to choose the correct answer from the few
possibilities.
