## rock with the wired shark! (misc, 70p)

	sniffing traffic is fun. i saw a wired shark. isn't that strange?
	
###eng
[pl](#pl-version)

after extracting objects from given pcap file, we get only a couple of webpages and a zip file.
it was encrypted, but we found the password in http basic authorization.

###pl version

wypakowawszy obiekty z otrzymanego pliku pcap, dostaliśmy jedynie kilka stron oraz zaszyfrowanego
zipa. hasło, po chwili szukania, można było znaleźć w autoryzacji żądania http w oryginalnym pliku.
