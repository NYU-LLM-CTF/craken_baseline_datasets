# sherlock (crypto)

```
sherlock has a mystery in front of him. help him to find the flag. 
```

###eng
[pl](#pl-version)

in the task we get a [book](sherlock.txt).
we figured we could compare it to the [original text from project gutenberg](sherlock_orig.txt).

we had to make it lowercase and remove the toc but other than that the comparison was simple:

```python
import codecs


def main():
    with codecs.open("sherlock.txt", "r") as input_file:
        task_data = input_file.read()
        task_data.replace("\n\n", "\n")
    with codecs.open("sherlock.txt", "r") as input_file:
        original_data = input_file.read()
        original_data = original_data.lower()
        original_data.replace("\n\n", "\n")
    result = "".join([task_data[i] for i in range(len(task_data)) if task_data[i] != original_data[i]])
    print(result)


main()
```

this gave us a long string with `zeroonezero...`.
we changed this into a number and interpreted as text:

```python
from crypto_commons.generic import long_to_bytes

    result = result.replace("zero", "0")
    result = result.replace("one", "1")
    print(long_to_bytes(int(result, 2)))
```

and we got `bitsctf{h1d3_1n_pl41n_5173}`

###pl version

w zadaniu dostajemy [książkę](sherlock.txt).
postanowiliśmy porównać ją z [oryginalnym tekstem z project gutenberg](sherlock_orig.txt).

musieliśmy zmienić ją na lowercase i usunąć spis treści, ale cała reszta była prosta:

```python
import codecs


def main():
    with codecs.open("sherlock.txt", "r") as input_file:
        task_data = input_file.read()
        task_data.replace("\n\n", "\n")
    with codecs.open("sherlock.txt", "r") as input_file:
        original_data = input_file.read()
        original_data = original_data.lower()
        original_data.replace("\n\n", "\n")
    result = "".join([task_data[i] for i in range(len(task_data)) if task_data[i] != original_data[i]])
    print(result)


main()
```

to dało nam długi string `zeroonezero...`.
po zmianie tego na liczbę a następnie zinterpretowaniu jako tekst:

```python
from crypto_commons.generic import long_to_bytes

    result = result.replace("zero", "0")
    result = result.replace("one", "1")
    print(long_to_bytes(int(result, 2)))
```

dostaliśmy `bitsctf{h1d3_1n_pl41n_5173}`
