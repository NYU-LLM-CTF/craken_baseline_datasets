## srpp (crypto, 231p)

###eng
[pl](#pl-version)

we are given quite complicated file, but after simplification, the only important part is this:

```python
params = getparams(nbit)
n, g, k = params
email = 'admin@asis-ctf.ir'
client.send('params = (n, g, k) = ' + str(params) + '\n')
salt = urandom(32)
n, g, _ = params
x = hash(salt, email, password)
verifier = pow(g, x, n)

client.send('send the email address and the public random positive value a seperated by "," as "email, a": ' + '\n')
ans = client.recv(_bufsize).strip()
print ans
email, a = ans.split(',')
a = int(a)
assert (a != 0 and a != n), client.send('are you kidding me?! :p' + '\n')
assert email == 'admin@asis-ctf.ir', client.send('you should login as admin@asis-ctf.ir' + '\n')
b = getrandomrange(1, n)
b = (k * verifier + pow(g, b, n)) % n

client.send('(salt,  public_ephemeral) = (%s, %d) \n' % (salt.encode('base64')[:-1], b))

u = hash(a, b)

client.send('send the session key: ' + '\n')
k_client = client.recv(_bufsize).strip()
assert k_client.isdigit(), client.send('please send a valid positive integer as session key.' + '\n')
k_client = int(k_client)

s_s = pow(a * pow(verifier, u, n), b, n)
print 's_s', s_s
k_server = hash(s_s)
print 'k_server', k_server

client.send('send a poc of session key: ' + '\n')
m_client = client.recv(_bufsize).strip()

assert m_client.isdigit(), client.send('please send valid positive integer as poc.' + '\n')
m_client = int(m_client)

assert (k_server == k_client), client.send('the session key is not correct!' + '\n')
assert (m_client == hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)), client.send('the poc is not correct!' + '\n')

m_server = hash(a, m_client, k_server) # todo: check server poc in clinet side

client.send('great, you got the flag: ' + flag + '\n')
client.close()
```

this looks complicated, and hard to break, but let's look again. there are basically two checks we have to pass:

```python
assert (k_server == k_client), client.send('the session key is not correct!' + '\n')
assert (m_client == hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)), client.send('the poc is not correct!' + '\n')
```

and the second one is no-issue (because every variable used in assert is given to us by challenge!). so we only have to calculate `k_client`.
how are we going to achieve this? well this looks impossible - algorithm here is almost bulletproof. almost - except one small scar...

```python
s_s = pow(a * pow(verifier, u, n), b, n)
```

a here is controlled by us. what if we could send a=0? recovering `s_s` would be trivial (`0*anything == 0`). alternatively we could send a=n. unfortunatelly, challenge authors have thought about it:

```python
assert (a != 0 and a != n), client.send('are you kidding me?! :p' + '\n')
```

but wait, what if we could send a=2n?

well, this wasn't thought about, and this is how we solved this challenge.

the only nontrivial part is this:

```python
a = 2*n
k_client = 43388321209941149759420236104888244958223766953174235657296806338137402595305  # hardcoded k_client assuming that s_s = 0
s.send(email + ', ' + str(a) + '\n')
s.send(str(k_client) + '\n')
```

the rest is just basic mathematical operations on numbers given to us by challenge:

```python
def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha512(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c

print s.recv(9999)

proof = proof_of_work(s)
print proof
s.send(proof)

kot = recvuntil(s, ["public random"])
print kot

email = 'admin@asis-ctf.ir'
ls = kot.split('\n')
for l in ls:
    if 'params' in l:
        data = l[21:]
        n, g, k = eval(data)
        print n, g, k

a = 2*n
k_client = 43388321209941149759420236104888244958223766953174235657296806338137402595305
s.send(email + ', ' + str(a) + '\n')
s.send(str(k_client) + '\n')

# almost done, just need to calculate poc

kot = recvuntil(s, ['session key'])
print kot
ls = kot.split('\n')
for l in ls:
    if 'salt' in l:
        data = l[28:]
        salt, b = re.findall("\((.*),(.*)\)", data)[0]
        salt = salt.decode('base64')
        b = b.strip()
        print salt, b

poc = hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)

print poc
s.send(str(poc))

print s.recv(999)
```

and that's it.


###pl version

dostajemy całkiem skomplikowany plik, ale po uproszczeniu, jedyna skomplikowana część to to:

```python
params = getparams(nbit)
n, g, k = params
email = 'admin@asis-ctf.ir'
client.send('params = (n, g, k) = ' + str(params) + '\n')
salt = urandom(32)
n, g, _ = params
x = hash(salt, email, password)
verifier = pow(g, x, n)

client.send('send the email address and the public random positive value a seperated by "," as "email, a": ' + '\n')
ans = client.recv(_bufsize).strip()
print ans
email, a = ans.split(',')
a = int(a)
assert (a != 0 and a != n), client.send('are you kidding me?! :p' + '\n')
assert email == 'admin@asis-ctf.ir', client.send('you should login as admin@asis-ctf.ir' + '\n')
b = getrandomrange(1, n)
b = (k * verifier + pow(g, b, n)) % n

client.send('(salt,  public_ephemeral) = (%s, %d) \n' % (salt.encode('base64')[:-1], b))

u = hash(a, b)

client.send('send the session key: ' + '\n')
k_client = client.recv(_bufsize).strip()
assert k_client.isdigit(), client.send('please send a valid positive integer as session key.' + '\n')
k_client = int(k_client)

s_s = pow(a * pow(verifier, u, n), b, n)
print 's_s', s_s
k_server = hash(s_s)
print 'k_server', k_server

client.send('send a poc of session key: ' + '\n')
m_client = client.recv(_bufsize).strip()

assert m_client.isdigit(), client.send('please send valid positive integer as poc.' + '\n')
m_client = int(m_client)

assert (k_server == k_client), client.send('the session key is not correct!' + '\n')
assert (m_client == hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)), client.send('the poc is not correct!' + '\n')

m_server = hash(a, m_client, k_server) # todo: check server poc in clinet side

client.send('great, you got the flag: ' + flag + '\n')
client.close()
```

wygląda na skomplikowane i trudne do złamania. ale w sumie, są tylko dwa testy które musimy przejść:

```python
assert (k_server == k_client), client.send('the session key is not correct!' + '\n')
assert (m_client == hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)), client.send('the poc is not correct!' + '\n')
```

i drugi z nich to żaden problem (bo każda zmienna użyta w assercie jest wysyłana do nas przez serwer zadania) - więc musimy tylko obliczyć `k_client`.
jak zamierzamy to zrobić? cóż, wygląda to na niemożliwe - algorytm jest prawie że kuloodporny. prawie że - ma jeden drobny problem...

```python
s_s = pow(a * pow(verifier, u, n), b, n)
```

a tutaj jest kontrolowane przez nas. co jeśli wysłalibyśmy a=0? odzyskanie `s_s` byłoby trywialne (`0*cokolwiek = 0`). albo moglibyśmy wysłać a=n. niestety, twórcy zadania pomyśleli o tym:

```python
assert (a != 0 and a != n), client.send('are you kidding me?! :p' + '\n')
```

hmm, ale co jeśli wyślemy a=2n?

cóż, nikt o tym widać nie pomyślał, i w ten sposób rozwiązaliśmy to zadanie.

jedyna nietrywialna część naszego kodu to to:

```python
a = 2*n
k_client = 43388321209941149759420236104888244958223766953174235657296806338137402595305  # hardcoded k_client assuming that s_s = 0
s.send(email + ', ' + str(a) + '\n')
s.send(str(k_client) + '\n')
```

reszta to podstawowe operacje matematyczne na liczbach które dostajemy od zadania:

```python
def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha512(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c

print s.recv(9999)

proof = proof_of_work(s)
print proof
s.send(proof)

kot = recvuntil(s, ["public random"])
print kot

email = 'admin@asis-ctf.ir'
ls = kot.split('\n')
for l in ls:
    if 'params' in l:
        data = l[21:]
        n, g, k = eval(data)
        print n, g, k

a = 2*n
k_client = 43388321209941149759420236104888244958223766953174235657296806338137402595305
s.send(email + ', ' + str(a) + '\n')
s.send(str(k_client) + '\n')

# almost done, just need to calculate poc

kot = recvuntil(s, ['session key'])
print kot
ls = kot.split('\n')
for l in ls:
    if 'salt' in l:
        data = l[28:]
        salt, b = re.findall("\((.*),(.*)\)", data)[0]
        salt = salt.decode('base64')
        b = b.strip()
        print salt, b

poc = hash(hash(n) ^ hash(g), hash(email), salt, a, b, k_client)

print poc
s.send(str(poc))

print s.recv(999)
```

i to w sumie tyle, wystarczyło to do zdobycia flagi.
