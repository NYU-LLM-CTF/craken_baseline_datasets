# writeup bioterra ctf 2016

team: msm, c7f.m0d3, akrasuski1, nazywam, other19, cr019283, shalom

### table of contents

* [orgone market (web)](orgone_market)
* [akashic records (pwn)](akashic_records)
* [zip (forensics)](zip)
* [job portal (web/pwn)](job_portal)
* [illuminati (web)](illuminati)
