# chinese satellite (crypto 200)


## eng
[pl](#pl-version)

this task was very strange.
the author clearily didn't understand quantum key exchange at all, and in this particular case knowing how this should work was making the task harder to solve...

in the task we get some intercepted quantum transfers [sat->ground](q_transmission_1), [ground->sat](q_transmission_2), [sat->ground](q_transmission_3) and a ciphertext in public channel:

`269118188444e7af980a245aedce5fb2811b560ccfc5db8e41f102a23f8d595ffde84cb1b3f7af8efd7a919bd2a7e6d3`

in general quantum key exchange is quite simple:

1. alice sends set of random bits encoded in one of two bases (let's call them x and y)
2. bob receives the qbits and randomly selects which base to use to measure value (since he can't know which base alice used for each of qbits). statistically he will get about half of the bases right.
3. bob sends to alice information which bases he used for each of the qbits.
4. alice compares the list from bob with the bases she actually used and sends to bob information which bases he got right.

in case bob used the right base he knows the bit value alice wanted to send.
those agreed bits are then normally used as some symmetric key for the communication.

we have our 3 transmissions, and they are exactly what described above: 

1. first one is the whole dump of initial qbits sent by alice. we have two bases -> straight (`-` or `|`) and cross (`/` or `\`).
2. second one is bases bob used - straight `+` or cross `x`.
3. last one is the list of bits bob got right marked as `v`.

so we can simply read values sent by alice in 1st transmission for which there is `v` in last tramissions and we will get the qbits that they got right. we don't really know if `\` is 0 or 1 and if `|` is 0 or 1, but this is simple enough, we can just test all 4 options.

```python
def get_agreed_bytes(data_sent, bases_measured, bases_correct, v1, v2):
    agreed_bits = []
    for i in range(len(bases_correct)):
        if bases_correct[i] == 'v':
            if bases_measured[i] == '+':
                if data_sent[i] == '-':
                    agreed_bits.append(v1)
                else:
                    agreed_bits.append(abs(v1 - 1))
            else:
                if data_sent[i] == '/':
                    agreed_bits.append(v2)
                else:
                    agreed_bits.append((abs(v2 - 1)))
    return hex(int("".join([str(c) for c in agreed_bits]), 2))[2:-1]
```

now it was strange, because we get some bits and we don't know how to use them as encryption key to recover the flag.
fortunately we noticed that byte values seem in printable range and i printed out the agreed bytes and one of the options was:

`iv:281e6bfc14a9aad39845f29b30ef1334,key:b340fe5025b06657034822b340ceb9d4,algo:aes_cbc`

which makes little sens in terms of crypto channel key exchange, because alice can't know which bits bob will get, but whatever...

so we have all we need -> algo and parameters and we can just decrypt the flag: `h4ck1t{tr4nsmi55i0n_0v3r_bb84_l00ks_s3cur3_0k}`

complete solver [here](quantum.py)

## pl version

to było dość dziwne zadanie.
autor ewidentnie nie rozumie o co chodzi w kwantowej wymianie klucza i paradoksalnie w tym zadaniu znajomość tego zagadnienia tylko utrudniała rozwiązanie zadania...

w zadaniu dostajemy kilka przechwyconych kwantowych transmisji [sat->ground](q_transmission_1), [ground->sat](q_transmission_2), [sat->ground](q_transmission_3) i szyfrogram w publicznym kanale:

`269118188444e7af980a245aedce5fb2811b560ccfc5db8e41f102a23f8d595ffde84cb1b3f7af8efd7a919bd2a7e6d3`

generalnie kwantowa wymiana klucza jest dość prosta:

1. alice wysyła do boba losowe bity kodowane w jednej z dwóch baz (nazwijmy je x i y)
2. bob odbiera qbity i wybiera losowo w jakiej bazie odczytać wartość (ponieważ nie wie w jakiej bazie wartość została zakodowana przez alice). statystycznie powinien odczytać około połowy poprawnie.
3. bob wysyła do alice informacje których baz użył dla każdego z qbitów.
4. alice porównuje listę od boba ze swoją listą z bazami których użyła i wysyła do boba informacje, które bazy wybrał poprawnie.

jeśli bob użył dobrej bazy dla danego bitu to zna wartość którą alice chciała wysłać.
bity, które się zgodziły są zwykle używane do generacji klucza dla kryptografii symetrycznej.

mamy 3 tranmisje danych i są dokładnie tym co opisane wyżej:

1. pierwsza to zrzut qitów które alice wysłała. mamy tam dwie bazy -> prostą (`-` i `|`) oraz skośną (`/` i `\`).
2. druga to lista baz których użył bob - prosta `+` lub skośna `x`.
3. ostatnia to lista bitów które bob odczytał dobrze, oznaczonych przez `v`.

możemy więc po prostu odczytać wartości które alice wysłała w 1 transmisji, dla których w trzeciej transmisji mamy `v` i w ten sposób poznamy listę qbitów które się zgodziły.
nie wiemy co prawda czy `\` to 1 czy 0 oraz czy `|` to 1 czy 0, ale możemy przetestować wszystkie 4 opcje.

```python
def get_agreed_bytes(data_sent, bases_measured, bases_correct, v1, v2):
    agreed_bits = []
    for i in range(len(bases_correct)):
        if bases_correct[i] == 'v':
            if bases_measured[i] == '+':
                if data_sent[i] == '-':
                    agreed_bits.append(v1)
                else:
                    agreed_bits.append(abs(v1 - 1))
            else:
                if data_sent[i] == '/':
                    agreed_bits.append(v2)
                else:
                    agreed_bits.append((abs(v2 - 1)))
    return hex(int("".join([str(c) for c in agreed_bits]), 2))[2:-1]
```

teraz następuje dość dziwny krok, bo mamy zgodne bity, ale nie wiemy co dalej z nimi zrobić żeby odzyskać flagę.
szczęślwie zauważyliśmy, że wartości bajtów wyglądają na drukowalne ascii więc wypisaliśmy sobie uzyskane możliwości i dostaliśmy dla jednego z nich:

`iv:281e6bfc14a9aad39845f29b30ef1334,key:b340fe5025b06657034822b340ceb9d4,algo:aes_cbc`

co zupełnie nie ma sensu z punktu widzenia kwantowej wymiany klucza, bo alice nie mogła wiedzieć które bity bob odzyta poprawnie, no ale co tam...

mamy podany algorytm i prametry więc odszyfrowujemy flagę: `h4ck1t{tr4nsmi55i0n_0v3r_bb84_l00ks_s3cur3_0k}`

cały solver [tutaj](quantum.py)
