# 4_messages (crypto 100)


## eng
[pl](#pl-version)

in the task we get [4 playfair ciphertexts](captured.log) and we know that the plaintext starts with `good evening hackit two thousand seventeen`.

we actually approached this in a bit unconventional way, since the first attack we found was a heuristic to recover message from a single ciphertext with no plaintext known at all described here: http://practicalcryptography.com/cryptanalysis/stochastic-searching/cryptanalysis-playfair/

so we simply proceed with this and recover plaintexts within seconds:

```
good evening hackit two thousand seventeen in this tiny brocure we would like to describe how it is to be a playfair cryptor no doubt it is easy as heck but you got to have a piece of paper all the time we bet there is no convinience now lets cut the shit restore the matrix keys for each ciphertext then take first six letters then combine them to get her and you will get the flag
```

and the matrix keys:

```
tbdefglmnopqrsuvwxyzhacki
wxztuverisbcdyahklfgopqmn
ngedacfhrblmoikstupqxyzvw
uvwxzcryptoabdefghiklmnqs
```

now with some luck, guessing and 5x5 matrix column/row shifts we figure out the codewords:

```
hackit
isvery
danger
crypto
```

so the flag is: `h4ck1t{hackitisverydangercrypto}`

## pl version

w zadaniu dostajemy [4 szyfrogramy playfair](captured.log) i wiemy że plaintext zaczyna się od `good evening hackit two thousand seventeen`.

podeszliśmy do tego zadania trochę niekonwencjonalnie, bo pierwszy atak na który trafiliśmy to była heurystyka do odzyskiwania wiadomości na podstawie jednego szyfrogramu bez żadnej znajomości plaintextu opisana tutaj: http://practicalcryptography.com/cryptanalysis/stochastic-searching/cryptanalysis-playfair/

uruchomiliśmy więc solver i w kilka sekund odzyskaliśmy wiadomości:

```
good evening hackit two thousand seventeen in this tiny brocure we would like to describe how it is to be a playfair cryptor no doubt it is easy as heck but you got to have a piece of paper all the time we bet there is no convinience now lets cut the shit restore the matrix keys for each ciphertext then take first six letters then combine them to get her and you will get the flag
```

i klucze:

```
tbdefglmnopqrsuvwxyzhacki
wxztuverisbcdyahklfgopqmn
ngedacfhrblmoikstupqxyzvw
uvwxzcryptoabdefghiklmnqs
```

dalej przy odrobinie szczęścia, zgadywania i przesuwania kolumn/wierszy macierzy 5x5 dostajemy:

```
hackit
isvery
danger
crypto
```

więc flaga to: `h4ck1t{hackitisverydangercrypto}`
