-------------------------------------------
[eletronics] eletronic ballot box prototype - 50 points
-------------------------------------------

> a member of project sky has infiltrated into a club recycling facility and got access to one of the first prototypes of what became, afterwards, an electronic ballot box (yes, all of this has been born because of the influence of the club). we know that the prototype has the potential to unveil the true inner workings behind electronic voting, but we need your help. add ctf-br{} around the flag before submitting it.

in this task we were given an image of electronic circuit's hand sketch, and an arduino code.
it seemed that the code was reading a number from keyboard, setting 8 pins to various states depending on the 
number, waiting for the hardware to respond, reading other 8 pins (and sometimes adjusting them by one), then
finally printing the values to serial port. example for input=13:
```
      digitalwrite(2, high);
      delay(10);
      digitalwrite(4, high);
      delay(10);
      digitalwrite(6, high);
      delay(10);
      digitalwrite(8, low);
      delay(10);
      digitalwrite(22, low);
      delay(10);
      digitalwrite(24, high);
      delay(10);
      digitalwrite(26, low);
      delay(10);
      digitalwrite(28, high);

      a = digitalread(3);
      serial.print(a);
      serial.print('-');
      b = digitalread(5);
      serial.print(b);
      serial.print('-');
      c = digitalread(7);
      serial.print(c);
      serial.print('-');
      d = digitalread(9);
      serial.print(d);
      serial.print('-');
      e = digitalread(23) - 1;
      serial.print(e);
      serial.print('-');
      f = digitalread(25);
      serial.print(f);
      serial.print('-');
      g = digitalread(27) + 1;
      serial.print(g);
      serial.print('-');
      h = digitalread(29) - 1;
      serial.print(h);
      serial.println(" ");
      delay(100);
```
well, it seems all we needed to do was to reverse the hardware. since it was only drawn on paper, we could do it by hand
only. here's my attempt:


[image extracted text: 82'
445
q
janan
147 ,
1-4415*2'
"oo
akote
pufuujuu
qudac
boluluu
ftm
hjuuujuwl
j9
d6
10-
joti
8p1k
'
npod
ck |
7"6yj
uuuul
bulu
juukul
d93
898
85
mt
8
883
486
p
tedol
"p);
sl
td
vrn
ppluulud
uuluu d
ulubl
4ui
mvop
1  f"i
px
499]


it seemed that each output is a simple function of just one of the inputs. we wrote a simple python script (`doit.py`) to parse
the arduino code and simulate the circuitry for every keyboard input. running it gives us the flag: `fraudetotal`
