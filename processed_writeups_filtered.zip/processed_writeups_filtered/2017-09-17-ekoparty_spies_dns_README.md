# spies (dns, 466p, 21 solved)

```
watch out from those prying eyes! 
it seems someone is opening everything to the world, find that webcam and you will see for yourself!

https://mydns.webcam/
```

task suggests there is some webcam registered as subdomain of `mydns.webcam` where we can find the flag.
the hard part is that there are already plenty of domains registered and also players can register new domains at will.

in this task we first collected all subdomains of `mydns.webcam` and simply checked what is there.
we knew that all the user-registered domains without external server show some message about "billing issues" and we knew that `crazy.mydomain.webcam` is for a different task, so we're interested only in the remaining domains:

```python
    for host in host_list:
        if host != "crazy.mydns.webcam":
            try:
                result = requests.get("http://" + host, timeout=1)
                if "billing" not in result.text:
                    print(host, result.text)
            except:
                pass
    pass
```

after we pass through those domains we get only a few hits, and only two are webcams.

out of those two only `greenhouse.mydns.webcam` shows us:


[image extracted text: source
live view
e015225_
'every wiere]


so the flag is `eko{spies_everywhere}

the other webcam `supercam.mydns.webcam` was showing stuff like for example rickroll.
