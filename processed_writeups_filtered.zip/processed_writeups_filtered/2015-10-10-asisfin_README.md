# writeup asis ctf finals 2015

uczestniczyliśmy (rev, shalom, other019, nazywam, pp i msm) w finałach asis ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:
- pierwszy ctf gdzie pierwsze punkty udało nam się zdobyć dopiero po kilku godzinach.
- wyjątkowo dużo zadań nad którymi musieliśmy pracować w kilka osób (robiąc research, pisząc część skryptów etc.). zwykle jedno zadanie rozwiązuj 1-2 osoby, tutaj było kilka nad którymi pracowały 3-4 osoby na raz.
- przeważająca większość zadań to re, pwn i crypto, czyli generalnie kategorie w których nie jesteśmy najmocniejsi. 

opisy zadań po kolei.

# spis treści:
* [asishash (re 150)](re_150_asishash)
* [big lie (forensic 100)](forensic_100_big_lie)
* [bodu (crypto 175)](crypto_175_bodu)
* [calcexec i (pwn 200)](pwn_200_calcexec_i)
* [calm down (trivia 75)](trivia_75_calm_down)
* [exampleflag (trivia 1)](trivia_1_example_flag)
* [fake (re 150)](re_150_fake)
* [flaghunter (misc 75)](misc_75_flaghunter)
* [impossible (web 225)](web_225_impossible)
* [license (re 125)](re_100_license)
* [meowmeow (misc 75)](misc_75_meowmeow)
* [shop-1 (pwn 100)](pwn_100_shop_1)
* [strange (forensic 150)](forensic_150_strange)

# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
