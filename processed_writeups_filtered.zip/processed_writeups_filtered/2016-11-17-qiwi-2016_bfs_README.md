# bfs (ppc 400)

###eng
[pl](#pl-version)

in the task we get a database [file](maze.db) with maze definition.
we dumped the data to [txt](data.txt) to simplify usage.
each node stores a single byte of data.
we guess that the point is to find the path through the maze.
we used simple bfs search for that:

```python
import codecs
import collections


def print_matrix(matrix):
    for i in range(50):
        print(" ".join(matrix[i]))


def add_unvisited_node(to_process, visited, x, y, backtrace, prev):
    if (x, y) not in visited:
        visited.add((x, y))
        backtrace[(x, y)] = prev
        to_process.append((x, y))


def main():
    visited = {(0, 0)}
    to_process = [(0, 0)]
    graph = collections.defaultdict(dict)
    backtrace = {}
    with codecs.open("data.txt") as input_file:
        for line in input_file:
            # eg. 1|0|0|gate|1
            data = line[:-2].split("|")
            node_id = int(data[0])
            x = int(data[1])
            y = int(data[2])
            wall_type = data[3]
            payload = data[4]
            graph[x][y] = (node_id, wall_type, payload)

    while len(to_process) > 0:
        xy = to_process.pop(0)
        x = xy[0]
        y = xy[1]
        if x in graph and y in graph[x]:
            node = graph[x][y]
            if node[0] == 2500:
                break
            if node[1] == "gate":
                add_unvisited_node(to_process, visited, x - 1, y, backtrace, xy)
                add_unvisited_node(to_process, visited, x, y - 1, backtrace, xy)
                add_unvisited_node(to_process, visited, x, y + 1, backtrace, xy)
                add_unvisited_node(to_process, visited, x + 1, y, backtrace, xy)
    print(backtrace)
    current = (49, 49)
    data = []
    matrix = [['   ' for i in range(50)] for j in range(50)]
    i = 0
    while current != (0, 0):
        x = current[0]
        y = current[1]
        matrix[x][y] = "%3d" % i
        i += 1
        data.append(graph[x][y][2])
        current = backtrace[(x, y)]
    data.reverse()
    print_matrix(matrix)
    result = "".join(data)
    print(result)


main()

```

which prints out the maze solution and the bytes picked up on the way:

```
54c82f36487a9157315aadfdded1bb83ecd98e49eadafeb03db563a94e0851478c408cfd6b0bb42b030f61a82e655b7fca0e1fa68df676758dc60fbfd1016f0eb8e7a2b5170a157497ef711e4009653bc9b20726c98b6561efbe316ac2ab2dcbe56494f05b44ed3eb62da4109beec2537266fede44acb12a17ca8c8a5ba9e1a4d24acad900ffbd228ac187b9024bedc941d137ea3a92f9f8506740cd8c62dbedb9990f3e0259434d9fcf070fec9e60c5697baba83a4e59eb4c3f0e7afd44b1b8d9d93933962b27237560b5f8f7d19904d790842fa596fbb52b2a3f7ee15b7f589d28a6f20f747615e7ed135e17afe8fe073b6606f5c893d40cb78b635aa5fe4e0ee10c572d5e7aeceaf743953d05f78bbc10a9bb3d53b0011ae5f269c806e5f9e6026c954a0cdf9c797953360602b96fc06324c3160701505c24597f6f7c77d5b76cbe25cd2b706a41da324a1b79cfc4ba8b11f800593514d27754
```

as far as i remember this was the flag.

###pl version

w zadaniu dostajemy [plik](maze.db) z definicją labiryntu.
zrzuciliśmy dane do [txt](data.txt) żeby ułatwić sobie pracę.
każdy węzeł uzyskanego grafu przechowuje jeden bajt danych.
domyślaliśmy się, ze zadaniem jest znaleźć drogę w labiryncie.
użyliśmy do tego bfsa:

```python
import codecs
import collections


def print_matrix(matrix):
    for i in range(50):
        print(" ".join(matrix[i]))


def add_unvisited_node(to_process, visited, x, y, backtrace, prev):
    if (x, y) not in visited:
        visited.add((x, y))
        backtrace[(x, y)] = prev
        to_process.append((x, y))


def main():
    visited = {(0, 0)}
    to_process = [(0, 0)]
    graph = collections.defaultdict(dict)
    backtrace = {}
    with codecs.open("data.txt") as input_file:
        for line in input_file:
            # eg. 1|0|0|gate|1
            data = line[:-2].split("|")
            node_id = int(data[0])
            x = int(data[1])
            y = int(data[2])
            wall_type = data[3]
            payload = data[4]
            graph[x][y] = (node_id, wall_type, payload)

    while len(to_process) > 0:
        xy = to_process.pop(0)
        x = xy[0]
        y = xy[1]
        if x in graph and y in graph[x]:
            node = graph[x][y]
            if node[0] == 2500:
                break
            if node[1] == "gate":
                add_unvisited_node(to_process, visited, x - 1, y, backtrace, xy)
                add_unvisited_node(to_process, visited, x, y - 1, backtrace, xy)
                add_unvisited_node(to_process, visited, x, y + 1, backtrace, xy)
                add_unvisited_node(to_process, visited, x + 1, y, backtrace, xy)
    print(backtrace)
    current = (49, 49)
    data = []
    matrix = [['   ' for i in range(50)] for j in range(50)]
    i = 0
    while current != (0, 0):
        x = current[0]
        y = current[1]
        matrix[x][y] = "%3d" % i
        i += 1
        data.append(graph[x][y][2])
        current = backtrace[(x, y)]
    data.reverse()
    print_matrix(matrix)
    result = "".join(data)
    print(result)


main()

```

co wypisuje na koniec rozwiązanie labiryntu oraz dane zebrane po drodze:

```
54c82f36487a9157315aadfdded1bb83ecd98e49eadafeb03db563a94e0851478c408cfd6b0bb42b030f61a82e655b7fca0e1fa68df676758dc60fbfd1016f0eb8e7a2b5170a157497ef711e4009653bc9b20726c98b6561efbe316ac2ab2dcbe56494f05b44ed3eb62da4109beec2537266fede44acb12a17ca8c8a5ba9e1a4d24acad900ffbd228ac187b9024bedc941d137ea3a92f9f8506740cd8c62dbedb9990f3e0259434d9fcf070fec9e60c5697baba83a4e59eb4c3f0e7afd44b1b8d9d93933962b27237560b5f8f7d19904d790842fa596fbb52b2a3f7ee15b7f589d28a6f20f747615e7ed135e17afe8fe073b6606f5c893d40cb78b635aa5fe4e0ee10c572d5e7aeceaf743953d05f78bbc10a9bb3d53b0011ae5f269c806e5f9e6026c954a0cdf9c797953360602b96fc06324c3160701505c24597f6f7c77d5b76cbe25cd2b706a41da324a1b79cfc4ba8b11f800593514d27754
```

o ile dobrze pamiętam to była flaga.
