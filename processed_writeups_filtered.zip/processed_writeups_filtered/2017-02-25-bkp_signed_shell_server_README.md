# signed shell server (pwn, 200)

> i'll only execute shell commands that are authenticated with my hmac-sha1 key.
> i'll sign a few benign commands for you, but after that, you're on your own!

as described in the task description, we were given a binary that would execute anything we
give it, but only if authenticated with hmac. we were given `ls` and a few other commands - nothing useful though.

the two global variables of particular interest were `char buff[256]` and immediately following `bool md5_vs_sha1`.
the latter one was set based on `argc` - on server it was set to 1, which meant md5 was used as hmac hash.
the `buff` array was the place to which our input was sent to.

it turns out we could overwrite the `md5_vs_sha1` flag with a zero by sending exactly 256 bytes of data, as the server,
trying to be helpful, null-terminates the buffer: `buff[chars_read]=0;`. so, we were able to use sha1 now.

the second bug was in the `execute` function too. the stack layout was generally: 
`char hash_buff[20]; void (*denied)(); void (*granted)();`. for some reason - i couldn't find a reasonable explanation - 
if the hash used was sha1, the hash was saved one byte later, i.e. at `hash_buff+1`. since sha1 length is 20 bytes, that
means we should be able to overwrite the `denied` function pointer's lowest byte (it was then called when hmac was incorrect).
by sending random data, we had about 1/256 chance of that byte becoming the same as `granted` function's, thus executing 
our command. so, we simply generated `cat flag` with a lot of random spaces and tabs to the rights, hoping it gives
correct result. eventually, it did.
