# pay2win (web 200)

###eng
[pl](#pl-version)

in the task we have a webpage where we can purchase some cheap object and a flag.
flag is much more expensive.
once we click on the item to purchase we can see a page with details and we have to put credit card number to confirm the purchase.

we notice instantly that the webpage with item details has the same url, with different long hash-looking value.
after fiddling with this we figure it's a 8-bytes block encryption ecb ciphertext.
this means we can split and combine blocks in different order to get some funny results.
this way we can "assemble" items with strange names and strange prices.

after that we tried actually buying an item.
we can't buy the flag with some fake credit card number, but we can buy the other item.
and the purchase results webpage has exactly the same layout at item details - again there is one url and the same looking ecb ciphertext.

so we fiddle again and see what we can assemble from the correct confirmation and the incorrect confirmation.

and we combine the valid cheap confirmation:

```
5765679f0870f430
9b1a3c83588024d7
c146a4104cf9d2c8
d3d78d0842397676
28df361f896eb3c3
706cda0474915040
```

with invalid flag confirmation:

```
232c66210158dfb2
3a2eda5cc945a0a9
650c1ed0fa0a08f6
a7ef23b6d345dd42
f1380b66410fa383
2f7ef761e2bbe791
```

to get the valid flag confirmation:

```
5765679f0870f430
9b1a3c83588024d7
650c1ed0fa0a08f6
a7ef23b6d345dd42
f1380b66410fa383
2f7ef761e2bbe791
```

and the flag: `33c3_3c81d6357a9099a7c091d6c7d71343075e7f8a46d55c593f0ade8f51ac8ae1a8`


###pl version

w zadaniu dostajemy stronę internetową na której można kupić jakiś tani obiekt oraz flagę.
flaga jest dużo droższa.
kiedy klikniemy na wybrany obiekt dostajemy stronę ze szczegółami obiektu oraz miejsce na podanie numeru karty kredytowej.

zauważyliśmy szybko, że strona ze szczegółami ma ten sam url oraz długi parametr wyglądający jak hash.
po zabawie z tym parametrem doszliśmy do wniosku że to dane szyfrowane 8-bajtowym szyfrem blokowym w trybie ecb.
to oznacza że możemy mieszać bloki i składać z nich nowe szyfrogramy, uzyskując ciekawe rezultaty jak dziwne nazwy oraz ceny.

następnie spróbowaliśmy kupić coś.
nie mogliśmy kupić flagi bo strona twierdziła że nasz fałszywy numer karty kredytowej przekroczył limit, ale mogliśmy kupic drugi obiekt.
po kupieniu przenosimy się na stronę ze szczegółami kupna, która wygląda bardzo podobnie - znowu jest tam jeden url i szyfrogram.

ponownie postanowiliśmy pobawić się w mieszanie bloków, tym razem z szyfrogramu z nieudaną próbą kupna flagi oraz z udanym kupnem innego obiektu.

finalnie łączymy udane kupno:

```
5765679f0870f430
9b1a3c83588024d7
c146a4104cf9d2c8
d3d78d0842397676
28df361f896eb3c3
706cda0474915040
```

z nieudanym kupnem flagi:

```
232c66210158dfb2
3a2eda5cc945a0a9
650c1ed0fa0a08f6
a7ef23b6d345dd42
f1380b66410fa383
2f7ef761e2bbe791
```

dostając udane kupno flagi:

```
5765679f0870f430
9b1a3c83588024d7
650c1ed0fa0a08f6
a7ef23b6d345dd42
f1380b66410fa383
2f7ef761e2bbe791
```

i samą flagę: `33c3_3c81d6357a9099a7c091d6c7d71343075e7f8a46d55c593f0ade8f51ac8ae1a8`
