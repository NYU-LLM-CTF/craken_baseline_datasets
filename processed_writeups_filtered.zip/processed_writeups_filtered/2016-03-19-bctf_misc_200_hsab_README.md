## hsab (misc, 200)

in this task, we were given only an ip and port to connect to. after sending a simple proof of work,
we are immediately dropped into bash shell. trying a couple of standard commands, such as `ls` or
`cat /etc/passwd` doesn't work - it said `ls: command not found`. playing with it some more time, we
noticed `echo` actually did work, `echo xxx` actually printed `xxx`. using `echo *`, `echo */*` and so on,
we could list all the files on the server. i did not save the output, but it was mostly normal linux
stuff, `/etc` and similar. however, two things stood out. first, the only binaries in `/bin` were `bash`
itself and `server` - presumably the program managing the connection. second, there was a file called
`/home/ctf/flag.ray`, probably containing the flag. however, without `cat` we could not easily read it.

thankfully, most of the bash builtin commands were working. after quick look into `man bash`, we thought
`read` should work - `read xxx < flag.ray; echo $xxx` was the command we tried. although it worked locally,
on the server it was syntax error - probably they disabled redirection, as `echo < /etc/passwd` errored too.

one more thing we tried, was running `bash flag.ray`. trying it on local system with dummy flag, it outputed:
```
$ bash flag.ray 
flag.ray: line 1: dummy_flag: command not found
```
on the server, there was no output though. that meant it was probably a correct bash script. finally, the
thing that worked was running `bash -v flag.ray` - or running bash in verbose mode. it turned out, that
the file contents were `#bctf{ipreferzshtobash}` - commented flag.
