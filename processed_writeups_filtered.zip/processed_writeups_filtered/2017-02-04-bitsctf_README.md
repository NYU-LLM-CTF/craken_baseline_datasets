# writeup bitsctf 2017

team: c7f.m0d3, cr01283, msm, rev, shalom, akrasuski1, nazywam, psrok1

### table of contents

* [ghost_in_the_machine (forensics)](ghost_in_the_machine)
* [enigma (crypto)](enigma)
* [sherlock (crypto)](sherlock)
* [beginners luck (crypto)](beginners_luck)
* [woodstock 1&2 (forensics)](woodstock)
* [riskv_and_reward](riskv_and_reward)
