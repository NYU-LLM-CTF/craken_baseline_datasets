## dark forest (ppc, 90p)

	description: someone pre-ordered a forest and now i'm lost in it. 
	there are a lot of binary trees in front and behind of me. 
	some are smaller or equal-sized than others. 
	can you help me to invert the path and find out of the forest? 
	hint: it's about (inverted) bsts. don't forget the spaces. 
	
###eng
[pl](#pl-version)

server sends input as:

	i'm lost in a forest. can you invert the path?
	level 1.: [13, 3]
	
this is list of binary tree nodes in pre-order. 
our task is to recontruct the tree, invert it and send to the server as pre-order.
inverting the tree means that any left branch becomes right branch, and right branch becomes left:

```python
def invert_tree(root):
    left = root.left
    right = root.right
    root.right = left
    root.left = right
    if root.right is not none:
        invert_tree(root.right)
    if root.left is not none:
        invert_tree(root.left)
```

traversing and printing pre-order means that we print the value of the node before we print the branches nodes:

```python
def display(root):
    result = []
    result.append(root.data)
    if root.left is not none:
        result.extend(display(root.left))
    if root.right is not none:
        result.extend(display(root.right))
    return result
```

therefore we simply read nodes from input, add them to the tree, invert it and send inverted tree as response.
complete solution is [here](tree.py).

after 100 tasks we get the flag: `iw{10000101010101tr33}`

###pl version

serwer przysyła dane jako:

	i'm lost in a forest. can you invert the path?
	level 1.: [13, 3]
	
to jest lista węzłów drzewa binarnego w porządku pre-order.
naszym zadaniem jest odbudować drzewo, odwrócić je a następnie wysłać je do serwera w porządku pre-order.
odwracanie drzewa oznacza że każda lewa gałąź staje się prawą a prawa lewą:

```python
def invert_tree(root):
    left = root.left
    right = root.right
    root.right = left
    root.left = right
    if root.right is not none:
        invert_tree(root.right)
    if root.left is not none:
        invert_tree(root.left)
```

przechodzenie i wypisanie drzewa pre-order oznacza że najpierw wypisujemy wartość danego węzła a dopiero potem jego gałęzi:

```python
def display(root):
    result = []
    result.append(root.data)
    if root.left is not none:
        result.extend(display(root.left))
    if root.right is not none:
        result.extend(display(root.right))
    return result
```

w związku z tym pobieramy z wejścia listę węzłów, dodajemy je do drzewa, odwracamy je i odsyłamy odwrócone drzewo jako odpowiedź.
całe rozwiązanie jest [tutaj](tree.py).

po 100 przykładach dostajemy flagę: `iw{10000101010101tr33}`
