# j1 (forensics)

###eng
[pl](#pl-version)

this was a multilevel forensics task.

we were given a windows virtual machine to work with. 
the machine had user "m" with unknown password.
intially we reset the password, but this turned out to be a bad idea since the user had bitlocker encrypoted files and the password was necessary after all.
so we used ophcrack to recover the password hash `f6939966b0ffbc61c2c520cea20c2db0` and some online breaker told us this is `qwerty1234`.

now we could decrypt the files:

* a picture with some meaningless email
* email hinting that admin likes to use the same password in many places
* html page with some javascript

the javascript has some placeholders for parameters we had to guess/bruteforce but after a while we got:

```javascript
for (var d = 11; d < 12; d++) {
	var key = "";
	var clear = "";
	var encrypted = "96.28.95.118.9.2.58.29.56.52.44.25.58.51.83.8.108.20.53.37.88.2.71.80";
	secret = navigator.platform + "en-ustrue2000" ;

	for (i=0; i < secret.length; i++) { key+= string.fromcharcode(secret.charcodeat(i) ^ d);}
	encrypted = encrypted.split ("."); for (i=0; encrypted.length > key.length; i++) { key += key; }

	for (i=0; i < encrypted.length; i++) { clear += string.fromcharcode(key.charcodeat(i) ^ parseint(encrypted[i]));}
	document.write (clear + "<br>");
}
```

and were left with the only interesting result:

```
<~:n0l_;fls`d]j3w/ig=:~>
```

it took us a while to realise that this is ascii85 encoding and it decodes to `openstego v0.6.1`.

we used this tool on the picture we recovered, using the same admin password (as hinted in the recovered email) and we got a doc file from this.

this doc file contained a macro with flag decryption.
sadly none of us had ms word to open this :( luckily quick thinking of one of our players saved us.
he uploaded this word file to malwr, which then opened the file inside a sandbox and provided us with a useful memory dump.
among other things there was a base64 string, which decoded finally gave us the flag.


###pl version

zadanie było wielopoziomowym problemem z informatyki śledczej.

dostaliśmy windowsową maszynę wirtualną do pracy.
na maszynie był użytkownik "m" z nieznanym hasłem.
początkowo zresetowaliśmy hasło, ale to okazało się złym pomysłem, bo na dysku były pliku szyfrowane bitlockerem i hasło było potrzebne żeby je odzyskać.
użyliśmy ophcracka żeby odzyskać hash hasła `f6939966b0ffbc61c2c520cea20c2db0` a jakiś onlinowy hash breaker powiedział że to `qwerty1234`.

teraz mogliśmy odszyfrować pliki:

* obrazek z nieistotnym mailem
* mail wspominający że admin lubi używać tego samego hasła wielokrotnie
* stronę html ze skryptem js

skrypt miał pewne placeholdery które trzeba było zgadnąć / brutować ale po pewnym czasie uzyskaliśmy:

```javascript
for (var d = 11; d < 12; d++) {
	var key = "";
	var clear = "";
	var encrypted = "96.28.95.118.9.2.58.29.56.52.44.25.58.51.83.8.108.20.53.37.88.2.71.80";
	secret = navigator.platform + "en-ustrue2000" ;

	for (i=0; i < secret.length; i++) { key+= string.fromcharcode(secret.charcodeat(i) ^ d);}
	encrypted = encrypted.split ("."); for (i=0; encrypted.length > key.length; i++) { key += key; }

	for (i=0; i < encrypted.length; i++) { clear += string.fromcharcode(key.charcodeat(i) ^ parseint(encrypted[i]));}
	document.write (clear + "<br>");
}
```

i otrzymaliśmy jedyny sensowny wynik:

```
<~:n0l_;fls`d]j3w/ig=:~>
```

chwile zajęło nam odkrycie że to string kodowany jako ascii85 i dekoduje się do `openstego v0.6.1`.

użyliśmy tego narzędzia na odzyskanym obrazku, używając tego samego hasła admina (jak zasugerowano w mailu który odzyskaliśmy) i dostaliśmy z tego plik doc.

ten plik worda zawierał makro które dekodowało flagę.
niestety nikt z nas nie miał pod ręką ms worda i nie mogliśmy tego otworzyć.
szczęśliwie uratował nas świetny pomysł jednego z graczy.
wrzucił on rzeczony plik na malwr, gdzie plik został otwarty w sandboxie, z którego dostaliśmy użyteczny memdump.
pośród różnych rzeczy był tam string base64, który po zdekodowaniu dał nam flagę.
