## rand2 (web, 2p)
	
###eng
[pl](#pl-version)

page uses rand() to generate random numbers.
one is printed at the start of the script.
five next is stored and only md5 hash is returned.
flag is displayed after we submit five unknown (for us numbers).

the seed has only 32 bit. given enough cpu power we can exhaust a lot of this space.
it also helps to try several rand() outputs at once - we need just one correct solution.
to generate seeds producing given rand() output c program is used: 
```cpp
static unsigned int rnd(unsigned int seed) {
	srand(seed);
	return rand();
}

int main(int argc, char*argv[]) {
	int n[100];
	for(int i=0;i<argc-1;i++) {
		n[i]=atoi(argv[i+1]);
	}
	int skip = !!fork() + 2*(!!fork());
	for (uint32_t i=skip;i!=int_max;i+=4) {
		int x = rnd(i);
		for(int j=0;j<argc-1;j++) {
			if(n[j] == x) {
				printf("%d %d\n", j, i);
				fflush(stdout);
			}
		}
	}
}
```
to check if given seed produces numbers matching md5, php script is used:
```php
<?php
srand((int)($argv[1]));
echo rand();
echo "\n";
$rand = array();
$i = 5;
$d = '';
$_d = '';
while($i--){
	$r = (string)rand();
	$rand = $r;
	$d .= $r;
	$_d .= 'check[]=';
	$_d .= $r;
	$_d .= "&";
}
echo md5($d);
echo "\n";
echo $_d;
echo "\n";
?>
```
all is stiched up with a python script:
```python
import requests
import subprocess

url = "http://202.120.7.202:8888/"
n = 8

session = [none] * n;
rands = [none] * n
hashes = [none] * n

for i in xrange(len(session)):
	session[i] = requests.session()
	p = session[i].get(url+"?go")
	md5 = p.text[len(p.text)-32:]
	r = p.text[:len(p.text)-32]
	rands[i] = r
	hashes[i] = md5
	print i, r, md5


proc = subprocess.popen(["./a.out"]+rands, stdout=subprocess.pipe)
for output in iter(proc.stdout.readline,''):
	print output
	i,s = output.split(" ")
	r_output = subprocess.popen(["php", "rand.php", s], stdout=subprocess.pipe).communicate()[0]
	g_rand,g_hash,g_d,_ = r_output.split("\n")
	print hashes[int(i)], g_hash
	if hashes[int(i)] == g_hash:
		print g_d
		print session[int(i)].get(url+"?"+g_d).text
		proc.kill()
		break
```
we try 8 sessions at once. after only a few tries valid seed is found and flag returned.


###pl version


stronka używa funckcji rand() do generowania liczb.
pierwsza jest wypisywana przy starcie skryptu.
pięć następnych jest zapisywanych a zwracany jest tylko hasz md5.
flaga zostanie nam ujawniona gdy podamy te pięć nieznanych nam liczb.

ziarno dla funkcji rand() ma tylko 32 bity.
przy dostatecznie dużej mocy obliczeniowej możemy przeszukać znaczącą część tej przestrzeni.
możemy też próbować odgadnąć kilka ziaren na raz - potrzebne nam tylko jedno poprawne rozwiązanie a błędne nic na nie kosztują.
aby wygenerować możliwe ziarna dla podanej wartośći rand() używamy poniższego programu w c:
```cpp
static unsigned int rnd(unsigned int seed) {
	srand(seed);
	return rand();
}

int main(int argc, char*argv[]) {
	int n[100];
	for(int i=0;i<argc-1;i++) {
		n[i]=atoi(argv[i+1]);
	}
	int skip = !!fork() + 2*(!!fork());
	for (uint32_t i=skip;i!=int_max;i+=4) {
		int x = rnd(i);
		for(int j=0;j<argc-1;j++) {
			if(n[j] == x) {
				printf("%d %d\n", j, i);
				fflush(stdout);
			}
		}
	}
}
```
każda podana liczba może być wygenerowana przez kilka różnych ziaren.
aby odrzucić fałszywe, generujemy hasz 5 kolejnych liczb skryptem php.
ziarno jest odrzucane jeżeli hasz różni się od wartośći orzymanej ze strony.
```php
<?php
srand((int)($argv[1]));
echo rand();
echo "\n";
$rand = array();
$i = 5;
$d = '';
$_d = '';
while($i--){
	$r = (string)rand();
	$rand = $r;
	$d .= $r;
	$_d .= 'check[]=';
	$_d .= $r;
	$_d .= "&";
}
echo md5($d);
echo "\n";
echo $_d;
echo "\n";
?>
```
całość połączona jest skryptem w pythonie:
```python
import requests
import subprocess

url = "http://202.120.7.202:8888/"
n = 8

session = [none] * n;
rands = [none] * n
hashes = [none] * n

for i in xrange(len(session)):
	session[i] = requests.session()
	p = session[i].get(url+"?go")
	md5 = p.text[len(p.text)-32:]
	r = p.text[:len(p.text)-32]
	rands[i] = r
	hashes[i] = md5
	print i, r, md5


proc = subprocess.popen(["./a.out"]+rands, stdout=subprocess.pipe)
for output in iter(proc.stdout.readline,''):
	print output
	i,s = output.split(" ")
	r_output = subprocess.popen(["php", "rand.php", s], stdout=subprocess.pipe).communicate()[0]
	g_rand,g_hash,g_d,_ = r_output.split("\n")
	print hashes[int(i)], g_hash
	if hashes[int(i)] == g_hash:
		print g_d
		print session[int(i)].get(url+"?"+g_d).text
		proc.kill()
		break
```
próbująć odgadnąć 8 ziaren na raz, wystarczyło tylko kilka prób aby odgadnąć jedno mieszcząc się w czasie.

