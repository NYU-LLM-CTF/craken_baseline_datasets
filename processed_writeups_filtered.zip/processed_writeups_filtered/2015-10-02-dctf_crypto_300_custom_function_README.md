﻿## crypto 300 (crypto, 300p)

### pl

[eng](#eng-version)

bardzo ciekawe zadanie dla nas, musieliśmy sporo z nim powalczyć, ale w końcu udało się rozwiązać zagadkę szyfru.

otóż dostajemy taki szyfr:

    320b1c5900180a034c74441819004557415b0e0d1a316918011845524147384f5700264f48091e45
    00110e41030d1203460b1d0752150411541b455741520544111d0000131e0159110f0c16451b0f1c
    4a74120a170d460e13001e120a1106431e0c1c0a0a1017135a4e381b16530f330006411953664334
    593654114e114c09532f271c490630110e0b0b

oraz kod którym go zaszyfrowano (w wersji przepisanej przez nas do pythona, nie jesteśmy fanami php):

    def encrypt(plaintext):
        space = 10
        ciphertext = ""
        for i in range(len(plaintext)):
            if i + space < len(plaintext) - 1:
                ciphertext += chr(ord(plaintext[i]) ^ ord(plaintext[i + space]))
            else:
                ciphertext += chr(ord(plaintext[i]) ^ ord(plaintext[space]))
            if ord(plaintext[i]) % 2 == 0:
                space += 1
            else:
                space -= 1
        return ciphertext

bardzo komplikuje wszystko ta ruszająca się space. ale jej stan zależy tylko od najniższego bitu, co wykorzystaliśmy przy rozwiązywaniu zadania.
rozwiązywaliśmy je w dwóch częściach - najpierw odzyskaliśmy najniższe bity plaintextu, a później dopiero całe hasło.

pierwsza próba złamania najniższych bitów wyglądała tak:

    def verify(ciphertext, guessedbits):
        space = 10
        for i in range(len(guessedbits)):
            if i + space < len(ciphertext) - 1:
                if i + space >= len(guessedbits):
                    return true
                if (ord(ciphertext[i]) & 1) != ((ord(guessedbits[i]) & 1) ^ (ord(guessedbits[i + space]) & 1)):
                    return false
            else:
                if space >= len(guessedbits):
                    return true
                if (ord(ciphertext[i]) & 1) != ((ord(guessedbits[i]) & 1) ^ (ord(guessedbits[space]) & 1)):
                    return false
            if guessedbits[i] == '0':
                space += 1
            else:
                space -= 1
        return true


    def decrypt(ciphertext, guessedbits, i):
        if i >= len(ciphertext):
            print 'ok:', guessedbits
            return
        if len(guessedbits) == 10:
            print (int(guessedbits, 2) / 1024.0) * 100, '%'
        if verify(ciphertext, guessedbits):
            decrypt(ciphertext, guessedbits + '0', i + 1)
            decrypt(ciphertext, guessedbits + '1', i + 1)

konkretnie, był to bruteforce z odcinaniem - sprawdzaliśmy wszystkie możliwości, i jeśli verify() się nie udał, wychodziliśmy ze sprawdzanej gałęzi

niestety, było to dużo za wolne. zaczeliśmy od mikrooptymalizacji - jeśli dobrze pamiętam, przyśpieszyło to wykonanie skryptu prawie 600 razy (!) (a używaliśmy już pypy do wszystkich testów i tak):

    def verify(ciphertext, guessedbits, length, guessed_len):
        space = 10
        for i in range(guessed_len):
            if i + space < length - 1:
                if i + space >= guessed_len:
                    return true
                if (ciphertext[i] & 1) != ((guessedbits[i] & 1) ^ (guessedbits[i + space] & 1)):
                    return false
            else:
                if space >= guessed_len:
                    return true
                if (ciphertext[i] & 1) != ((guessedbits[i] & 1) ^ (guessedbits[space] & 1)):
                    return false
            if guessedbits[i] == 0:
                space += 1
            else:
                space -= 1
        return true


    def decrypt(ciphertext):
        guessed_bits = [0] * len(ciphertext)
        length = len(ciphertext)
        i = 0
        orded_cipher = [ord(c) for c in ciphertext]
        decrypt_r(orded_cipher, guessed_bits, i, length)


    def decrypt_r(orded_cipher, guessedbits, i, length):
        if i >= length:
            print 'ok:', guessedbits
            return
        if i == 10:
            print (int(''.join(str(c) for c in guessedbits[:10]), 2) / 1024.0) * 100, '%'
        if verify(orded_cipher, guessedbits, length, i):
            guessedbits[i] = 0
            decrypt_r(orded_cipher, guessedbits, i + 1, length)
            guessedbits[i] = 1
            decrypt_r(orded_cipher, guessedbits, i + 1, length)

wykonywało się już relatywnie szybko. odpaliliśmy to na czterech rdzeniach u jednego z członków naszego zespołu.

ale nie zapowiadało się to zbyt optymistycznie, więc spróbowaliśmy jeszcze zmienić podejście (viva la algorytmika!). zamiast za każdym razem weryfikować całe hasło (i wychodzić w przód niepotrzebnie), odrzucać niemożliwe rozwiązania od razu:

    def decrypt(ciphertext):
        guessed_bits = ['?'] * len(ciphertext)
        length = len(ciphertext)
        i = 0
        orded_cipher = [ord(c) & 1 for c in ciphertext]
        decrypt_r(orded_cipher, guessed_bits, i, length, 10)
    
    
    def try_guess(orded_cipher, guessedbits, i, length, guess, space):
        guessedbits = list(guessedbits)
        guessedbits[i] = guess
        if i + space < length - 1:
            nextndx = i + space
        else:
            nextndx = space
    
        nextbit = orded_cipher[i] ^ guess
        if guess == 0:
            newspace = space + 1
        else:
            newspace = space - 1
    
        if guessedbits[nextndx] == '?' or guessedbits[nextndx] == nextbit:
            guessedbits[nextndx] = nextbit
            decrypt_r(orded_cipher, guessedbits, i + 1, length, newspace)
    
    def decrypt_r(orded_cipher, guessedbits, i, length, space):
        if i >= length:
            print 'ok:', ''.join(str(c) for c in guessedbits)
            return
        if guessedbits[i] == '?':
            try_guess(orded_cipher, guessedbits, i, length, 0, space)
            try_guess(orded_cipher, guessedbits, i, length, 1, space)
        elif guessedbits[i] == 0:
            try_guess(orded_cipher, guessedbits, i, length, 0, space)
        elif guessedbits[i] == 1:
            try_guess(orded_cipher, guessedbits, i, length, 1, space)

używamy tu swoistego triboola w tablicy guessedbits, czyli 0 oznacza "na pewno będzie tam 0", 1 oznacza "na pewno będzie tam 1", a ? oznacza ofc "nie wiadomo".

pisanie i debugowanie tej wersji zajęło nam około godziny. a rozwiązanie dała dosłownie kilka sekund po uruchomieniu (poprzednia wersja ciągle się liczyła jeszcze).

tak czy inaczej, poprawne rozwiązania (szukaliśmy tutaj najniższych bitów plaintextu, przypominam) były cztery:

sln = '1001011001110101110010100010110110010000010000100111010010111010010100111100001001110000011110010011110100101001010110010110101000110110100'
sln = '1001011001110101110010100010110110000100010111010011010000011001001100111100111011110000000110100001110100101001010110010110101000110110100'
sln = '0101011000010101110100001010000110100101001011010111000100111000010010000011001000110101001110101111110100001000110110101001010111111110100'
sln = '0101011000010101110100001010000110100101001011000011000100111000110010001100011001110101000010100001110101100111000100101001010111001001011'

otrzymaliśmy w ten sposób układ równań dla 140 zmiennych. nasza pierwsza próba to było użycie gotowego solvera do rozwiązania tego układu. przykładowo dla 4 rozwiązania:

    from constraint import *
    problem = problem()

    odd = range(33, 128, 2) + [13]
    even = range(32, 128, 2) + [10]

    problem.addvariable(0, odd)
    problem.addvariable(1, even)
    problem.addvariable(2, even)
    problem.addvariable(3, odd)
    problem.addvariable(4, even)
    # (...) snip
    problem.addvariable(134, odd)
    problem.addvariable(135, even)
    problem.addvariable(136, odd)
    problem.addvariable(137, even)
    problem.addvariable(138, even)

    problem.addconstraint(lambda av, bv: av ^ bv == 0x32, (0, 10))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (1, 10))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x1c, (2, 12))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x59, (3, 14))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x0, (4, 14))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x18, (5, 16))
    # (...) snip
    problem.addconstraint(lambda av, bv: av ^ bv == 0x6, (133, 17))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x30, (134, 16))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x11, (135, 15))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xe, (136, 16))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (137, 15))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (138, 16))

    print problem.getsolutions()

niestety, solver wykonywał się wieki (nie mamy pewności czy wykonałby się w tym stuleciu). dlatego, w czasie kiedy on się liczył, my zabraliśmy się za ręczne pisanie solvera:

    import string
    slv = [none] * len(sln)
    
    def filling_pass(slv):
        while true:
            any = false
            space = 10
            for i in range(len(sln)):
                if i + space < len(sln) - 1:
                    nx = i + space
                else:
                    nx = space
                if sln[i] == '0':
                    space += 1
                else:
                    space -= 1
                if slv[i] is not none:
                    sn = ord(slv[i]) ^ ord(ciph[i])
                    if slv[nx] is none:
                        slv[nx] = chr(sn)
                        if (sn >= 32 and sn < 127) or sn == 10 or sn == 13:
                            any = true
                        else:
                            return false
                    else:
                        if slv[nx] != chr(sn):
                            return false
            if not any:
                return true
    
    def tryit(slvo, start):
        while slvo[start] is not none:
            start += 1
            if start >= len(slvo):
                print ''.join(' ' if c is none else '.' if ord(c) < 32 else c for c in slvo)
                return
            continue
        for c in string.printable:
            slv = list(slvo)
            slv[start] = c
            possible = filling_pass(slv)
            if possible:
                tryit(slv, start)
    
    tryit(slv, 0)

i po raz drugi w tym zadaniu, to co liczyło się godziny/dni naiwnym programem, po poprawie algorytmu zadziałało w *sekundy*. cieszy że mimo postępu komputerów jednak myślenie nad wydajnością ma czasami zastosowanie.

konkretnie, nasze rozwiązanie działało na takiej zasadzie:

    hasło = ['?'] * długość_hasła
    while (nie wszystkie literki w haśle znane):
        for char in charset:
            podstaw char za kolejną literkę w haśle
            wywnioskuj na podstawie znanych ograniczeń jak najwięcej innych znaków (funkcja filling_pass). jeśli wyjdzie sprzeczność, zaniechaj, inaczej rekurencyjnie powtarzaj.

odpaliliśmy więc nasz algorytm:

    c:\users\xxx\code\re\ctf\2015-10-02 def\crypto300>python hackz.py
    cpgl5bpyy5qz{p5lz`5vas5eb{pg;5[zb5\5}tcp5az5r|cp5lz`5a}p5gpbtgq5szg5tyy5a}|f5}tgq5bzg~5zg5xtlwp5r`pff|{r;5a}p5sytr5|f5vgleat{tylf|fj|fj}tgq
    izmf?hzss?{pqz?fpj?\ky?ohqzm1?qph?v?w~iz?kp?xviz?fpj?kwz?mzh~m{?ypm?~ss?kwvl?w~m{?hpmt?pm?r~f}z?xjzllvqx1?kwz?ys~x?vl?|mfok~q~sflvl@vl@w~m{
    qbu~'pbkk'chib'~hr'dsa'wpibu)'ihp'n'ofqb'sh'`nqb'~hr'sob'ubpfuc'ahu'fkk'sont'ofuc'phul'hu'jf~eb'`rbttni`)'sob'akf`'nt'du~wsfifk~tntxntxofuc
    rav}$sahh$`kja$}kq$gpb$tsjav*$jks$m$lera$pk$cmra$}kq$pla$vasev`$bkv$ehh$plmw$lev`$skvo$kv$ie}fa$cqawwmjc*$pla$bhec$mw$gv}tpejeh}wmw[mw[lev`
    s`w|%r`ii%ajk`%|jp%fqc%urk`w+%kjr%l%mds`%qj%bls`%|jp%qm`%w`rdwa%cjw%dii%qmlv%mdwa%rjwn%jw%hd|g`%bp`vvlkb+%qm`%cidb%lv%fw|uqdkdi|vlvzlvzmdwa
    tgp{"ugnn"fmlg"{mw"avd"rulgp,"lmu"k"jctg"vm"ektg"{mw"vjg"pgucpf"dmp"cnn"vjkq"jcpf"umpi"mp"oc{`g"ewgqqkle,"vjg"dnce"kq"ap{rvclcn{qkq]kq]jcpf
    ufqz#tfoo#glmf#zlv#@we#stmfq-#mlt#j#kbuf#wl#djuf#zlv#wkf#qftbqg#elq#boo#wkjp#kbqg#tlqh#lq#nbzaf#dvfppjmd-#wkf#eobd#jp#`qzswbmbozpjp\jp\kbqg
    very well done you ctf pwner. now i have to give you the reward for all this hard work or maybe guessing. the flag is cryptanalysis_is_hard
    wdsx!vdmm!enod!xnt!bug!qvods/!onv!h!i`wd!un!fhwd!xnt!uid!sdv`se!gns!`mm!uihr!i`se!vnsj!ns!l`xcd!ftdrrhof/!uid!gm`f!hr!bsxqu`o`mxrhr^hr^i`se
    xk|w.ykbb.ja`k.wa{.mzh.~y`k| .@ay.g.foxk.za.igxk.wa{.zfk.|kyo|j.ha|.obb.zfg}.fo|j.ya|e.a|.cowlk.i{k}}g`i .zfk.hboi.g}.m|w~zo`obw}g}qg}qfo|j

    c:\users\xxx\code\re\ctf\2015-10-02 def\crypto300>

świetnie - zdobyliśmy flagę - `cryptanalysis_is_hard`

### eng version

very interesting task for us, we had to put much effort into this by we finally solved it.

we get a ciphertext:

    320b1c5900180a034c74441819004557415b0e0d1a316918011845524147384f5700264f48091e45
    00110e41030d1203460b1d0752150411541b455741520544111d0000131e0159110f0c16451b0f1c
    4a74120a170d460e13001e120a1106431e0c1c0a0a1017135a4e381b16530f330006411953664334
    593654114e114c09532f271c490630110e0b0b

and code whcih was used to encode it (rewritten to python since we're not fans of php):

    def encrypt(plaintext):
        space = 10
        ciphertext = ""
        for i in range(len(plaintext)):
            if i + space < len(plaintext) - 1:
                ciphertext += chr(ord(plaintext[i]) ^ ord(plaintext[i + space]))
            else:
                ciphertext += chr(ord(plaintext[i]) ^ ord(plaintext[space]))
            if ord(plaintext[i]) % 2 == 0:
                space += 1
            else:
                space -= 1
        return ciphertext

the biggest issue here is the moving space. however its state depends only on the lowest bit of the plaintext character, which we exploited to solve the task.
the solution was split into two parts - first we extracted lowest bits of the plaintext and after that we decoded the whole ciphertext.

first attempts to extract the lowest bits:

    def verify(ciphertext, guessedbits):
        space = 10
        for i in range(len(guessedbits)):
            if i + space < len(ciphertext) - 1:
                if i + space >= len(guessedbits):
                    return true
                if (ord(ciphertext[i]) & 1) != ((ord(guessedbits[i]) & 1) ^ (ord(guessedbits[i + space]) & 1)):
                    return false
            else:
                if space >= len(guessedbits):
                    return true
                if (ord(ciphertext[i]) & 1) != ((ord(guessedbits[i]) & 1) ^ (ord(guessedbits[space]) & 1)):
                    return false
            if guessedbits[i] == '0':
                space += 1
            else:
                space -= 1
        return true


    def decrypt(ciphertext, guessedbits, i):
        if i >= len(ciphertext):
            print 'ok:', guessedbits
            return
        if len(guessedbits) == 10:
            print (int(guessedbits, 2) / 1024.0) * 100, '%'
        if verify(ciphertext, guessedbits):
            decrypt(ciphertext, guessedbits + '0', i + 1)
            decrypt(ciphertext, guessedbits + '1', i + 1)

this is a simple brute-force with prunning - we test all possibilities and if verify() failed we prune given branch.

unfortunately this was too slow. we started with some optimization of the code - and if i remember correctly this resulted in 600 times faster execution (!) (and we were already running on pypy for all the tests):

    def verify(ciphertext, guessedbits, length, guessed_len):
        space = 10
        for i in range(guessed_len):
            if i + space < length - 1:
                if i + space >= guessed_len:
                    return true
                if (ciphertext[i] & 1) != ((guessedbits[i] & 1) ^ (guessedbits[i + space] & 1)):
                    return false
            else:
                if space >= guessed_len:
                    return true
                if (ciphertext[i] & 1) != ((guessedbits[i] & 1) ^ (guessedbits[space] & 1)):
                    return false
            if guessedbits[i] == 0:
                space += 1
            else:
                space -= 1
        return true


    def decrypt(ciphertext):
        guessed_bits = [0] * len(ciphertext)
        length = len(ciphertext)
        i = 0
        orded_cipher = [ord(c) for c in ciphertext]
        decrypt_r(orded_cipher, guessed_bits, i, length)


    def decrypt_r(orded_cipher, guessedbits, i, length):
        if i >= length:
            print 'ok:', guessedbits
            return
        if i == 10:
            print (int(''.join(str(c) for c in guessedbits[:10]), 2) / 1024.0) * 100, '%'
        if verify(orded_cipher, guessedbits, length, i):
            guessedbits[i] = 0
            decrypt_r(orded_cipher, guessedbits, i + 1, length)
            guessedbits[i] = 1
            decrypt_r(orded_cipher, guessedbits, i + 1, length)

this was already reasonably fast. we fired this four times for different prefixes on one machine.

but since we had to wait anyway, we decided to try a different approach (viva la algorithmics). instead of verifying the whole password every time (by going forward) we rejected impossible solutions right away:

    def decrypt(ciphertext):
        guessed_bits = ['?'] * len(ciphertext)
        length = len(ciphertext)
        i = 0
        orded_cipher = [ord(c) & 1 for c in ciphertext]
        decrypt_r(orded_cipher, guessed_bits, i, length, 10)
    
    
    def try_guess(orded_cipher, guessedbits, i, length, guess, space):
        guessedbits = list(guessedbits)
        guessedbits[i] = guess
        if i + space < length - 1:
            nextndx = i + space
        else:
            nextndx = space
    
        nextbit = orded_cipher[i] ^ guess
        if guess == 0:
            newspace = space + 1
        else:
            newspace = space - 1
    
        if guessedbits[nextndx] == '?' or guessedbits[nextndx] == nextbit:
            guessedbits[nextndx] = nextbit
            decrypt_r(orded_cipher, guessedbits, i + 1, length, newspace)
    
    def decrypt_r(orded_cipher, guessedbits, i, length, space):
        if i >= length:
            print 'ok:', ''.join(str(c) for c in guessedbits)
            return
        if guessedbits[i] == '?':
            try_guess(orded_cipher, guessedbits, i, length, 0, space)
            try_guess(orded_cipher, guessedbits, i, length, 1, space)
        elif guessedbits[i] == 0:
            try_guess(orded_cipher, guessedbits, i, length, 0, space)
        elif guessedbits[i] == 1:
            try_guess(orded_cipher, guessedbits, i, length, 1, space)

we use a tri-value-boolean in guessedbits, 0 for `there is definitely 0`, 1 for `there is definitely 1` and ? for `don't know`.

it took us an hour to write this and debug but we got the results within a few seconds (while the previous version was still computing).

anyway, the final correct sulutions (for lowest bits of the plaintext) were four:

sln = '1001011001110101110010100010110110010000010000100111010010111010010100111100001001110000011110010011110100101001010110010110101000110110100'
sln = '1001011001110101110010100010110110000100010111010011010000011001001100111100111011110000000110100001110100101001010110010110101000110110100'
sln = '0101011000010101110100001010000110100101001011010111000100111000010010000011001000110101001110101111110100001000110110101001010111111110100'
sln = '0101011000010101110100001010000110100101001011000011000100111000110010001100011001110101000010100001110101100111000100101001010111001001011'

this way we got a set of equations with 140 variables. we tried to use a constraint-programming solver to solve it. for example for the bits number 4:

    from constraint import *
    problem = problem()

    odd = range(33, 128, 2) + [13]
    even = range(32, 128, 2) + [10]

    problem.addvariable(0, odd)
    problem.addvariable(1, even)
    problem.addvariable(2, even)
    problem.addvariable(3, odd)
    problem.addvariable(4, even)
    # (...) snip
    problem.addvariable(134, odd)
    problem.addvariable(135, even)
    problem.addvariable(136, odd)
    problem.addvariable(137, even)
    problem.addvariable(138, even)

    problem.addconstraint(lambda av, bv: av ^ bv == 0x32, (0, 10))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (1, 10))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x1c, (2, 12))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x59, (3, 14))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x0, (4, 14))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x18, (5, 16))
    # (...) snip
    problem.addconstraint(lambda av, bv: av ^ bv == 0x6, (133, 17))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x30, (134, 16))
    problem.addconstraint(lambda av, bv: av ^ bv == 0x11, (135, 15))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xe, (136, 16))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (137, 15))
    problem.addconstraint(lambda av, bv: av ^ bv == 0xb, (138, 16))

    print problem.getsolutions()

unfortunately, it was taking a long time (and we're not sure if it would compute in this century). so in the meanwhile we attempted to make a custom solver:

    import string
    slv = [none] * len(sln)
    
    def filling_pass(slv):
        while true:
            any = false
            space = 10
            for i in range(len(sln)):
                if i + space < len(sln) - 1:
                    nx = i + space
                else:
                    nx = space
                if sln[i] == '0':
                    space += 1
                else:
                    space -= 1
                if slv[i] is not none:
                    sn = ord(slv[i]) ^ ord(ciph[i])
                    if slv[nx] is none:
                        slv[nx] = chr(sn)
                        if (sn >= 32 and sn < 127) or sn == 10 or sn == 13:
                            any = true
                        else:
                            return false
                    else:
                        if slv[nx] != chr(sn):
                            return false
            if not any:
                return true
    
    def tryit(slvo, start):
        while slvo[start] is not none:
            start += 1
            if start >= len(slvo):
                print ''.join(' ' if c is none else '.' if ord(c) < 32 else c for c in slvo)
                return
            continue
        for c in string.printable:
            slv = list(slvo)
            slv[start] = c
            possible = filling_pass(slv)
            if possible:
                tryit(slv, start)
    
    tryit(slv, 0)

and again for the second time in this task, what was taking hours in the naive implementation, took only *seconds* with a better algorithm. it's nice to think that even though we get more and more powerful computers, thinking about the computational complexity pays off sometimes.

the solver worked like this:

    plaintext = ['?'] * plaintext_length
    while (not all characters in plaintext are decoded):
        for char in charset:
            use char as next letter in password
			using known constraints try to figure out as much as possible of next characters in plaintext (filling_pass function). if there is a constraint violation break, otherwise repeat recursively.

this way we got:

    c:\users\xxx\code\re\ctf\2015-10-02 def\crypto300>python hackz.py
    cpgl5bpyy5qz{p5lz`5vas5eb{pg;5[zb5\5}tcp5az5r|cp5lz`5a}p5gpbtgq5szg5tyy5a}|f5}tgq5bzg~5zg5xtlwp5r`pff|{r;5a}p5sytr5|f5vgleat{tylf|fj|fj}tgq
    izmf?hzss?{pqz?fpj?\ky?ohqzm1?qph?v?w~iz?kp?xviz?fpj?kwz?mzh~m{?ypm?~ss?kwvl?w~m{?hpmt?pm?r~f}z?xjzllvqx1?kwz?ys~x?vl?|mfok~q~sflvl@vl@w~m{
    qbu~'pbkk'chib'~hr'dsa'wpibu)'ihp'n'ofqb'sh'`nqb'~hr'sob'ubpfuc'ahu'fkk'sont'ofuc'phul'hu'jf~eb'`rbttni`)'sob'akf`'nt'du~wsfifk~tntxntxofuc
    rav}$sahh$`kja$}kq$gpb$tsjav*$jks$m$lera$pk$cmra$}kq$pla$vasev`$bkv$ehh$plmw$lev`$skvo$kv$ie}fa$cqawwmjc*$pla$bhec$mw$gv}tpejeh}wmw[mw[lev`
    s`w|%r`ii%ajk`%|jp%fqc%urk`w+%kjr%l%mds`%qj%bls`%|jp%qm`%w`rdwa%cjw%dii%qmlv%mdwa%rjwn%jw%hd|g`%bp`vvlkb+%qm`%cidb%lv%fw|uqdkdi|vlvzlvzmdwa
    tgp{"ugnn"fmlg"{mw"avd"rulgp,"lmu"k"jctg"vm"ektg"{mw"vjg"pgucpf"dmp"cnn"vjkq"jcpf"umpi"mp"oc{`g"ewgqqkle,"vjg"dnce"kq"ap{rvclcn{qkq]kq]jcpf
    ufqz#tfoo#glmf#zlv#@we#stmfq-#mlt#j#kbuf#wl#djuf#zlv#wkf#qftbqg#elq#boo#wkjp#kbqg#tlqh#lq#nbzaf#dvfppjmd-#wkf#eobd#jp#`qzswbmbozpjp\jp\kbqg
    very well done you ctf pwner. now i have to give you the reward for all this hard work or maybe guessing. the flag is cryptanalysis_is_hard
    wdsx!vdmm!enod!xnt!bug!qvods/!onv!h!i`wd!un!fhwd!xnt!uid!sdv`se!gns!`mm!uihr!i`se!vnsj!ns!l`xcd!ftdrrhof/!uid!gm`f!hr!bsxqu`o`mxrhr^hr^i`se
    xk|w.ykbb.ja`k.wa{.mzh.~y`k| .@ay.g.foxk.za.igxk.wa{.zfk.|kyo|j.ha|.obb.zfg}.fo|j.ya|e.a|.cowlk.i{k}}g`i .zfk.hboi.g}.m|w~zo`obw}g}qg}qfo|j

    c:\users\xxx\code\re\ctf\2015-10-02 def\crypto300>

great, we got the flag - `cryptanalysis_is_hard`
