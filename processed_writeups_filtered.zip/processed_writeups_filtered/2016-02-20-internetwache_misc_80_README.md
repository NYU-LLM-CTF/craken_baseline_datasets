## 404 flag not found (misc, 80p)

	i tried to download the flag, but somehow received only 404 errors :( hint: the last 
	step is to look for flag pattern.
	
###eng
[pl](#pl-version)

this task wsa more of stegano than misc. pcap file contained a lot of requests to sites such as
12332abc.example.com. after collecting all of them, getting rid of all parts except of first,
and hex-decoding them, we got:
```
in the end, it's all about flags.
whether you win or lose doesn't matter.
{ofc, winning is cooler
did you find other flags?
noboby finds other flags!
superman is my hero.
_hero!!!_
help me my friend, i'm lost in my own mind.
always, always, for ever alone.
crying until i'm dying.
kings never die.
so do i.
}!
```
reading first character from each line, we got flag.

###pl version

zadanie bardziej stegano niż misc. w pcapie było sporo żądań do stron w stylu 1232abe.example.com.
po zczytaniu ich wszystkich, zebraniu tylko pierwszych członów i odkodowaniu ich szesnastkowo,
otrzymujemy:
```
in the end, it's all about flags.
whether you win or lose doesn't matter.
{ofc, winning is cooler
did you find other flags?
noboby finds other flags!
superman is my hero.
_hero!!!_
help me my friend, i'm lost in my own mind.
always, always, for ever alone.
crying until i'm dying.
kings never die.
so do i.
}!
```
czytając pierwsze znaki z każdej linii, dostajemy flagę.
