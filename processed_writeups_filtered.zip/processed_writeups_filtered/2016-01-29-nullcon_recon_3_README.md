﻿##cook (recon, 300p)

	still hungry and unsutisfied, you are looking for more. 
	some more, unique un heard dishes. 
	then you can find one to make it your self. 
	its his dish. 
	he has his own website which is he describes as " a social home for each of our passions". 
	the link to his website is on his google+ page. whats the name of his site. 
	by the way he loves and hogs on "onion kheer". 
	have you heard of "onion kheer"?

###pl
[eng](#eng-version)

szukając `a social home for each of our passions` trafiamy na: 
https://plus.google.com/+bibhutibhusanpanigrahyneedrecipes/posts/w96mixp2fye 
które linkuje do strony `affimity.com` co też jest flagą w zadaniu.

###eng version

searching for `a social home for each of our passions` we find:
https://plus.google.com/+bibhutibhusanpanigrahyneedrecipes/posts/w96mixp2fye 
which is linking to `affimity.com` which is the flag.
