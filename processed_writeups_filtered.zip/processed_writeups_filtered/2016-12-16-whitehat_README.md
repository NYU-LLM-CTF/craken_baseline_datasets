# writeup whitehat ctf gp 2016

team: nazywam, c7f.m0d3, akrasuski1, cr019283, shalom

### table of contents

* [banh can / hello (web)](hello)
