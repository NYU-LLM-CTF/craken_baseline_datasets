##strange 150 (forensics, 150p)

### pl
[eng](#eng-version)

w tym zadaniu zostanie przetestowana nasza umiejętność otwierania dużych obrazków, dostajemy plik [strange.png](strange.png) ważący 16mb ale pojawia się jeden problem:


[image extracted text: downloads
bash
8ox17
michas-macbook-air:download;
michals
file strange.png
strange
png=
png
image
cata_
344987
344987
1-bit
colormap
non-interlaced
michas-macbook-air:downloac;
michals]


tak, zgadza się, obrazek ma `344987x344987` pikseli, nawet z 1 bitową mapą daje nam dużo za dużo wymaganej pamięci.

(tutaj spędziliśmy trochę czasu na próbowanie gotowych programów obsługujących duże pliki, lecz nie przyniosło to żadnego efektu więc tą część pomijamy :) )

należałoby zaglądnąć do środka tej binarki, żeby dowiedzieć się co tak na prawdę tam w środku siedzi. 

okazuje się, że znaczną większość pliku stanowią nullbyte-y. więc w sumie spróbujmy wyciąć linijki z samymi nullami, zmniejszmy rozmiar obrazka w exifie i zobaczmy co się stanie...


[image extracted text: ]


teraz tylko spróbujmy je posklejać i...


[image extracted text: 4ss{e8348ab pa854ca90218 58446403943]


flaga jest nasza!

### eng version

in this task we're given an 16mb [png image](strange.png), there's just one problem:


[image extracted text: downloads
bash
8ox17
michas-macbook-air:download;
michals
file strange.png
strange
png=
png
image
cata_
344987
344987
1-bit
colormap
non-interlaced
michas-macbook-air:downloac;
michals]


yes, that's right, it's `344987x344987` pixels big, even with 1 bit map, it's still too much to even consider trying viewing it.

(insert 2 hours of trying various programs with little success here)

why don't we look inside the image, maybe we could find out something interesting.

it turns out that a huge majority of the file is just null bytes. let's try to cut lines composed of only nulls and edit the image exif data to make it smaller


[image extracted text: ]


some weird binary lines, how about sticking them together?


[image extracted text: 4ss{e8348ab pa854ca90218 58446403943]


the flag is ours! (just be careful with 1's and f's)
