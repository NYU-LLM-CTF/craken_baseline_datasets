--------------------------------------
[python exploitation] secret accounts - 80 points
--------------------------------------

> through many months of sniffing, we discovered a server running a software which the club uses to manage information about secret bank accounts abroad. we even obtained its source code. we need to obtain access to the system in order to discover the real name of the owner of the account possessing the greater amount of money, in which bank it is, and the real amount. as you might expect, it seems that the club has hunkered down to assert only authorized people, which really know what they are doing, are able to operate this system and to interpret information provided by it. rumors exist that the mentor himself manages it, as amazing as it may seem (he is old but not deciduous!).

> you will need good “python-fu” to win this challenge!

> submit the flag in the following format: ctf-br{info1_info2_info3}.

> hint: who is fideleeto (cuba!) in real life? take this into account. :)

in this task we were given an obfuscated python script and a server running it. unfortunately i do no longer have the
original code, because i was deobfuscating it overwriting the file each time. it had a lot of octal numbers, some 
additions and multiplications just to hide the constants and so on.

we had to input password. connecting the dots, we guessed that `master` (variable name) corresponds to description text's
fideleeto, and birthyear is 1926, as per wikipedia. we added some z's because the source code asked us for it.

after a couple of seconds, we were logged in. we were asked for option 1-4, but in reality our input was subtracted,
multiplied and generally messed with, so we simply brute forced the needed numbers. when we chose correct number, we 
were presented with a menu. the most interesting part of it was that our text was inputted via `input()`. since
python's `input()` is equivalent to `eval(raw_input())`, we had arbitrary code execution. we used it to write the file
with flag to stdout. full exploit code is available in `doit.py`.
