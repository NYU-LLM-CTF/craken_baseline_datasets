# tic tac toe (web/misc)

a bit of a wtf challenge.
you can play tic tac toe against a computer player, but since he starts and plays well, you can't win.
to get the flag you need to win 100 times in a row.

there was a ton of obfuscated js, and fortunately we were too lazy to analyse it, because it turned out to be useless.
the point of the task was to notice that once you perform a selected sequence of moves the game "breaks" and allows you to make a move for the computer player.

once we noticed this we simply automated the task:

```javascript
function sleep(ms) {
  return new promise(resolve => settimeout(resolve, ms));
}

window.alert = function() {
    // do nothing.
};

    

for(var i=0; i<100; i++){
    document.getelementbyid("button_11").click()
    await sleep(500);
    document.getelementbyid("button_10").click()
    await sleep(500);
    document.getelementbyid("button_02").click()
    await sleep(500);
    document.getelementbyid("button_01").click()
    await sleep(500);
    document.getelementbyid("button_20").click()
    await sleep(1000);
}
````

and run this via chrome console, and after a while we got `flag{s9ck3t_i0_set_by_th3_empire_niahahahahahaha_xd}`
