gibson 9000 calcumatron.

caving under the pressure of environmentalists, the gibson inc. cpu
manufacturing company is working on a new line of processors in order to
decrease power consumption and cooling requirements, while still increasing
the amount of jigawatts.

the current gibson 9000 cpu design uses only uses 6 instructions, thereby
obviously reducing operating costs.  the gibson 9000 incorporates bleeding-edge
automatic thermal throttling, but also advances the state-of-the-art through
its faster and more efficient "meditation" mode. 

our cpu has read-only program memory, 128 bytes of read-write data memory, an
instruction pointer and a data pointer.

the gibson 9000 instructions are 2 octets wide and include one opcode and one
parameter.  for instance, the instruction "+5" (0x2b, 0x35) executes opcode
0x2b with parameter 0x35. aside for 0x2a and 0x2b, the parameter for all other
instructions is ignored.

the opcodes are as follows:

0x2a	'*'		add parameter to the value pointed out by the data pointer.
0x2b	'+'		add parameter to the data pointer
0x5f	'_'		conditional jump when the value pointed at by the data pointer is 0x00, otherwise skip
0x58	'x'		output the data region
0x4d	'm'		meditate to cool down the cpu
0x44	'd'		toggle debugging mode

the possible parameters are:

0x30	'0'		value 0
0x31	'1'		value 1
0x32	'2'		value 2
0x33	'3'		value 3
0x34	'4'		value 4
0x35	'5'		value 5
0x36	'6'		value 6
0x37	'7'		value 7
0x38	'8'		value negative 0
0x39	'9'		value negative 1
0x41	'a'		value negative 2
0x42	'b'		value negative 3
0x43	'c'		value negative 4
0x44	'd'		value negative 5
0x45	'e'		value negative 6
0x46	'f'		value negative 7


for faster adoption, gibson inc. provides an emulator of the new cpu
architecture so that all your banking software can already be converted to more
efficient opcodez.

disclaimer: our emulator was written by an intern who was more occupied with
riding his skateboard than producing quality work. please don't send viruses.
