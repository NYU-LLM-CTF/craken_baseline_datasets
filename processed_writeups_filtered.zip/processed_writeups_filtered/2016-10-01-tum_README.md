# writeup tum ctf 2016

team: psrok1, c7f.m0d3, cr019283, ppr, nazywam, msm, akrasuski1, shalom


[image extracted text: 2
1
l
{
1
{
l
]
9
2
position
team
9
w
1
1
6
l
h
3
8
huew
e
1
w4t
iv
l
2
]
score
lchbc
6429
spatenbrau
6129
tasteless
4576
dragon sector
3898
p4
3518
eat sleep pwn repeat
3506
odaysober
3191
217
2732
dcua
2664
balsn
2523
10
tokyowesterns
2430
[
0]



### table of contents

* [haggis (crypto 100 +3)](haggis_crypto_100)
* [hiecss (crypto 150 +22)](hiecss_crypto_150)
* [the joy of painting (stegano 50 +2)](joy_stegano_50)
* [c0py pr073c710n (pwn 200 +11)](c0py_pr073c710n_pwn_200)
