# today’s moon phase (pwn 150)

## eng
[pl](#pl-version)

in the task we get arm x86 [binary](pwn150) to work with.
we can run the binary via retdec and get [source](pwn150.c).

in the code we have already a nice function to read the flag.
we also have to stack canary protection.
this means we expect some stack buffer overflow to overwrite return pointer and jump to function which prints the flag.

this points to all places where we can provide some inputs to the application.
we have `getline` which reallocates memory automatically, so not here.
we have `scanf` with `%c` so again, surely not here.
we have another `scanf` with `%5hu%c` and the buffer is large enough (although retdec decompilation doesn't show this nicely).
finally we have something interesting:

```c
snprintf((char *)&str2, 32, "%%%zus", (int64_t)(v6 % 0x10000));
scanf((char *)&str2);
```

again retdec doesn't do justice here, but what happens is that we create a format string based on integer we read before and then we read based on this format.
we read the input into buffer initially set as:

```c
memset((char *)&v1, 0, 512);
```

so it has 512 bytes, and this is all inside a condition:

```c
if ((int16_t)v6 < 513)
```

it would seem we can't pass anything more than 512, so we can't create a format string which would allow the buffer overflow.
let's look one more time on the format for the size: `%5hu`, so 5 digits and we read this as `unsigned short`.
5 digits seems a lot considering the max number we expect is `512`...

now let's look at the condition one more time: `(int16_t)v6 < 513`. but surely `int16_t` is `signed short`!
so we found signed-unsigned issue here.
we could pass a value much larger than 512, as long as after casting to signed value it's lower than 513, which is simple enough because anything large will become negative.

so the exploitation chain is as follows:

1. send random name.
2. send `y` (we want to send feedback)
3. send large number to create string format allowing overflow
4. send payload overflowing the buffer and overwrite return pointer (532 bytes + address) to function printing the flag (0x104d8)

```
python -c "print('a\n'+'y\n'+'65536\n'+('a'*532)+chr(0xd8)+chr(0x04)+chr(0x01)+'\n')" | nc6 165.227.98.55 2222
```

and we get `h4ck1t{astronomy_is_fun}`

## pl version

w zadaniu dostajemy [binary](pwn150) arm x86.
możemy zdekompilować go za pomocą retdec i dostaniemy [source](pwn150.c).

w kodzie widać od razu ładną funkcje do wypisywania flagi.
nie ma też stack canary.
to oznacza, że spodziewamy się stack buffer overflow za pomocą którego nadpiszemy adres powrotu z funkcji i skoczymy od funkcji wypisującej flagę.

to sugeruje analizę miejsc, gdzie wprowadzamy do aplikacji dane.

na początku mamy `getline`, ale on realokuje pamięć w miarę potrzeb, więc nie tutaj.
następnie mamy `scanf` ale z `%c` więc też nic z tego.
później jest kolejny `scanf` z `%5hu%c` ale bufor jest wystarczająco duży (chociaż w retdecowej dekompilacji słabo to widać).
wreszcie mamy coś ciekawego:

```c
snprintf((char *)&str2, 32, "%%%zus", (int64_t)(v6 % 0x10000));
scanf((char *)&str2);
```

znów retdec poległ na generacji sensownego kodu, ale zamysł jest taki, ze generujemy tu string format zależny od wartości zmiennej wczytanej wcześniej i za pomocą tego formatu pobieramy dane.
dane idą do bufora który był przygotowany przez:

```c
memset((char *)&v1, 0, 512);
```

więc ma 512 bajtów, a tworzenie formatu i pobieranie danych jest w warunku:

```c
if ((int16_t)v6 < 513)
```

wydawałoby się, że nie możemy podać niczego ponad 512, więc nie wygenerujemy string format, który pozwolilby na overflow.
popatrzmy jednak jeszcze raz na format według którego pobierany jest rozmiar: `%5hu`, więc 5 cyfr i czytamy `unsigned short`.
5 cyfr to dużo skoro oczekujemy nie wiecej niż `512`...

popatrzmy teraz na warunek jeszcze raz: `(int16_t)v6 < 513`. a przecież `int16_t` to `signed short`!
mamy więc błąd signed-unsigned.
można więc przemycić wartość większą niż 512, o ile po zrzutowaniu do typu signed jej wartość będzie mniejsza niż 513, co jest trywialne, bo każda wystarczająco duża liczba będzie ujemna.

więc schemat ataku to:

1. wysyłamy losowe imie.
2. wysyłamy `y` (chcemy wysłać feedback)
3. wysyłamy dużą liczbę która pozwoli nam utworzyć string format umożliwiający overflow
4. wysyłamy dane przepełniające bufor i nadpisujący adres powrotu z funkcji (532 bajty + adres) na adres funkcji wypisującej flagę (0x104d8).

```
python -c "print('a\n'+'y\n'+'65536\n'+('a'*532)+chr(0xd8)+chr(0x04)+chr(0x01)+'\n')" | nc6 165.227.98.55 2222
```

i dostajemy: `h4ck1t{astronomy_is_fun}`
