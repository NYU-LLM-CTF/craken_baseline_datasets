## blocks (forensics, 400p)

    i recovered as much data as i could. can you recover the flag?

    download data3

###eng
[pl](#pl-version)

let's look at hexdump of the file. it contains some sql-like text:
```
00000220  00 00 00 81 14 04 07 17  15 15 01 82 0b 74 61 62  |.............tab|
00000230  6c 65 64 61 74 61 64 61  74 61 05 43 52 45 41 54  |ledatadata.creat|
00000240  45 20 54 41 42 4c 45 20  22 64 61 74 61 22 20 28  |e table "data" (|
00000250  0a 09 60 49 44 60 09 49  4e 54 45 47 45 52 20 4e  |..`id`.integer n|
00000260  4f 54 20 4e 55 4c 4c 20  50 52 49 4d 41 52 59 20  |ot null primary |
```
it looks like database dump, but sqlite3 doesn't want to work with it. after investigation, it seems that file magic is
missing. patching the file allows us to work with the database. let's look at contents:
```
sqlite version 3.8.11.1 2015-07-29 20:00:57
enter ".help" for usage hints.
connected to a transient in-memory database.
use ".open filename" to reopen on a persistent database.
sqlite> .open dat
sqlite> .tables
category  data    
sqlite> .schema category
create table `category` (
	`id`	integer not null primary key autoincrement unique,
	`cat`	text not null
);
sqlite> select * from category;
1|chrm
2|idat
3|iccp
4|ihdr
5|text
6|time
7|plte
8|trns
sqlite> .schema data
create table "data" (
	`id`	integer not null primary key autoincrement unique,
	`data`	blob not null,
	`cat`	integer not null
);
sqlite> select id, cat from data;
1|2
2|2
3|2
4|2
5|2
6|7
7|4
8|2
9|2
10|2
11|2
12|8
13|2
14|2
```
it seems like a png file was saved in the database. unfortunately the chunks are in parts - the most important, idat
chunk is in 11 parts. concatenating them in the most obvious order doesn't work, so we had to bruteforce it - after
all it's only `11!` or `39,916,800` combinations. using `getblobs.sh`, `doit.py` and `to_image.py` in this order, we
were able to get image, containing flag.

###pl version

obejrzyjmy hexdump pliku. zawiera tekst podobny do sqla:
```
00000220  00 00 00 81 14 04 07 17  15 15 01 82 0b 74 61 62  |.............tab|
00000230  6c 65 64 61 74 61 64 61  74 61 05 43 52 45 41 54  |ledatadata.creat|
00000240  45 20 54 41 42 4c 45 20  22 64 61 74 61 22 20 28  |e table "data" (|
00000250  0a 09 60 49 44 60 09 49  4e 54 45 47 45 52 20 4e  |..`id`.integer n|
00000260  4f 54 20 4e 55 4c 4c 20  50 52 49 4d 41 52 59 20  |ot null primary |
```
wygląda to na zserializowaną bazę danych, ale sqlite3 nie chce z nią pracować. okazuje się, że brakuje magii w pliku.
po spatchowaniu danych, możemy pracować. spójrzmy na zawartość:
```
sqlite version 3.8.11.1 2015-07-29 20:00:57
enter ".help" for usage hints.
connected to a transient in-memory database.
use ".open filename" to reopen on a persistent database.
sqlite> .open dat
sqlite> .tables
category  data    
sqlite> .schema category
create table `category` (
	`id`	integer not null primary key autoincrement unique,
	`cat`	text not null
);
sqlite> select * from category;
1|chrm
2|idat
3|iccp
4|ihdr
5|text
6|time
7|plte
8|trns
sqlite> .schema data
create table "data" (
	`id`	integer not null primary key autoincrement unique,
	`data`	blob not null,
	`cat`	integer not null
);
sqlite> select id, cat from data;
1|2
2|2
3|2
4|2
5|2
6|7
7|4
8|2
9|2
10|2
11|2
12|8
13|2
14|2
```
wygląda na to, że ukryto w bazie plik png. niestety chunki są w kawałkach - w szczególności, chunk idat jest w 11 
częściach. połączenie ich w oczywisty sposób nie działa, więc kolejność musieliśmy wybrutować - to ostatecznie tylko
`11!`, czyli `39,916,800` kombinacji. odpalając `getblobs.sh`, `doit.py` oraz `to_image.py` w tej kolejności, po
parunastu minutach brutowania dostaliśmy obrazek z flagą.
