# writeup defcamp ctf finals 2015


[image extracted text: ccsir
defcamp6
capture
flag
competition]


# spis treści:
* [web 200](web200)
* [crypto 100 (morse c'est)](crypto100)
* [crypto 300](crypto300)
* [crypto 400](crypto400)
* [reverse 200 (time is not your friend)](re_200_time_is_not_your_friend)
* [reverse 300 (try harder)](re_300_tryharder)

### eng version
# table of contents:
* [web 200](web200#eng-version)
* [crypto 100 (morse c'est)](crypto100#eng-version)
* [crypto 300](crypto300#eng-version)
* [crypto 400](crypto400#eng-version)
* [reverse 200 (time is not your friend)](re_200_time_is_not_your_friend#eng-version)
* [reverse 300 (try harder)](re_300_tryharder#eng-version)
