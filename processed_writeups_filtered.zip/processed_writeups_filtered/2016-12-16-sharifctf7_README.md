# writeup sharif ctf 7 2016

team: nazywam, c7f.m0d3, akrasuski1, msm, psrok1, seikendev, shalom

### table of contents

* [strange pdf (forensics 150)](for_150_strange_pdf)
* [poor guy (web 150)](web_150_poor_guy)
* [irish home (web 200)](web_200_irish_home)
* [jare captcha (web 200)](web_200_jarecaptcha)
* [lost voice (misc 100)](misc_100_voice)
* [cbpm (web 300)](web_300_cbpm)
* [lsb oracle (crypto 150)](crypto_150_lsb)
* [lobotomized lsb oracle (crypto 400)](crypto_400_lob_lsb)
