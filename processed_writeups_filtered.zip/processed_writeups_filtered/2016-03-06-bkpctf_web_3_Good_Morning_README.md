## good morning (web, 3 points, 110 solves)
	http://52.86.232.163:32800/  https://s3.amazonaws.com/bostonkeyparty/2016/bffb53340f566aef7c4169d6b74bbe01be56ad18.tgz

in this task we were given a source of web survey. it used mysql in backend to store our answers. the script
was not using prepared statements, so we quickly came to conclusion that there has to be a sql injection possible.
unfortunately, our input was escaped before passing to mysql library. however, they use their home-made escaping function
instead of properly tested official ones. 

because the site was in japanese, they used shift-jis character encoding. one of the oddities conencted to this encoding
is that it changes position of backslash - 0x5c, which is ascii backslash, in sjis means yen. the websocket and python script
itself (including escaping function) use unicode, so we can send `[yen]" stuff`, which will be converted by escaping function
to `[yen]\" stuff`, and then converted to sjis `0x5c\" stuff`. since 0x5c is equivalent to backslash, that means our input will
be interpreted as one escaped backslash, followed by unescaped quote, enabling us to put arbitrary sql code there.

proof:
```
>>> print mysql_escape(json.loads('{"type":"get_answer","question":"q","answer":"\u00a5\\\""}')["answer"]).encode("sjis")
\\"
```
exploiting via chrome developer console:
```
socket.onmessage=function(e){console.log(e.data);};
socket.send('{"type":"get_answer","question":"q","answer":"\u00a5\\\" or 1=1 -- "}')

vm416:2 {"type": "got_answer", "row": [1, "flag", "bkpctf{tryyourbestontheotherstoo}"]}
```
