# integrity (crypto)

##eng
[pl](#pl-version)

in the task we get a service:

```python
#!/usr/bin/python -u

from crypto.cipher import aes
from hashlib import md5
from crypto import random
from signal import alarm

bs = 16
pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs) 
unpad = lambda s : s[0:-ord(s[-1])]


class scheme:
    def __init__(self,key):
        self.key = key

    def encrypt(self,raw):
        raw = pad(raw)
        raw = md5(raw).digest() + raw

        iv = random.new().read(bs)
        cipher = aes.new(self.key,aes.mode_cbc,iv)

        return ( iv + cipher.encrypt(raw) ).encode("hex")

    def decrypt(self,enc):
        enc = enc.decode("hex")

        iv = enc[:bs]
        enc = enc[bs:]

        cipher = aes.new(self.key,aes.mode_cbc,iv)
        blob = cipher.decrypt(enc)

        checksum = blob[:bs]
        data = blob[bs:]

        if md5(data).digest() == checksum:
            return unpad(data)
        else:
            return

key = random.new().read(bs)
scheme = scheme(key)

flag = open("flag",'r').readline()
alarm(30)

print "welcome to 0ctf encryption service!"
while true:
    print "please [r]egister or [l]ogin"
    cmd = raw_input()

    if not cmd:
        break

    if cmd[0]=='r' :
        name = raw_input().strip()

        if(len(name) > 32):
            print "username too long!"
            break
        if pad(name) == pad("admin"):
            print "you cannot use this name!"
            break
        else:
            print "here is your secret:"
            print scheme.encrypt(name)


    elif cmd[0]=='l':
        data = raw_input().strip()
        name = scheme.decrypt(data)

        if name == "admin":
            print "welcome admin!"
            print flag
        else:
            print "welcome %s!" % name
    else:
        print "unknown cmd!"
        break
```

as can be seen we can either login or register.
loggin in as admin will give us the flag, so this is the ultimate goal.
we can see that we can't register as `admin` because this is explicitly checked.

once we register we get as a result login token in the form `iv | aes_cbc(md5(login) | login)`.

since we can modify freely the iv, we can force the decoding of md5 checksum to any value we want.
this is because in cbc block crypto the first decrypted block is `iv xor aes_decrypt(ciphertext[0])` and we know the value of `aes_decrypt(ciphertext[0])` because it is md5 of the login we provided.
so in order to force k-th decoded byte to value `x` we simply need to modify k-th byte of iv to `iv[k] ^ md5(login)[k] ^ x`.

as a result we can easily fool the md5 checksum and we can provide iv such that the decoded md5 checksum will be a checksum of `pad("admin")`.

now we need somehow to obtain ciphertext which will decode to `pad("admin")`.
this is again quite simple, since we're dealing with block crypto and the login token does not contain any information about the length of the provided input (unlike in real hmac).
it means that we can remove some ciphertext blocks from the end and the decryption will still work just fine, assuming the padding is correct.

so if we decide to encrypt login in a form of `pad("admin")+16_random_bytes`, the server will send us ciphertext of `pad(pad("admin")+16_random_bytes)`.
and of course this translates to 3 ciphertext blocks in a form of `pad("admin")+16_random_bytes+pkcs_padding`.
but as said before, we can simply remove the last 2 blocks of ask server to use only the first one, which decodes to `pad("admin")`!

```python
import hashlib
from crypto_commons.netcat.netcat_commons import nc, send, receive_until_match

bs = 16
pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs)


def generate_payload(ct):
    stripped_ct = ct[:-64]  # skip last 2 blocks, the pkcs padding and the dummy block
    target_md5 = hashlib.md5(pad("admin")).digest()  # md5 we want to get from decryption
    source_md5 = hashlib.md5(pad(pad("admin") + ("a" * 16))).digest()  # md5 the server calculated
    original_iv = stripped_ct[:32].decode("hex")
    new_iv = []
    for i in range(len(original_iv)):
        new_iv.append(chr(ord(original_iv[i]) ^ ord(source_md5[i]) ^ ord(target_md5[i])))
    iv = "".join(new_iv).encode("hex")
    payload = iv + stripped_ct[32:]
    return payload


def main():
    s = nc("202.120.7.217", 8221)
    print(receive_until_match(s, ".*ogin"))
    send(s, "r")
    send(s, pad("admin") + ("a" * 16))
    print(receive_until_match(s, ".*secret:"))
    ct = s.recv(9999).split("\n")[1]
    send(s, "l")
    send(s, generate_payload(ct))
    print(s.recv(9999))
    print(s.recv(9999))
    print(s.recv(9999))


main()
```

and this gives us `flag{easy_br0ken_scheme_cann0t_keep_y0ur_integrity}`

##pl version

w zadaniu dostajemy dostęp do serwisu:

```python
#!/usr/bin/python -u

from crypto.cipher import aes
from hashlib import md5
from crypto import random
from signal import alarm

bs = 16
pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs) 
unpad = lambda s : s[0:-ord(s[-1])]


class scheme:
    def __init__(self,key):
        self.key = key

    def encrypt(self,raw):
        raw = pad(raw)
        raw = md5(raw).digest() + raw

        iv = random.new().read(bs)
        cipher = aes.new(self.key,aes.mode_cbc,iv)

        return ( iv + cipher.encrypt(raw) ).encode("hex")

    def decrypt(self,enc):
        enc = enc.decode("hex")

        iv = enc[:bs]
        enc = enc[bs:]

        cipher = aes.new(self.key,aes.mode_cbc,iv)
        blob = cipher.decrypt(enc)

        checksum = blob[:bs]
        data = blob[bs:]

        if md5(data).digest() == checksum:
            return unpad(data)
        else:
            return

key = random.new().read(bs)
scheme = scheme(key)

flag = open("flag",'r').readline()
alarm(30)

print "welcome to 0ctf encryption service!"
while true:
    print "please [r]egister or [l]ogin"
    cmd = raw_input()

    if not cmd:
        break

    if cmd[0]=='r' :
        name = raw_input().strip()

        if(len(name) > 32):
            print "username too long!"
            break
        if pad(name) == pad("admin"):
            print "you cannot use this name!"
            break
        else:
            print "here is your secret:"
            print scheme.encrypt(name)


    elif cmd[0]=='l':
        data = raw_input().strip()
        name = scheme.decrypt(data)

        if name == "admin":
            print "welcome admin!"
            print flag
        else:
            print "welcome %s!" % name
    else:
        print "unknown cmd!"
        break
```

jak łatwo zauważyć możemy się zalogować lub zarejetrować.
logowanie jako admin pozwoli uzyskać flagę i to jest naszym finalnym celem.
możemy zauważyć, że nie możemy zarejestrować się jako `admin` ponieważ jest to wyraźnie sprawdzane.

po rejestracji dostajemy token logowania w postaci `iv | aes_cbc(md5(login) | login)`.

ponieważ możemy dowolnie zmieniać iv, możemy wymusić dowolne dekodowanie wartości md5.
wynika to bezpośrednio z tego jak działa szyfr blokowy w trybie cbc - pierwszy dekodowany blok to `iv xor aes_decrypt(ciphertext[0])` a znamy wartość `aes_decrypt(ciphertext[0])`bo to md5 wyliczone z wprowadzonych przez nas danych.
więc żeby wymusić dekodowanie k-tego bajtu do wartości `x` musimy jedynie zmienić k-ty bajt iv na `iv[k] ^ md5(login)[k] ^ x`

w efekcie możemy w prosty sposób oszukać checksume md5 i podać takie iv, że odkodowane md5 będzie zgodne z checksumą dla `pad("admin")`.

teraz potrzebujemy uzyskać ciphertext który zdekoduje się do `pad("admin")`.
to znów jest dość proste, ponieważ mamy do czynienia z szyfrem blokowym a token logowania nie zawiera nigdzie informacji o długości wprowadzonych danych (w przeciwieństwie do prawdziwego hmac).
to oznacza, że możemy usunąć kilka bloków ciphertextu z końca a deszyfrowanie nadal przebiegnie pomyślnie, o ile padding się zgadza.

jeśli więc zdecydujemy się zaszyfrować login w postaci `pad("admin")+16_random_bytes` serwer odeśle nam ciphertext dla `pad(pad("admin")+16_random_bytes)`
a to oczywiście oznacza że dostaniemy 3 bloki ciphertextu w postaci `pad("admin")+16_random_bytes+pkcs_padding`.
jak wspomnieliśmy wcześniej, możemy teraz usunąć 2 ostatnie bloki i poprosić serwer o deszyfrowanie tylko pierwszego, który dekoduje się do `pad("admin")`!

```python
import hashlib
from crypto_commons.netcat.netcat_commons import nc, send, receive_until_match

bs = 16
pad = lambda s: s + (bs - len(s) % bs) * chr(bs - len(s) % bs)


def generate_payload(ct):
    stripped_ct = ct[:-64]  # skip last 2 blocks, the pkcs padding and the dummy block
    target_md5 = hashlib.md5(pad("admin")).digest()  # md5 we want to get from decryption
    source_md5 = hashlib.md5(pad(pad("admin") + ("a" * 16))).digest()  # md5 the server calculated
    original_iv = stripped_ct[:32].decode("hex")
    new_iv = []
    for i in range(len(original_iv)):
        new_iv.append(chr(ord(original_iv[i]) ^ ord(source_md5[i]) ^ ord(target_md5[i])))
    iv = "".join(new_iv).encode("hex")
    payload = iv + stripped_ct[32:]
    return payload


def main():
    s = nc("202.120.7.217", 8221)
    print(receive_until_match(s, ".*ogin"))
    send(s, "r")
    send(s, pad("admin") + ("a" * 16))
    print(receive_until_match(s, ".*secret:"))
    ct = s.recv(9999).split("\n")[1]
    send(s, "l")
    send(s, generate_payload(ct))
    print(s.recv(9999))
    print(s.recv(9999))
    print(s.recv(9999))


main()
```

a to daje nam `flag{easy_br0ken_scheme_cann0t_keep_y0ur_integrity}`
