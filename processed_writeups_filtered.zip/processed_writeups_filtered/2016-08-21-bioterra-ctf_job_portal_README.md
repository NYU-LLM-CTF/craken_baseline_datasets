# job portal (200, web/exploit)

> they pretend to check your letter of application. 
> i want to proof that they are doing nothing to help you. get me access to the filesystem!

in this task we were given access to service allowing to upload tar files. when uploaded, we could check the
tarball contents (file names only) on separate page. the url extension was `.cgi`, which hinted at possible
shell injection. indeed, when we submitted tar with one file called `name; cat /etc/passwd`, we could read directory 
contents listed on the website. getting the flag from there was just a matter of `cat`ting it.
