## des ofb (crypto, 2 points, 189 solves)
	decrypt the message, find the flag, and then marvel at how broken everything is. 

we were given encryption code and a ciphertext. it used des cipher in ofb mode. ofb means
that iv was encrypted using key, its result then encrypted using the key again, then again
and so on. ciphertext is obtained through xoring those encrypted blocks with plaintext.
longer description is available on [wikipedia](https://en.wikipedia.org/wiki/block_cipher_mode_of_operation#output_feedback_.28ofb.29).

code was very simple and des cipher is not easily breakable, so we looked into hex dump of
ciphertext:
```
00000000  70 2b 7b ef 93 27 53 d3  43 13 5c 5b 41 16 43 57  |p+{..'s.c.\[a.cw|
00000010  04 26 3e a1 d6 7f 1b dd  45 13 5b 47 15 42 5f 5d  |.&>.....e.[g.b_]|
00000020  04 35 2e e8 85 7f 1a d3  5f 09 38 63 5d 53 43 50  |.5......_.8c]scp|
00000030  41 36 7b aa 82 62 00 9c  7f 5c 50 58 50 44 17 51  |a6{..b...\pxpd.q|
00000040  4a 64 2f e5 93 2b 1e d5  5f 57 12 40 5a 16 44 4d  |jd/..+.._w.@z.dm|
00000050  42 22 3e ff fc 5f 1b d9  11 60 5e 5d 5b 51 44 18  |b">.._...`^][qd.|
00000060  45 2a 3f ad b7 79 01 d3  46 40 12 5b 53 16 58 4d  |e*?..y..f@.[s.xm|
00000070  50 36 3a ea 93 64 06 cf  11 75 5d 46 41 43 59 5d  |p6:..d...u]facy]|
00000080  08 4e 14 ff d6 7f 1c 9c  45 52 59 51 15 77 45 55  |.n......eryq.weu|
00000090  57 64 3a ea 97 62 1d cf  45 13 53 14 66 53 56 18  |wd:..b..e.s.fsv.|
000000a0  4b 22 7b f9 84 64 06 de  5d 56 41 18 3f 77 59 5c  |k"{..d..]va.?wy\|
000000b0  04 26 22 ad 99 7b 03 d3  42 5a 5c 53 15 53 59 5c  |.&"..{..bz\s.sy\|
```
this is just the beginning, but there are obvious patterns - for example every character
in 4th and 5th columns were unprintable. this should not happen if we used secure cipher,
so there must have been some problem. as des used 8-byte blocks and ciphertext had
pattern with period of 16, that means des used a particularly bad key, which made the keystream
periodic with period of 2, i.e. `des(des(iv, key), key)==iv`. 

what that means, is that we can treat the ciphertext as xored with 16-byte key. using simple
heuristic (most frequent character in each column was likely space), we managed to decrypt
most of the plaintext. we then fixed the rest of the key manually - full code available in
`decrypt.py`. the plaintext was hamlet's beginning, with flag appended.
