﻿##dictator (recon, 300p)

	your simple good deeds can save you but your greed can kill you. 
	this has happened before. 
	this greedy person lived a miserable life just for the greed of gold and lust. 
	you must know him, once you know him, you must reach his capital and next clues will be given by his famous ex-body guard. 
	this file consists of few paragraphs. each paragraph singles out one alphabet. 
	scrambling those aplphabets will help you to know the country of this ruler. who was this ruler?

###pl
[eng](#eng-version)

dostajemy informacje że flagą jest dyktator, oraz że coś na jego temat może powiedzieć ex-ochroniarz. 
dodatkowo dostajemy 5 tekstów (mają literówki i są pomieszane) i każdy z nich ma wskazać słowo.
z połączenia tych słów można uzyskać nazwę kraju szukanego dyktatora.

wszystkie teksty [tutaj](thelastruler.txt)

pierwszy tekst pochodzi z http://wadiya.wikia.com/wiki/wadiya

drugi z https://en.wikipedia.org/wiki/lion

trzeci z https://en.wikipedia.org/wiki/innings

pozostałych nie mogliśmy znaleźć, ale nie były konieczne.

mamy więc 3 słowa: `wadiya, lion, innings`. 
następnym krokiem było poszukanie informacji na temat dyktatorów oraz ex-ochroniarzy i dopasowanie kraju danego dyktatora do posiadanych słów. 
trafiliśmy wreszcie na `muammar gaddafi` oraz `libyia`. 
kraj pasował do posiadanych słów, a dyktator okazał się flagą.

###eng version

we get information that the flag is the name of a dictator and that something can be learned from his ex-bodyguard.
additionally we get 5 texts (with misspells and some changes) and each one of the is pointing to a word.
by combining those words we are supposed to get name of the country of the dictator.

all texts [here](thelastruler.txt)

first one comes from http://wadiya.wikia.com/wiki/wadiya

second from https://en.wikipedia.org/wiki/lion

third from https://en.wikipedia.org/wiki/innings

we could not find the last two, but they were not necessary.

so we have 3 words: `wadiya, lion, innings`.
next step was to look for informations regarding dictators and ex-bodyguards and matching the country with words we have.
we finally stumbled upon `muammar gaddafi` and `libyia`. the country was matching our words and the dictator turned out to be the flag.
