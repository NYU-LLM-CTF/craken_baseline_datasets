# writeup hitcon ctf quals 2015

uczestniczyliśmy (msm, rev, shalom, other019, nazywam i pp) w hitcon ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:
?

opisy zadań po kolei.

# spis treści:
* [puzzleng (forensic 250)](forensic_250_puzzleng)
* [simple (crypto 100)](crypto_100_simple)
* [rsabin (crypto 314)](crypto_314_rsabin)
* [babyfirst (web 100)](web_100_babyfirst)
* [hardtosay (misc 200)](misc_200_hardtosay)

# table of contents:
* [puzzleng (forensic 250)](forensic_250_puzzleng#eng-version)
* [simple (crypto 100)](crypto_100_simple#eng-version)
* [rsabin (crypto 314)](crypto_314_rsabin#eng-version)
* [babyfirst (web 100)](web_100_babyfirst#eng-version)
* [hardtosay (misc 200)](misc_200_hardtosay#eng-version)



# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
