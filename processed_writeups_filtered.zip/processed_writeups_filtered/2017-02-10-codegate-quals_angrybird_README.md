# angrybird (re 125)

###eng

we are faced with x64 elf binary.

binary is obviously corrupted - it exits right at the beginning. unfortunatelly i don't have non-patched binary anymore,
but i had to nop a lot of code at the beginning:

```asm
55                push    rbp
48 89 e5          mov     rbp, rsp
48 83 c4 80       add     rsp, 0ffffffffffffff80h
64 48 8b 04 25 28+mov     rax, fs:28h
48 89 45 f8       mov     [rbp+var_8], rax
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
90                nop
48 c7 45 90 18 60+mov     [rbp+var_70], offset strncmpp
48 c7 45 98 20 60+mov     [rbp+var_68], offset putsp
48 c7 45 a0 28 60+mov     [rbp+var_60], offset stack_chk_fail
48 c7 45 a8 38 60+mov     [rbp+var_58], offset startmain
b8 00 00 00 00    mov     eax, 0
e8 4b ff ff ff    call    should_return_21
89 45 8c          mov     [rbp+n], eax
b8 00 00 00 00    mov     eax, 0
90                nop
90                nop
90                nop
90                nop
90                nop
b8 00 00 00 00    mov     eax, 0
```

and patch function `should return 21` (because according to debug string, it should return 21):

```asm
                  should_return_21 proc near
55                push    rbp
48 89 e5          mov     rbp, rsp
bf 64 50 40 00    mov     edi, offset s   ; "you should return 21 not 1 :("
e8 8c fe ff ff    call    _puts
8b 05 56 59 20 00 mov     eax, cs:const_1
5d                pop     rbp
c3                retn
                  should_return_21 endp
```

now binary is working correctly: it reads flag, and does a lot of checks, one char at a time:


[image extracted text: nop
mov
eax_
call
sub_40072a
58  z0+mov
rdx ,
cs:stdin
stream
io 
ecx_
[rbptn_
lea
rax_
[rbp+s]
mov
esi
mov
rdi
rax
call
_fgets
b6 55
movzx
edx
rbp+s]
movzx
eax
[rbp+var_
4f ]
xor
eax_
edx
io 
[rbptvar_30] ,
movzx
eax,
[rbp+var_30]
cmp
ofh
short
loc
400803
mov
edi
offset amelong
"melong'
call
_puts
loc
400803 :
io v
edi
status
movzx
edx
[rbp+s]
call
exit
movzx
eax
[rbp+var
4f]
and
eax
edx
mov
[rbp+var_30] ,
movzx
eax
[rbptvar
30]
cmp
s0h
jle
short loc_40082c
mov
edi
offset amelong
long
call
puts
loc_
40082c :
mov
edi
status
mov
[rbp+var_30]
fd ff
call
exit
movzx
eax,
[rbp+var_
cmp
al,
jle
short
loc_
40084
mov
edi
offset amelong
melong
call
_puts
mov
edi
status
e8  94
call
exit]


this looks easy enough, right?
well, let's zoom out:


[image extracted text: ]


wait, what? let's zoom out even more:


[image extracted text: ]


`o_o`.

ok, we might need to do this more intelligently.

turns out that if you think hard enough, everything is trivial. or maybe just angr creators are genius, i don't know.
anyway, i created this very basic angr script (my second angr experience ever):

```python
import angr

main = 0x4007da
find = 0x404fab
find = 0x404fc1
avoid = [0x400590]

p = angr.project('./angrybird2')
init = p.factory.blank_state(addr=main)
pg = p.factory.path_group(init, threads=8)
ex = pg.explore(find=find, avoid=avoid)

final = ex.found[0].state
flag = final.posix.dumps(0)

print("flag: {0}".format(final.posix.dumps(1)))
```

and, just like that, it worked (almost) first time and shown the flag:

```
╭─msm@mercury /home/msm/codegate2017  ‹system›
╰─$ python angrdo.py
warning | 2017-02-13 19:40:46,155 | simuvex.plugins.symbolic_memory | concretizing symbolic length. much sad; think about implementing.
flag: you typed : im_so_cute&pretty_:) @  @@
```
