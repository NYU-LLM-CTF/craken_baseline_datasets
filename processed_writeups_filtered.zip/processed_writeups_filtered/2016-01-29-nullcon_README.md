# writeup hackim (nullcon) ctf 2016

uczestniczyliśmy (cr019283, c7f.m0d3, msm, rev, other019, nazywam i shalom) w nullcon ctf 2016, i znowu spróbujemy opisać zadania z którymi walczyliśmy.

### spis treści:
* ["twitter search" (recon) 200](recon_1)
* ["dictator" (recon) 300](recon_2)
* ["cook" (recon) 300](recon_3)
* ["nullcon youtube" (recon) 400](recon_4)
* ["game of life" (ppc/recon) 500](recon_5)
* ["xor with static key" (crypto) 500](crypto_1)
* ["caesar" (crypto) 400](crypto_2)
* ["repeating xor" (crypto) 400](crypto_3)
* ["md5" (crypto) 200](crypto_4)
* ["rsa" (crypto) 500](crypto_5)
* ["zorropub" (re) 100](re_1)
* ["pseudorandom" (re) 300](re_2)
* ["exploit 1" (pwn) 100](pwn_1)
* ["exploit 2" (pwn) 200](pwn_2)
* ["exploit 3" (pwn) 300](pwn_3)
* ["sign server" (web) 100](web_1)
* ["unickle" (web) 200](web_2)
* ["luhn" (web) 300](web_3)
* ["smashthestate" (web) 400](web_4)
* ["hqlol" (web) 500](web_5)
* ["catchmeifyoucan" (forensics) 100](forensics_1)
* ["trivia 2" (trivia/recon) 200](trivia_2)
* ["trivia 3" (trivia) 300](trivia_3)
* ["trivia 4" (trivia) 400](trivia_4)

