## serverfarm (re, 70p)

	description: someone handed me this and told me that to pass the exam, i have to
	extract a secret string. i know cheating is bad, but once does not count. so are
	you willing to help me?

###eng
[pl](#pl-version)

after reversing the provided arm binary, we quickly find some print statements printing
hardcoded characters and short strings, such as `printf("%s%c", "iw",'{')`. gathering all
of them, we quickly get the password.

###pl version

spojrzawszy na zdeasemblowany kod armowej binarki, zauważamy miejsce, w którym następuje
wypisywanie flagi. skłąda się ona z kilku/kilkunastu wypisań znaków i krótkich stringów, jak
`printf("%s%c", "iw",'{')`. po zebraniu wszystkich z nich, dostajemy flagę.
