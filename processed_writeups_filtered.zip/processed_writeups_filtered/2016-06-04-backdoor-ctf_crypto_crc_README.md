# crc

in this task we were given 26 encrypted zip files. it is easy to notice though, that they have
very small size - they uncompress to 5 byte files. that means we should be able to brute force
the actual contents, and check their validity using crc, since zips contain crc32 of 
their uncompressed contents:
```
[adam@adam-y510p ~/ctf/backdoor/zipcrc]λ unzip -lv 0.zip
archive:  0.zip
 length   method    size  cmpr    date    time   crc-32   name
--------  ------  ------- ---- ---------- ----- --------  ----
       5  stored        5   0% 2015-11-26 19:49 a36bb2ae  0.txt
--------          -------  ---                            -------
       5                5   0%                            1 file
```
we listed all crcs in `list`, and wrote a brute forcer - `check.cpp`. it looped over all printable
5-character strings and calculated its crc, after which it checked whether it fits any zip.

unfortunately there were many collisions, so we wrote a quick visualizer showing possibilites
for each zip (`parse.py`). output:
```
[ p,id] [ func] [h&3o4] [func(] [) { e] [.erm*] [h'9!r] [!lzw(] ["; fo] [ngxh4]
[<?php] [<))ow] [tion ] [z:2b<] [5o'!q] [b6in]  [the f] [m?wsl] [>t|g{] [r($i ] 
[pl]l4]                         [esv$!] [^y#hz]         [qp+rx]
                                        [cho "]         [lag: ]                
                                        ['3!6]          [p.;;4]                 


[!ol:4] [$i < ] [/}g!0] [8ije<] [echo ] [.eoe8] [)vpl7] [ (($i]
[= 0; ] [8&|=4] [32; $] [hu;@l] [y,4n4] [b6ba|] [e%}hs] [<gt%}] 
[lbqw<] [tuq9p] [bpzl8] [t:gax]         [^y>@h] [yj!ig] [qjihu]
                        [i++) ]         [chr(0] [d{m!?]        
                        [udw(4]         ['.)$]  [x41 +]          




[ ^ 0x] [-}u!1] [ 0x19] [)); e] [.erm*] [,rs>p] [ao:tz] [2jhw<] [*4der]
[pbq5(] [12) %] [<$0-]  [5fg!q] [b6in]  [@!~:4] [} fun] [bv9rl]
[q<a\d] [`phl9] [lcu5}] [xkzly] [^y#hz] [\n"; ]         [^9esx] 
                                [cho "] [ansx]          [c(); ]         
                                ['3!6]  [}02rl]         [gu:4]            
```
we quickly noticed it should be a php code (`<?php` in the first block gives it away). connecting
the dots, we manually created the script:
```
function func() { 
	echo "the flag: "; 
	for($i = 0; $i<32; $i++) 
		echo chr(0x41 + (($i ^ 0x12) % 0x19)); 
	echo "\n"; 
} 
func();
```
after running it, we got the flag.
