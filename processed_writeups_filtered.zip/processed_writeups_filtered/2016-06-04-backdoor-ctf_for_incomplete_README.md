# incomplete

in this task, we were given a pcap file containing a couple of http requests. they mostly got 
"partial content" response, but asked for the same file. that meant we could extract the requested
file, but with some small holes.

we have manually extracted the parts of files from the pcap into `24`, `38` and so on. then,
we wrote a python script (`join.py`) 
joining them together, filling the empty places with 0xcc bytes (and
also printing their offsets, to avoid false positives). quick inspection of the hexdump showed
it was probably a png file - it contained idat and iend strings, for example. we were unable
to open it though, because it lacked header and was not even recognized as a valid png.

after adding the constant header in hexeditor, we still had problems with opening it - there
were complaints about invalid crc in idat chunk. well, we calculated it as well 
(using `pngcheck` utility) and fixed
it (it was in position, where 4 bytes were missing). later, we had to fix chunk names (easy,
since all of them were idat, so no guessing here), and their lengths (also simple, because
in this png they all were the same size - 16000 bytes). the final missing byte was not
a metadata though, but one of the data bytes. since png chunks contain checksum, we could
just brute force the missing byte and see if it gives us the correct checksum.

fixing the image just in hexeditor would take us some time, so we wrote a simple script
`fix.py`. it did nothing more than i described here, but semi-automatically, so that i can work
on clean png every time.

the final result is `png3`. note that it is too tall, because we had to guess the size - it was
erased. the image is clearly visible though, so we submitted flag with no problems.
