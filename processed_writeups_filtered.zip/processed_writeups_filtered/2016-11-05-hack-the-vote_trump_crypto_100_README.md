# trump trump (crypto 100)

###eng
[pl](#pl-version)

in the task we get access to remote rsa signature service.
we also get a [picture](trump.jpg) we are supposed to sign with this service.
but the server refuses to sign this specific payload.

we can send some random payloads and check how it's signed since we know the `e` and `n` public key components.
we can figure out from this that rsa is unpadded!
the attack is quite simple - it's rsa blinding attack on homomorphic unpadded rsa.
in short: we can split the payload into parts, sign each one of the separately and then combine the signatures.

so we make a script:
```python
import codecs
import socket
import re
from time import sleep


def bytes_to_long(data):
    return int(data.encode('hex'), 16)


def long_to_bytes(flag):
    flag = str(hex(flag))[2:-1]
    return "".join([chr(int(flag[i:i + 2], 16)) for i in range(0, len(flag), 2)])


def get_payload(payload):
    url = "trumptrump.pwn.republican"
    port = 3609
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    data = s.recv(9999)
    print(data)
    sleep(1)
    s.sendall(str(payload) + "\r\n")
    sleep(1)
    data = s.recv(99999999)
    return data


def get_signature(payload):
    data = get_payload(payload)
    print(data)
    return int(re.findall("kid: (\d+)", data)[0])


def combine_sigs(sig1, sig2):
    n = 23377710160585068929761618506991996226542827370307182169629858568023543788780175313008507293451307895240053109844393208095341963888750810795999334637219913785780317641204067199776554612826093939173529500677723999107174626333341127815073405082534438012567142969114708624398382362018792541727467478404573610869661887188854467262618007499261337953423761782551432338613283104868149867800953840280656722019640237553189669977426208944252707288724850642450845754249981895191279748269118285047312864220756292406661460782844868432184013840652299561380626402855579897282032613371294445650368096906572685254142278651577097577263
    return (sig1 * sig2) % n


def find_divisor(picture_long):
    for i in xrange(2, 10000):
        if picture_long % i == 0:
            print(i)
            return i


def main():
    with codecs.open("trump.jpg", "rb") as input_file:
        picture = input_file.read()
        picture_long = bytes_to_long(picture)
        print(picture_long)
        divisor = find_divisor(picture_long)
        sig1 = get_signature(picture_long / divisor)
        sig2 = get_signature(divisor)
        result_sig = combine_sigs(sig1, sig2)
        print(result_sig)
        payload = get_payload(result_sig)
        with codecs.open("result.bin", "wb") as output:
            output.write(payload)
```

this code takes the payload to sign, finds integer divisor (in this case `3`), signs divisor and payload/divisor and then combines the signatures.
combining the signatures is just multiplying them back modulo `n`.

now there was a very confusing step - what to do with the signature?
apparently author really likes guessing games...
it turnes out we had to send the signature again to the server as payload and this would give us in return the picture with a flag:


[image extracted text: [image processing failed]]


###pl version

w zadaniu dostajemy adres zdalnego serwera podpisującego dane za pomocą rsa.
dostajemy też [obrazek](trump.jpg) który mamy podpisać.
ale serwer odmawia podpisania tych konkretnych danych.

możemy wysłać inne dane a potem sprawdzić jak zostały zaszyfrowane bo znamy `e` oraz `n` - elementy klucza publicznego.
z tego dowiadujemy sie że rsa nie używa tu paddingu!
atak jest dość prostu - to rsa blinding na homomorficzne rsa bez paddingu.
w skrócie: mozemy podzielić dane na kawałki, podpisać je osobno a potem złożyć sygnatury.

piszemy do tego skrypt:

```python
import codecs
import socket
import re
from time import sleep


def bytes_to_long(data):
    return int(data.encode('hex'), 16)


def long_to_bytes(flag):
    flag = str(hex(flag))[2:-1]
    return "".join([chr(int(flag[i:i + 2], 16)) for i in range(0, len(flag), 2)])


def get_payload(payload):
    url = "trumptrump.pwn.republican"
    port = 3609
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    data = s.recv(9999)
    print(data)
    sleep(1)
    s.sendall(str(payload) + "\r\n")
    sleep(1)
    data = s.recv(99999999)
    return data


def get_signature(payload):
    data = get_payload(payload)
    print(data)
    return int(re.findall("kid: (\d+)", data)[0])


def combine_sigs(sig1, sig2):
    n = 23377710160585068929761618506991996226542827370307182169629858568023543788780175313008507293451307895240053109844393208095341963888750810795999334637219913785780317641204067199776554612826093939173529500677723999107174626333341127815073405082534438012567142969114708624398382362018792541727467478404573610869661887188854467262618007499261337953423761782551432338613283104868149867800953840280656722019640237553189669977426208944252707288724850642450845754249981895191279748269118285047312864220756292406661460782844868432184013840652299561380626402855579897282032613371294445650368096906572685254142278651577097577263
    return (sig1 * sig2) % n


def find_divisor(picture_long):
    for i in xrange(2, 10000):
        if picture_long % i == 0:
            print(i)
            return i


def main():
    with codecs.open("trump.jpg", "rb") as input_file:
        picture = input_file.read()
        picture_long = bytes_to_long(picture)
        print(picture_long)
        divisor = find_divisor(picture_long)
        sig1 = get_signature(picture_long / divisor)
        sig2 = get_signature(divisor)
        result_sig = combine_sigs(sig1, sig2)
        print(result_sig)
        payload = get_payload(result_sig)
        with codecs.open("result.bin", "wb") as output:
            output.write(payload)
```

ten kod bierze dane do podpisu, znajduje dzielnik całkowity (w tym przypadku `3`), podpisuje dzielnik oraz payload/dzielnik a następnie składa te dwa podpisy.
składanie podpisów to po prostu przemnożenie ich modulo `n`.

teraz nastąpił bardzo dziwny problem - co dalej zrobić z tym podpisem?
autor bardzo lubi zgadywanki...
okazało się, że należy wysłać ten podpis do serwera a serwer w odpowiedzi wyśle nam flagę:


[image extracted text: [image processing failed]]

