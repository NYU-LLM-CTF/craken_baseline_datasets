﻿## jigsaw (misc)
	tl;dr solve the jigsaw, get letter indexes from binary

we're given 64 pieces of puzzle, after taking a quick glance, we've noticed that some of them have white background and other ones black. so there are either 2 puzzles to be solved or some of the pieces have had their colors inverted. 

we've decided to go with the second option, so we've started by inverting tiles with black background and marking such pieces with a: 


[image extracted text: ]


now all we have to do is solve the puzzle ;)

after some googling, we've found a [nice-looking solver](https://github.com/biswajitsc/jigsaw-solver)

skipping some hassle with opencv, we got:


[image extracted text: "

jul
nzf
b
(e
zdj=
l]


not bad, solving the rest manually should be easy:


[image extracted text: ep
p
[ ulo]


the peppers contain each letters index in binary (`left-up, righ-up, left-down, right-down`)

some indexes appeared more than once, so we had to shuffle pieces from the same letters to get a unique index for each letter.
