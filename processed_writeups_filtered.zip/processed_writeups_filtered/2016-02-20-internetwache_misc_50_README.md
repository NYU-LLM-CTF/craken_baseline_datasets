## the hidden message (misc, 50p)

	my friend really can't remember passwords. so he uses some kind of obfuscation. can you
	restore the plaintext?
	
###eng
[pl](#pl-version)

this was a really trivial task. given text consisted of base-8 numbers, which interpreted as
ascii yielded base64-encoded string. reversing the encoding, we get the flag.

###pl version

proste zadanie, polegające na zinterpretowaniu liczb w systemie ósemkowym jako kody znaków ascii,
a następnie odkodowanie powstałego tekstu za pomocą base64.
