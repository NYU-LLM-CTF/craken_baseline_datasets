## illuminati (web, 200p)

###eng
[pl](#pl-version)

in the task we get access to a illuminati recruitment webpage.
however the recruitment is closed and we can only send messages to the admin and he might accept us.
we could see only our own messages.

our first assumption was that it's some standard xss attack on the admin, but placing some example xss payload in the form uncovered an sql error printed.
this meant we have an sql injection vulnerability.
the form had 2 fields:

- subject limited to 40 characters (verified server side)
- message with no length limit

both of them were exploitable with a `"`.
the injection point was an `insert into` query, which limited a bit our capabilities.
more so that initially we though we have to exploit the `subject` field doing some crazy sql golfing in 40 characters, since we could not inject a `select` into the second field due to query construction.
the query was something like:

`insert into requests (id, "$subject", "$message")`

which means that the message field content was either inside quotation marks, or if we close the quotation mark, already outside insert query.
we could chain another insert values but we didn't know the id and thus we would not see the contents of this second insert query.

for a moment we though we will have to make a blind sqli here, but fortunately we came up with a great idea - why not chain injections from both fields at the same time, putting an injection in `subject` which will `shift` the column to the `message` field, lifting the 40 characters limit.

we figured we can put for example the subject as:

```
thesubject",concat(
```

and message as:

```
,(select whatever we want)))#
```

and therefore we escape the quotation marks by concat of empty string and our query result!

this way we could now execute any query we wanted, so we dumped the whole database via group_concat and substring.
the passwords, including the admin password, were hashed and not likely to be broken.
rest of the database did not contain anything particularly useful.

we thought that maybe we could update the admin password to our own password hash (hoping the passwords are not salted with username as salt), but we did not have rights to do it.

it took us a while to notice that the session cookie for this task was very particular - it helped that we developed a simple python script to send queries, and thus we had session cookie as parameter.
the cookie was a number plus our user id, which is quite odd.
so we figured that maybe it's possible to forge admin cookie.
in the database in users table there was a strange field with `last login timestamp`.
timestamps are often used as random seeds so we checked what random can we get using our timestamp as seed and we got our missing cookie part!

therefore, we finally extracted admin login timestamp from database via sql injection, we seeded random with the value, took the generated random int, glued it with admin user id and got the final cookie `1229569179-209`, which was enough to get us logged in as admin and get the flag.

###pl version

w zadaniu dostajemy dostęp do strony rekrutacyjnej illuminatów.
jednakże rekrutacja jest zamknięta i możemy jedynie wysłać wiadomość do admina, który może nas zaakceptuje.
możemy widzieć tylko nasze własne wiadomości.

nasze pierwsze skojarzenie to oczywiście standardowy atak xss na admina, jednakże przykładowy payload xss w formularzu sprawił że naszym oczom ukazał się błąd sqla.
to oznaczało, że podatność stanowi jednak sql injection.
formularz miał 2 pola:

- temat z limitem 40 znaków (sprawdzane po stronie serwera)
- wiadomość bez limitu długości

oba pola były exploitowalne przez `"`.
punktem wstrzyknięcia było zapytanie `insert into` co trochę ograniczało nasze możliwości.
dodatkowo początkowo myśleliśmy, że możemy użyć efektywnie tylko pola `subject` i trzeba będzie robić jakiś ciężki sql golfing na 40 znaków, ponieważ nie mogliśmy wstrzyknąć `select` do drugiego pola ze względu  na budowę zapytania.
zapytanie miało postać:

`insert into requests (id, "$subject", "$message")`

co oznaczało, że zawartość pola message była albo wewnatrz cudzysłowów, albo jeśli je domknęliśmy, poza danymi do insertowania.
moglibyśmy co prawda dołączyć kolejny zestaw danych dla insert, ale nie znaliśmy wartości id i nie moglibyśmy zobaczyć wyniku tego drugiego zapytania.

początkowo myśleliśmy, że skończy się na ataku blind sqli, ale na szczęście wpadliśmy na lepszy pomysł - czemu nie połączyć wstrzyknięcia z dwóch pól jednocześnie, umieszczajac w polu `subject` kod który `przesunie` kolumne do pola `message`, usuwając 40 znakowy limit.

wymyśliliśmy, że do pola subject można dać:


```
thesubject",concat(
```

a wiadomość:

```
,(select whatever we want)))#
```

i tym samym uciekamy z cudzysłowia przez złączenie pustego stringa z wynikiem naszego zapytania!

w ten sposób mogliśmy teraz wykonać dowolne zapytania więc dumpowaliśmy całą bazę przez group_concat i substring.
hasła w bazie, w tym hasło admina, były niestety hashowane i raczej nie wyglądały na łamalne.
reszta bazy nie wyglądała na zbyt przydatną.

myśleliśmy, że może da się podmienić hash hasła admina na nasz własny (licząc, że hasła nie są solone loginami), ale nie mieliśmy do tego praw.

chwile zajęło nam zauważenie, że ciastko sesji dla tego zadania wyglądało dość nietypowo - pomógł fakt, że mieliśmy już napisany prosty skrypt pythona do wysyłania zapytań do bazy i tym samym session id było w nim parametrem.
cookie zawierało pewien numer oraz user id, co jest dość dziwne.
uznaliśmy więc, że może da się sfabrykować cookie admina.
w bazie danych w tabeli użytkowników znajdowało się dziwne pole `last login timestamp`.
znaczniki czasowe często są stosowane jako ziarna dla randoma, więc sprawdziliśmy co da nam random dla naszego timestampa jako ziarna i otrzymaliśmy liczbę z naszego cookie!

w związku z tym wyciągnęliśmy z bazy timestamp dla admina przez sql injection, ustawiliśmy ziarno randoma na tą wartość, pobraliśmy losową liczbę, połączyliśmy z id admina i uzyskaliśmy cookie `1229569179-209`, które pozwoliło zalogować się do aplikacji jako admin i uzyskać flagę.
