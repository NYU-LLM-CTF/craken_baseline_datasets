## eso tape (re, 80p)

	description: i once took a nap on my keyboard. i dreamed of a brand new language, but
	i could not decipher it nor get its meaning. can you help me? hint: replace the
	spaces with either '{' or '}' in the solution. hint: interpreters don't help. 
	operations write to the current index.

###eng
[pl](#pl-version)

this was a fun task. we were given a source code of an unknown programming language.
we assumed it would print out the flag. first observation we made, was that number 
of `@*`, `@**` and `@***` instructions was about right for the flag, and ther distribution among
code was about uniform - so we assumed those were print statements. this is start of code:
```
## 
%% 
%++ 
%++ 
%++ 
%# 
*&* 
@** 
%# 
**&* 
***-* 
***-* 
%++ 
%++ 
@*** 
```
this code should print out `iw`. after trying many things, we noticed that i is 9th letter of
alphabet, which is `3*3` - and 3 is the number of `@++` instructions, so `*&*` was likely
multiplication. we also guessed that `*`, `**` and `***` refer to distinct "registers" of
machine. since the first print statement prints from the second register, something had to be
put there - after some trial and error, we concluded that `%#` is something like "move current
write pointer to the next register". we wrote interpreter up to this part, at which point we got
stuck. after some time, admin hinted on irc, that this is a real language. looking it up on 
esolang website, we found out it is `tapebagel`. after finishing up the interpreter, we got flag.

###pl version

to byłe ciekawe zadanie - dostaliśmy plik z kodem w nizenanym języku programowania. naturalnie 
założyliśmy, że wypisuje on flagę. patrząc na liczbę instrukcji z `@`, domyśliliśmy się, że
są to instrukcje wypisania. początek kodu:
```
## 
%% 
%++ 
%++ 
%++ 
%# 
*&* 
@** 
%# 
**&* 
***-* 
***-* 
%++ 
%++ 
@*** 
```
ten kod powinien zatem wypisywać `iw`. po dłuższej chwili zauważyliśmy, że i jest dziewiątą literą 
alfabetu, a `9=3*3`, przy czym 3 to ilość instrukcji `%++`, które zapewne zwiększają jakąś liczbę.
zatem `*&*` zapewne mnoży liczbę `*` przez samą siebie. później wpadliśmy na to, że `*`, `**`,
 `***` to zapewne kolejne rejestry maszyny. ponieważ `@**` wypisuje dopiero drugi rejestr, coś
musiało być do niego wcześniej włożone. w ten sposób wymyślilismy, że `%#` to "zwiększanie
wskaźnika". napisaliśmy interpreter uwzględniający znane już nam instrukcje, nie mogliśmy
wypisać nic więcej niż `iw ilov`. po jakimś czasie admin napisał na ircu, że to prawdziwy język.
poszukalismy więc na stronie esolang tegoż, i znaleźliśmy - jest to `tapebagel`. dokończywszy
interpreter, dostaliśmy flagę.
