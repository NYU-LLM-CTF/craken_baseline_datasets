## a numbers game (ppc, 50p)

	description: people either love or hate math. do you love it? prove it! you just need to solve a bunch of equations without a mistake. 
	
###eng
[pl](#pl-version)

server sends input in format:

	hi, i heard that you're good in math. prove it!
	level 1.: x - 18 = -12

and we are supposed to send the solution to the equation. 
so for the example above we parse `-` as operation, `18` as operand and `-12` as result, and thus the solution is `-12 + 18`.
we automate is wih a simple script that parses operation, operand and result and then applies corresponding operation (eg. + for -).

```python
import re
import socket
from time import sleep


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11027))
    regex = "level \d+\.: x (.) (\d+) = (.+)"
    initial_data = str(s.recv(4096))
    print(initial_data)
    while true:
        sleep(1)
        task = str(s.recv(4096))
        m = re.search(regex, task)
        print(task)
        operation = m.group(1)
        operand = int(m.group(2))
        result = int(m.group(3))
        x = result
        if operation == "+":
            x = result - operand
        elif operation == "-":
            x = result + operand
        elif operation == "*":
            x = result / operand
        elif operation == "/":
            x = result * operand
        s.sendall(str(x) + "\n")
    pass

main()
```

after 100 examples we get a flag: `iw{m4th_1s_34sy}`

###pl version

serwer dostarcza dane w formacie:

	hi, i heard that you're good in math. prove it!
	level 1.: x - 18 = -12

a naszym zadaniem jest rozwiązać podane równanie.
dla przykładu powyżej parsujemy `-` jako operacje, `18` jako operand oraz `-12` jako wynik, więc rozwiązaniem jest `-12 + 18`.
automatyzujemy to skryptem który parsuje operacje, operand oraz wynik a nastepnie wykorzystuje operacje przeciwną (np. + dla -).

```python
import re
import socket
from time import sleep


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11027))
    regex = "level \d+\.: x (.) (\d+) = (.+)"
    initial_data = str(s.recv(4096))
    print(initial_data)
    while true:
        sleep(1)
        task = str(s.recv(4096))
        m = re.search(regex, task)
        print(task)
        operation = m.group(1)
        operand = int(m.group(2))
        result = int(m.group(3))
        x = result
        if operation == "+":
            x = result - operand
        elif operation == "-":
            x = result + operand
        elif operation == "*":
            x = result / operand
        elif operation == "/":
            x = result * operand
        s.sendall(str(x) + "\n")
    pass

main()
```

po 100 przykładach dostajemy flagę: `iw{m4th_1s_34sy}`
