# multicast (misc, 175p)

## eng
[pl](#pl-version)

in the task we get a [sage script](generate.sage) which generated the [data](data.txt):

```python
nbits = 1024
e = 5
flag = open("flag.txt").read().strip()
assert len(flag) <= 64
m = integer(int(flag.encode('hex'),16))
out = open("data.txt","w")

for i in range(e):
    while true:    
        p = random_prime(2^floor(nbits/2)-1, lbound=2^floor(nbits/2-1), proof=false)
        q = random_prime(2^floor(nbits/2)-1, lbound=2^floor(nbits/2-1), proof=false)
        ni = p*q
        phi = (p-1)*(q-1)
        if gcd(phi, e) == 1:
            break

    while true:
        ai = randint(1,ni-1)
        if gcd(ai, ni) == 1:
            break

    bi = randint(1,ni-1)
    mi = ai*m + bi
    ci = pow(mi, e, ni)
    out.write(str(ai)+'\n')
    out.write(str(bi)+'\n')
    out.write(str(ci)+'\n')
    out.write(str(ni)+'\n')
```

it is a standard rsa with e=5 and 1024 bits modulus.
what is noticable is that we get 5 payloads, and e is 5, so the setup looks very much like for a hastad broadcast attack.
also the name of the task could suggest this.

however, unlike for the simple hastad case, we don't really have the same message sent with different moduli.
such case can be solved very simply using chinese reminder theorem.
here each of the encrypted messages is different, however each has form `ai*m + bi` so a linear polynomial was applied over the message before the encryption.

if we look at the generic hastad description, for example in durfee phd thesis http://theory.stanford.edu/~gdurf/durfee-thesis-phd.pdf (page 25-26) we will find that in fact it is also applicable in out scenario, although the final coputation requires coppersmith attack.

we follow the method described in the linked paper (for details just read the paper) and we get a [solver](solver.sage) with the core part:

```python
def main():
	import codecs
   	with codecs.open("data.txt", "r") as input_file:
		data = [int(c) for c in input_file.readlines()]
		a = [data[i * 4] for i in range(5)]
		b = [data[i * 4+1] for i in range(5)]
		c = [data[i * 4+2] for i in range(5)]
		ns = [data[i * 4 + 3] for i in range(5)]
		t = []
		for n in ns:
			other_moduli = [x for x in ns if x != n]
			t.append(crt([1,0,0,0,0],[n]+other_moduli))
		n = reduce(lambda x,y: x*y, ns)
		e = 5
		p.<x> = polynomialring(zmod(n), implementation='ntl');
		pol = 0
		for i in range(5):
			pol += t[i]*((a[i]*x+b[i])^e - c[i])
		dd = pol.degree()
		if not pol.is_monic():
			leading = pol.coefficients(sparse=false)[-1]
			inverse = inverse_mod(int(leading), int(n))
			pol *= inverse
		beta = 1
		epsilon = beta / 7
		mm = ceil(beta**2 / (dd * epsilon))
		tt = floor(dd * mm * ((1/beta) - 1))
		xx = ceil(n**((beta**2/dd) - epsilon))
		roots = pol.small_roots()
		for root in roots:
			print(long_to_bytes(root))
	
main()
```

so we read the data and partition them into the recovered polynomials coefficients and moduli.
we use chinese reminder theorem to get values `ti` which for each dataset `i` should give 1 mod `ni` and 0 modulo any other of the moduli.
then we calculate the product of all moduli and create a polynomial ring with this value, because now all calculations will be mod `n1*n2*...`.

finally we create a polynomial suggested by durfee and we find the roots using coppersmith method.

the extracted root is the message we were looking for: `pctf{l1ne4r_p4dd1ng_w0nt_s4ve_y0u_fr0m_h4s7ad!}`


## pl version

w zadaniu dostajemy [skrypt sage](generate.sage) który wygenerował [dane](data.txt):

```python
nbits = 1024
e = 5
flag = open("flag.txt").read().strip()
assert len(flag) <= 64
m = integer(int(flag.encode('hex'),16))
out = open("data.txt","w")

for i in range(e):
    while true:    
        p = random_prime(2^floor(nbits/2)-1, lbound=2^floor(nbits/2-1), proof=false)
        q = random_prime(2^floor(nbits/2)-1, lbound=2^floor(nbits/2-1), proof=false)
        ni = p*q
        phi = (p-1)*(q-1)
        if gcd(phi, e) == 1:
            break

    while true:
        ai = randint(1,ni-1)
        if gcd(ai, ni) == 1:
            break

    bi = randint(1,ni-1)
    mi = ai*m + bi
    ci = pow(mi, e, ni)
    out.write(str(ai)+'\n')
    out.write(str(bi)+'\n')
    out.write(str(ci)+'\n')
    out.write(str(ni)+'\n')
```

mamy tu standardowe rsa e=5 oraz 1024 bitowym modulusem.
możemy zauważyć, że mamy 5 wiadomości oraz e równe 5, co sugeruje konfiguracje podobną do ataku hastad broadcast.
dodatkowo sama nazwa zadania także może to sugerować.

jednak, w przeciwieństwie do klasycznego przypadku hastada, nie mamy tutaj tej samej wiadomości wysłanej z różnymi modulusami.
taki przypadek trywialnie można rozwiązać za pomocą chińskiego twierdzenia o resztach.
tutaj każda wiadomość jest inna, niemniej jednak każda ma postać `ai*m + bi` więc pewien liniowy wielomian został policzony z wiadomości przed szyfrowaniem.

jeśli popatrzymy na ogólny przypadek hastada, na przykład w pracy doktorskiej pana durfee http://theory.stanford.edu/~gdurf/durfee-thesis-phd.pdf (strony 25-26) zobaczymy, że w rzeczywistości twierdzenie można wykorzystać także w naszym przypadku, chociaż finalne obliczenia będą wymagać użycia ataku coppersmitha.

postępujemy zgodnie z metodą opisaną w linkowanej publikacji (po szczegóły i wyjaśnienia odsyłam tam) i dostajemy [solver](solver.sage) z główną częścią:

```python
def main():
	import codecs
   	with codecs.open("data.txt", "r") as input_file:
		data = [int(c) for c in input_file.readlines()]
		a = [data[i * 4] for i in range(5)]
		b = [data[i * 4+1] for i in range(5)]
		c = [data[i * 4+2] for i in range(5)]
		ns = [data[i * 4 + 3] for i in range(5)]
		t = []
		for n in ns:
			other_moduli = [x for x in ns if x != n]
			t.append(crt([1,0,0,0,0],[n]+other_moduli))
		n = reduce(lambda x,y: x*y, ns)
		e = 5
		p.<x> = polynomialring(zmod(n), implementation='ntl');
		pol = 0
		for i in range(5):
			pol += t[i]*((a[i]*x+b[i])^e - c[i])
		dd = pol.degree()
		if not pol.is_monic():
			leading = pol.coefficients(sparse=false)[-1]
			inverse = inverse_mod(int(leading), int(n))
			pol *= inverse
		beta = 1
		epsilon = beta / 7
		mm = ceil(beta**2 / (dd * epsilon))
		tt = floor(dd * mm * ((1/beta) - 1))
		xx = ceil(n**((beta**2/dd) - epsilon))
		roots = pol.small_roots()
		for root in roots:
			print(long_to_bytes(root))
	
main()
```

pobieramy dane i dzielimy je na odpowiednie parametry wielomianów i modulusy.
następnie za pomocą chińskiego twierdzenia o resztach wyliczamy współczynniki `ti` które dla każdego wejścia `i` dają 1 mod `ni` oraz 0 modulo dowolny inny modulus z zestawu.
następnie wyliczamy iloczyn wszystkich modulusów i tworzymy pierścień wielomianowy z tym iloczynem, ponieważ wszystkie obliczenia wykonywane będą teraz modulo `n1*n2*...`.

finalnie tworzymy wielomian zaproponowany przez durfee i znajdujemy jego pierwiastki metodą coppersmitha.

znaleziony pierwiastek to szukana flaga: `pctf{l1ne4r_p4dd1ng_w0nt_s4ve_y0u_fr0m_h4s7ad!}`
