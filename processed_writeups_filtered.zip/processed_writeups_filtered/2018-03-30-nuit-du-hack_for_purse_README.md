# where is my purse (for)

in the task we get a large filesystem image and a memdump to work with.
interesting part of memdump is a running keepass instance.

we got some password-like strings from it, but we've never actually used them.
for some reason they were not necessary at all.

we've looked around the drive image and the only unusual files we've noticed were connected with `dcrwallet` (which had some connotation with "purse" from the task name).
we grabbed all the files of the wallet, and there was a [db file](wallet.db) which contains plaintext string `flag{thx_you_found_my_wallet}`
