﻿##rsa (crypto, 500p)

	now you are one step away from knowing who is that warrior. 
	the fighter who will decide the fate of war between the 2 countries. 
	the pride of one and envey of the other... 
	you have got the secrete file which has the crucial information to identify the fighter. 
	but the file is encrypted with a rsa-private key. 
	good news you have its corresponding public key in a file. 
	bad news there are 49 other keys. 
	whos is the fighter.

###pl
[eng](#eng-version)

dostajemy szyfrowany [plik](warrior.txt) oraz zbiór [kluczy publicznych](all_keys.txt).
plik został zaszyfrowany przy pomocy klucza prywatnego rsa (dość dziwny pomysł, ale matematycznie zupełnie poprawny) a jeden z kluczy publicznych którymi dysponujemy pasuje do tego klucza prywatnego.

w przypadku rsa parametry kluczy są dobrane tak, aby:

`d*e = 1 mod (totient(n))`

ponieważ dzięki temu

`(x^e)^d mod n = x^ed mod n = m`

jak nie trudno zauważyć, nie ma więc znaczenia czy jak w klasycznym przypadku mamy:

`ciphertext = plaintext^e mod n` 

i dekodujemy go przez podniesienie do potęgi `d` czy też mamy:

`ciphertext = plaintext^d mod n` 

i dekoduejmy go przez podniesienie do potęgi `e`.

uruchamiamy więc prosty skrypt który spróbuje zdekodować plik przy pomocy każdego z kluczy:

```python
import codecs
from crypto.publickey import rsa
from base64 import b64decode
from crypto.util.number import long_to_bytes, bytes_to_long

with codecs.open("warrior.txt", "rb") as warrior:
    w = warrior.read()
    ciphertext = bytes_to_long(w)
    print(len(w))
    with codecs.open("all_keys.txt") as input_file:
        data = input_file.read()
        for i, key in enumerate(data.split("-----end public key-----")):
            key = key.replace("\n", "")
            key = key.replace("-----begin public key-----", "")
            if key:
                keyder = b64decode(key)
                keypub = rsa.importkey(keyder)
                print(i)
                pt = pow(ciphertext, keypub.key.e, keypub.key.n)
                print("plaitnext: " + long_to_bytes(pt))

```

jeden z wyników zawiera:

	this fighter is a designation for two separate, heavily upgraded derivatives of the su-35 'flanker' jet plane. 
	they are single-seaters designed by sukhoi(knaapo).

sprawdzamy więc skąd pochodzi cytat i trafiamy na https://en.wikipedia.org/wiki/sukhoi_su-35 a flagą jest `sukhoi su-35`
	
###eng version

we get a encrypted [file](warrior.txt) and set of [public keys](all_keys.txt)
the file was encrypted with rsa private key (unusual, but mathematically correct) and one of the public keys we have is corresponding key to the private key used in encryption.

in case of rsa cipher the key parameters are selected so that:


`d*e = 1 mod (totient(n))`

and therefore:

`(x^e)^d mod n = x^ed mod n = m`

as can be noticed, it doesn't matter if we have the classic example:

`ciphertext = plaintext^e mod n` 

and we decode it with raising to power `d`, or if we have:

`ciphertext = plaintext^d mod n` 

and decode by raising to power `e`.

so we run a simple script which will decode the file using each of the keys:

```python
import codecs
from crypto.publickey import rsa
from base64 import b64decode
from crypto.util.number import long_to_bytes, bytes_to_long

with codecs.open("warrior.txt", "rb") as warrior:
    w = warrior.read()
    ciphertext = bytes_to_long(w)
    print(len(w))
    with codecs.open("all_keys.txt") as input_file:
        data = input_file.read()
        for i, key in enumerate(data.split("-----end public key-----")):
            key = key.replace("\n", "")
            key = key.replace("-----begin public key-----", "")
            if key:
                keyder = b64decode(key)
                keypub = rsa.importkey(keyder)
                print(i)
                pt = pow(ciphertext, keypub.key.e, keypub.key.n)
                print("plaitnext: " + long_to_bytes(pt))

```

one of the results contains:

	this fighter is a designation for two separate, heavily upgraded derivatives of the su-35 'flanker' jet plane. 
	they are single-seaters designed by sukhoi(knaapo).

we check where did this come from and we find https://en.wikipedia.org/wiki/sukhoi_su-35 and the flag is `sukhoi su-35`