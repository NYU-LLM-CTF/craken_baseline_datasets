# rescue shell, 100p, exploit

in this task we were given a binary showing a password prompt. there was a 
simple buffer overflow, allowing us to rop and first dump got `fread` address, then
overwrite it with libc single gadget offset.
