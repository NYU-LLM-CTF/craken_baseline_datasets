# writeup plaid ctf 2016

team: c7f.m0d3, akrasuski1, cr019283, nazywam, shalom, mnmd21891, msm, rev

### table of contents

 * [rabit (crypto)](crypto_rabit)
 * [tonnerre (crypto)](crypto_tonnerre)
 * [pixelshop (web)](web_pixelshop)
 * [hevc (misc)](misc_hevc)
 * [morset (misc)](misc_morset)
 * [the stuff (misc)](misc_the_stuff)
 * [untitled (misc)](misc_untitled)
 * [pound (pwn)](pwnable_pound)
 * [quixotic (re)](reversing_quixotic)
