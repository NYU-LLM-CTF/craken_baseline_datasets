# writeup tokyo westerns/mma ctf 2016

team: akrasuski, c7f.m0d3, cr019283, ppr, shalom, nazywam, rev, msm

### table of contents

* [backpacker's cipher (crypto)](backpacker)
* [whiteout mathmatics (reverse, ppc)](whiteout_mathematics)
* [private/local/comment (ppc)](restricted_ruby)
* [rotten uploader (web)](rotten_uploader)
