# jpeg file (misc, 100p)

```
it will be fixed if you change somewhere by 1 bit.
```

in the task we get a [jpeg file](tktk.jpg) and the description is quite clear - we need a single bitflip to uncover the flag.
we simply generated images with bitflips and the scrolled through thumbnails.
we thought about using tesseract but it would take much time.

bitflips were generated via:

```python
import codecs


def main():
    start_byte = 0
    stop_byte = 700
    with codecs.open("tktk.jpg", "rb") as input_file:
        data = input_file.read()
    for byte in range(start_byte, stop_byte):
        for bit in range(8):
            modified = chr(ord(data[byte]) ^ (1 << bit))
            output_data = data[:byte] + modified + data[byte + 1:]
            with codecs.open("res/" + str(byte) + "_" + str(bit) + ".jpg", "wb") as output_file:
                output_file.write(output_data)
main()
```

and once we flipped bits in byte 623 we got the flag:


[image extracted text: seccon{ip3g_study}]


the flag was `seccon{jp3g_study}`
