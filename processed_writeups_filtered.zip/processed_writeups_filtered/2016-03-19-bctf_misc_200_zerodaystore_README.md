## zerodaystore (misc, 200)
	tldr; add &price=0 to the end of the /pay request

[server.py](server.py.8c15b34d5e32243f5ed38c1b055bfd6f)
[zerodaystore.apk](zerodaystore.apk.7869c5b00cdf037273e39572fb1affdb)

we start off by decompiling the apk file using [javadecompilers](http://www.javadecompilers.com/apk). the code is pretty straight-forward, we can purchase 0dayexploits with our money. 

there is one problem though, we have no money and 0days are expensive! there are 2 solutions though. 

we can craft the requests ourselfes and send them directly to the recovered url or rebuild the apk with our money and/or exploits' prices faked. 


[image extracted text: 15 08
zerodaystore
adobe flash
850,000
nclonc {rec!
internet explorer
5801000
eqje
fan wallahiel
please confirm your order
your cash;16384
fee.3125
cancel
androld
8120,0 00
mmbzjc klled !
ios
8500,000
los 92.1 pettecl jailbree<]


after a purchase has been made a json request to `http://paygate.godric.me/order` is sent with products price, id and our devices id. 


[image extracted text: bost
order
httb/ l
content
type
application/json
user-agent
dalvik/2_
linuxa
androig
gt-i34
300
buil
d/mb29u)
host:
mall
godric
onnection:
close
accept-encoding:
giip
content-length:
ductid
price
3125
androidid"
e4b6b4d91543lbda]


the request is then corrected(price is set again from productid), signed and returned as a strings contacted by `&`. the response is then sent to `http://paygate.godric.me/order`

the server source tells us that we need to send a pay request with `price=0`, we could try sending a fake request directly at /pay but unfortunatelly the message is verified using rsa and sending edited requests results in error.

it turns out that the signing mechanism is broken, we can smuggle our `&price=0` after the message and sign. this way, we can have correctly-signed message and the price variable set to 0 which should give us the flag.

`bctf{0dayl0ver1chguy5}`
bingo!
