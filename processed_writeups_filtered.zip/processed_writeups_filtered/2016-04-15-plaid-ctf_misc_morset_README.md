# morset (misc, 50pts, 86 solves)
	a mysterious signal… can you decode it? 
	running at morset.pwning.xxx:11821

in this task we were told to conenct to certain server. the server sent us some
dots and dashes, so we immediately thought it could be morse code. decoding it, though,
gave us some gibberish alfanumeric string. they were generally very different, but
sometimes they were pretty similar. for example:
```
aidqjb34i3oa5b0bvlpe3ogv6xx23ttige6i451cc6v0vpwvwwgl1123el2k56os6r3w123wf2b0p90xh6n
aidqjb34i3oa5b0bvlpe3ogv6xx23ttige6i451cc6v0vpwvwwgl1123el2k56os6r41gdx88yqmo172z3z
```
we thought it could be some constant start of the message followed by some challenge.

finally, we came up with an idea how to decode this text - since this was neither base64
nor base32, it could be base36! used alphabet was `0-9a-z`.
final decoding and encoding code is in `doit.py` - it turns out
server was sending us questions such as "what is sha256(grapefruit1234)?". after sending
answer in the same format, we got the flag.
