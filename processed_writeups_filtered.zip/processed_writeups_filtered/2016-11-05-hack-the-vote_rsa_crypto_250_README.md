# the best rsa (crypto 250)

###eng
[pl](#pl-version)

this was a very badly designed task.
we prepared an expected solver, but we didn't get the flag simply because we assumed this can't be a right solution.
apparently author thought it's a great idea to prepare a task which requires hours (!) of heavy multithreaded computations.

we get [data](data.txt) with a very very long ciphertext and very very long modulus.
however it's quite simple to notice that the modulus is divisible by 5, and quick check shows that it can be actually factored into primes <= 251.
the only problem is that there are about 1500 of each prime, so de modulus is something like:

`n = 3^14xx * 5^14xx * ... * 251^14xx`

we can quickly factor this with small sieve.

the naive approach would be to calculate `d` and `fi(n)` and decrypt the message, but this would take forever.
smarter approach would be to use rsa-crt, so calculate `c^d mod p1`, `c^d mod p2`... where `p1 = 3^14xx`, `p2 = 5^14xx` etc, and then we use chinese reminder theorem to calculate the final value.

but this again takes a very very long time to calculate.
we even tried to speed this up using hensel lifting when calculating each of the values, but this didn't help that much.

therefore we simply decided we missed something here because it's just stupid to force us to run hours of computations.
apparently we didn't and this was the intended solution...

###pl version

to było bardzo źle zaprojektowane zadanie.
napisaliśmy do niego solver, ale nie uzyskaliśmy flagi zwyczajnie dlatego, ze uznaliśmy że to nie może być poprawne rozwiązanie.
najwyraźniej autor uznał za świetny pomysł zadanie wymagające wielu godzin (!) równoległych obliczeń.

dostajemy [dane](data.txt) z bardzo bardzo długim ciphertextem oraz bardzo bardzo długim modulusem.
niemniej łatwo zauważyc, ze modulus jest podzielny przez 5, a szybkie sprawdzenie pozwala stwierdzić że w ogóle rozkłada sie na iloczyn liczb pierwszych <=251.
jedyny problem jest taki, że każdej z tych liczb jest około 1500 więc modulus to coś w stylu:

`n = 3^14xx * 5^14xx * ... * 251^14xx`

możemy to szybko rozłożyć prostym sitem.

naiwne podejście to policzyć `d` oraz `fi(n)` a potem odszyfrować wiadomość, ale to trwałoby wieki.
lepsze podejście to użyć rsa-crt, policzyć `c^d mod p1`, `c^d mod p2`... gdzie `p1 = 3^14xx`, `p2 = 5^14xx` itd a potem złożyć te rozwiązania za pomocą chińskiego twierdzenia o resztach.

ale to mimo wszystko trwa bardzo długo.
próbowaliśmy przyspieszyć to za pomocą liftingu hensela przy liczeniu kolejnych wartości, ale to specjalnie nie pomogło.

w związku z tym uznaliśmy, że coś przeoczyliśmy, no przecież idiotycznym pomysłem byłoby wykonywać wielogodzinne obliczenia.
okazało się jednak, że wg autora to wcale nie takie głupie i takie właśnie było oczekiwane rozwiązanie...
