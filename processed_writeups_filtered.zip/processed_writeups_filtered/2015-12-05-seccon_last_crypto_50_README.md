##last challenge (thank you for playing) (misc/crypto, 50p)

```
ex1
cipher:pxfr}qivtmszcndkuwagjb{lhyeo
plain: abcdefghijklmnopqrstuvwxyz{}

ex2
cipher:ev}zzd{dwzra}ffdnfgqo
plain: {helloworldsecconctf}

quiz
cipher:a}ffdnea}}hdjn}lgh}pwo
plain: ??????????????????????
```

###pl
[eng](#eng-version)

dostajemy do rozwiązania prost szyfr podstawieniowy. na podsatwie pierwszej pary plaintext-ciphertext generujemy mapę podstawień a następnie dekodujemy flagę:

```python
data1 = "pxfr}qivtmszcndkuwagjb{lhyeo"
res1 = "abcdefghijklmnopqrstuvwxyz{}"
sub = dict(zip(data1, res1))
print("".join([sub[letter] for letter in "a}ffdnea}}hdjn}lgh}pwo"]))
```

`seccon{seeyounextyear}`


### eng version

we get a very simple substitution cipher to solve. using the first plaintext-ciphertext pair we genrate a substitution map and the we decode the flag:

```python
data1 = "pxfr}qivtmszcndkuwagjb{lhyeo"
res1 = "abcdefghijklmnopqrstuvwxyz{}"
sub = dict(zip(data1, res1))
print("".join([sub[letter] for letter in "a}ffdnea}}hdjn}lgh}pwo"]))
```

`seccon{seeyounextyear}`