# writeup volga ctf 2016 quals

team: akrasuski1, nazywam, graszka22, c7f.m0d3, cr019283, mnmd21891, msm, other019, rev, shalom

### table of contents
* [yacs2 (ppc)](yacs2)
* [image archeology (admin)](image_archeology)

