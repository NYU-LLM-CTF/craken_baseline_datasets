# random noise (staganography)

in this challenge, we're given a file that is in fact 2 pngs:

```
┌[michal@bobik] [/dev/ttys004] 
└[~/desktop]> binwalk final.png 

decimal       hexadecimal     description
--------------------------------------------------------------------------------
0             0x0             png image, 799 x 397, 8-bit colormap, non-interlaced
821           0x335           zlib compressed data, default compression
3360          0xd20           png image, 799 x 397, 8-bit/color rgba, non-interlaced
3401          0xd49           zlib compressed data, default compression
```


they both contain clues essential to the solution of the challange:


the first image contains some data on the lowest bits of each color of the upper row:


[image extracted text: stegsolve 1.3 by caesum
file
analyse
help
green plane
ag{this_is_not_the_actual_iiag}]



which we can extract using a simple python script:

``` python
def chunks(l, n):
    """yield successive n-sized chunks from l."""
    for i in range(0, len(l), n):
        yield l[i:i + n]

with open("lsb.pnm") as f:
	dots = f.read().split("\n")

pixels = chunks(dots, 3)
data = ""

for pix in list(pixels)[:-1]:
	pix = map(int, pix)
	r, g, b = pix
	data += str(r&1)

data = map(lambda x:chr(int(x,2)), chunks(data, 8))
print(''.join(data))
```

```
┌[michal@bobik] [/dev/ttys004] 
└[~/desktop]> python parse_lsb.py
key for vigenere cipher: thiskeycantbeguessed (not the flag) 
```

let's move on to the second picture:


[image extracted text: ]


we actually spent quite a while on this stage but finally came up with a good guess: let's sort the pixels by colors, if they in fact random the distribution should be quite equal, right?



[image extracted text: ]



some weird anomalies, let's filter theese out in the original image:


[image extracted text: ]


bingo!, it's [a morse](https://i.pinimg.com/originals/f8/9d/35/f89d3592cc9c024df2e003f0468e5c85.jpg)

`wsiyswfgylhvnamxkszhwumg`

if we now decipher it using the vigenre password we get: `heyyoujustsavedneo`