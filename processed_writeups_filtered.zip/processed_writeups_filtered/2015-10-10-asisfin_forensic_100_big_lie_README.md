﻿## big lie (forensic, 100p, 101 solves)

> find the [flag](biglie.pcap).

### pl
[eng](#eng-version)

otrzymany plik pcap ładujemy do wiresharka i na podstawie wyeksportowanych obiektach z sesji http dochodzimy do wniosku, że użytkownik skorzystał z usługi pastebin, która przed wysłaniem danych szyfruje je lokalnie, a klucz przesyłany jest za pomocą części "fragment" (to, co za `#`) urla. jest to część, która nie jest częścią requestu http i nie jest przesyłana serwerowi (i tym samym nie znalazło się w zrzucie danych sieciowych).

ale po dalszej analizie sesji http znajdujemy pełnego urla (razem z kluczem) w requestach do wewnętrznej usługi monitorującej ruch.


[image extracted text: follow tcp stream (tcp,stream eq 16)
stream content
get
piwile
action_name-0bin?ozo
zopas
dsite-1
orecaner-0bj53282h29en4-ygtedk&ur ]-httpx arzfkzfobin:asis: lox2fpastex
zfithaokv4923zz-nhpnrovggg 3522f792frwdzpnzpz| 580x9y2g3iuehfceur iref_http%3arzf%
zfobin
032f%
3fe
d-ddi7970821486b638_
idts-14430813568_idvc-18_idn-0&_refts-0&_viewts-14430813568sen
mage-o8pdf_leqt-ogrealp_o8wma_oadir_oafla-l&java-legears_ogag_o8cookie-leres-1440x90
oegt
ms=141
http
rebinapdg?=]


po urldecode:

[image extracted text: ipiwik php?action_
name-qbin
encrypted
pastebin&idsite=
8recz18r=1754748h=118m-298s-48url-http iiobin asis iolpaste/1thaokva#zz-
nhpnrovggg3s/7irwdzpnzpzis8ox9y2g3iuehic&urlref-http iiqbin asis i0/?
d=dd1797a841486h62&
ictc
430813562]


zawartość "pasty":

[image extracted text: expire in 18
rsky" #g]


po przeklejeniu do edytora z wyłączonym word-wrap:

[image extracted text: asi3}? 8elkaxay]


`asis{e29a3ef6f1d71d04c5f107eb3c64bbbb}`

### eng version

we load the inpit pcap file in wireshark and based on the exported http session objects we conclude that the user was using pastebin service which locally encrypts the data before sending them, and the key is sent via "fragment" of the url (what is after `#`). it's the part that is not a part of http request and is not sent to the server (and therefore it's not in the network communication dump).

however after firther analysis of the http session we find the full url (the encryption key included) in requests for internal traffic monitoring service.


[image extracted text: follow tcp stream (tcp,stream eq 16)
stream content
get
piwile
action_name-0bin?ozo
zopas
dsite-1
orecaner-0bj53282h29en4-ygtedk&ur ]-httpx arzfkzfobin:asis: lox2fpastex
zfithaokv4923zz-nhpnrovggg 3522f792frwdzpnzpz| 580x9y2g3iuehfceur iref_http%3arzf%
zfobin
032f%
3fe
d-ddi7970821486b638_
idts-14430813568_idvc-18_idn-0&_refts-0&_viewts-14430813568sen
mage-o8pdf_leqt-ogrealp_o8wma_oadir_oafla-l&java-legears_ogag_o8cookie-leres-1440x90
oegt
ms=141
http
rebinapdg?=]


after urldecode:

[image extracted text: ipiwik php?action_
name-qbin
encrypted
pastebin&idsite=
8recz18r=1754748h=118m-298s-48url-http iiobin asis iolpaste/1thaokva#zz-
nhpnrovggg3s/7irwdzpnzpzis8ox9y2g3iuehic&urlref-http iiqbin asis i0/?
d=dd1797a841486h62&
ictc
430813562]


pastebin contents:

[image extracted text: expire in 18
rsky" #g]


when placed in an editor with word-wrap:

[image extracted text: asi3}? 8elkaxay]


`asis{e29a3ef6f1d71d04c5f107eb3c64bbbb}`