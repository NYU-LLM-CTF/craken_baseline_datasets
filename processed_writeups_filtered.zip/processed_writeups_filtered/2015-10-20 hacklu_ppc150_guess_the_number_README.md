﻿## guessthenumber (ppc, 150+80p)

	the teacher of your programming class gave you a tiny little task: just write a guess-my-number script that beats his script. he also gave you some hard facts:
	he uses some lcg with standard glibc lcg parameters
	the lcg is seeded with server time using number format ymdhms (python strftime syntax)
	numbers are from 0 up to (including) 99
	numbers should be sent as ascii string
	you can find the service on school.fluxfingers.net:1523

### pl
[eng](#eng-version)

pierwsze podejście do zadania polegało na implementacji opisanego w zadaniu lcg i próbie dopasowania wyników do zgadywanki z serwera. jednak bardzo szybko uznaliśmy, że możliwości jest bardzo dużo i nie ma sensu ich analizować skoro da się to zadanie wykonać dużo prościej.
do zgadnięcia mamy zaledwie 100 liczb pod rząd a rozdzielczość zegara na serwerze to 1s. w związku z tym uznaliśmy, że prościej i szybciej będzie po prostu oszukiwać w tej grze :)

wiemy że liczby generowane są przez lcg co oznacza, że dla danego seeda liczby do zgadnięcia są zawsze takie same. w szczególności jeśli dwóch użytkowników połączy się w tej samej sekundzie to wszystkie 100 liczb do zgadnięcia dla nich będzie takie samo. dodatkowo serwer zwraca nam liczbę której oczekiwał jeśli się pomylimy.

nasze rozwiązanie jest dość proste:

* uruchamiamy 101 wątków, które w tej samej sekundzie łączą się z docelowym serwerem.
* synchronizujemy wątki tak, żeby wszystkie zgadywały jedną turę w tej samej chwili a następnie czekały aż wszystkie skończą.
* w każdej turze wszystkie wątki oprócz jednego czekają na liczbę do wysłania.
* w każdej iteracji jeden wątek "poświęca się" wysyłając -1 jako odpowiedź, a następnie odbiera od serwera poprawną odpowiedź i informuje o niej pozostałe wątki.
* w efekcie co turę "tracimy" jeden wątek, ale wszystkie pozostałe przechodzą do następnej tury podając poprawną odpowiedź.

każdy wątek realizuje poniższy kod:

```python
max = 101
threads = queue()
correct_values = queue()
init_barier = threading.barrier(max)
init_barier_seeds = threading.barrier(max)
bar = [threading.barrier(max - i) for i in range(max)]
seeds = set()


def worker(index):
    threads.get()
    init_barier.wait()
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("school.fluxfingers.net", 1523))
    initial_data = str(s.recv(4096))
    seeds.add(parse_seed(initial_data))
    init_barier_seeds.wait()
    if len(seeds) != 1:  # make sure we all start with the same seed, otherwise quit
        threads.task_done()
        return
    for i in range(max):
        bar[i].wait() #wait on the barrier for all other threads
        if i == index:  # suicide thread
            value = -1
        else:
            value = correct_values.get()
        s.send(bytes(str(value) + "\n", "ascii"))
        data = str(s.recv(4096))
        print("thread " + str(index) + " iteration " + str(i) + " " + data)
        if "wrong" in data.lower():
            correct = re.compile("'(\d+)'").findall(data)[0]
            for j in range(max - i - 1):  # tell everyone what is the right number
                correct_values.put(correct)
            break
    threads.task_done()
```

kompletny skrypt dostępny [tutaj](guess.py)

uruchamiamy skrypt i dostajemy:
```
thread 98 iteration 97 b'correct! guess the next one!\n'
thread 99 iteration 97 b'correct! guess the next one!\n'
thread 100 iteration 97 b'correct! guess the next one!\n'
thread 98 iteration 98 b"wrong! you lost the game. the right answer would have been '38'. quitting."
thread 99 iteration 98 b'correct! guess the next one!\n'
thread 100 iteration 98 b'correct! guess the next one!\n'
thread 99 iteration 99 b"wrong! you lost the game. the right answer would have been '37'. quitting."
thread 100 iteration 99 b"congrats! you won the game! here's your present:\nflag{don't_use_lcgs_for_any_guessing_competition}"
```

`flag{don't_use_lcgs_for_any_guessing_competition}`

### eng version

initial attempt for this task was to implement described lcg and trying to match the output for the results on the server. but we instantly decided that there are too many possibilities and there is no point in wasting time for analysis when we can do it much easier.
we need to guess only 100 numbers in a row and the clock resolution on the server is just 1s. so we decided that it will be better and faster just to cheat the game :)

we know that the numbers are generated with lcg which means that for given seed the numbers are always the same. in particular, if two users connect at the same time the 100 numbers to guess will be identical. on top of that the server returns the expected number if we make a mistake.

our solution was quite simple:

* run 101 threads, which will connect to the server at the same time.
* synchronize the threads so that they all execute a single turn and the wait for the rest.
* in each turn all threads but one are waiting for the number to send.
* in each turn one thread "sacrifices himself" sending -1 as answer, and the collects the correct number form server response and informs rest of the threads about it.
* as a result in each turn we "lose" one thread but all the others pass to the next round.

eaach thread executes:

```python
max = 101
threads = queue()
correct_values = queue()
init_barier = threading.barrier(max)
init_barier_seeds = threading.barrier(max)
bar = [threading.barrier(max - i) for i in range(max)]
seeds = set()


def worker(index):
    threads.get()
    init_barier.wait()
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("school.fluxfingers.net", 1523))
    initial_data = str(s.recv(4096))
    seeds.add(parse_seed(initial_data))
    init_barier_seeds.wait()
    if len(seeds) != 1:  # make sure we all start with the same seed, otherwise quit
        threads.task_done()
        return
    for i in range(max):
        bar[i].wait() #wait on the barrier for all other threads
        if i == index:  # suicide thread
            value = -1
        else:
            value = correct_values.get()
        s.send(bytes(str(value) + "\n", "ascii"))
        data = str(s.recv(4096))
        print("thread " + str(index) + " iteration " + str(i) + " " + data)
        if "wrong" in data.lower():
            correct = re.compile("'(\d+)'").findall(data)[0]
            for j in range(max - i - 1):  # tell everyone what is the right number
                correct_values.put(correct)
            break
    threads.task_done()
```

complete script is [here](guess.py).

we run the script and we get:
```
thread 98 iteration 97 b'correct! guess the next one!\n'
thread 99 iteration 97 b'correct! guess the next one!\n'
thread 100 iteration 97 b'correct! guess the next one!\n'
thread 98 iteration 98 b"wrong! you lost the game. the right answer would have been '38'. quitting."
thread 99 iteration 98 b'correct! guess the next one!\n'
thread 100 iteration 98 b'correct! guess the next one!\n'
thread 99 iteration 99 b"wrong! you lost the game. the right answer would have been '37'. quitting."
thread 100 iteration 99 b"congrats! you won the game! here's your present:\nflag{don't_use_lcgs_for_any_guessing_competition}"
```

`flag{don't_use_lcgs_for_any_guessing_competition}`