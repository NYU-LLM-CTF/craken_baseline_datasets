# writeup seccon 2016 quals

team: nazywam, c7f.m0d3, cr019283, akrasuski1, rev, shalom

### table of contents

* [vigenere (crypto 100)](vigenere)
* [voip (forensics 100)](voip)
* [basiq (web)](web_100_basiq)
* [memory analysis (forensics)](memory)
* [uncomfortable web (web 300)](web_300_uncomfortable_web)