﻿##trivia 3 (trivia, 300p)

	we got this log which is highly compressed. find the intruder's secret.

###pl
[eng](#eng-version)

###eng version
