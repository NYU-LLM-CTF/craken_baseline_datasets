﻿##unickle (web, 200p)

	osaas is the new trend for 2016! store your object directly in the cloud. get rid of the hassle of managing your own storage for object with osaas. unickle currently offers a beta version that demonstrates how osaas will make the internet a better place... one object at a time!!

###pl
[eng](#eng-version)

###eng version
