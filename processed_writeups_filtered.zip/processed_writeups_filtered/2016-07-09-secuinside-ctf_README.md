# writeup secuinside ctf 2016

team: c7f.m0d3, cr019283, nazywam, other19, rev, msm, shalom

### table of contents

* [sbbs (web)](sbbs)
* [trendyweb (web)](trendyweb)

