﻿## ure (crypto, 100p)

    universal reencryption


###eng
[pl](#pl-version)

we have to change ciphertext in such way, that after decrypting plaintext is unchanged:


[image extracted text: universal re-encryption
letp be a prime, and g be an element
of z; of prime order 9-
letx € zq be the private key; and h = g" (modp) be the public key:
to encrypt a message
z , pick two random values r, s € zy and compute
the ciphertext as follows:
(a, b,€,d) = (g ,w, g ,mk)
download a valid ciphertext & = (a, b,c,d) below;
compute another valid
ciphertext &' = (a', b' , &' , d) such that:
and &' decrypt to the same message;
2.a f &' and b # b' and c # c' and d #d
download
ext
enter the quadruple (a', b' , c' , d) here:
ail numbers are assumed to be in hexadecimal (without "ox" prefix)
ox
hexadecimal value for
ox
hexadecimal value for b"
ox
hexadecimal value for c'
d'
ox
hexadecimal value for d"
yt r ty r
captcha
submit query
and
cipherte]


we need to think about what task authors really want from us - in mathematical terms. `r` and `s` are random numbers, so if we substitute them with another numbers
plaintext will surely be unchanged.

so if we change `(g^r, h^r, g^s, mh^s)` to `(g^x, h^x, g^y, mh^y)` (for any x != r, y != s) then task is solved.

we tried few possibilities, but after not very long time we came to good substitution:

    r -> r+r
    s -> r+s

our solver demonstrating that substitution (basic algebra is enough to prove it right)

```python
def solve(a, b, c, d, p):
    # a = g^r 
    # b = h^r
    # c = g^s
    # d = m*g^xs
    return [x%p for x in [
        a*a, # g^(r+r)
        b*b, # h^(r+r)
        a*c, # g^(r+s)
        d*b  # m*h^(r+s)
    ]]
```

and our solution

    a': 3287406693040037454338117703746186185132137914785835752950604845777415758360615360784432898128185782894436154048036406523549199332371675403330587908658389
    b': 3106361558536896198315490627917020257039985078045091925325167930756012775219021778274538316287957153184501076513389822529518252243096913454042609623430979
    c': 2705749471178411581710759303917406711797848509917528975018497036876024862091214580659339932929912633743841281275200381261759865873903109533343463983599973
    d': 5373483039142295785146805049046423326555571326092245347871091138664843112902523040473342171017639501524961161720758693343930112103298610080325764680063048

###pl version

naszym zadaniem jest zmiana ciphertextu tak, aby po zdeszyfrowaniu jego zawartośc (plaintext) się nie zmieniła:


[image extracted text: universal re-encryption
letp be a prime, and g be an element
of z; of prime order 9-
letx € zq be the private key; and h = g" (modp) be the public key:
to encrypt a message
z , pick two random values r, s € zy and compute
the ciphertext as follows:
(a, b,€,d) = (g ,w, g ,mk)
download a valid ciphertext & = (a, b,c,d) below;
compute another valid
ciphertext &' = (a', b' , &' , d) such that:
and &' decrypt to the same message;
2.a f &' and b # b' and c # c' and d #d
download
ext
enter the quadruple (a', b' , c' , d) here:
ail numbers are assumed to be in hexadecimal (without "ox" prefix)
ox
hexadecimal value for
ox
hexadecimal value for b"
ox
hexadecimal value for c'
d'
ox
hexadecimal value for d"
yt r ty r
captcha
submit query
and
cipherte]


można się zastanowić czego dokładnie chcą od nas twórcy zadania w "matematycznych" słowach. `r` i `s` są liczbami losowymi, więc jeśli uda nam się je zamienić,
otrzymamy jednocześnie rozwiązanie zadania.

tzn. jeśli bylibyśmy w stanie zamienić `(g^r, h^r, g^s, mh^s)` na `(g^x, h^x, g^y, mh^y)` (dla jakiegoś x != r, y != s) to mamy rozwiązanie zadania.

przy rozwiązaniu było trochę kombinowania, ale szybko wpadliśmy na podmianę którą można było łatwo wykonać:

    r -> r+r
    s -> r+s

nasz solver demonstrujący podmianę (podstawy algebry wystarczą żeby udowodnić poprawność rozwiązania):

```python
def solve(a, b, c, d, p):
    # a = g^r 
    # b = h^r
    # c = g^s
    # d = m*g^xs
    return [x%p for x in [
        a*a, # g^(r+r)
        b*b, # h^(r+r)
        a*c, # g^(r+s)
        d*b  # m*h^(r+s)
    ]]
```

i rozwiązanie:

    a': 3287406693040037454338117703746186185132137914785835752950604845777415758360615360784432898128185782894436154048036406523549199332371675403330587908658389
    b': 3106361558536896198315490627917020257039985078045091925325167930756012775219021778274538316287957153184501076513389822529518252243096913454042609623430979
    c': 2705749471178411581710759303917406711797848509917528975018497036876024862091214580659339932929912633743841281275200381261759865873903109533343463983599973
    d': 5373483039142295785146805049046423326555571326092245347871091138664843112902523040473342171017639501524961161720758693343930112103298610080325764680063048
