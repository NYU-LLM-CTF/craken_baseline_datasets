# writeup tokyo westerns ctf 2017

team: c7f.m0d3, shalom, akrasuski1, nazywam, psrok1, cr019283, msm

### table of contents

* [my simple cipher (crypto)](crypto_simple)
* [freshen uploader (web)](web_uploader)
* [baby rsa (crypto)](crypto_rsa)
* [private local comment (ppc)](ppc_plc)
* [baby dlp (crypto)](crypto_dlp)
* [baby pinhole (crypto)](crypto_pinhole)
