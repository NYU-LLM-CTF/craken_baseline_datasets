## calculator (ppc/programming, 200p)

### pl version
[click for eng](#eng-version)

zadanie polegało na połączeniu się za pomocą nc z podanym serwerem. serwer podawał na wejściu działania i oczekiwał na ich rozwiązania. należało rozwiązać kilkadziesiąt przykładów pod rząd aby uzyskać flagę. działania przychodzące z serwera miały postać:

`eight hundred ninety nine million, one hundred sixty eight thousand eleven - 556226 * ( 576 - 21101236 ) * 948 - ( 29565441 + thirty six ) * 182,745 - 6,124,792 + cmlxxvi - 647 =`

na co serwer w odpowiedzi oczekiwał na: `11121023402232863`

zadanie rozwiązaliśmy wykorzystując parser liczb słownych, parser liczb rzymskich oraz pythonową funkcję `eval()`.
same transformacje są raczej trywialne i łatwie do znalezienia w internecie (cały skrypt [tutaj](calculator.py) ), reszta solvera to:

	def solve(data):
		fixed = data.replace(",", "") #turn 3,200 into 3200
		fixed = " " + fixed #ensure word boundary on the left
		romans = re.findall("[^\d=\\-\\+/\\*\\(\\)\s]+", fixed)
		for romannumber in romans:
			try:
				number = str(fromroman(romannumber))
				fixed = re.sub(r"\b%s\b" % romannumber, number, fixed)
			except:
				pass
		literals = re.findall("[^\d=\\-\\+/\\*\\(\\)]+", fixed)
		for literal in sorted(literals, key=lambda x: len(x), reverse=true):
			if literal != ' ' and literal != "":
				try:
					number = str(text2int(literal))
					fixed = re.sub(r"\b%s\b" % literal.strip(), number, fixed)
				except:
					pass
		return eval(fixed[:-2]) #omit " ="

czyli w skrócie:

* usuwamy przecinki będące separatorami tysiąców
* zamieniamy wszystkie znalezione liczby rzymskie na arabskie
* zamieniamy wszystkie znalezione literały na liczby arabskie (uwaga: trzeba zamieniać od tych najdłuższych, żeby np. zamiana "one" nie była plikowana do "fifty one")
* usuwamy znak `=` z końca
* ewaluujemy wyrażenie

po kilkudziesieciu przykładach dostajemy: `congratulations!the flag is tmctf{u d1d 17!}`

### eng version

the challenge was to connect to a server via nc. server was providing equations and was waiting for their solutions. we had to solve few dozens consecutively in order to get the flag. the equations were for example:

`eight hundred ninety nine million, one hundred sixty eight thousand eleven - 556226 * ( 576 - 21101236 ) * 948 - ( 29565441 + thirty six ) * 182,745 - 6,124,792 + cmlxxvi - 647 =`

and server was expecting a solution: `11121023402232863`

we solved this using literal nubmbers parser, roman numbers parser and python `eval()` function.
the parsers are trivial and easy to find on the internet (whole script [here](calculator.py) ), the rest was:

	def solve(data):
		fixed = data.replace(",", "") #turn 3,200 into 3200
		fixed = " " + fixed #ensure word boundary on the left
		romans = re.findall("[^\d=\\-\\+/\\*\\(\\)\s]+", fixed)
		for romannumber in romans:
			try:
				number = str(fromroman(romannumber))
				fixed = re.sub(r"\b%s\b" % romannumber, number, fixed)
			except:
				pass
		literals = re.findall("[^\d=\\-\\+/\\*\\(\\)]+", fixed)
		for literal in sorted(literals, key=lambda x: len(x), reverse=true):
			if literal != ' ' and literal != "":
				try:
					number = str(text2int(literal))
					fixed = re.sub(r"\b%s\b" % literal.strip(), number, fixed)
				except:
					pass
		return eval(fixed[:-2]) #omit " ="

so in short:

* we remove thousands separator `,`
* we turn all roman numbers into integers
* we turn all literal numbers into integers (notice: you need to replace starting from longest numbers so that for example replacing "one" doesn't affect "fifty one")
* we remove `=` from the end
* we evaluate the expression

after mutiple examples we finally get:`congratulations!the flag is tmctf{u d1d 17!}`
