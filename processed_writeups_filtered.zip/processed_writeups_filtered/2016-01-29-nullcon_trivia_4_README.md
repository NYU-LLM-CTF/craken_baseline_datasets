﻿##trivia 4 (trivia, 400p)

	bill gates loves cipher.

###pl
[eng](#eng-version)

###eng version
