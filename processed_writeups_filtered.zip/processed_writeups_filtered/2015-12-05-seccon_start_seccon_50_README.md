## start seccon ctf (exercise, 50p)

    ex1
    cipher:pxfr}qivtmszcndkuwagjb{lhyeo
    plain: abcdefghijklmnopqrstuvwxyz{}

    ex2
    cipher:ev}zzd{dwzra}ffdnfgqo
    plain: {helloworldsecconctf}

    quiz
    cipher:a}ffdnevpfsgv}kzpn}go
    plain: ?????????????????????


###pl
[eng](#eng-version)

bardzo proste rozgrzewkowe zadanie. szyfr który widać że jeden wejścia zawsze odpowiada takiemu samemu znaku wyjścia.

flaga:

    seccon{hacktheplanet}

rozwiązanie - zdekodowaliśmy ciphertext po prostu ręcznie.

### eng version

very easy exercise. it's obvious that in given cipher each ciphertext character is always decoded to the same character.

flag:

    seccon{hacktheplanet}

solution - we just did the decoding by hand.
