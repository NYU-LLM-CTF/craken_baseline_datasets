## tonnerre (crypto, 200 points, 119 solves)

	we were pretty sure the service at tonnerre.pwning.xxx:8561 (source) was totally secure. 
	but then we came across this website and now we’re having second thoughts... 
	we think they store the service users in the same database?

###eng
[pl](#pl-version)

this task consisted of two parts: website vulnerable to sql injection and server authenticating via `zero knowledge proof protocol` specifically `secure remote password protocol`.

using [script](doit.py) we quickly exploited the sql vulnerability to dump information about the only user stored in database: `username`, `verifier` and `salt` (although we didn't need salt).

the next part was forcing [server script](public_server.py) to authenticate us and get the flag.
the idea of zero knowledge proof is that the server aka `verifier` knows a `secret` and challenges the user to prove that the user also knows the `secret`.
this has to happen without disclosing the `secret` itself so no part of the `secret` should ever be transmitted.
the general approach to this problem is that the `verifier` provides a random task that can be solved only by someone with `secret`.

in our case the server prompted us for some number (denoted as `pc`) and calculated:

```
c=(pc*v)%n
if c not in forbidden set:
	r=random(2,n-3)
	ps=(g**r)%n
	res=(ps+v)%n
	secret=((pc*b)**r)%n
	key=f(res, secret)
```

it then sent us `res` and asked for resulting key.

we know `n` and `g` from the source code, while `v` is the verifier value we extracted via sql injection.

it is easy to see that if we know `res`, we can calculate `ps`.
this is because `ps` has to be less than `n` (it is reminder from division modulo `n`) and we know the value of `v` which is in the same order as `n`.
this implies that `ps+v` has to be between `v` and `2n-1` and thus the modular division reminder of `res=(ps+v) mod n` can be:

- bigger than `v` which means that `ps` was small enough that the sum `ps+v` did not exceed `n` and this means the `ps = res - v`
- smaller than `v` and this means the actual sum was greater than `n` and got cut by modulo and therefore `ps = res - v + n`

our case was the second one.

now the task can be stated  as follows:
```
given ps, n, v, g
knowing ps=g**r % n,
 find (pc*v)**r % n for any pc.
```

we can see that the numbers we need to find and the one we know are quite similar - they are both something to the power of `r` modulo `n`. 
if we make bases equal, we would succeed. 
indeed, it is quite easy to find solution of equation:

```
pc*v=g (mod n)
```

we can multiply both sides by modular inverse of `v` mod `n` and get:

```
pc*v*modinv(v)=g*modinv(v) (mod n)
pc=g*modinv(v) (mod n)
```

unfortunately, this solution would not be accepted, as this particular `pc` is in forbidden set.
so are also the obvious solutions like `pc=0` which would give `0**r % n = 0`

since the only thing we can use is the value of `g**r (mod n)` it's clear that the `pc*v` has to be connected with `g`.
we also know that the most natural operation when dealing with modular powers are powers so we figure that we could square our "known" equation, to get:
```
ps**2=(g**2)**r (mod n)
```

so we know the value of `(g**2)**r (mod n)` and we need to convince the server to ask us to provide this value, so we need to provide such `pc` so that `pc*v mod n == g**2 mod n`

repeating steps above to this equation, we get:

```
pc=(g**2)*modinv(v) (mod n)
```

and therefore is we provide such `pc` the server will ask us for the value of:

```
(pc*v)**r = ((g**2)*modinv(v)*v)**r = (g**2)**r = (g**r)**2 = ps**2 (mod n)
```

and since we know `ps`, the task is solved and the flag is `pctf{srp_v1_best_srp_c0nf1rm3d}` - actual implementation is [here](solve.py).

###pl version

zadanie składało się z dwóch części: strony podatnej na sql injection oraz serwera autentykującego za pomocą `zero knowledge proof protocol`, konkretnie `secure remote password protocol`.

korzystając ze [skryptu](doit.py) szybko exploitowalismy podatność sql i pobralismy informacje na temat jedynego użytkownika z nazy danych - `username`, `verifier` i `salt` (akurat salt nie był nam potrzebny).

następny krok to zmuszenie [skryptu serwera](public_server.py) aby nas zautentykował i podał flagę.
idea zero knowledge proof polega na tym, ze server czyli `verifier` zna pewien `sekret` i daje użytkownikowi do rozwiązania zadanie które ma potwierdzić że użytkownik także zna `sekret`.
to musi odbywać się bez odkrycia `sekretu` więc żadna jego część nie może zostać transmitowana.
ogóle podejście do tego problemu polega na tym, że `verifier` generuje losowe zadanie możliwe do rozwiązania tylko przez kogoś z `sekretem`

w naszym przypadku serwer pytał o pewną liczbę (oznaczoną dalej jako `pc`) i obliczał:

```
c=(pc*v)%n
if c not in forbidden set:
	r=random(2,n-3)
	ps=(g**r)%n
	res=(ps+v)%n
	secret=((pc*b)**r)%n
	key=f(res, secret)
```

następnie przesyłał nam wartość `res` i pytał o wynikowy klucz.

wiemy ile wynoszą `n` oraz `g` z źródła serwera, podczas gdy `v` zostało przez nas wyciągnięte z bazy danych przez sql injection.

łatwo zauważyć że jeśli znamy `res` to możemy łatwo policzyć `ps`.
wynika to z faktu, że `ps` musi być mniejsze od `n` (to reszta z dzielenia przez `n`) oraz znamy wartość `v` która jest tego samego rzędu co `n`.
to oznacza, że `ps+v` musiby być pomiędzy `v` i `2n-1` a z tego wynika że reszta z dzielenia modulo `res=(ps+v) mod n` może być:

- większa od `v` co znaczy, że `ps` było małe i suma nie przekroczyła `n` i tym samym `ps = res - v`
- mniejsza od `v` co znaczy, że suma była większa od `n` i została obcięta przez modulo i tym samym `ps = res - v + n`

w naszym przypadku prawdziwa była sytuacja numer 2.

teraz zadanie można przedstawić jako:
```
mając dane ps, n, v, g
wiedząc że ps=g**r % n,
 znajdź (pc*v)**r % n dla pewnego pc.
```

możemy zauważyć, że liczby których szukamy i które znamy są dość podobne - i tutaj i tutaj mamy `r`-te potęgi modulo `n`.
gdybyśmy mogli ustalić identyczne podstawy potęg rozwiązalibyśmy zadanie.
łatwo wyliczyć potrzebną wartość `pc` z równania:

```
pc*v=g (mod n)
```

możemy obustronnie pomnożyć to przez modinv `v` mod `n` i dostajemy:

```
pc*v*modinv(v)=g*modinv(v) (mod n)
pc=g*modinv(v) (mod n)
```

niestety takie rozwiązanie znajduje się w zbiorze zabronionych wartości dla `pc`.
podobnie jest z innymi oczywistymi rozwiązaniami jak `pc=0` które dałoby łatwe do przewidzenia `0**r % n = 0`

jako że jedyna wartość którą możemy wykorzystać to `g**r (mod n)` jest jasne że `pc*v` musi mimo wszystko być powiązane z `g`.
wiemy też, że najbardziej naturalną operacją kiedy mamy do czynienia z potęgowaniem jest potęgowanie, dochodzimy więc do wniosku, że moglibyśmy podnieść znane równanie do kwadratu dostając:

```
ps**2=(g**2)**r (mod n)
```

wiemy więc teraz ile wynosi `(g**2)**r (mod n)` i potrzebujemy przekonać serwer aby spytał nas o tą właśnie wartość, więc musimy dostarczyć takie `pc` że `pc*v mod n == g**2 mod n`

wykonujac kroki podobne jak powyżej dla nowego równania dostajemy:

```
pc=(g**2)*modinv(v) (mod n)
```

i tym samym jeśli podamy tak wyliczone `pc` serwer zapyta nas o:

```
(pc*v)**r = ((g**2)*modinv(v)*v)**r = (g**2)**r = (g**r)**2 = ps**2 (mod n)
```

a wartość `ps` jest nam znana więc zadanie jest rozwiązane i flaga to `pctf{srp_v1_best_srp_c0nf1rm3d}` - całe rozwiązanie dostępne [tutaj](solve.py)

