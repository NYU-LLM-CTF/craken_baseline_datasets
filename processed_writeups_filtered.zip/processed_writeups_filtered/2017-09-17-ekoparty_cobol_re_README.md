# cobol (re, 485p, 10 solved)

in the task we get an old [ibm savf file](eko.savf).
unlike last year, where we could just load it to some online tools, this time the file was corrupted.

we quickly had a look around at the file contents, decoded from ebcdic string encoding, but the flag string seemed permutated, so we guessed we actually have to recover the binary and reverse it.
this was a huge mistake.
we wasted quite some time trying to fix this file, which had some checksum failures.

after a while we tried one more time to look at the strings:

```python
import codecs
import ebcdic

def decode():
    with codecs.open("eko.savf", 'rb') as input_file:
        print(input_file.read().decode('cp1148'))
```

we can see there a nice section:

```
you are rightwe}m_a4rreg0_rrpun+0ni04ngsa_o+7ut3313f_+rgo3hodt0_in4de{oaske  nope], your secret is wrong]
```

and from this we guess that the part:

```
}m_a4rreg0_rrpun+0ni04ngsa_o+7ut3313f_+rgo3hodt0_in4de{oaske
```

is the mangled flag.
it's clear it's inverted, so we invert it back:

```
eksao{ed4ni_0tdoh3ogr+_f3133tu7+o_asgn40in0+nuprr_0gerr4a_m}
```

we know that the flag starts with `eko{` so we need to take 2 characters, remove next 2, and again take 2.
we guessed we will check what happens if we proceed like this:

```
eko{4n0th3r+31tuo_gninnur_era_ew
```

and inverted:

```
we_are_running_out13+r3ht0n4{oke
```

so we're on a good track, and we have first half of the flag.
since the second half is also not random, we decided to do our take-2-leave-2, but with offset of 2:

```
saedi_doog_f337+as400+pr0gr4m}
}m4rg0rp+004sa+733f_good_ideas
```

this way we get a second half of the flag and rest of the message blended in:

```
eko{4n0th3r+31337+as400+pr0gr4m}
we_are_running_outf_good_ideas
```

as can is noticable now, we could have just removed all uppercase and `_` characters from the initial string to get the flag as well.
