# des (crypto 500)

###eng
[pl](#pl-version)

the general idea was simple -  the authors used double encryption with des and blowfish and the task was to decode the message.

the problems:

* authors used some shady website for encryption and not the ciphers directly. this website was adding random paddings and without knowing about it, there was no way to solve it. fortunately this was released as a hint.
* the authors for no apparent reason have given an example payload apart from the flag. this suggested a meet-in-the-middle attack using this payload, which was not a good approach, because the example payload was encrypted with different keys than the flag.
* the calculations for this task were a bit time consuming due to key universum size. seriously, there is no need to make a task where bruteforce is taking minutes to run on 8 paralell cores. it doesn't make the task any "harder", only more annoying.

so what we have here is the encrypted flag:

```
aiejlyxirulgg+oyayje5howvs8ufegdxrrcsiiy6pbh67fdvgblf/gtzihyw7wyvorsi7/n1sgavubu/vw1nweorohguzzfp5t7gw88smx9kfeplfsjolpkkvuumbvu6lno0fjjbu+7ft1vtdsqhah1lc91sdcduoi3j1fwffwwewy1l7fkjg14lz9fgamf5c43t8avl+bpobdfhipzk1mwv4ftvt6k5uv13cpv3vlm+jx7q/7llamyqlluu0o1pckzohi7oypngpfh7vmipijwcsmocayt8+yc/uqngpfuod0shfg7tvz7f8szkl6rfezlvfn++8b+rs+6agoishcmngbo4pncodzfwp4lyzqriz/dtn4ntg==
```

and we know that the flag was encrypted first with des with padding, the data were transformed into base64 and this was encrypted again with blowfish with padding and it was encoded as base64.
we also know that both keys are in the range 0-9999999.

so we run bruteforce first on the outer layer - to decode blowfish and take all proper base64 results as potential hits.
and then we take those results and try to decode them with des to look for the flag.
there is slim chance that such long payload decoded with improper blowfish key would give us base64 string, and in fact we got only a single hit there.
so we run the bruteforecer:

```python
import base64
import string
from crypto.cipher import des, blowfish
from multiprocessing import freeze_support
from src.crypto_commons.brute.brute import brute


def is_printable(decrypted):
    for i in range(len(decrypted)):
        if decrypted[i] not in string.printable:
            return false
    return true


def combine(partials):
    results = {}
    for partial in partials:
        for key, value in partial.items():
            results[key] = value
    return results


def worker_blowfish(data):
    first, payload = data
    results = {}
    for i in range(10000000):
        key = str(first) + '{:07}'.format(i)
        e = blowfish.new(key)
        decrypted = e.decrypt(payload)[8:]
        try:
            if is_printable(decrypted[:-8]):
                real_data = base64.b64decode(decrypted)[8:]
                results[key] = real_data
                print('potential match ', key, real_data)
        except:
            pass
    return results


def worker_des(data):
    first, payload = data
    results = {}
    for i in range(10000000):
        key = str(first) + '{:07}'.format(i)
        e = des.new(key)
        decrypted = e.decrypt(payload)[8:]
        if is_printable(decrypted[:-8]):
            results[key] = decrypted
            print('potential flag ', key, decrypted)
    return results


def main():
    cipher = base64.b64decode(
        'aiejlyxirulgg+oyayje5howvs8ufegdxrrcsiiy6pbh67fdvgblf/gtzihyw7wyvorsi7/n1sgavubu/vw1nweorohguzzfp5t7gw88smx9kfeplfsjolpkkvuumbvu6lno0fjjbu+7ft1vtdsqhah1lc91sdcduoi3j1fwffwwewy1l7fkjg14lz9fgamf5c43t8avl+bpobdfhipzk1mwv4ftvt6k5uv13cpv3vlm+jx7q/7llamyqlluu0o1pckzohi7oypngpfh7vmipijwcsmocayt8+yc/uqngpfuod0shfg7tvz7f8szkl6rfezlvfn++8b+rs+6agoishcmngbo4pncodzfwp4lyzqriz/dtn4ntg==')
    data = [(i, cipher) for i in range(10)]
    partials = brute(worker_blowfish, data, 10)
    candidates = combine(partials)
    print(candidates)

    for candidate_key, candidate_value in candidates.items():
        data = [(i, candidate_value) for i in range(10)]
        partials = brute(worker_des, data, 10)
        print(combine(partials))


if __name__ == '__main__':
    freeze_support()
    main()
```

where brute() comes from our crypto-commons and is simply:

```python
import multiprocessing


def brute(worker, data_list, processes=8):
    """
    run multiprocess workers
    :param worker: worker function
    :param data_list: data to distribute between workers, one entry per worker
    :param processes: number of parallel processes
    :return: list of worker return values
    """
    pool = multiprocessing.pool(processes=processes)
    return pool.map(worker, data_list)
```

from this we get the decoded data:

```
zeronights is a perfect place to discuss new attack methods and threats. it shows ways to attack and defend to its guests, and suggests unorthodox approach to cybersecurity problems solving.  
```

###pl version

generalna idea zadania była dość prosta - autorzy zaszyfrowali flagę najopiers desem a potem blowfishem a naszym zadaniem jest ją zdekodować.

problemy:

* autorzy użyli jakiejś dziwnej strony do szyfrowania, a nie bezpośrednio szyfrów. ta strona dodawała losowy padding i jeśli o tym nie wiemy to nie damy rady zrobić zadania. na szczęście później zotało to ujęte jako hint.
* autorzy bez powodu dodali w zadaniu drugi payload oprócz flagi. było to mocno mylące bo suguerowało atak meet-in-the-middle, który był tutaj błędem, ponieważ przykładowy payload używał innych kluczy niż flaga.
* obliczenia były czasochłonne ze względu na rozmiar kluczy. poważnie, nie ma potrzeby podawać w zadaniu danych wymagajacych minut obliczeń na 8 równoległych rdzeniach. to wcale nie sprawia że zadanie jest "trudniejsze", tylko bardziej wkurzające.

mamy daną zaszyfrowaną flagę:

```
aiejlyxirulgg+oyayje5howvs8ufegdxrrcsiiy6pbh67fdvgblf/gtzihyw7wyvorsi7/n1sgavubu/vw1nweorohguzzfp5t7gw88smx9kfeplfsjolpkkvuumbvu6lno0fjjbu+7ft1vtdsqhah1lc91sdcduoi3j1fwffwwewy1l7fkjg14lz9fgamf5c43t8avl+bpobdfhipzk1mwv4ftvt6k5uv13cpv3vlm+jx7q/7llamyqlluu0o1pckzohi7oypngpfh7vmipijwcsmocayt8+yc/uqngpfuod0shfg7tvz7f8szkl6rfezlvfn++8b+rs+6agoishcmngbo4pncodzfwp4lyzqriz/dtn4ntg==
```

wiemy że flaga została najpierw zaszyfrowana desem z paddingiem, następnie enkodowana base64 i zaszyfrowana blowfishem z paddingiem i znów enkodowana base64.
wiemy że klucze są z zakresu 0-9999999.

uruchamiamy więc brute-forcer najpierw na zewnętrznej warstwie - aby deszyfrować blowfisha i wziąć wszystkie poprawne base64 jako potencjalne trafienia.
następnie próbujemy dekodować je desem szukając flagi.
jest niewielka szansa że payload dekodowany blowfishem z losowym kluczem da nam poprawny base64 i faktycznie był tylko jeden poprawny ciąg.
więc uruchamiamy bruteforcer:

```python
import base64
import string
from crypto.cipher import des, blowfish
from multiprocessing import freeze_support
from src.crypto_commons.brute.brute import brute


def is_printable(decrypted):
    for i in range(len(decrypted)):
        if decrypted[i] not in string.printable:
            return false
    return true


def combine(partials):
    results = {}
    for partial in partials:
        for key, value in partial.items():
            results[key] = value
    return results


def worker_blowfish(data):
    first, payload = data
    results = {}
    for i in range(10000000):
        key = str(first) + '{:07}'.format(i)
        e = blowfish.new(key)
        decrypted = e.decrypt(payload)[8:]
        try:
            if is_printable(decrypted[:-8]):
                real_data = base64.b64decode(decrypted)[8:]
                results[key] = real_data
                print('potential match ', key, real_data)
        except:
            pass
    return results


def worker_des(data):
    first, payload = data
    results = {}
    for i in range(10000000):
        key = str(first) + '{:07}'.format(i)
        e = des.new(key)
        decrypted = e.decrypt(payload)[8:]
        if is_printable(decrypted[:-8]):
            results[key] = decrypted
            print('potential flag ', key, decrypted)
    return results


def main():
    cipher = base64.b64decode(
        'aiejlyxirulgg+oyayje5howvs8ufegdxrrcsiiy6pbh67fdvgblf/gtzihyw7wyvorsi7/n1sgavubu/vw1nweorohguzzfp5t7gw88smx9kfeplfsjolpkkvuumbvu6lno0fjjbu+7ft1vtdsqhah1lc91sdcduoi3j1fwffwwewy1l7fkjg14lz9fgamf5c43t8avl+bpobdfhipzk1mwv4ftvt6k5uv13cpv3vlm+jx7q/7llamyqlluu0o1pckzohi7oypngpfh7vmipijwcsmocayt8+yc/uqngpfuod0shfg7tvz7f8szkl6rfezlvfn++8b+rs+6agoishcmngbo4pncodzfwp4lyzqriz/dtn4ntg==')
    data = [(i, cipher) for i in range(10)]
    partials = brute(worker_blowfish, data, 10)
    candidates = combine(partials)
    print(candidates)

    for candidate_key, candidate_value in candidates.items():
        data = [(i, candidate_value) for i in range(10)]
        partials = brute(worker_des, data, 10)
        print(combine(partials))


if __name__ == '__main__':
    freeze_support()
    main()
```

gdzie brute() jest z naszego crypto-commons i to zwyczajnie:

```python
import multiprocessing


def brute(worker, data_list, processes=8):
    """
    run multiprocess workers
    :param worker: worker function
    :param data_list: data to distribute between workers, one entry per worker
    :param processes: number of parallel processes
    :return: list of worker return values
    """
    pool = multiprocessing.pool(processes=processes)
    return pool.map(worker, data_list)
```

z tego dostajemy zdekodowane dane:

```
zeronights is a perfect place to discuss new attack methods and threats. it shows ways to attack and defend to its guests, and suggests unorthodox approach to cybersecurity problems solving.  
```