# the joy of painting (stegano 50)

###eng
[pl](#pl-version)

in the task we get an audio [file](thejoyofpainting.flac) with some german radio recording.
the task name suggest painting and we once made a very similar stegano on our own ctf so the first thing we checked was loading the file into audacity, displaying spectrogram and raising the frequency limit to some high value.
this gave us:


[image extracted text: x thejoyofpai
48k
mono, 93000hz
40k -
32-bitowy float
30k -
hxp{/i-1'm-four13r0ud-/in}
hxp {
cisza
solo
20k -
10k -
ok]


###pl version

w zadaniu dostajemy [plik](thejoyofpainting.flac) z nagraniem niemieckiego radia.
nazwa zadania sugeruje malowanie a my zrobiliśmy kiedyś bardzo podobne stegano na naszym własnym ctfie więc pierwsze co zrobiliśmy, to załadowanie pliku do audacity, wyświetlenie spektrogramu i podniesienie zakresów częstotliwości.
to dało nam:


[image extracted text: x thejoyofpai
48k
mono, 93000hz
40k -
32-bitowy float
30k -
hxp{/i-1'm-four13r0ud-/in}
hxp {
cisza
solo
20k -
10k -
ok]

