# writeup hack.lu ctf 2015

uczestniczyliśmy (msm, rev, shalom, other019, nazywam i pp) w hack.lu ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:
- ctf w środku tygodnia = bardzo słaby pomysł bo wszyscy w pracy albo w szkole więc na ctfa zostaje tylko kilka godzin...

opisy zadań po kolei.

# spis treści / table of contents:
* module loader 100+10 
* php golf 75+70
* stackstuff 150+80
* bashful 200+40
* creative cheating 150+60
* checkcheckcheck 150+80
* perl golf 75+50
* teacher's pinboard 352+100
* secret library 200+70 
* grading board 300+80
* [guessthenumber (ppc 150+80)](ppc150_guess_the_number)
* guessthenumber 150+80
* salt 200+90
* dr. bob 150+80

# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
