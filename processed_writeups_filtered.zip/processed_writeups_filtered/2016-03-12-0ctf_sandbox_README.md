## sandbox (pwn, 5p)
	
	escape from this broken sandbox
	notice: you have to solve the warmup task first. and try to get
	the flag at /home/sandbox/flag
	
we were given small [linux binary](sandbox):
```
sandbox: elf 64-bit lsb executable, x86-64, version 1 (sysv), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, for gnu/linux 2.6.24, buildid[sha1]=d833f31d8d8592636906d44b40da9bcdbc0d686b, stripped
```

based on task title and description we suspect that warmup challenge solved previously may be part of this tasks.
we verify this by run warmup exploit against new server.

as expected, exploit successfully retrieved flag from */home/warmup/flag* file.
the same exploit however fails to retrieve */root/home/sandbox/flag*.
we suspect that in order to solve the tasks, we need to bypass sandbox implemented by the provided binary.

### sandbox analysis

we used radare2 to disassemble the binary.
the binary implements simple sandbox that inspects syscalls from monitored binary using ptrace.
this functionality is implemented by subroutine 0x00400b50.

syscall inspection is as follows:
```
|           0x00400c3e      488d742410     lea rsi, [rsp + 0x10]       ; struct user ctx
|           0x00400c43      89df           mov edi, ebx
|           0x00400c45      e876010000     call fcn.ptrace_getregs
|           0x00400c4a      488b84248800.  mov rax, qword [rsp + 0x88] ; ctx.regs.orig_rax
|           0x00400c52      4883f805       cmp rax, 5                  ; = sys32_open
|       ,=< 0x00400c56      7466           je 0x400cbe                 ; additional logic
|       |   0x00400c58      4883f801       cmp rax, 1                  ; = sys32_exit
|      ,==< 0x00400c5c      7467           je 0x400cc5                 ; allow
|      ||   0x00400c5e      488d50fd       lea rdx, [rax - 3]
|      ||   0x00400c62      4883fa01       cmp rdx, 1                  ; in (sys32_read, sys32_write)
|     ,===< 0x00400c66      765d           jbe 0x400cc5                ; allow
|     |||   0x00400c68      4883f806       cmp rax, 6                  ; = sys32_close
|    ,====< 0x00400c6c      7457           je 0x400cc5                 ; allow
|    ||||   0x00400c6e      4883f81b       cmp rax, 0x1b               ; = sys32_alarm
|   ,=====< 0x00400c72      7451           je 0x400cc5                 ; allow
|   |||||   0x00400c74      4883f85a       cmp rax, 0x5a               ; = sys32_mmap
|  ,======< 0x00400c78      744b           je 0x400cc5                 ; allow
|  ||||||   0x00400c7a      4883f87d       cmp rax, 0x7d               ; = sys32_mprotect
| ,=======< 0x00400c7e      7445           je 0x400cc5                 ; allow
| |||||||   0x00400c80      89df           mov edi, ebx
| |||||||   0x00400c82      be09000000     mov esi, 9
| |||||||   0x00400c87      e8e4faffff     call sym.imp.kill
| |||||||   0x00400c8c      31ff           xor edi, edi
| |||||||   0x00400c8e      e81dfbffff     call sym.imp.exit
```

the monitored process is allowed to execute:

* sys32_open, with additional check described below
* sys32_exit
* sys32_read
* sys32_write
* sys32_close
* sys32_alarm
* sys32_mmap
* sys32_mprotect

the additional check for *sys32_open* is implemented by subroutine 0x00400aa0:
```
/ (fcn) fcn.sandbox_inspect_open 176
|           ; call xref from 0x00400cc0 (fcn.sandbox_inspect_open)
|           0x00400aa0      53             push rbx
|           0x00400aa1      89fb           mov ebx, edi
|           0x00400aa3      4881ec001100.  sub rsp, 0x1100
|           0x00400aaa      488d742410     lea rsi, [rsp + 0x10]       ; struct user ctx
|           0x00400aaf      64488b042528.  mov rax, qword fs:[0x28]
|           0x00400ab8      48898424f810.  mov qword [rsp + 0x10f8], rax
|           0x00400ac0      31c0           xor eax, eax
|           0x00400ac2      e8f9020000     call fcn.ptrace_getregs
|           0x00400ac7      488b742438     mov rsi, qword [rsp + 0x38] ; ctx.regs.rbx
|           0x00400acc      488d9424f000.  lea rdx, [rsp + 0xf0]
|           0x00400ad4      4531c0         xor r8d, r8d
|           0x00400ad7      b900100000     mov ecx, 0x1000
|           0x00400adc      89df           mov edi, ebx
|           0x00400ade      e88d030000     call fcn.sandbox_read_vm
|           0x00400ae3      488dbc24f000.  lea rdi, [rsp + 0xf0]
|           0x00400aeb      31f6           xor esi, esi
|           0x00400aed      e86efcffff     call sym.imp.realpath       ; bug: depends on process
|           0x00400af2      4885c0         test rax, rax
|       ,=< 0x00400af5      7438           je 0x400b2f
|       |   0x00400af7      bfb40f4000     mov edi, str._home_warmup_flag ; "/home/warmup/flag" @ 0x400fb4
|       |   0x00400afc      b912000000     mov ecx, 0x12
|       |   0x00400b01      4889c6         mov rsi, rax
|       |   0x00400b04      f3a6           repe cmpsb byte [rsi], byte ptr [rdi]
|      ,==< 0x00400b06      741f           je 0x400b27
|      ||   0x00400b08      488d742410     lea rsi, [rsp + 0x10]
|      ||   0x00400b0d      89df           mov edi, ebx
|      ||   0x00400b0f      4889442408     mov qword [rsp + 8], rax
|      ||   0x00400b14      48c744243800.  mov qword [rsp + 0x38], 0   ; block pathname access
|      ||   0x00400b1d      e8ce020000     call fcn.ptrace_setregs
|      ||   0x00400b22      488b442408     mov rax, qword [rsp + 8]
|      `--> 0x00400b27      4889c7         mov rdi, rax
|       |   0x00400b2a      e8c1fbffff     call sym.imp.free
|       `-> 0x00400b2f      488b8424f810.  mov rax, qword [rsp + 0x10f8]
|           0x00400b37      644833042528.  xor rax, qword fs:[0x28]
|       ,=< 0x00400b40      7509           jne 0x400b4b
|       |   0x00400b42      4881c4001100.  add rsp, 0x1100
|       |   0x00400b49      5b             pop rbx
|       |   0x00400b4a      c3             ret
\       `-> 0x00400b4b      e8c0fbffff     call sym.imp.__stack_chk_fail ;[9]
```

we discovered potential issue with the above, where results of *realpath* subroutine may change depending on process.
typical example is accessing **/proc/self** that links to different location depending on pid of calling process.

we didn't find any other issues in provided binary.

### bypass approach

we spent some time experimenting with different pathnames that may be interpreted differently for different processes.
finally we decided to use following pathname:
```
/proc/self/task/[monitored_process_pid]/root
```

the above pathname:

* points to root directory when referred by monitored process and
* does not exists when referred by sandbox process, allowing for syscall to continue without modification.

as we don't know pid of monitored process, we will attempt to bruteforce this pid from within our exploit.

### exploit implementation

out exploit is based on code from warmup flag, were we modified rop chain and added new stage.

the rop chain has the following steps:

1. read next stage into data area of exploited binary
2. write *sys_mprotect* bytes using 0x08048135 to set eax register
3. execute 0x08048122 that performs syscall using pre-set eax, this will modify permission of data area to read+write+execute
4. jump to next stage

the next stage has the following steps:

1. bruteforces monitored_process_pid to open */proc/self/task/[monitored_process_pid]/root/home/sandbox/flag*
2. read the flag into memory
3. write content of buffer to standard output

attached [exploit.py](exploit.py) was used to retrieve flag during ctf.
