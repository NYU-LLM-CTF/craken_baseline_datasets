## dumped (forensics, 100p)

    in windows task manager, i right clicked a process and selected "create dump file". i'll give you the dump, but in return, give me the flag!

    download runme.dmp.xz

###eng
[pl](#pl-version)

running `strings runme.dmp | grep sharif` against this file gives us flag.

###pl version

wystarczy użyć `strings runme.dmp | grep sharif`.
