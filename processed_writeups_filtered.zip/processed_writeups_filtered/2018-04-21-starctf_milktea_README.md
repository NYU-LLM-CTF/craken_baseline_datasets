# milktea, re

in this task we got quite obfuscated, though small, binary. it asked for a password and checked whether it
is correct. as an easy to overlook obfuscation, it patched its got `memcmp` entry to point to a custom function,
which actually checks whether `arg1 == arg2 ^ const_buf`. other than that, the reverse engineering boiled down to
simplifying as many expressions from the executed statements as possible. in the end, most of them turned out
to be xors with constants, which eventually cancelled out to zero. the final encryption code was quite simple
and fit in a few lines of c code. all operations were invertible, so we wrote the decryption function, which
yielded the flag. the whole solution code is available in `doit.cpp`.
