# special (misc, 405p, 58 solved)

```
you will find a special path where the answer lies. 
```

a recon task, where nothing is given.
we spent some time looking around for some strange js files, comment in source code of the page etc. by to no avail.
then just accidentally someone got interested in the [background of the ctf webpage](background.jpg).
it's rather common to place some random codes on it webpages in images/logos etc, but still it might be something.
once you try to read the blurry code it becomes obvious that this is in fact the `special` task.

the code is quite simple, we have hexbytes which should get decoded to ascii chars, the resulting string is again hex encoded so we need to decode it one more time and finally we have to invert it to get the flag.

the hard part was to type down those blurry values but in the end we got it:

```python
"".join([chr(int(c,16)) for c in '37 39 37 33 36 31 36 35 37 30 35 66 37 39 37 33 36 31 36 35'.split()]).decode("hex")[::-1]
```

which becomes a flag: `eko{easy_peasy}`
