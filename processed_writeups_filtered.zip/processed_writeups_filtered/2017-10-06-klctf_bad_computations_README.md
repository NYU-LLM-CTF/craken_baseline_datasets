# bad computations (crypto, 800p)

in the task we get [crypto code](crypt.py) and encrypted flag: `hnd/goj/e4h1fowdhyofiiz+f3l1e4r5ii+gin+fha==`

we proceed with labelling the poorly obfuscated functions.
it's quite clear we have there something like: `primes_in_range`, `prime_sieve`, `extended_gcd` and `mod_inv`.
next we proceed to label the flag encryption procedure and it's easy to notice that it's paillier cryptosystem.
so once we label the code we end up with:

```python
flag_bytes = [ord(x) for x in flag]
paillier_encrypted_constant = paillier_encrypt(b, g, n, r)

for i in range(len(flag_bytes)):
	flag_bytes[i] = (paillier_encrypt(flag_bytes[i], g, n, r) * paillier_encrypted_constant) % (n * n)
	flag_bytes[i] = paillier_decrypt(flag_bytes[i], [p, q], g)

flag_bytes = b64encode(bytearray(flag_bytes))
print(str(flag_bytes)[2:-1])
```

so in reality encrypted flag byte is multiplied by encrypted constant and later decrypted.
but paillier has homomorphic properties.
we can calculate `encrypt(plaintext1 * plaintext2)` by doing `encrypt(plaintex1)^plaintext2 mod n^2` and we can calculate `encrypt(plaintext1 + plaintext2)` by doing `encrypt(plaintex1) * encrypt(plaintex2)`.
here we have the second option, so in reality the encryption code is just doing:

`decrypt(encrypt(flag[i]) * encrypt(22)) = decrypt(encrypt(flag[i]+22)) = flag[i] + 22`

so we can simply run:
```python
print("".join([chr(ord(c) - 22) for c in 'hnd/goj/e4h1fowdhyofiiz+f3l1e4r5ii+gin+fha=='.decode("base64")]))
```

to get the flag: `paillier_homomorphic_encryption`

i fail to see how this is worth 800p.
