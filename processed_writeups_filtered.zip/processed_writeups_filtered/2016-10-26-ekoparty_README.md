# writeup ekoparty ctf 2016

team: nazywam, other019, c7f.m0d3, cr019283, msm, rev, shalom


[image extracted text: dragon sector
dcua
odaysober
lcibc
samurai
losfuzzys
piggybird
pateam
antichat
elt
4000
2000
12 ph
6 fh
paz 28
12 ph
paz 27
12 fm
paz 28
12 fm
bushwhackess
pingme
ecaptute
85 fust
ine
kllttteetorccttcr
mau5
ascii overflow
t
3
international
s
eckobul)
gderongforsoju
n
oops:
ie
hokal
securimag
player

  country
score
dragon sector
6692
dcua
ys"rdot org satoweb
kesunny
li f 6096
ginllad
vctfefoois
odaysober
5422
rrtyvavv
datx lcibc
ufoloqists
shellphish ox5la
uls
3728
samurai
3682
3
uset[aeliilis
losfuzzys
kesatria garuda
tk 3660
piggybird
3316
pateam
3305
antichat
3234
10
elt
3034
paz _
swag]



### table of contents

* [f#ck (re 50)](re_50)
* [rreeggeexx (re 75)](re_75)
* [bleeding (pwn 50)](pwn_50)
* [my first service i (pwn 100)](pwn_100)
* [super duper advanced attack (web 100)](web_100)
* [old but gold (misc 250)](misc_250)
* [vsftpd dejavu (for 150)](for_150)
* [old times (re 100)](re_100)
* [metadata (fbi 50)](fbi_50)
* [carder (web 150)](web_150)
* [hacker in disguise (for 100)](for_100)
 	
