# writeup ectf 2016

team: nazywam, c7f.m0d3, cr019283, akrasuski1, shalom


### table of contents

* [number_place (misc 150)](misc_150)
* [daas (crypto 50)](crypto_50)
