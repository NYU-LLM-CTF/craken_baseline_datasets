# lone authot (forensics)

in the task we get a [zip file](lone_author.zip) which seems corrupted.
we notice that the pk headers are not right.
it should always be `04034b50` and in our case the 3rd byte is wrong.
we also notice that it's not any accidental flip.
once we extract all wrong headers we can see a pattern:

```
pkf
pkl
pka
pkg
pk{
pkm
pk3
pk3
pkt
pk_m
pk3
pk_1
```

so we've got a flag prefix -> `flag{m33t_m3_1`

once we fix those headers, we can finally extract the archive and we get [password protected zip](secret.zip) and [a piece of qr code](qr_ps.tif).
we initially thought we have to somehow fix the qr, but it turned out that in metadata there is:

`<pdf:author>password to the second part is 0xnox**</pdf:author>`

we used this password on the zip archive we got, and we managed to extract the file:


[image extracted text: n_the
_park_tomorrow}]


this makes up the whole flag: `flag{m33t_m3_1n_the_p4rk_t0morrow}`
