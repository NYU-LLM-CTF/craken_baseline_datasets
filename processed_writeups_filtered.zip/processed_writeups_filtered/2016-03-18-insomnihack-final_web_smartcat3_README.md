## smartcat3 (web)

this task was another web ping utility, similar to one from the teaser. we were able to submit a text, which would then
be passed to `ping` command, like so: `ping -c 1 our_text`. this asks for shell command injection - it was not that easy 
though, since server filtered most metacharacters, such as `$&|` and others. some special characters were allowed though - in
particular, `<>()`. using those, and bash's so called "process substitution" (which we found in `man bash`), we were able to
execute commands like `ping -c 1 <(ls)`. note that this did not give us any output on the web interface - the server returned
only whether the command succeeded or not.

first problem we had to deal with, was filtering of spaces. with `$` disallowed too, we were not able to use `${ifs}` or similar
constructs, but we could still redirect any text to any file, for example:
```
<(python<<<"print'%c%c'%(108,115)">/tmp/p4rocks)
```
this command, when used in process substitution context, should create file `/tmp/p4rocks` with `ls` in it (from ascii codes).
later, we could simply execute this script using `<(python</tmp/p4rocks)`. we automatized this workflow in `doit.py`.

right now, we were able to execute arbitrary command on the server, but we still did not have a way to read their output. 
the description of task, as we read it (as it turned out,
incorrectly, making our work harder), told us that all the ports on the server are closed. one of the ways to bypass this, is 
to use `ping` with payload - builting `ping` command has a nice feature: `-p pattern` makes a `ping` probe with selected
pattern. if we `ping` ourselves with pattern equal to output of the executed command, we are able to sniff it, and receive it.
sample output, as seen in wireshark, of `ls -al` (first 16 bytes):


[image extracted text: 0000
99 f5 55 35
gh _
u5..e.
0010
co a8
cc 6a oa od
t..
2e fe
01 17
b3 ta
00 2d 72 77 2d 72 2d
mv-t
31 20
2d 72 77
72 2d
tv-r_
0050
2d 2d 2d 2d 20 31 20 72
6f 6f 2d 72 77 2d 72 2d
00-t-r
0060
2d 2d]


you can clearly see `-rw-r----- 1 roo`, meaning that the first file was owned by root and had `-rw-r-----` permissions.

trying the usual stuff, such as `ls -al /`, we found that there are two interesting files in the root directory: `flag` and 
`read_flag`. `flag` was not readable by us, but `read_flag` was executable. when ran, it showed output like:
```
write "give me a..." on my stdin, wait 2 seconds, and then write "... flag!". this is to make sure you can execute anything.
```
well, since we had arbitrary code execution, we implemented this (`payload.py` was the final payload). the binary then read
the flag to us.
