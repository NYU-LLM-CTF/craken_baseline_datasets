# writeup alexctf 2017

team: nazywam, shalom, psrok1, c7f.m0d3

### table of contents
