# magic test (web)

in the task we get a very simple webpage where we can input a name and birthday.
we get source code of the server part as well:

```javascript
const express = require('express')
const app = express()

function gettimestamp(date) {
    try{
        var x = math.floor((new date(date)) / 1000);
        return x;
    } catch( e ){
        return  math.floor((new date()) / 1000);
    }
}

function getasciicode(str)
{
    var arr1 = [];
    for (var n = 0; n < str.length; n ++) 
     {
        var ascii = number(str.charcodeat(n));
        arr1.push(ascii);
     }
    return arr1.join('');
}

app.get('/:username/:birth_day', (req, res) => {
    flag = '************';
    username = req.params.username || '';
    birthday = req.params.birth_day || '';

    console.log(username);
    console.log(birthday);
    
    var priority = math.pow(2, getasciicode(username) + gettimestamp(birthday));
    
    if(priority >= 0) {
        res.send('hey peasent, no flag for you !!');
    }
    else {
        res.send('your magical powers have been proven, here is your flag: ' + flag );
    }
});

app.listen(3000, () => console.log('node task app listening on port 3000!'));
```

it's clear we need to bypass the check and therefore the value of `math.pow(2, getasciicode(username) + gettimestamp(birthday))` needs to be `< 0`.
initially we simply wanted to send a non-date string as birthday (eg. some text), causing the result of `gettimestamp` to be `nan`, but there must have been some validation of the input format.
in the end it worked as we wanted for string `2018-01-32` and we got `flag{php_h4s_security_issues_they-said!!!}`
