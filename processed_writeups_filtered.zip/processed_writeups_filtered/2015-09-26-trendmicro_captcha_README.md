## captcha (ppc/misc, 300p)

### pl version
`for eng version scroll down`

zadanie polegało na rozwiązaniu 500 kodów captcha poprawnie pod rząd, przy czym można było pomijać których nie chcieliśmy rozwiązywać captche. serwowane kody miały postać:


[image extracted text: uk_]


w celu rozwiązania zadania napisaliśmy skrypt w pythonie korzystając z python images library, pytesseract oraz tesseracta. niemniej wymóg 500 bezbłędnych rozwiązań pod rząd wymagał zastosowania pewnych heurystyk aby ocenić czy zdekodowane przez nas słowo jest aby na pewno poprawne.

cały skrypt dostępy jest [tutaj](captcha.py).

działanie skryptu:
na początek usuwane są różnokolorowe pionowe kreski. w tym celu pobieramy rozkład kolorów dla pikseli i odszukujemy dwa dominujące kolory - wypełnienie oraz tekst captchy (pomijamy kolor biały) a następnie skanujemy obraz i każdy piksel innego koloru niż 2 dominujące jest zamieniany na dominujący. jeśli piksel sąsiaduje z pikselami o kolorze tekstu wybieramy ten kolor, jeśli nie używamy koloru wypełnienia.
wykonujemy to skryptem:

	def get_filling(pixels, i, j, best_colors, x_range):
		left = pixels[(i - 1) % x_range, j]
		right = pixels[(i + 1) % x_range, j]
		if left in best_colors and left != best_colors[0]:
			return left
		elif right in best_colors and right != best_colors[0]:
			return right
		else:
			return best_colors[0]


	def fix_colors(im):
		colors_distribution = im.getcolors()
		ordered = sorted(colors_distribution, key=lambda x: x[0], reverse=true)
		best_colors = [color[1] for color in ordered]
		if (255, 255, 255) in best_colors:
			best_colors.remove((255, 255, 255))
		best_colors = best_colors[:2]
		pixels = im.load()
		for i in range(im.size[0]):
			for j in range(im.size[1]):
				color = pixels[i, j]
				if color not in best_colors:
					pixels[i, j] = get_filling(pixels, i, j, best_colors, im.size[0])
		return best_colors[0]


w efekcie z powyższego obrazu uzyskujemy:


[image extracted text: cexj]


następnym krokiem jest zamiana kolorów obrazu w celu zwiększenia kontrastu i ułatwienia pracy ocra. skanujemy obraz i każdy piksel o kolorze wypełnienia zamieniamy na biały a piksel i kolorze tekstu na czarny. 

	def black_and_white(im, filling):
		black = (0, 0, 0)
		white = (255, 255, 255)
		pixels = im.load()
		for i in range(im.size[0]):
			for j in range(im.size[1]):
				color = pixels[i, j]
				if color == filling:
					pixels[i, j] = white
				else:
					pixels[i, j] = black

w efekcie uzyskujemy:


[image extracted text: cexj]


tak przygotowany obraz skanujemy za pomocą tesseracta a potem wynik oceniamy za pomocą heurystyki:

	def on_blacklist(text):
		if len(text) != 4:
			return true
		blacklisted = ["i", "0", "o", "z", "q", "2", "s", "3", "g", "9", "1", "l", "c", "x", "v", "b", "8", "u"]
		for character in blacklisted:
			if character in text:
				return true
		matcher = re.match("[a-za-z0-9]+", text)
		if matcher is none or len(matcher.group()) != 4:
			return true
		return false

odrzucamy wszystkie rozwiązania które nie mają 4 symboli z zakresu `[a-za-z0-9]` bo wiemy że wszystkie captche powinny mieć 4 symbole alfanumeryczne. dodatkowo odrzucamy wszystkie rozwiązania zawierające ryzykowne symbole:

* tesseract często myli ze sobą: `o0q`, `2z`, `b8s`, `il1`, `6g`, `9g`
* tesseract często niepopranie rozpoznaje wielkość liter - jeśli podaje małą literę to jest ok, ale jeśli podaje dużą literę nie możemy mieć pewności. odrzucamy więc wszystkie symbole których mała i duża wersja jest zbyt podobna: `xvucszo`

w ten sposób uzyskujemy solver ze 100% skutecznością, chociaż działa on bardzo wolno, bo odrzuca 90% testowanych kodów captcha.
po rozwiązaniu wszystkich 500 przykładów dostajemy:


[image extracted text: welcome to captcha challengel
tmctf{217dae3fd34cee799658d4552e378278}
clj
submit]


### eng version

the challenge was to correctly solve 500 consecutive captcha codes, with the ability to skip codes we didn't want to solve. codes looked like this:


[image extracted text: uk_]


in order to solve this we prepared a python script using python images library, pytesseract and tesseracta. however the 500 consecutive correct answers required some special processing and heuristics to score the solution and decide if it's correct or not.

whole script is available [here](captcha.py).

the script works as follows:
first we remove the colorful vertical lines. for this we get the color distribution of image pixels and we get the two dominant colors - filling and text (skipping white) and then we scan the picture and if a pixel has different color than the 2 dominants, we change it to dominant. if it is next to text-color pixel we choose text-color, otherwise we use filling color.
we do this with:

	def get_filling(pixels, i, j, best_colors, x_range):
		left = pixels[(i - 1) % x_range, j]
		right = pixels[(i + 1) % x_range, j]
		if left in best_colors and left != best_colors[0]:
			return left
		elif right in best_colors and right != best_colors[0]:
			return right
		else:
			return best_colors[0]


	def fix_colors(im):
		colors_distribution = im.getcolors()
		ordered = sorted(colors_distribution, key=lambda x: x[0], reverse=true)
		best_colors = [color[1] for color in ordered]
		if (255, 255, 255) in best_colors:
			best_colors.remove((255, 255, 255))
		best_colors = best_colors[:2]
		pixels = im.load()
		for i in range(im.size[0]):
			for j in range(im.size[1]):
				color = pixels[i, j]
				if color not in best_colors:
					pixels[i, j] = get_filling(pixels, i, j, best_colors, im.size[0])
		return best_colors[0]

with this code, from the catpcha above we get:


[image extracted text: cexj]


next step is changing the colors to raise contrast and make life easier for ocr engine. we scan the picture and the color of all filling-color pixels change to white and text-color to black.

	def black_and_white(im, filling):
		black = (0, 0, 0)
		white = (255, 255, 255)
		pixels = im.load()
		for i in range(im.size[0]):
			for j in range(im.size[1]):
				color = pixels[i, j]
				if color == filling:
					pixels[i, j] = white
				else:
					pixels[i, j] = black

as a result we get:


[image extracted text: cexj]


picture prepared like that we pass to tesseract and then score the result with heuristic:

	def on_blacklist(text):
		if len(text) != 4:
			return true
		blacklisted = ["i", "0", "o", "z", "q", "2", "s", "3", "g", "9", "1", "l", "c", "x", "v", "b", "8", "u"]
		for character in blacklisted:
			if character in text:
				return true
		matcher = re.match("[a-za-z0-9]+", text)
		if matcher is none or len(matcher.group()) != 4:
			return true
		return false

we reject all solutions that doesn't have 4 symbols from `[a-za-z0-9]` range, since we know that all captchas should have 4 alphanumeric symbols. additionally we reject all solutions with risky symbols:

* tesseract mistakes sometimes: `o0q`, `2z`, `b8s`, `il1`, `6g`, `9g`
* tesseract often recognizes the letter case incorrectly - if it says there is a small letter it's fine, but if it ways it's a capital letter then we can't be sure. we reject all symbols where small and capital versions are similar: `xvucszo`

this way we get a 100% accuracy solver, however it works rather slowly since it rejects ~90% of tested codes.
after solving all 500 captchas we get:


[image extracted text: welcome to captcha challengel
tmctf{217dae3fd34cee799658d4552e378278}
clj
submit]
