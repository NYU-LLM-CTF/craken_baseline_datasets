# writeup hackit 2017

team: c7f.m0d3, nazywam, akrasuski1, shalom, ppr


[image extracted text: rank
team
score
secod
3770
dcua
3490
asis
3410
p4
3220
alles !
3000
infosect
2450
bunlisugeo
2160
rulello
1870
'k4i/8lt, e3m4707}
1860
10
wildwest
1850
11
shadow
servants
1700
12
shellwarp
1665
13
limpopo
1600
14
bushwhackers
1570
15
khack4o
1570]


### table of contents

* [b3tters0ci4ln3twork (web)](web50)
* [v1rus3pidem1c (web)](web100)
* [weekands of hacker (web)](web150)
* [today’s moon phase (pwn)](pwn150)
* [4_messages (crypto)](crypto100)
* [eva’s chance (crypto)](crypto150)
* [chinese satellite (crypto)](crypto200)
