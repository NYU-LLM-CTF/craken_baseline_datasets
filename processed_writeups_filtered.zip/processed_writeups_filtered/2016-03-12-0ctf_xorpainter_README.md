## xorpainter (misc, 4p)
	
	you need a big screen to solve this problem 
	
###eng
[pl](#pl-version)

317mb csv file is provided. each row contains 4 numbers.
it looks like first pair is always smaller than the second pair.
this suggests the numbers represent rectangles.
name of the file suggests we should paint them in xor mode (like in awt).

the data is huge, so we do one simple optimization.
instead of painting all the pixels, we mark only first and last row of each rectangle.

for example, for input:

	0, 0, 3, 3
	2, 2, 4, 4

following image is generated:

	1 1 1 0
	0 0 0 0
	1 1 0 1
	0 0 1 1

after xoring each row with previous one, end result is generated:

	1 1 1 0
	1 1 1 0
	1 1 0 1
	0 0 1 1

after this optimization, processing all the data takes only a couple of minutes.
the result is 16384x16384 image. imagemagick is able to load and navigate through such big image.
some letters are visible, but it's mostly empty space.
the image becomes more usefull after removing empty rows and columns.
```cpp
#include <stdio.h>
#include <stdlib.h>

#define size 16384

static int flip[size][size];
static int non_empty_x[size];
static int non_empty_y[size];

int main(int argc, char*argv[]) {
	int x0,y0,x1,y1;
	int row = 0;
	while(scanf("%d, %d, %d, %d", &x0, &x1, &y0, &y1) == 4) {
		for(int x=x0;x<x1;x++){
			flip[y0][x]^=1;
			flip[y1][x]^=1;
		}
		row++;
		if((row&0xfff) == 0) {
			fprintf(stderr, "row: %d\r", row);
		}
	}	

	row = 0;
	for(int y=1;y<size;y++){
		for(int x=0;x<size;x++){
			flip[y][x] ^= flip[y-1][x];
		}
		row++;
		if((row&0xfff) == 0) {
			fprintf(stderr, "flip: %d\r", row);
		}
	}

	for(int y=0;y<size;y++){
		for(int x=0;x<size;x++){
			non_empty_x[x] |= flip[y][x];
			non_empty_y[y] |= flip[y][x];
		}
	}

	int xsize = 0;
	int ysize = 0;

	for(int i=0;i<size;i++){
		xsize += non_empty_x[i];
		ysize += non_empty_y[i];
	}


	printf("p1 %d %d\n",xsize,ysize);
	for(int y=0;y<size;y++){
		for(int x=0;x<size;x++){
			if(non_empty_x[x] && non_empty_y[y]) {
				printf("%d ",flip[y][x]);
			}
		}
		printf("\n");
	}
}
```
it looks like only outlines of the letters are visible - probably due to off by one error.
the image is also still 3195 x 3321 pixels, but we can read a flag from it.

`0ctf{5m@ll_fl@g_#n_big_bitmap}`

###pl version

otrzymujemy 317 megabajtowy plik csv.
każdy wiersz zawiera 4 liczby.
pierwsza para jest zawsze mniejsza niż druga para.
sugeruje to że wartości reprezentują prostokąty (x0, y0, x1, y1).
nazwa pliku sugeruje że powinniśmy je namalować trybem xor (jak w awt).

dane są jednak zbyt duże dla naiwnego algorytmu.
stosujemy więc prostą optymalizację.
zamiast malować każdy piksel, malujemy tylko pierwszy i ostatni rząd każdego prostokąta.

np. dla wejścia:

	0, 0, 3, 3
	2, 2, 4, 4

generowana jest bitmapa:

	1 1 1 0
	0 0 0 0
	1 1 0 1
	0 0 1 1

po sxorowaniu ze sobą kolejnych rzędów otrzymujemy ostateczny obraz: 

	1 1 1 0
	1 1 1 0
	1 1 0 1
	0 0 1 1

po tej optymalizacji, przetworzenie danych zajmuje tylko kilka minut.
wynikiem jest bitmapa 16384x16384 pikseli.
imagemagick (jako jeden z nielicznych) potrafi otworzyć i nawigować po tak wielkim obrazie.
widoczne są jakieś litery, ale większość obrazka jest pusta.
aby zwiększość czytelność usuwamy puste wiersze i kolumny.
```cpp
#include <stdio.h>
#include <stdlib.h>

#define size 16384

static int flip[size][size];
static int non_empty_x[size];
static int non_empty_y[size];

int main(int argc, char*argv[]) {
	int x0,y0,x1,y1;
	int row = 0;
	while(scanf("%d, %d, %d, %d", &x0, &x1, &y0, &y1) == 4) {
		for(int x=x0;x<x1;x++){
			flip[y0][x]^=1;
			flip[y1][x]^=1;
		}
		row++;
		if((row&0xfff) == 0) {
			fprintf(stderr, "row: %d\r", row);
		}
	}	

	row = 0;
	for(int y=1;y<size;y++){
		for(int x=0;x<size;x++){
			flip[y][x] ^= flip[y-1][x];
		}
		row++;
		if((row&0xfff) == 0) {
			fprintf(stderr, "flip: %d\r", row);
		}
	}

	for(int y=0;y<size;y++){
		for(int x=0;x<size;x++){
			non_empty_x[x] |= flip[y][x];
			non_empty_y[y] |= flip[y][x];
		}
	}

	int xsize = 0;
	int ysize = 0;

	for(int i=0;i<size;i++){
		xsize += non_empty_x[i];
		ysize += non_empty_y[i];
	}


	printf("p1 %d %d\n",xsize,ysize);
	for(int y=0;y<size;y++){
		for(int x=0;x<size;x++){
			if(non_empty_x[x] && non_empty_y[y]) {
				printf("%d ",flip[y][x]);
			}
		}
		printf("\n");
	}
}
```
tylko krawędź liter jest widoczna - prawdobodobnie powinniśmy użyć <= zamiast <.
obrazek nadal ma aż 3195 x 3321 pikseli.
nie przeszkadza to jednak w odczytaniu flagi.

`0ctf{5m@ll_fl@g_#n_big_bitmap}`
