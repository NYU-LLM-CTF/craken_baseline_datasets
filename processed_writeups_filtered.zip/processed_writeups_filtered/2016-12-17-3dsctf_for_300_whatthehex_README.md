# what the hex (for 300)

###eng
[pl](#pl-version)

in the task we get a large binary file (too large to put here, sorry).
we notice that the file is in fact a 3000 concatenated jpg files with missing headers.
we fix them and split with a script:

```python
s = open("massa.raw", "rb").read().decode("hex")
r = s.split("fif\x00")
for i in range(1, 3001):
    open("out/" + str(i) + ".jpg", "wb").write("\xff\xd8\xff\xe0\x00\x10jfif\x00" + r[i])
```

and this way we get 3000 files looking like this:


[image extracted text: 3dsctf{heroins6
heroins7
heroins8}]


it's quite clear that the `flag` in the picture has incorrect format.
we assume that there is one flag with proper format somewhere, but who would look for it by hand?
instead we used pytesseract to ocr each file and look for something more like the flag.
tesseract had some issues with reading blue letters on blue background, so we made it black and white with pillow first:

```python
import codecs
import io
import math
from multiprocessing import freeze_support
from pil import image
from pytesseract import pytesseract
from crypto_commons.brute.brute import brute


def similar(color1, color2):
    return sum([math.fabs(color1[i] - color2[i]) for i in range(3)]) < 50


def black_and_white(im, filling):
    black = (0, 0, 0)
    white = (255, 255, 255)
    pixels = im.load()
    for i in range(im.size[0]):
        for j in range(im.size[1]):
            color = pixels[i, j]
            if similar(color, filling):
                pixels[i, j] = white
            else:
                pixels[i, j] = black


def worker(i):
    with codecs.open("c:\\users\\pc\\desktop\\3ds\\outp\\" + str(i) + ".jpg", "rb")as f:
        image_file = io.bytesio(f.read())
        im = image.open(image_file)
        im = im.convert('rgb')
        black_and_white(im, (173, 217, 230))
        text = pytesseract.image_to_string(im, config="-psm 8")
        print(i, text)
        if not text.startswith("3dsctf"):
            im.show()
            print('real flag', i, text)


def main():
    brute(worker, range(1, 3001))


if __name__ == '__main__':
    freeze_support()
    main()
```

by running this in paralell with our crypto-commons multiprocessing brute we get the results pretty fast and the only result we get is:


[image extracted text: 3ds{u
shouldv3
7ried
tesseract}]


there was a very nasty twist here, because the actual flag was supposed to contain large `o` and small `l`.
while the `l` is reasonable, since both large `i` and small `l` look alike, using large `o` where in the picture it's pretty clear that we have `0` is just a dick move.

anyway the actual flag was `3ds{u_5houidv3_7ried_tesseract}`

###pl version

w zadaniu dostajemy duży plik binarny (za dużo żeby to wrzucić, przepraszamy).
zauważamy, ze plik to w rzeczywistości sklejone ze sobą 3000 plików jpg bez headerów.
poprawiamy je i dzielimy za pomocą:

```python
s = open("massa.raw", "rb").read().decode("hex")
r = s.split("fif\x00")
for i in range(1, 3001):
    open("out/" + str(i) + ".jpg", "wb").write("\xff\xd8\xff\xe0\x00\x10jfif\x00" + r[i])
```

i tym sposobem dostajemy 3000 plików wyglądajacych tak:


[image extracted text: 3dsctf{heroins6
heroins7
heroins8}]


jest dość jasne, że `flaga` na obrazku ma niepoprawny format.
zakładamy że jest tam gdzieś jedna poprawna flaga, ale kto by jej szukał ręcznie?
zamiast tego używamy pytesseract żeby ocrować pliki i szukać czegoś co bardziej przypomina flagę.
tesseract miał jakieś problemy z niebieskimi napisami na niebieskim tle więc zmieniliśmy obrazki na czarno-białe za pomocą pillow:

```python
import codecs
import io
import math
from multiprocessing import freeze_support
from pil import image
from pytesseract import pytesseract
from crypto_commons.brute.brute import brute


def similar(color1, color2):
    return sum([math.fabs(color1[i] - color2[i]) for i in range(3)]) < 50


def black_and_white(im, filling):
    black = (0, 0, 0)
    white = (255, 255, 255)
    pixels = im.load()
    for i in range(im.size[0]):
        for j in range(im.size[1]):
            color = pixels[i, j]
            if similar(color, filling):
                pixels[i, j] = white
            else:
                pixels[i, j] = black


def worker(i):
    with codecs.open("c:\\users\\pc\\desktop\\3ds\\outp\\" + str(i) + ".jpg", "rb")as f:
        image_file = io.bytesio(f.read())
        im = image.open(image_file)
        im = im.convert('rgb')
        black_and_white(im, (173, 217, 230))
        text = pytesseract.image_to_string(im, config="-psm 8")
        print(i, text)
        if not text.startswith("3dsctf"):
            im.show()
            print('real flag', i, text)


def main():
    brute(worker, range(1, 3001))


if __name__ == '__main__':
    freeze_support()
    main()
```

uruchamiając to równolegle z naszym brute z crypto-commons dostajemy dość szybko wyniki i jedyne trafienie to:


[image extracted text: 3ds{u
shouldv3
7ried
tesseract}]


było tutaj dość nieładne zagranie ze strony organizatorów, bo flaga miała zawierać duże `o` oraz małe `l`.
o ile `l` jest sensowne, bo duże `i` oraz małe `l` wyglądają tak samo, użycie dużego `o` podczas gdy na obrazku ewidentnie mamy `0` to po prostu zagranie poniżej pasa.
tak czy siak końcowa flaga to `3ds{u_5houidv3_7ried_tesseract}`
