#offensive 100 (web, 100p)

## pl
`for eng scroll down`

w tym zadaniu dostajemy stronę z 3 sekcjami:

  * przycisk sign up
  * przycisk sign in
  * tabela z logiem logowań
  
w tym zadaniu trzeba było zauważyć 2 rzeczy:

 * czasami, logując się, zamiast zalogować się na swoje konto zostajemy zalogowani na konto osoby która zalogowała się w tym samym czasie.

 * dokładnie co minutę, loguje się ktoś z id równym 0 (przypuszczamy, że jest to konto na które mamy się dostać)

łącząc te dwa zjawiska postanawiamy zalogować się na swoje konto dokładnie w zerowej sekundzie.
 nie działa, robimy reload strony iiii...
 
 
[image extracted text: welcome to strange auth system
welcome tmctf{ad7ocob2a1d07792a310b2349cab8890}
ogout]


## eng

in this task we get a web site with 3 sections:
 * sign up button
 * sign in button
 * accounts logged in log

in order to complete this challange we had to notice 2 things:

 * sometimes, when we log in, instead of logging in to our account we get redirected a account that logged in the same time.
 * exactly every minute, a id=0 login appears in the log. (that probably is the account we have to get into)
 
using theese 2 observations we decide to log in to our account at exactly 0 seconds.
when the site loads we're still on our accounts page, we try to reload the site and...
  
[image extracted text: welcome to strange auth system
welcome tmctf{ad7ocob2a1d07792a310b2349cab8890}
ogout]

