# oldpc (misc, 478 points, 14 solves)

in the task we get [machine code dump](oldpc.hex).
a bit of googling for byte sequencec got us to http://www.xgc-tek.com/manuals/erc32-ada-gs/x286.html where we could see assembly listing with similar machine code to what we had (at least the stack frame creation and ret/leave).
now we just had to check what is this erc32 and/or what assembly was in the listing.

in th end the main difficulty of this challenge was noticing that the given binary file contained sparc assembly.

after getting through that difficulty all we need to do is load the file in a disassembler and select `sparc big endian`:


[image extracted text: roh:
attributes:
based
frame
rom: 00000000
rom: 0000000"
sub
roh: 00000000
save
0*70,
%sp
rom: 0000006_
mov
%00
rom: 00000008
0*1061c,
%o 1
rom: 000000
mov
%02
roh: e
mov
%g1
rom: 000000
0*10
rom: 000000
nop
rom: 00000020
mov
0*83_
%0 1
roh: 0000002-
jno
0k7f_
rom: 00000028
mov
0*71_
%03
roh: 0000002c
mnu
0xgds
%04
rom: 00000030
0 *5 1bddscz_
%05
roh: 0000
sub
144
rom: 00000035
nop
rom: 000000_
jno
0 kgb,
%o 1
rom: 000000-
mov
0 *67_
%02
roh: 000000-
jno
465,
%03
rom: 0000004c
mov
0 *6
804
roh: 00000050
0x1e170013,
%05
rom: 0000005=
cai
sub
144
roh: 000005
nop
rom: 0000004
mov
0*59_
%0 1
rom: 0000006_
0x53_
%02
rom: 00000068
mov
0 *4f_
%03
roh: 0000006c
0*49_
%04
rom: 00000070
0 *606233d,
%05
rom: 00000078
sub
144
rom: 0000007"
nop
roh: 00005
jno
0*47 _
%o 1
rom: 00000084
mov
0*43_
%02
rom: 00000088
jno
0 <30,
%03
rom: 0000008c
mov
0 *3b_
804
roh: 00000090
0*35226276,
%05
rom: 00000098
sub
144
rom: 0000009c
nop
rom: 00000040
mov
0*35_
%0 1
0y_ n
xspa
%02]



[image extracted text: roa: 60000
rom: 00000144
attributes:
based
frame
rom: 00000 144
rom: 00000144
sub
144:
code xref:
sub_0+381p
roh: %
0000
sub
0+58tp
rom: 00006
roh: 00000144
var_
0 *40
rom: 00000144
roh: 00000144
save
%sp_
-0*40
%sp
rom: 00000 148
%i5,
["sp+o *40+var_
roh: 0000014c
idub
[%sp+9 x4+var_
40 ] ,
883
rom: 00006
btog
%i5
roh: %
[gsp+o x4+var
rom:
dub
gsp+o x4u+var
40+1],
%i5
roh: %
0000
btog
%i2_
%i5
rom: 0005
%i5,
["sp+o *40+var_
roh: %
0000164
dub
gsp+ix4+var_
40+2],
40*18
rom: 00000168
btog
%i3_
%i5
roh: 0000016c
%i5,
[%sp+9 x4+var_
rom: 00006
dub
"sp+i *40+var
40+3]-
40823
roh: %
btog
614,
%i5
rom: 00006
stb
%i5,
0 x40+var
40+3]
roh: 00000 -
mnu
%0g
rom: 00000 180
mov
%0 1
roh: 00000 184
%02
rom: 00000 188
mov
roh: 00000 18c
0*10
rom: 00000190
ret
roh: 00000194
restore
rom: 00006194
end
function
sub
144
[spte
xsp_]


the code may seem simple and well, it is. all it does is xors a bunch of values and prints them out. 

a quick script gave us back a flag in no time:


``` python
import struct
import sys

a = [
(0x837f716d, -0x51bdd5c2),
(0x6b676561, 0x1e170013),
(0x59534f49, 0x606233d),
(0x47433d3b, 0x35226276),
(0x352f2b29, 0x6481f76),
(0x251f1d17, 0x655f4e47),
(0x13110d0b, 0x52434e4b),
(0x07050302, 0x47583e2f),
]


for i in a:

	a = struct.pack(">q", i[0])[4:]
	b = struct.pack(">q", i[1])[4:]
	for aa, bb in zip(a, b):
	    sys.stdout.write(chr(ord(aa) ^ ord(bb)))


print
```

`-=[super_ultra_m3g4_@@sparc@@]=-`