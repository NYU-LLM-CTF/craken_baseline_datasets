# climate controller catastrophe, exp, 750pts

> catting cars is a major issue these days. it's impossible to sell your stolen car as a whole, so you sell it in parts. dashboard computers are popular since they break quite often ;-).

> unfortunately, the dashboard computer is paired with the main computer. so, simply exchanging it will not do the trick. in fact, without the handshake to the main computer it will not operate the climate control buttons.

> of course just pairing the dashboard computer isn't cool enough, try to smash the stack instead! we suspect the device isn't using the serial interface for its pairing algorithm.

> in addition to the attached challenge and reversing binaries, you're provided a special "challenge" which you can flash to wipe the eeprom of your dashboard computer.

this was a long challenge. most of the communication with the board
had to be made via a custom can protocol, not uart. some of the 
messages required "authentication", which after closer look was
implemented as challenge-response based on rsa. the binary had
the public key hardcoded, but it was only 32-bit long, so trivially 
factorizable. using arduino and mcp2515, we implemented the
authentication scheme.

being authenticated, we had access to some useful commands,
one of which erased part of eeprom. using patched `simavr`, we 
implemented exploit, which overwrote one of return addresses
via heap and stack collision. the vulnerable function was multiplication
of two bigints during processing of sent certificate (using can id 0x776).

final exploit is in `climate/ardu.cpp`, to be flashed on arduino. the
whole folder also contains some notes from reverse engineering,
along with code for generating the exploit and `simavr` patches.