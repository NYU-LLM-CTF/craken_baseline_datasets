# voip (forensics 100)

###eng
[pl](#pl-version)

in the task we get a [pcap](voip.pcap) of a voip call.
there was not much to do here since wireshark can out-of-the-box decode this for us:

[!](ws.png)

and the flag is `seccon{9001ivr}`

###pl version

w zadaniu dostajemy [pcapa](voip.pcap) z rozmowy przez voip.
nie było tu zbyt wiele do roboty bo wireshark potrafi to od razu zdekodować:

[!](ws.png)

a flaga to `seccon{9001ivr}`
