# writeup 3ds ctf 2016

team: msm, nazywam, c7f.m0d3, akrasuski, rev, psrok, shalom

### table of contents

* [rot13 (crypto 100)](crypto_100_rot13)
* [merces (re 100)](re_100_merces)
* [get started (pwn 100)](pwn_100_get_started)
* [unbreakable (crypto 200)](crypto_200_unbreakable)
* [what the hex (forensics 300)](for_300_whatthehex)
* [fibonacci calls (ppc 400)](ppc_400_fibonacci)
* [halp (network 300)](net_300_halp)
