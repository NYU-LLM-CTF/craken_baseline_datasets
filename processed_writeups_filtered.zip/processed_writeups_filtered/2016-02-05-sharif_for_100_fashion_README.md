## we lost the fashion flag! (forensics, 100p)

    in sharif ctf we have lots of task ready to use, so we stored their data about author or creation date and other related information in some files. but one of our staff used a method to store data efficiently and left the group some days ago. so if you want the flag for this task, you have to find it yourself!

    download fashion.tar.gz

###eng
[pl](#pl-version)

in this task we had a bunch of unknown files and one `fashion.model`. looking at hexdump of it, we see string "femtozip".
it turns out it's name of a compression program. downloading it and decompressing the files, we have a couple thousand
of files with contents like:
```
{'category': 'reverse', 'author': 'staff_4', 'challenge': 'fashion', 'flag': 'sharifctf{b262389c6b7a6b5f112547d5394079db}', 'ctf': 'shairf ctf', 'points': 300, 'year': 2014}
```
every file had different flag. however, we could grep  all the files for correct year, category etc. using command:

`for f in `ls`; do cat $f | grep "'points': 100" | grep "'category': 'forensic'" | grep "'year': 2016"; done`

this gives us only five results, first one of which is correct.

###pl version

w tym zadaniu dostaliśmy sporo nieznanych plików i jeden `fashion.model`. hexdump z niego zawiera tekst "femtozip".
okazuje się, że to program do kompresji danych. pobierając go i odpalając, otrzymujemy kilka tysięcy plików z 
zawartością w stylu:
```
{'category': 'reverse', 'author': 'staff_4', 'challenge': 'fashion', 'flag': 'sharifctf{b262389c6b7a6b5f112547d5394079db}', 'ctf': 'shairf ctf', 'points': 300, 'year': 2014}
```
każdy plik zawierał jednakże inną flagę. ale od czego jest grep! użyliśmy go do odfiltrowania zawartości ze śmieci:

`for f in `ls`; do cat $f | grep "'points': 100" | grep "'category': 'forensic'" | grep "'year': 2016"; done`

w tym momencie zostało już tylko pięć flag, jedna z których jest poprawna.
