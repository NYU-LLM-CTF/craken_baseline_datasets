## image archeology (admin, 350)

> we have found the file, which contains a part of gai. but where is it?
> hints
> you don't need any special reverse skills to solve this. it will be enough to use strings
> to reveal how the flag can be found.

in this task, we received an image of a small disk. after mounting it, we found an usual unix folder (/bin and so on).
even without the hint, we searched for unusual things in it:
```
find . -type f -exec bash -c "strings {} | grep -e volga\|volga && echo {}" \;
hacker.volga.ctf
./bin/busybox2
hacker.volga.ctf
./core
strings: ./usr/bin/sudo: permission denied
strings: ./usr/sbin/visudo: permission denied
```
well, it's unlikely that untampered system would have such strings, so we quickly looked into `busybox2` executable.
when ran, it didn't do much - it returned into prompt immediately. however, after a couple of seconds, our system 
restarted... after a close look, we noticed the executable contained string `/sbin/reboot`. we patched it, so it will call
`/bin/ls` instead (a crude patch, but it worked). 

the code itself was not very hard - it was:
- xoring stuff
- taking two `rand()`s without any `srand()` before and interpreting the results as a date
- sending something to `hacker.volga.ctf` (host unavailable)
- forking, and rebooting in one child

well, we did not waste our time reversing the code any further - we simply stepped through the code in debugger
and break when the connection was made to the aforementioned site. it turns out, that the flag was in memory at that
time.
