## jit in my pants (reversing, 3 points, 38 solves)
	because reversing an obfuscated jit'ed virtual machine for 3 points is fun! 

in this task we got an elf binary. looking at it's disassembly was really hard - lots
of obfuscated code was put there - i thought that for 3 points we were supposed to use
something easier. 

tracing the binary, we notice a lot of `gettimeofday` calls. this was a function checking
current time - something which should not be present in legitimate key checking code.
i created a simple replacement function (`tofd.c`), which i then ld_preload'ed to achieve
deterministic execution.

in my solution, i used instruction counting to get the flag. the idea is, that the code
checks flag characters one by one, exitting early if a character is wrong. we can exploit
this - when we supply a good prefix of the flag, the binary will execute slightly longer 
than with a wrong one. using `doit.py` and intel's pin, we brute forced the solution
one char at a time in around an hour (this could take shorter time, but i wanted to stay
on the safer side and used `string.printable` as the character set).
