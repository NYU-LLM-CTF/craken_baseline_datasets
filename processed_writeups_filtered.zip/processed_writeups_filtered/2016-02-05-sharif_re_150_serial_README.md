## serial (reverse, 150p)

    run and capture the flag!
    
    download serial

###eng
[pl](#pl-version)

we were given a binary, asking for a serial and telling us whether it's correct. disassembling it gave a weird result - 
for example:
```
0x00400a2c      je 0x400a3c
0x00400a2e      mov ax, 0x5eb
0x00400a32      xor eax, eax
0x00400a34      je 0x400a30
0x00400a36      call 0x424a24
0x00400a3b      add byte [rdi], cl
0x00400a3d      mov dh, 0x85
```
we can see jumps into the middle of instruction, which misaligned further disassembled code. thankfully, debugger was 
still working just fine. stepping through the code we can see a number of checks being done on our input.
i decided to set registers manually to expected values whenever there was a `cmp` validating our input, which allowed me
to do the task in a single run. the checks were pretty basic - for example:
```
movzx eax, byte [rbp - 0x1ff]
movsx edx, al
movzx eax, byte [rbp - 0x1f2]
movsx eax, al
add eax, edx
cmp eax, 0x9b
```
this checked whether sum of two particular letters of our password are equal to 0x9b.

after collecting all the checks like this one, we manually
calculated every character. typing it into the binary confirms it's correct, so we submitted it as a flag.

###pl version

dostaliśmy binarkę proszącą o podanie hasła i odpowiadającej, czy jest ono poprawne. deasemblacja niestety daje
dziwne rezultaty, na przykład:
```
0x00400a2c      je 0x400a3c
0x00400a2e      mov ax, 0x5eb
0x00400a32      xor eax, eax
0x00400a34      je 0x400a30
0x00400a36      call 0x424a24
0x00400a3b      add byte [rdi], cl
0x00400a3d      mov dh, 0x85
```
widzimy nietypowe skoki w środek instrukcji, które powodują nieprawidłową deasemblację kodu. na szczęście debugger
takiego problemu nie ma, wiec mogliśmy przejść instrukcja po instrukcji i obserwować jak nasze hasło jest sprawdzane.
postanowiłem ręcznie ustawiać rejestry na oczekiwane wartości przed każdą instrukcją `cmp`, dzięki czemu wystarczyło
pojedyncze przejście przez binarkę. na szczęście kod sprawdzający był dość prosty, na przykład:
```
movzx eax, byte [rbp - 0x1ff]
movsx edx, al
movzx eax, byte [rbp - 0x1f2]
movsx eax, al
add eax, edx
cmp eax, 0x9b
```
ten fragment sprawdzał, czy suma pewnych dwóch znaków hasła jest równa 0x9b.

po zebraniu wszystkich takich porównań, ręcznie ułożyliśmy hasło przechodzące je wszystkie. binarka potwierdzała jego
poprawność, zatem wysłaliśmy je jako flagę.
