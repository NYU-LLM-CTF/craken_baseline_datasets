# merces (re 100)

###eng
[pl](#pl-version)

in the task we get an elf [binary](merces) to work with.
w put it in ret-dec and we get a nice decompilation result:

```c
// address range: 0x804842b - 0x804850a
int32_t flag(int32_t a1, int32_t a2) {
    // 0x804842b
    int32_t chars_printed; // 0x804850a_2
    if (a1 != 42 || a2 < 2) {
        // 0x8048452
        if (a1 == 42) {
            // 0x8048452
            chars_printed = g1;
            // branch -> 0x8048509
        } else {
            // 0x80484f5
            putchar(51);
            putchar(68);
            putchar(83);
            putchar(123);
            putchar(48);
            putchar(112);
            putchar(49);
            putchar(110);
            putchar(49);
            putchar(64);
            printf("_te_");
            chars_printed = printf("pr%dnd%d}\n", 3, 3);
            // branch -> 0x8048509
        }
        // 0x8048509
        return chars_printed;
    }
    // 0x804843d
    chars_printed = printf("3ds{c0ruj0u}");
    // branch -> 0x8048509
    // 0x8048509
    return chars_printed;
}

// address range: 0x804850b - 0x804853f
int main(int argc, char ** argv) {
    int32_t v1 = argc;
    g1 = &v1;
    flag(42, argc);
    return 0;
}
```

we can see that simply running the binary will return a fake flag `3ds{c0ruj0u}` because the passed parameter is `42`.
we can also see that if we could modify the value passed to the `flag` function, for example with a debugger or by patching the binary, it would print the flag for us.
however, we don't even need that, considering we can see that that flag comes from:

```c
putchar(51);
putchar(68);
putchar(83);
putchar(123);
putchar(48);
putchar(112);
putchar(49);
putchar(110);
putchar(49);
putchar(64);
printf("_te_");
printf("pr%dnd%d}\n", 3, 3)
```

which evaluates to `3ds{0p1n1@_te_pr3nd3}`.

###pl version

w zadaniu dostajemy elfową [binarke](merces).
po wrzuceniu jej do ret-dec dostajemy dość ładny zdekompilowany kod:

```c
// address range: 0x804842b - 0x804850a
int32_t flag(int32_t a1, int32_t a2) {
    // 0x804842b
    int32_t chars_printed; // 0x804850a_2
    if (a1 != 42 || a2 < 2) {
        // 0x8048452
        if (a1 == 42) {
            // 0x8048452
            chars_printed = g1;
            // branch -> 0x8048509
        } else {
            // 0x80484f5
            putchar(51);
            putchar(68);
            putchar(83);
            putchar(123);
            putchar(48);
            putchar(112);
            putchar(49);
            putchar(110);
            putchar(49);
            putchar(64);
            printf("_te_");
            chars_printed = printf("pr%dnd%d}\n", 3, 3);
            // branch -> 0x8048509
        }
        // 0x8048509
        return chars_printed;
    }
    // 0x804843d
    chars_printed = printf("3ds{c0ruj0u}");
    // branch -> 0x8048509
    // 0x8048509
    return chars_printed;
}

// address range: 0x804850b - 0x804853f
int main(int argc, char ** argv) {
    int32_t v1 = argc;
    g1 = &v1;
    flag(42, argc);
    return 0;
}
```

widzimy od razu że samo uruchomienie aplikacji da nam fałszywą flagę `3ds{c0ruj0u}` ponieważ do funkcji flag przekazywany jest argument `42`.
widzimy też, że moglibyśmy zmodyfikować tą wartość debugerem lub patchując aplikacje i wypisała by dla nas flagę.
ale nie musimy robić nawet tego, ponieważ widać wyraźnie że prawdziwa flaga wychodzi z:

```c
putchar(51);
putchar(68);
putchar(83);
putchar(123);
putchar(48);
putchar(112);
putchar(49);
putchar(110);
putchar(49);
putchar(64);
printf("_te_");
printf("pr%dnd%d}\n", 3, 3)
```

co ewaluuje się do `3ds{0p1n1@_te_pr3nd3}`.
