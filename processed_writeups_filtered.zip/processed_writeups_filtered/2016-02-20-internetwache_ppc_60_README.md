## it's prime time! (ppc, 60p)

	description: we all know that prime numbers are quite important in cryptography. can you help me to find some? 
	
###eng
[pl](#pl-version)

the server sends input as:

	hi, you know that prime numbers are important, don't you? help me calculating the next prime!
	level 1.: find the next prime number after 8:
	
and our task is to provide next prime numer after given number. 
numbers were small so we could have implemented a naive algorithm or a sieve, but instead we just used `gmpy2.next_prime`:

```python
import re
import socket
import gmpy2
from time import sleep


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11059))
    regex = "level \d+\.: .* (\d+)"
    initial_data = str(s.recv(4096))
    print(initial_data)
    while true:
        sleep(1)
        task = str(s.recv(4096))
        m = re.search(regex, task)
        print(task)
        previous_number = int(m.group(1))
        result = int(gmpy2.next_prime(previous_number))
        print("result = "+str(result))
        s.sendall(str(result) + "\n")
    pass

main()
```

and after 100 examples we got a flag: `iw{pr1m3s_4r3_!mp0rt4nt}`

###pl version

serwer przysyła dane w formacie:

	hi, you know that prime numbers are important, don't you? help me calculating the next prime!
	level 1.: find the next prime number after 8:
	
a naszym zadaniem jest zwrócić kolejną liczbę pierwszą po podnanej liczbie.
liczby były bardzo małe więc mogliśmy użyć algorytmu naiwnego albo sita, ale zamiast tego użyliśmy gotowego `gmpy2.next_prime`:

```python
import re
import socket
import gmpy2
from time import sleep


def main():
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect(("188.166.133.53", 11059))
    regex = "level \d+\.: .* (\d+)"
    initial_data = str(s.recv(4096))
    print(initial_data)
    while true:
        sleep(1)
        task = str(s.recv(4096))
        m = re.search(regex, task)
        print(task)
        previous_number = int(m.group(1))
        result = int(gmpy2.next_prime(previous_number))
        print("result = "+str(result))
        s.sendall(str(result) + "\n")
    pass

main()
```

i po 100 przykładach dostaliśmy flagę: `iw{pr1m3s_4r3_!mp0rt4nt}`
