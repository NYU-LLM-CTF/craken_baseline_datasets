# writeup insomnihack teaser ctf 2016

team: cr019283, c7f.m0d3, msm, rev, other019, nazywam, shalom

### table of contents
* [fridginator 10k (crypto/web) 200](crypto_200_fridginator)
* [toasted (pwn) 250](pwn_250_toasted)
* [smartcat (web) 100](web_100_smartcat)
* [greenbox (web) 300](web_300_greenbox)
* [bring the noise (crypto) 200](crypto_200_bring_the_noise)

