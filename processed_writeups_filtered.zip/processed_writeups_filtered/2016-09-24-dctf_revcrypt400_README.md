# dctfizer (revcrypt 400)

> format response: dctf{md5(sol)} https://dctf.def.camp/quals-2016/re400.bin 

> [update]: initially it was mdcccxlvi ...... don't even bother if you have nerve problems. 

> [update] updated ciphertext again. this time key was modified too! --- http://pastebin.com/r4bndgiy

in this task, we got just the encrypted, hex-encoded file. it was easy to see some patterns were repeating, such as
`qedocbqhc` or `8dwnel`. if we read them backwards, they are `chqbcodeq` and `lenwd8`, respectively, which seem similar
to `charcode` or `length` - some javascript function names - which seemed good, so we reversed the whole ciphertext. 
we found a couple of such ciphertext-plaintext pairs and noticed
that the lower nibbles of the character never changes - for example, `q` (ascii 0x71) from `chqbcode` was changed to `a`
(ascii 0x61). we wrote an [interactive brute forcer](interactive.py), which allowed us to recover a couple
dozens of plaintext bytes:
```
`ufa,(hvensdio.(y{fq"p:];8)<7 <6 <8%<8'<9$<9 <7!<7$<8 <7)<8(<7&<8!<7%<6%<6&<8&<8"<7r={fq"p1][
 eval((function(){var j=[89,70,60,85,87,94,90,71,74,80,79,88,76,81,75,65,66,86,82,7b];var a=[
```
if we write higher nibble of ciphertext, of plaintext, and of their xor, we will get something like this:
```
`ufa,(hvensdio.(y{fq"p:];8)<7 <6 <8%<8'<9$<9 <7!<7$<8 <7)<8(<7&<8!<7%<6%<6&<8&<8"<7r={fq"p1][
 eval((function(){var j=[89,70,60,85,87,94,90,71,74,80,79,88,76,81,75,65,66,86,82,7b];var a=[
676622676676662277672735332332332332332332332332332332332332332332332332332332332335376727355
267662267667666227767263533233233233233233233233233233233233233233233233233233233234537672635
411040411011004050115556601101101101101101101101101101101101101101101101101101101101641155560
```
we can notice a pattern: lower row is xor of last two numbers on top row. with this in mind, we wrote a [script](solv.py)
to decrypt the whole file.

the decrypted file was the following script (after unpacking and unminifying):
```javascript
var _$_ddec = [ "tostring", "charcodeat", "length", "0", "map", "", "split", "join", "fromcharcode", "max", "log", "dctfizer", "undctfizer", "so what exactly do you want?" ];
 
function gotohex(b) {
    var c = b["split"]("")["map"](function(d) {
        var e = d["charcodeat"](0)["tostring"](16);
        return e["length"] == 1 ? "0" + e : e;
    });
    return c["join"]("");
}
 
function backfromhex(b) {
    var c = "";
    for (var a = 0; a < b["length"]; a += 2) {
        c += string["fromcharcode"](parseint(b[a] + b[a + 1], 16));
    }
    return c;
}
 
function memorygood(b, l) {
    var f = [];
    var g = 0;
    for (var a = 0; a < 234; a++) {
        f[a] = a;
    }
    for (a = 0; a < math["max"](234, b["length"]); a++) {
        var h = l["charcodeat"](a);
        l += string["fromcharcode"]((h << 1 | h >> 7) & 255);
    }
    console["log"](l["charcodeat"](4));
    for (a = 0; a < 234; a++) {
        g = (g + f[a] + l["charcodeat"](a)) % 234;
        f[a] ^= f[g];
        f[g] ^= f[a];
        f[a] ^= f[g];
    }
    a = g = 0;
    result = "";
    for (var m = 0; m < b["length"]; m++) {
        a = (a + 1) % 234;
        g = (g + f[a]) % 234;
        f[a] ^= f[g];
        f[g] ^= f[a];
        f[a] ^= f[g];
        var n = f[(f[a] + f[g]) % 234];
        var o = l["charcodeat"](m);
        result = result + string["fromcharcode"](n ^ b["charcodeat"](m) ^ o);
    }
    return result;
}
 
function proceed(b, l, p) {
    if (p == "dctfizer") {
        ciphertext = memorygood(b, l);
        return gotohex(ciphertext);
    } else {
        if (p == "undctfizer") {
            plaintext = memorygood(backfromhex(b), l);
            return plaintext;
        }
    }
    return "so what exactly do you want?";
}
```

this is a modified rc4 algorithm.
in this code we can see a vulnerability in key expansion algorithm:

```javascript
    for (a = 0; a < math["max"](234, b["length"]); a++) {
        var h = l["charcodeat"](a);
        l += string["fromcharcode"]((h << 1 | h >> 7) & 255);
    }
```

the key is basically rotating, so if the first byte was `1100` then the first byte of extended key part would be `1001` and in the next round `0011` and so on. 
this means that if we could extract a single bit position of the key, with enough ciphertext length we could extract the whole key.
however the code here was broken because `% 234` does not leave any bit position intact (maybe they wanted to do `& 234`?).
we contacted admins and they admited that it was a mistake and it should have been `128` and not `234`, which basically coverges this task to the same problem as here:

https://github.com/p4-team/ctf/tree/master/2015-11-20-dctffinals/crypto300#eng-version

because now the msb of all of the xored elements is 0 apart from the one from key, so we can extract all msb bits from ciphertext and combine them to recover the key (we need to brute-force the key length as well but the range is small).
