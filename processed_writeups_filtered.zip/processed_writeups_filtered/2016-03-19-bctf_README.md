# writeup bctf 2016

team: akrasuski1, c7f.m0d3, cr019283, graszka, msm, nazywam, other019, rev, shalom

### table of contents
* ruin (exploit, 200)
* irc (misc, 10)
* catvideo (stegano, 150)
* special rsa (crypto, 200)
* memo (exploit, 300)
* betafour (ppc, 500)
* bcloud (exploit, 150)
* [zerodaystore (misc, 200)](misc_200_zerodaystore)
* [hsab (misc, 250)](misc_200_hsab)
