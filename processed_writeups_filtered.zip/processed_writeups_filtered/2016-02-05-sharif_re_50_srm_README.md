﻿## srm (reverse, 50p)

> the flag is : the valid serial number
> [download](rm.exe)

###eng
[pl](#pl-version)

we downloaded windows binary and run it. it asks us to enter serial and checks its validity.

we disasembled it, and checked content of its dialogfunc. we can clearly see interesting fragment:

```c
if (strlen(v13) != 16
  || v13[0] != 67
  || v25 != 88
  || v13[1] != 90
  || v13[1] + v24 != 155
  || v13[2] != 57
  || v13[2] + v23 != 155
  || v13[3] != 100
  || v22 != 55
  || v14 != 109
  || v21 != 71
  || v15 != 113
  || v15 + v20 != 170
  || v16 != 52
  || v19 != 103
  || v17 != 99
  || v18 != 56 ) {
    // fail
  } else {
    // ok
  }
```

different xxx stand for different characters of input - using debugger it's easy to check which variable is which character.
reversing this check took a while, because every comparsion had to be implemented, but when we succeeded, we get valid serial that turned out to be flag:

    cz9dmq4c8g9g7bax

###pl version

pobieramy windowsową binarkę i uruchamiamy. prosi ona o podanie serialu i sprawdza jego poprawność.

disasemblujemy ją więc, i patrzymy na zawartośc dialogfunc. od razu widać ciekawy fragment:

```c
if (strlen(v13) != 16
  || v13[0] != 67
  || v25 != 88
  || v13[1] != 90
  || v13[1] + v24 != 155
  || v13[2] != 57
  || v13[2] + v23 != 155
  || v13[3] != 100
  || v22 != 55
  || v14 != 109
  || v21 != 71
  || v15 != 113
  || v15 + v20 != 170
  || v16 != 52
  || v19 != 103
  || v17 != 99
  || v18 != 56 ) {
    // fail
  } else {
    // ok
  }
```

różne vxx odpowiadają za różne znaki inputu - łatwo dojść do tego które odpowiadają za które przy użyciu debuggera.
reversowanie tego zajęło chwilę bo trzeba było porównać wszystkie znaki, ale kiedy się udało, otrzymaliśmy poprawny serial, będący równoczesnie flagą:

    cz9dmq4c8g9g7bax
