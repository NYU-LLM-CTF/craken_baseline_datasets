#metadata (fbi, 50 points, solved by 311)


```
help me to find some metadata!

https://silkroadzpvwzxxv.onion
```

the flag was hidden in the website's certificate:



[image extracted text: issucd to
common namc
(cnj: si_kroadzpvwzxxv
cnior
organization
oj: ekoparty
organizational unit
exo{is_thig
just
rea]
life
this
jugt_fantagy}
(oui:]

