##connect the server (web/network, 100p)

```
login.pwn.seccon.jp:10000
```

###pl
[eng](#eng-version)

po połączeniu się z serwerem za pomocą nc dostajemy:


[image extracted text: nc6: using
3tream
socket
connect
300
come
seccon
berver
the
3erver
connected
via
3l0w
dial-up
connection
please
be patient 
and
not
brute
force
login:
login
timer
timed
out
thank
you
for
your
cooperation
hint :
already
your
hands
good
bye]


wpisanie dowolnego loginu także nie daje żadnych efektów. próbowaliśmy podejść do tego zadania z różnych stron, bez efektów. w końcu uznaliśmy, że skoro zadanie wspomina o wolnym połączeniu to może spróbujemy ataku czasowego albo próby wyczerpania wątków serwera. jednak w trakcie pisania skryptu zauważyliśmy dość dziwny wynik:

```
b'connect 300\r\n\r\nwelcome to seccon server.\r\n\r\nthe server is connected via slow dial-up connection.\r\nplease be patient, and do not brute-force.\r\ns\x08 \x08e\x08 \x08c\x08 \x08c\x08 \x08o\x08 \x08n\x08 \x08{\x08 \x08s\x08 \x08o\x08 \x08m\x08 \x08e\x08 \x08t\x08 \x08i\x08 \x08m\x08 \x08e\x08 \x08s\x08 \x08_\x08 \x08w\x08 \x08h\x08 \x08a\x08 \x08t\x08 \x08_\x08 \x08y\x08 \x08o\x08 \x08u\x08 \x08_\x08 \x08s\x08 \x08e\x08 \x08e\x08 \x08_\x08 \x08i\x08 \x08s\x08 \x08_\x08 \x08n\x08 \x08o\x08 \x08t\x08 \x08_\x08 \x08w\x08 \x08h\x08 \x08a\x08 \x08t\x08 \x08_\x08 \x08y\x08 \x08o\x08 \x08u\x08 \x08_\x08 \x08g\x08 \x08e\x08 \x08t\x08 \x08}\x08 \x08\r\nlogin: '
```

naszą uwagę zwróciły niepiśmienne znaki o numerze ascii 8, czyli backspace. otóż serwer wypisywał flagę, ale było to niewidoczne w konsoli.

`seccon{sometimes_what_you_see_is_not_what_you_get}`

### eng version

after connecting with nc we get:


[image extracted text: nc6: using
3tream
socket
connect
300
come
seccon
berver
the
3erver
connected
via
3l0w
dial-up
connection
please
be patient 
and
not
brute
force
login:
login
timer
timed
out
thank
you
for
your
cooperation
hint :
already
your
hands
good
bye]


using any login doesn't help us moving forward with the task. we tried different approaches but to no avail. finally we decided that, since the task mentions and weak slow connection, we could try a timing attack or try to exhaust server threads. however, while writing a script we noticed a strange data coming from server:

```
b'connect 300\r\n\r\nwelcome to seccon server.\r\n\r\nthe server is connected via slow dial-up connection.\r\nplease be patient, and do not brute-force.\r\ns\x08 \x08e\x08 \x08c\x08 \x08c\x08 \x08o\x08 \x08n\x08 \x08{\x08 \x08s\x08 \x08o\x08 \x08m\x08 \x08e\x08 \x08t\x08 \x08i\x08 \x08m\x08 \x08e\x08 \x08s\x08 \x08_\x08 \x08w\x08 \x08h\x08 \x08a\x08 \x08t\x08 \x08_\x08 \x08y\x08 \x08o\x08 \x08u\x08 \x08_\x08 \x08s\x08 \x08e\x08 \x08e\x08 \x08_\x08 \x08i\x08 \x08s\x08 \x08_\x08 \x08n\x08 \x08o\x08 \x08t\x08 \x08_\x08 \x08w\x08 \x08h\x08 \x08a\x08 \x08t\x08 \x08_\x08 \x08y\x08 \x08o\x08 \x08u\x08 \x08_\x08 \x08g\x08 \x08e\x08 \x08t\x08 \x08}\x08 \x08\r\nlogin: '
```

we focused on the acii characters number 8 - backspace. the server was printing a flag but we simply didn't see that in the console.

`seccon{sometimes_what_you_see_is_not_what_you_get}`
