# a7 ~ gee cue elle (misc, 283p)

> we installed a fancy automatic attack protection system to be more secure against automated attacks from robots and hackers so it can be fully a7 compliant!

> hint: .yaml~

> start.html

in this task we are given a small html file. its whole content is here:
```html
<script>
location.replace('http://'+parseint(math.random()*1e15)+'-abuse.web.ctfcompetition.com/login');
</script>
```

it's a simple redirect to randomly generated host. what we see next, is a simple login site. 
there is a login and password
field, along with a `~login~` button. trying to type anything into the fields and clicking the
button shows a popup saying `please match the requested format`. ok, we may be able to craft a
request anyway (the check is client-side), but let's not do this yet. instead, we'll peek
into the source of the website. honestly, not much is here, just the regex for checking the 
fields: `admin` for the login field, and `ctf[{]qu0t45[a-z0-9_]{16}www-[0-9a-za-z_-]{64}[}]` for
the password.

when we type the login and password matching the formats, we receive a popup saying 
`wrong password`. nothing unexpected. however, if we check for sql injection by forging a 
request with apostrophe character in password field, we receive a redirect to a subpage
showing popup 
`parse error: identifier is a reserved keyword at symbol ancestor`.
hmmm. googling the error shows it's an error of gql (google query language, alternative to sql).
now we can make sense of the challenge title: "gee cue elle" is the phonetic form of gql.

gql is known for being difficult to inject to. we were stuck at this point for a while, but 
then a hint arrived: `.yaml~`.

as one of the first steps, we checked `robots.txt` file. it showed:
```
user-agent: *
disallow: /app.yaml
disallow: qa!
```
we obviously tried to fetch the `app.yaml`, but the request was blocked (maybe permissions 
issue). anyway, after the hint, we thought to append a tilde character to the filename, as 
though someone left editor temporary files on the server. and it worked! here are the contents
of the file:
```yaml
service: anon2-lmuwucba5we9gi5a
runtime: python27
api_version: 1
threadsafe: true

handlers:
- url: /login
  script: main.app

- url: /
  static_files: index.html
  upload: index.html

- url: /(.+)
  static_files: \1
  upload: .*[.](?!py$).*

libraries:
- name: webapp2
  version: latest
- name: jinja2
  version: latest

skip_files:
- ^(.*/)?\.bak$
```

looks like it's app engine's configuration file 
(`https://cloud.google.com/appengine/docs/standard/python/config/appref`).
after looking at some of sample projects using this platform, we noticed a lot of them contains
`main.py` file. we checked for its presence on the server, and we managed to download it
when we appended a tilde (so, temporary file again).

now we have full application source code. it appears it's a pretty basic login checker,
but just as we noticed earlier, there is an gql injection:
```python
  def post(self):
    sql = "select password from usermodel where ancestor is :1 and user = '%s'"
    query = ndb.gql(sql % self.request.get("user"), self.quota.key)
    result = query.fetch(1)
    if not result:
      self.redirect("/index.html?e=%s" % urllib.quote("wrong username"))
    elif result[0].password != self.request.get("password"):
      raise exception("wrong password")
    else:
      self.response.write(self.request.get("password"))
```
the query should have used `:2` placeholder for username, instead of formatting the query
using `%s`. 

well, it seems we can't really get password directly sent to us, because the only result
we can have is that we either have `wrong username` error, or `wrong password` one (or
correct password, but we won't get it by accident ;]). wrong username will be returned only
if the query doesn't return any rows - and we know `admin` user exists. so, if we set
username to `admin' and some_check`, we might have error-based injection, and be able to 
dump the password bit by bit. in fact, we used the following username:
```
admin' and password > 'checked_password
```
the full query then looks like:
```sql
select password from usermodel where ancestor is :1 and user = 'admin' and password > 'checked_password'
```
now we can binary searched the password.


... or so we thought. i haven't mentioned that, but the application implements a simple
abuse detection. when too many password checks have been done, or too many errors have 
been made, it bans us for 90s. in addition, it bans us permamently after 2240s. it even 
writes that in the response if we get banned:
```html
<h1>abuse detection system triggered!</h1>
<h3>you have been banned for 90 seconds.</h3>
<p>
  <b>
    if you believe this is a mistake, contact your system administrator.
  </b>
  possible reasons include:
  <ul>
    <li>generating too many errors too quickly
      <!--debug: 2 queries / 30 seconds--></li>
    <li>making too many requests too quickly
      <!--debug: 13 queries / 30 seconds--></li>
    <li>spending too much time without authenticating
      <!--debug: 2240 seconds--></li>
  </ul>
</p>
```

when i first implemented the binary search, i just got throttled so much, that i eventually
hit the 2240s limit while getting less than half of the password. i retried a couple of times,
but the results were the same.

hmmm. let's make some calculations.

the password follows a certain regex. from the python source, we know all the characters,
except for 64 pseudo-random base64 characters. since each base64 character has 6 bits of
entropy, that means we have a total of `64*6 == 384` bits and we need that many queries.
on average, half of them counts as errors (`wrong password` is signalled through raising
an exception, while `wrong username` directly redirects). if we don't throttle requests
on our side, we will get banned for 90s after around 4 requests, so reading all bits will
take approximately `384/4*90 == 8640` seconds. that's way too much. we can reduce it
threefold if we throttle the requests locally - in other words, when we got 2 errors within
the last 30 seconds, we wait until this condition is no longer true. that algorithm
will give password after, very approximately, `384/4*30 == 2880` seconds. that's much
closer to the limit of 2240s, but still, when we tried it a couple of times, we were
getting banned too soon. 

what else can we do? well, let's assume for a moment only error requests are counted towards
the limit, and otherwise we can do them as much as we can. then, we would be able to check
consecutive letters: `a`, `b`, `c`, and so on, each time getting free `wrong username`,
until we finally hit the correct letter with `wrong password`. this would take only one
error per letter, so one timeout per 4 letters or `64/4*30 == 480` seconds (not
counting latency for checking all the small characters). 

unfortunately, the non-error requests are limited too (up to 13 requests per 30 seconds),
so we cannot directly apply that strategy. instead, we biased our binary search algorithm
to divide the search space not in the middle, but at around 90%. the value is pretty arbitrary,
it should probably be close to `allowed_hits/(allowed_hits+allowed_errs)`, but the truly
optimal strategy would also take into account how many of the errors are already used up.
we decided not to bother with such hard optimizations and just opened 20 instances of the
biased binary search, and after 2240s we found two of them actually managed to squeeze
through and calculated the whole flag.

ctf-quality code for solving is available in `doit2.py` file. 
