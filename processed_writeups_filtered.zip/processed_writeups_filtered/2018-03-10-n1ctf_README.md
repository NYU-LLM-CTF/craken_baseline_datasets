# n1 ctf 2018

team: borysp, nazywam, eternal, chivay, shalom, ppr, pwn.m0d3, akrasuski1, msm, sasza

### table of contents

* [patience (re)](re_patience)
* [mathgame (ppc)](ppc_mathgame)
* [rsa padding (crypto)](crypto_rsapadding)
