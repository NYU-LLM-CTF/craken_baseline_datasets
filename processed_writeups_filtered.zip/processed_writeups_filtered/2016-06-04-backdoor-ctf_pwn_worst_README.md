## worst pwn ever (pwn)

###eng
[pl](#pl-version)

we get netcat connection parameters to work with.
after connecting to the server we get a custom command-line prompt, but typing some random things cause the connection to close.
some fuzzing lead us to typing `1+()` which crashes with a nice python exception that we can't add int to a tuple.
this means that our input has to be evaluated by python interpreter.
we use this to run:

```python
__import__("pty").spawn("/bin/sh")
```

to get a real shell on the target machine.
after that we tried the standard aproach with `find flag` but it gave us nothing.
fortunately we came back to task description which stated that the admin is `environmentalist` and so we typed `set` to see evn variables and there was a variable named `_f_l_ag` containing the flag itself.

###pl version

dostajemy parametry do połączenia się przez netcata.
po połączeniu serwer wyświetla znak zachęty jak w shellu, ale próby wpisywania losowych rzeczy powodują zerwanie połączenia.
trochę fuzzowanai pozwala zauważyć że wpisanie `1+()` wysypuje shella z ładnym pythonowym wyjątkiem ze nie można dodać inta do krotki.
to oznacza, że nasz input jest ewaluowany przez interpreter pythona.
w związku z tym uruchamiamy:

```python
__import__("pty").spawn("/bin/sh")
```

aby dostać prawdziwego shella na docelowej maszynie.
po tym próbowaliśmy trochę standardowych operacji jak `find flag` ale niczego nie znaleźliśmy.
na szczęście wróciliśmy do opisu zadania, w którym było napisane że admin to `environmentalist` w zwiazku z tym wpisaliśmy komendę `set` żeby zobaczyć wszystkie zmienne środowiskowe i faktycznie jedną z nich była `_f_l_ag` zawierająca flagę.
