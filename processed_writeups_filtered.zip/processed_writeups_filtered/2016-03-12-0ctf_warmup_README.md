## warmup (pwn, 2p)
	
	warmup for pwning!
	notice: this service is protected by a sandbox, you can only
	read the flag at /home/warmup/flag
	
we were given small [linux binary](warmup):
```
warmup: elf 32-bit lsb executable, intel 80386, version 1 (sysv), statically linked, buildid[sha1]=c1791030f336fcc9cda1da8dc3a3f8a70d930a11, stripped
```

### vulnerability

the file is 724 bytes long.
for such small files, usual strategy is to start by understanding the code in order to identify vulnerability.

we used ida to disassemble the binary.
soon we identified classic buffer-overflow in subroutine 0x0804815a:
```
.text:0804815a read_user_data  proc near               ; code xref: start+2bp
.text:0804815a
.text:0804815a fd              = dword ptr -30h
.text:0804815a addr            = dword ptr -2ch
.text:0804815a len             = dword ptr -28h
.text:0804815a buffer          = byte ptr -20h
.text:0804815a
.text:0804815a                 sub     esp, 30h
.text:0804815d                 mov     [esp+30h+fd], 0 ; fd
.text:08048164                 lea     eax, [esp+30h+buffer]
.text:08048168                 mov     [esp+30h+addr], eax ; addr
.text:0804816c                 mov     [esp+30h+len], 34h ; len
.text:0804816c                                         ; vulnerability: len > sizeof(buffer)
.text:08048174                 call    sys_read
.text:08048179                 mov     [esp+30h+fd], 1 ; fd
.text:08048180                 mov     [esp+30h+addr], offset agoodluck ; "good luck!\n"
.text:08048188                 mov     [esp+30h+len], 0bh ; len
.text:08048190                 call    sys_write
.text:08048195                 mov     eax, 0deadbeafh
.text:0804819a                 mov     ecx, 0deadbeafh
.text:0804819f                 mov     edx, 0deadbeafh
.text:080481a4                 mov     ebx, 0deadbeafh
.text:080481a9                 mov     esi, 0deadbeafh
.text:080481ae                 mov     edi, 0deadbeafh
.text:080481b3                 mov     ebp, 0deadbeafh
.text:080481b8                 add     esp, 30h
.text:080481bb                 retn
.text:080481bb read_user_data  endp
```

the identified vulnerability allows for reading 0x14 bytes after end of buffer.
this includes return address from this subroutine that is stored on stack.

we didn't find any other vulnerabilities in provided binary.

### exploitation approach

we started the binary and captured process memory map of the process when vulnerable function is executing:
```
# cat /proc/[pid]/maps
08048000-08049000 r-xp 00000000 00:13 924601                             /root/ctf/warmup/fix
08049000-0804a000 rw-p 00000000 00:13 924601                             /root/ctf/warmup/fix
f77ce000-f77d0000 r--p 00000000 00:00 0                                  [vvar]
f77d0000-f77d1000 r-xp 00000000 00:00 0                                  [vdso]
ffe1b000-ffe3c000 rw-p 00000000 00:00 0                                  [stack]
```

it looks as we don't have any write+execute pages.
repeating this second time shows that locations other than binary itself are randomized.

for such cases, typical approach is by using gadgets that may be present in the binary itself.

### exploit implementation

the identified vulnerability allows for controlling just 0x10 bytes after the overwritten return address.
searching for available gadgets indicates that task difficulty is to construct useful rop chain in controlled buffer.
e.g. if we use subroutine 0x0804811d to read additional data, there are too few available bytes left for opening and reading flag file.

to overcome this limitation we decided to return back to program entry at 0x080480d8 instead.
this allows for filling longer stack area by repeatedly overflowing the buffer, such that each read is lower down the stack.
once complete rop is ready, we jump to the first gadget.

the rop chain has the following steps:

1. read string */home/warmup/flag* into data area of exploited binary
2. write *sys_open* bytes using 0x08048135 to set eax register
3. execute 0x08048122 that performs syscall using pre-set eax, this will open */home/warmup/flag* for read
4. read content of flag file using data area of exploited binary as buffer, we assume that file opened in previous step uses descriptor 3
5. write content of buffer to standard output

attached [exploit.py](exploit.py) was used to retrieve flag during ctf.
