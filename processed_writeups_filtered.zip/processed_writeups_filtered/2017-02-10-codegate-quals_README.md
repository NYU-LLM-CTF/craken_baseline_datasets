# writeup whitehat ctf gp 2016

team: msm, rev, shalom, nazywam, c7f.m0de, cr019283, akrasuski1, psrok1

### table of contents

* [messenger (pwn 205)](messenger)
* [meow (re/crypto/pwn 365)](meow)
* [angrybird (re 125)](angrybird)
