## whiteout mathmatics (reverse, ppc, 200p)
	tl;dr reverse the program, find the number that matches the problem



our job is to run the included [whitespace program](program) with following arguments: `100 1000000000000`

after some fiddling with it, we've noticed it's hard to get the output in reasonable for anything bigger than a couple hundred. so we have to find out what exactly does it do.

covert the source code to asm-like instructions, do some dynamic analysis and you get something like this:

```assembly



     push 1                                         
     iint              //load first input to 1  input1                        
     push 2                                         
     iint              //load second input to 2 input2                          
     push 3                                         
     push -1                                        
     set               //store -1 at 3                             
     push 1                                         
     get               //push input 1
part "a"                                            
     copy              //duplicate                             
     push 2                                         
     get               //push input 2
     push 1                                         
     add               //push (1 + input2)                            
     sub               //input1 - input2                            
     less "b"          //jump b if <0                             
     goto "d"          //jump d else                             
part "b"                                            
     copy                                         
     call "e"    // return sum of divisors for current input1 (on top of the stack)                                    
     copy                                           
     push 3                                         
     get          
     sub          
     less "c"    // generally, set value of variable_3 to max of variable_3 and returned value from "e"                                
     push 3                                         
     swap                                           
     set                                            
     push 0                                         
part "c"                                            
     away                                           
     push 1                                         
     add                                            
     goto "a"                                       
part "d"   //print twctf{variable_3}
     push 3                                         
     get                                            
     push 84                                        
     ochr                                           
     push 87                                        
     ochr                                           
     push 67                                        
     ochr                                           
     push 84                                        
     ochr                                           
     push 70                                        
     ochr                                           
     push 123                                       
     ochr                                           
     oint                                           
     push 125                                       
     ochr                                           
     push 10                                        
     ochr                                           
     exit                                           
part "e"     // set variable_5 to 0
     push 5                                         
     push 0                                         
     set            //store 0 at 5                                       
     push 1                                         
part "f"                                            
     copy 1         
     copy 1                                                                        
     mod            
     zero "g"       //jump if interator divides current input1                                
     goto "h"       

part "g"     //add current interator value to variable_5
     copy                                           
     push 5                                         
     get            //push from 5                                
     add            //add interator                                 
     push 5                                         
     swap                                           
     set            //store to 5

part "h"     // check if interator value is equal or bigger than current input1                                       
     push 1  
     add                                            
     copy                                           
     copy 2  //input1                                       
     sub                                            
     push 1                                         
     sub                                            
     less "f"                                       
     away                                           
     away                                           
     push 5                                         
     get                                            
     back                                           
```

it turns out, that the program searches for the biggest sum of divisors for numbers from `input1` to `input2` and it's complexity is o(n^2), which means, it wont return the answer for 10^12 before end of the ctf ;).

so we either have to calculate the outcome using a more sophisticated algorithm... or find the result on [google](https://oeis.org/a002093/b002093.txt)

use wolframalpha to get the sum of divisors and your score magically increments by 200 points!

`twctf{5618427494400}`
