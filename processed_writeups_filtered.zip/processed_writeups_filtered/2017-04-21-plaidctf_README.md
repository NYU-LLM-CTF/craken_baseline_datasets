# plaid ctf 2017

team: nazywam, ppr, psrok1, c7f.m0d3, cr019283, shalom

## table of contents

* [logarithms are hard (misc)](logarithms)
* [multicast (crypto)](multicast)
* [bb-8 (crypto)](bb8)
* [sha-4 (web/crypto)](sha4)
* [pykemon (web)](pykemon)
