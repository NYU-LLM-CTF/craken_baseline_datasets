## interpolation (reverse, 200p)

    newton is an autonomous unmanned aerial vehicle (uav). where the uav is refueled at t=180 ?

    path planning:
    t x y
    0; 35.645592; 50.951123;
    20; 35.144068; 50.467725;
    40; 34.729775; 48.204541;
    60; 34.204433; 46.117139;
    80; 33.602623; 44.908643;
    100; 33.162285; 42.337842;
    120; 33.712359; 40.140576;
    140; 33.931410; 38.580518;
    150; 33.894940; 37.745557;
    170; 33.474422; 36.273389;
    190; 35.32583531; 35.663648;
    210; 33.130089; 35.19047214;
    220; 32.409544; 35.141797;
    230; 32.085525; 34.786115;
    the flag is: [the bridge`s name near the refule place][latitude of the place with 5 digits after the decimal point][longitude of the place with 5 digits after the decimal point]

###eng
[pl](#pl-version)

task description mentions newton and the title was "interpolation" - so we used newton's interpolation method
to find `(x, y)` at `t=180`. this gave us location - after checking it in google maps, there was indeed a bridge nearby.

###pl version

ponieważ zadanie wspominało o newtonie i interpolacji, użyliśmy metody newtona do znalezienia `(x, y)` w momencie
`t=180`. to dało nam współrzędne geograficzne - po sprawdzeniu ich na mapach google, okazało się, że faktycznie jest
w pobliżu most, o który nas proszą w zadaniu.
