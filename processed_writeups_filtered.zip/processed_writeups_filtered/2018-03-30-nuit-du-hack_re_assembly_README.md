# assembly me (re)

in the task we get a simple webpage with a single textbox and button.
there is javascript and [webassembly](wasm.txt) code which validates password we input on the page.

there is quite a lot of this webasm, and reversing it is quite hard, but already initial reading shows:

```javascript
	var button = document.getelementbyid('check');

	button.addeventlistener('click', function(){

	u = document.getelementbyid("i").value;
	var a = module.cwrap('checkauth', 'string', ['string']);
	var b = a(u);
	document.getelementbyid("x").innerhtml = b;
	});
```

so we know that entry point is `checkauth` function, and we can see that:

```
  (export "_checkauth" (func $func35))
```

so let's focus on this single function:

```
  (func $func35 (param $var0 i32) (result i32)
    (local $var1 i32) (local $var2 i32)
    get_global $global5
    set_local $var1
    get_global $global5
    i32.const 16
    i32.add
    set_global $global5
    get_local $var1
    set_local $var2
    get_local $var0
    i32.const 1616
    i32.const 4
    call $func57
    i32.eqz
    if
      get_local $var0
      i32.const 4
      i32.add
      i32.const 1638
      i32.const 4
      call $func57
      i32.eqz
      if
        get_local $var0
        i32.const 8
        i32.add
        i32.const 1610
        i32.const 5
        call $func57
        i32.eqz
        if
          get_local $var0
          i32.const 13
          i32.add
          i32.const 1598
          i32.const 4
          call $func57
          i32.eqz
          if
            get_local $var0
            i32.const 17
            i32.add
            i32.const 1681
            i32.const 3
            call $func57
            i32.eqz
            if
              get_local $var0
              i32.const 20
              i32.add
              i32.const 1654
              i32.const 9
              call $func57
              i32.eqz
              if
                get_local $var1
                set_global $global5
                i32.const 1690
                return
              end
            end
          end
        end
      end
    end
    i32.const 1396
    get_local $var0
    get_local $var0
    call $func45
    call $func57
    i32.eqz
    if
      get_local $var1
      set_global $global5
      i32.const 1761
      return
    end
    i32.const 1747
    get_local $var2
    call $func77
    drop
    get_local $var1
    set_global $global5
    i32.const 1761
  )
```

main part of the code is a cascade of conditions and calls to `$func57`.
once we pass a single condition we can enter another one, so it's safe to assume we need to pass all of them.

reversing webasm is hard, so first we tried to work with this as some kind of blackbox.
it's clear that before calling function 57 there is some address put on the stack (1616, 1638... are addresses of some strings in the code) and some small number.
we can also see that we want the return value to be 0, so we can pass the condition.
by seding some random values for the first condition we can notice a very interesting characteristic of the return value - it's not random at all.
in fact it's monotonous!
if we send `a` we get value `x`, if we send `b` we get `x+1` etc.
so it's trivial to calculate which character we need to send in order to get `0`.
but once we do this, the value instead of 0 becomes some larger number.
our guess was that the function checks multiple characters, so once we get a "valid" first character, it checks another one and thus we get a large number again.

with those assumptions the solution seems quite straightforward:

1. we put breakpoint on `i32.eqz` 
2. we send random letter as password, let's say `a`.
3. we send next letter in alphabet, to make sure we didn't actually get the right one on first try.
4. now we know how far `a` is from the expected letter, so we can calculate a real password character by `chr(ord('a')-x)`

we can repeat this with second letter of the password, and so on, until we actually pass the condition.
once we pass the check (after a few letters), we can place another breakpoint on the next condition and repeat the same procedure.

so for example when we send `a` we get return value (top of the stack) `-3` which means the real character is `chr(ord('a')-(-3) == 'd'`:


[image extracted text: paused in
debugger
authentication failed.
login
sources
network
performance
memory
application
security
audits
(index)
indexjs
wasm-ooo18bea-35 *
func
(param 132) (result 132)0
paused on breakpoint
(local 132 132)
global
watch
set
local
get_global
call stack
132.const 16
<wasm unnamed>
wasm;
00o
132.add
set_global
module:
checkauth
local
ccall
10
set
local
local
(anonymous)
132
const 1616
%
132.const
(anonymous)
call 57
scope
15
hi32.eqz
global
if
local
local
132.const
locals: {arg#0:
6864,
local#l:
6880,
local#2:
6880}
e
132.add
stack: {0:
-3}
132
const 1638
this:
global
132
const
breakpoints
get
get_
get
get]


we follow this approach to get whole password: `d51xpox)1s0xk5s11w_ekxk,,,xie` and we get `authentication is successful. the flag is ndh{password}`
