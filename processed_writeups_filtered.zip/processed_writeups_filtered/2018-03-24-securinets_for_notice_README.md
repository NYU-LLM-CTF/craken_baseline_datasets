# notice me (forensics/stegano)

in the task we get some image drive (heavy one, so we won't upload it here), and hint that someone had secret data they removed.
binwalk says there is a png file and strings analysis shows that this png is close to `trash` strings.

we extract the image:


[image extracted text: mrr030#]


then we checked with stegsolve is maybe there is something hidden in the picture, and it turns out that lsb of the last data lines hides a link, to another image.
they look identical, but the next image hides a different link.
we assume this might be a long chain, so we've wrote a script to download the whole chain:

```python
import codecs
import requests
from crypto_commons.generic import chunk


def extract_link(data):
    bits = []
    for b, g, r, a in data:
        lsb = b & 1
        bits.append(lsb)
    chunked_bytes = chunk(bits, 8)
    integers = map(lambda x: int("".join(map(str, x)), 2), chunked_bytes)
    full = "".join(map(chr, integers))
    print(full[-100:])
    return full[-23:]


def main():
    from pil import image
    index = 0
    filename = "pngs/" + str(index) + ".png"
    while true:
        im = image.open(filename)
        data = im.getdata()
        index += 1
        new_link = extract_link(data)
        print(new_link)
        r = requests.get("http://" + new_link)
        filename = "pngs/" + str(index) + ".png"
        with codecs.open(filename, "wb") as output_file:
            output_file.write(r.content)


main()
```

it turns out it didn't take that long, already the 6th image is:


[image extracted text: [ ]
r4,



n m
5
2

5

13e77
08 -
piz
ldae
33
een
7-#
5
66

t=2
737
5
14!
e2f2 -
n
0
p
kit=
5e2
  & $
x582
7e -
pe-?
e _
e
ul
at
k
f=-
2

#f-
e
a
i
7 =1-4
e
{3 
5e--272
y~


t#
ftt==
772
b1
fa
2n
39
64
0 0
[

zi"
t72
f]
e
ber
l1
u u_
1
2= 3
el
1
nm
4
tits75 =
0i
eefi [
aus axnus
6 j
5
[
1 :"
lork police depti
fane
s
patte=_7
mr robot
51 ^
fon
fing
jasdaq]


and hides: `flag{m1nd_4wak3_b0dy_4sl33p}`
