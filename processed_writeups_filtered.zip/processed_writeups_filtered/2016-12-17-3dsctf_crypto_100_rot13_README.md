# rot13 (crypto 100)

###eng
[pl](#pl-version)

we get `3rg{hv1g_f0h_1g_b0h_g0_v0h}` as ciphertext and n=11.
it looks like some substitution cipher working only on letters, so we assume a caesar.
so after running caesar solver on this we get the flag `3ds{th1s_r0t_1s_n0t_s0_h0t}` for shift 11.

###pl version

dostajemy ciphertext `3rg{hv1g_f0h_1g_b0h_g0_v0h}` i n=11.
wygląda to jak szyfr podstawieniowy działający tylko dla liter, więc założyliśmy cezara.
więc po uruchomieniu solvera dla cezara dostajemy flagę `3ds{th1s_r0t_1s_n0t_s0_h0t}` dla shiftu 11.
