## jarecaptcha (web/ppc, 200 points, 32 solves)


[image extracted text: 3 | 2
3 | 2| 1| 7 | 9
answer:
gbh.jirb
captcha (case sensitive):
submit]



after solving a sudoku and entering the correct captcha we get `you have solved 1 sudokus, just 199 to go!`

solving sudokus is easy, ocr-ing captchas is the hard part, and with 200 puzzles, doing it manually is not a possibility.

the current captcha id is stored in our session id, and we get a new one each time the image is downloaded.

which means that we should be able to load a starting captcha once, transcribe it manually and then send each sudoku solution with the same captcha answer.

a random sudoku solver should work, (we used https://attractivechaos.github.io/plb/kudoku.html)

``` javascript


//get the sudoku fields
tables = document.getelementsbytagname("tr")

out = ""

//parse the sudoku board
for(var i=1; i<tables.length; i++){
	rows = tables[i].children
	for(var j=0; j<9; j++){
		fields = (rows[j].innerhtml)
		if(fields != "&nbsp;&nbsp;"){
			out += (fields)
		} else {
			out += "."
		}
	}
}


function sudoku_solver() {
...
solving sudoku, boring...
...
}

//solve the sudoku 
solver = sudoku_solver()
solution = (solver(out)[0].join(''))

//fill the form
document.getelementsbyname("solvedsudoku")[0].value = solution
document.getelementsbyname("captcha")[1].value = "209s1 6065s" //first captcha

//submit
document.forms[0].submit.click()

```

chrome has a setting to stop it from downloading any images, which made things a lot easier.

and after a lot of clicking, we get the flag:

`sharifctf{431bdff2b76f2e54a2621d13d5d5fbb7} ;) `