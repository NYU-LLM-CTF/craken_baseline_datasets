# random (crypto, 100p)

we were given this simple c++ code:

```cpp
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::string;

[[noreturn]] void fatal_error(const string& msg)
{
        cout << msg << endl;
        exit(0);
}

class randstream
{
        std::random_device rd;
        std::mt19937 gen;

public:
        randstream() : rd(), gen(rd()) {}

        unsigned int nextuint()
        {
                return gen();
        }
};

int main()
{
        cout << "let's see if you can predict mersenne twister output from just"
             << " six values!" << endl;
        cout << "btw. you have only 5 seconds." << endl;

        randstream rand{};
        for (int i = 0; i < 6; i++)
                cout << std::hex << std::setfill('0') << std::setw(8) << rand.nextuint()
                     << endl;

        for (int i = 0; i < 5; i++)
        {
                unsigned int num;
                cin >> std::hex >> num;
                if (num != rand.nextuint())
                        fatal_error("wrong!");
        }

        cout << "good work!" << endl;

        ifstream f("flag.txt");
        string flag;
        f >> flag;
        if (f.fail())
                fatal_error("reading flag failed, contact admin");
        cout << flag << endl;
}
```

this line may look strong:


```
randstream() : rd(), gen(rd()) {}
```

but in fact it's completely broken (mt is seeded with only 32bits of entropy). so it's enough to bruteforce the seed to get the flag.

according to organisers we were supposed to "cache" something to be "fast". well, we're more lazy than that, so we just guessed randomly until we did it. with tiny complication, beacuse of 5 second timeout, code looked like this:

```python
def stuff():
    s = socket.socket()
    s.connect(('random.hackable.software', 1337))
    data = s.recv(9999)
    sample = data.split('\n')[2]
    out = command(['./a.out', sample, '0']).run(timeout=5)  # class stolen from stackoverflow
    if out:
        print '---'
        print out
        print '---'
        s.send(out + '\n')

        print s.recv(9999)

def main():
    while true:
        if stuff():
            break
```

and `a.out` was compiled version of minimally modified given program:

```cpp
class randstream
{
        //std::random_device rd;
        std::mt19937 gen;

public:
        randstream(int i) : gen(i) {}

        unsigned int nextuint()
        {
                return gen();
        }
};

int main(int argc, char *argv[])
{
    unsigned int sought = std::strtoul(argv[1], null, 16);
    unsigned int start = std::strtoul(argv[2], null, 16);
    for (unsigned int i = start; i < 0xfffffffe; i++) {
        randstream rand(i);
        if (rand.nextuint() != sought) {
            continue;
        }
        for (int i = 0; i < 5; i++) {
            rand.nextuint();
        }
        for (int i = 0; i < 5; i++) {
            cout << std::hex << rand.nextuint() << ' ';
        }
        return 0;
    }
}
```

just good, plain, old brute force.
