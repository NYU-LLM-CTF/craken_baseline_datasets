# a...mazeing (network / ppc, 200) (16 solvers)
	hi!. let's play old nes game. i just plugged this stuff to tcp ports for ya ...
	ip: amazeing.hackable.software


[image extracted text: ill
tcp:1337
tcp.31336
tcp.31337
tcp.31338
tcp.31339,]


in this task we were told that there is a service runnning a game
and several tcp ports represent pressing various buttons on snes
controller.

connecting to the main server gave us game token and a position.
connecting to other ports and sending the token made the main server
send us an ok message (or failed one). we quickly thought it may be 
some kind of maze or something, so we wrote a quick python script
(`doit.py`) which discovers whole board using dfs - note that we had 
to increase stack limit.

drawing the board gives us the following image with the flag hidden on the bottom right corner:


[image extracted text: ]

