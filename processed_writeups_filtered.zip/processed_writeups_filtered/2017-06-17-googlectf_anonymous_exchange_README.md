# anonymous exchange (misc, 253p)

> i've bought some bitcoins with my credit cards, and some of them attracted attention, but i don't know which ones. could you find out?

> challenge running at anon.ctfcompetition.com:1337


connecting to the challenge, we are presented the following menu:
```
hey. could you tell me if my cards ccard0x1 through ccard0x40 have attracted the wrong type of attention? flagged cards are displayed in their dumps, and their encryption is deterministic. i seem to have the wrong encoding on my terminal, so i'll need help there.
i'll patch you into a management interface in a few seconds.


welcome to our telnet dogecoin exchange !.
we've currently frozen most of the operations pending an investigation into potential credit card fraud with law enforcement.
 - newacc to create an account.
 - newcard to create a test credit card.
 - assoc <cardx> <accounty> to associate cardx to accounty.
 - backup to generate a anonymized encrypted jsonified maybe-emojified backup.
```
let's try typing some of the commands:
```
newacc
ok: account uaccount0x1 created.
newcard
ok: card ucard0x1 created.
assoc ccard0x1 uaccount0x1
ok: card ccard0x1 associated with account uaccount0x1.
backup
[{"cards":[],"account":"d5d061c7916d633d"},
{"account":"2e110af22576601e","cards":[]},
{"account":"c514f2320ec707bf","cards":[{"card":"f3d94eb824490d44"}]},
{"account":"2dc5381fae066a60","cards":[{"card":"9573c3b0c238bf93"}]},
{"cards":[],"account":"746cb63871de2c89"},

[...]
]

so, which cards are burnt?
answer with a string of zeroes and ones, no spaces.
```

the whole dump had a couple hundred of accounts and cards. some of the cards had not only its
id in the dump, but also `"flagged" : "1"` pair, meaning the card is burnt.

we need to know which of the cards with specific names are burnt, but we don't know
which card ids (such as "9573c3b0c238bf93"), correspond to which card name (such as
"ccard0x40"). we can insert our own cards and accounts to the system though, so we can
make some kind of special structure in the account-card graph. in fact, the graph is pretty
sparse, as we are allowed only three cards per account and three accounts per card. that means,
on average, the graph will have a lot of rather small components, and a long chain of 
accounts and cards will be very rare. if we insert such a chain ourselves, then we will
know which card ids correspond to which card names (for now, just our cards).

let's make such a graph:
```
ucard0xff
    |
uaccount0x1 - ucard0x1 - uaccount0x2 - ucard0x2 - uaccount0x3 - ... - ucard0x41 - uaccount0x42
    |
ucard0xfe
```

now, if we find a long chain in the received dump, it's very likely our structure. we can even
know which end is which, because one of them ends with two cards, and the other with an account.

so we're able to distinguish our cards and accounts from the whole mess. let's connect the
queried cards to our known accounts: `ccard0x1` to `uaccount0x2`, `ccard0x2` to `uaccount0x3`
and so on. then, we can easily find those cards in the dump too, and find which of them
are flagged.

after answering the query, we receive the flag. the solution implementation is in `doit.py`
file.

