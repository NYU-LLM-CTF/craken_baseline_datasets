# icss (misc/crypto, 471p, 18 solved)

a blackbox crypto challenge.
we get a base64 encoded ciphertext `ypovstywdfkneotwnc3axtll2iwwkuja1qawdvyynitddipknntqr1gb+nzl` and access to a service which can encrypt for us up to 6 characters of input.

first we need to understand how this encryption works, and for this we played a bit with it, sending specially crafted payloads.
we can notice some things:

1. encryption goes character by character, there are no blocks. it's easy to see when we add or remove characters.

2. ciphertext for a character depends on the character itself and on the position where it is in the input. the same character on a different position encrypts differently, but the same character at the same position, even for different plaintexts gives the same encrypted value.
for example:
aaa -> a060a2
aba -> a063a2

so the encryption for the last `a` stayed the same.

3. an exception to above rule is the first character. it affects how rest of the string is encrypted.

another set of tests we did gave some interesting results. 
by sending `\x00\x00\x00\x00\x00\x00` bytes we got `010102030508` which looks like a fibonacci sequence!
it got even better when we sent `\x01\x00\x00\x00\x00\x00` because we got `00020305080d` which is the same sequence just shifter 1 position further (disregarding the first byte).
if we now send `\x01\x05\x00\x00\x00\x00` we will get `00070305080d` so the sequence is the same but second byte is bigger by 5, which is the value we tried to encrypt.
first byte encryption is unknown, but it depends only on this character, so we don't really care, it can be brute-forced.

we did a bit more checking and it was quite clear that the encryption does something like:
1. encrypt first byte in some special way
2. every other byte in position `k` is encrypted as `fibonacci(first_byte + k) + kth_byte_value`

however, there is some weird stuff happening when overflow is reached, and it seemed some other special cases are present as well for even/odd numbers.

instead of trying to figure out how to handle those issues, we decided to go the "easy" way instead.
we know that by changing the first byte we can "shift" the fibonacci sequence for the rest of the encryption, but it means that we basically shift the positions!
by sending `xa` we can get encrypted byte `a` at positon `1` with starting byte `x`, but if we send `(x+1)a` we will shift the sequence and the result will be the same as encrypted `a` at position `2` with starting byte `x`.

this means that we can pretty much get any encrypted byte at any position we want by encrypting only 2 bytes at a time!
we use this approach with the server as "oracle" serving us the encrypted bytes and we brute-force the flag.

what we want to do:
1. take a single encrypted character from the encrypted flag we have at k-th position.
2. encrypt via server every possible character at k-th position and compare it with the one we have. once they match we know what was the plaintext character.
3. repeat until we get whole flag.

so we run:

```python
import base64
import string

from crypto_commons.netcat.netcat_commons import nc, send


def brute_character_at_position(position, expected):
    for c in string.letters + "{_" + string.digits + string.punctuation:
        if int(get_encrypted_char_at_position(c, position), 16) == ord(expected):
            return c
    return "?"


def get_encrypted_char_at_position(character, position):
    return get_ciphertext(chr(ord('e') + position) + character)[2:4]


def get_ciphertext(c):
    url = 'icss.ctf.site'
    port = 40112
    s = nc(url, port)
    s.recv(9999)
    s.recv(9999)
    send(s, c)
    s.recv(9999)
    result = s.recv(9999)
    return base64.b64decode(result).encode("hex")


def main():
    flag_ciphertext = base64.b64decode("ypovstywdfkneotwnc3axtll2iwwkuja1qawdvyynitddipknntqr1gb+nzl")
    flag_plaintext = "e"
    for i in range(len(flag_ciphertext) - 1):
        expected_encrypted_byte = flag_ciphertext[i + 1]
        flag_plaintext += brute_character_at_position(i, expected_encrypted_byte)
        print(flag_plaintext)
    print(flag_plaintext)


main()
```

after a while we finally get: `eko{mr_leon4rd0_pisano_big0770_aka_fib@nacc!}`
