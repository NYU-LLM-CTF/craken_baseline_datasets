# halp (network 300)

###eng
[pl](#pl-version)

in the task we get a [pcap file](transmission.pcap).
the file is from some voip call.
if we analyse the rtp streams and use voip feature of wireshark to play the streams it can find, we will hear someone connecting to an automatic response machine, and then typing a number with dial tones:


[image extracted text: transmission pcap
plik
edytuj
widok
idz
przechwytuj
analizuj
statystyki
telefonia
bezprzewodowe
narzedzia
pomoc
zastosuj tiltr wyswietlania
<ctri-/ >
time
source
destination
protocol
length
info
0.000000
192
2 0.000159
192
wireshark
potaczenia volp
transmission
000692
19
4 4.502436
192
czas start
czas stop
domyslny glosnik
protoko}
pakiety
stan
komentarze
5 4.502452
192
4.502436
31.794914 192.168.1.22
<sip:1000@192.168.1.29,transport-udp
<sip.318@192.168.1.29,transport-udp sip
completed invite 407 200
6 4.502454
19
7 4.502754
19
8 4.502922
192
wireshark , odtwarzacz rtp
9 4.503120
192
10 4.503278
192
4.503487
192
frame
938
bytes
ethernet ii,
src:
internet
protocol
user
datagram
prot
session initiation
00
0010
03
9c 25
53 40
0u20
01 1d 93
03 13
0030
20 73 69 70 3a
0040
2e 31 2e 32 39
0050
55 44 50 20 53
3a 20 53 49 50
13,5
22,5
31,5
32 2e 31 36 38
3b 62 72 61
adres zrodlowy
port zrodlowy
adres docelowy
port docelowy
ssrc
ramka konfiguracji
pakiety
okres czasu (s)
probkowanie (hz)
dane
090
64 38 37 35 34
192.168.1.22
8000
192.168.1.29
19378
0x987fb524
1360
4.6 - 31.8 (27.2)
8000
9711a
dau
65 33 62 35 35
192.168.1.29
19378
192.168.1.22
8000
0x375513eb 11
1360
4.56 - 31.8 (27.2) 8000
9711a
00b0
34 7a 2d 0d
00c0
73 3a 20 37 30
00d0
3c 73 69 70 3a 31
uueu
38 2e 31 2e 32 32
00f0
6e 73 70 6f 72 74
0100
20 3c 73 69 70 3a
bufor jitter:
czas strumienia: | buforowanie jitter
czas dnia
0110
38 2e 31 2e 32 39
0120
3d 55 44 50 3e @0d
zamknij
pomoc
70
j2 )4
j0
j0
j0]


we extracted the dial-tones to a [file](dtm.flac) and then used dtmf decoder audacity plugin to recognize the keys:


[image extracted text: 4.0
6.0
7.0
8.0
10.0
11.0
12.0
nyquist
4952061545946271
ok]


i was confused what to do next, but my level headed friend just tried simply `3ds{4952061545946271}` as the flag, and it worked.

###pl version

w zadaniu dostajemy [plik pcap](transmission.pcap).
jest to zapis z rozmowy voip.
jeśli przeanalizujemy strumienie rtp i użyjemy później narzędzi wiresharka do analizy voip, znajdziemy zapis audio z połączenia do jakiegoś automatycznego systemu odpowiedzi, a następnie wystukanie na klawiaturze tonowej jakichś cyfr:


[image extracted text: transmission pcap
plik
edytuj
widok
idz
przechwytuj
analizuj
statystyki
telefonia
bezprzewodowe
narzedzia
pomoc
zastosuj tiltr wyswietlania
<ctri-/ >
time
source
destination
protocol
length
info
0.000000
192
2 0.000159
192
wireshark
potaczenia volp
transmission
000692
19
4 4.502436
192
czas start
czas stop
domyslny glosnik
protoko}
pakiety
stan
komentarze
5 4.502452
192
4.502436
31.794914 192.168.1.22
<sip:1000@192.168.1.29,transport-udp
<sip.318@192.168.1.29,transport-udp sip
completed invite 407 200
6 4.502454
19
7 4.502754
19
8 4.502922
192
wireshark , odtwarzacz rtp
9 4.503120
192
10 4.503278
192
4.503487
192
frame
938
bytes
ethernet ii,
src:
internet
protocol
user
datagram
prot
session initiation
00
0010
03
9c 25
53 40
0u20
01 1d 93
03 13
0030
20 73 69 70 3a
0040
2e 31 2e 32 39
0050
55 44 50 20 53
3a 20 53 49 50
13,5
22,5
31,5
32 2e 31 36 38
3b 62 72 61
adres zrodlowy
port zrodlowy
adres docelowy
port docelowy
ssrc
ramka konfiguracji
pakiety
okres czasu (s)
probkowanie (hz)
dane
090
64 38 37 35 34
192.168.1.22
8000
192.168.1.29
19378
0x987fb524
1360
4.6 - 31.8 (27.2)
8000
9711a
dau
65 33 62 35 35
192.168.1.29
19378
192.168.1.22
8000
0x375513eb 11
1360
4.56 - 31.8 (27.2) 8000
9711a
00b0
34 7a 2d 0d
00c0
73 3a 20 37 30
00d0
3c 73 69 70 3a 31
uueu
38 2e 31 2e 32 32
00f0
6e 73 70 6f 72 74
0100
20 3c 73 69 70 3a
bufor jitter:
czas strumienia: | buforowanie jitter
czas dnia
0110
38 2e 31 2e 32 39
0120
3d 55 44 50 3e @0d
zamknij
pomoc
70
j2 )4
j0
j0
j0]


wyciągnęliśmy same tony do osobnego [pliku](dtm.flac) a następnie użyliśmy pluginu do audacity dtmf decoder żeby rozpoznać klawisze:


[image extracted text: 4.0
6.0
7.0
8.0
10.0
11.0
12.0
nyquist
4952061545946271
ok]


miałem w tej chwili zagwoztkę co zrobić dalej, ale jeden z moich kolegów spróbował wpisać po prostu `3ds{4952061545946271}` jako flagę i zadziałało.
