﻿##game of life (ppc/recon, 500p)

	dont blink your eyes, you might miss it. but the fatigue and exhaustion rules out any logic, any will to stay awake. what you need now is a slumber. cat nap will not do. 1 is life and 0 is dead. in this game of life sleep is as important food. so... catch some sleep. but remember...in the world of 10x10 matirx, the life exists. if you sloth, sleep for 7 ticks, or 7 generation, in the game of life can you tell what will be the state of the world?

	the world- 10x10

	0000000000,0000000000,0001111100,0000000100,0000001000,0000010000,0000100000,0001000000,0000000000,000000000

###pl
[eng](#eng-version)

###eng version
