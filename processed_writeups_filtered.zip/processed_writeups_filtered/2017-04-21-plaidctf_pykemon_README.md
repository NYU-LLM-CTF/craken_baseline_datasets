# pykemon (web, 151p)

## eng
[pl](#pl-version)

we get access to a simple [python flask webapp](pykemon.zip).
the application displays on the screen some pokemon and a flag among them.
we can click on them to "catch".

by looking in the source code of the application we can see that it's actually impossible to catch a flag, since it's "rarity" has value 0.
we instantly noticed that the cookie for this page was really big, and was changing with the state of the game changes.
this suggested to us that the game state might be stored there.
checking in the source code proved this is true.

more importantly this meant also the pokemon "descriptions" were there, including the flag!
it actually turned out to be an unintended solution to the task, because the author did not know that decoding flask cookie is trivial.
the inteded solution was a template injection in the pokemon nickname.
we noticed that there was some vulnerability there, which we initially considered some stored xss at most, but since we found the cookie, we went this way.

so we basically take the cookie, decode it and read the flag value from the game state:

```python
import base64
import zlib
from flask import json
from itsdangerous import base64_decode, base64_encode


def decode(cookie):
    compressed = false
    payload = cookie
    if payload.startswith('.'):
        compressed = true
        payload = payload[1:]
    data = payload.split(".")[0]
    data = base64_decode(data)
    if compressed:
        data = zlib.decompress(data)
    return data.decode("utf-8")


def main():
    session = ".ejy9v11zojau_ss7ppsaudritb82bqe7ly648pgdzg4klfecmijfdprf96l9sfbbfdc-kxvzdc49oqkrkqyekksuirckgpqxn0vdlztxszrom6n7--gpjc2m0_r9dcwxqkczct4fn-2v9couutlifdjdf3hg9wn_iaero-ehq5u9w6qjq8vehcr-lsqeosxx7nyv8dx31zyatufdo0sdswnw47nuvdwwlavptdv5ukm2psnbzd5mu3hfglyuc7ngnp7xg7rfdt9vuwsuwmfjy7s2vpnjhu8yxjkqgfbuoj3cdjoixlkfnwlujtwys_l937t_wrq2dk71mni0yzloiljantxlvzhteqeonsywxv3uh7od3iazji_71taut5aguvgulamhzt9ttlolixyn3f88qdecxeu4xnjgigvpx2qa9dlaicksjwn3i54h5j6hcpy6dc_enhmwodwwwxqpaepwznbx96ymnwtli-smoexdt0riawxe12mhgrf8xf9s06b-tgnbrag8rjdu_4_kqwv5r6hcsaaqvlptwlcoe6y9jumsitmgfsjibox1oatibbq4c7ghqrmnl0pdefsqagwbupbw0rbnw8wuoiggnvigibx63ao9q3lkkdbc45yz_rjuvqo1nkaaeqad8ovstm_pmo0evnflcldftbw_gb1tkfafigxd9odqfab0g1wk7jk4x1brqhmsfr2bivoz01nb0cko1ngu-_ojxvfvkazu4dlucgsm59aw4actzt7mphjynfswzndqwfuzqp4jc60paxoahqse3fjolljojnadgoytfi1i38nv4w3gqy_ggwi8zd540du8ehgacxgnrjcyqa5wwrzbhi5s3kgj1jytxovxr9qochkyi1dlqhapl7cvp-2heubdrtngsnreddihfjp7lbs3ke98tvnzbr9ryrfaerxwut_rgzibxcw2n81nhlloerpae9tnookcxegagk-e7m1bntq8j9nqufbodsfx3sqmxoizu1tm67_r0pliw3rwirpekzs0rop314n3njx94s2mmwnq19vmofxys_ghtssm_jwueabpmnxkp6d__pp4oa.c90p4g.yja29lcu7ln3k40olyna6cn9r8m"
    session_decoded = decode(session)
    print(session_decoded)
    loaded = json.loads(session_decoded)
    room = loaded['room']
    pykemons = room['pykemon']
    for pykemon in pykemons:
        desc = pykemon['description']
        print(base64.b64decode(desc.items()[0][1]))

main()
```

and we find: `pctf{n0t_4_sh1ny_m4g1k4rp}`

## pl version

dostajemy dostęp do prostej [pythonowej aplikacji we flasku](pykemon.zip).
aplikacja wyświetla na ekranie pokemony oraz flagę.
możemy klikać na nie żeby je "złapać".

z kodu źródłowego wynika, że nie da się złapać flagi ponieważ ma "rarity" ustawione na 0.
szybko zauważyliśmy, że cookie na tej stronie było bardzo duże i zmieniało się wraz ze zmiane stanu gry.
to sugerowało że stan gry może być tam przechowywany.
sprawdzenie kodu źródłowego dowodziło że faktycznie tak jest.

co więcej znajduje się tam tez pole "description" które zawiera flagę!
okazało się później, że ta metoda była zupełnie niezamierzona i autor zadania nie wiedział ze cookie flaska łatwo zdekodować.
oczekiwane rozwiązanie polegało na template injection w nickname pokemona.
zauważliśmy też podatność w nickname, chociaż początkowo uznaliśmy ją za stored xss, ale widząc cookie uznaliśmy, że pójdziemy w tym kierunku.

zdekodowaliśmy więc cookie ze stanem gry:

```python
import base64
import zlib
from flask import json
from itsdangerous import base64_decode, base64_encode


def decode(cookie):
    compressed = false
    payload = cookie
    if payload.startswith('.'):
        compressed = true
        payload = payload[1:]
    data = payload.split(".")[0]
    data = base64_decode(data)
    if compressed:
        data = zlib.decompress(data)
    return data.decode("utf-8")


def main():
    session = ".ejy9v11zojau_ss7ppsaudritb82bqe7ly648pgdzg4klfecmijfdprf96l9sfbbfdc-kxvzdc49oqkrkqyekksuirckgpqxn0vdlztxszrom6n7--gpjc2m0_r9dcwxqkczct4fn-2v9couutlifdjdf3hg9wn_iaero-ehq5u9w6qjq8vehcr-lsqeosxx7nyv8dx31zyatufdo0sdswnw47nuvdwwlavptdv5ukm2psnbzd5mu3hfglyuc7ngnp7xg7rfdt9vuwsuwmfjy7s2vpnjhu8yxjkqgfbuoj3cdjoixlkfnwlujtwys_l937t_wrq2dk71mni0yzloiljantxlvzhteqeonsywxv3uh7od3iazji_71taut5aguvgulamhzt9ttlolixyn3f88qdecxeu4xnjgigvpx2qa9dlaicksjwn3i54h5j6hcpy6dc_enhmwodwwwxqpaepwznbx96ymnwtli-smoexdt0riawxe12mhgrf8xf9s06b-tgnbrag8rjdu_4_kqwv5r6hcsaaqvlptwlcoe6y9jumsitmgfsjibox1oatibbq4c7ghqrmnl0pdefsqagwbupbw0rbnw8wuoiggnvigibx63ao9q3lkkdbc45yz_rjuvqo1nkaaeqad8ovstm_pmo0evnflcldftbw_gb1tkfafigxd9odqfab0g1wk7jk4x1brqhmsfr2bivoz01nb0cko1ngu-_ojxvfvkazu4dlucgsm59aw4actzt7mphjynfswzndqwfuzqp4jc60paxoahqse3fjolljojnadgoytfi1i38nv4w3gqy_ggwi8zd540du8ehgacxgnrjcyqa5wwrzbhi5s3kgj1jytxovxr9qochkyi1dlqhapl7cvp-2heubdrtngsnreddihfjp7lbs3ke98tvnzbr9ryrfaerxwut_rgzibxcw2n81nhlloerpae9tnookcxegagk-e7m1bntq8j9nqufbodsfx3sqmxoizu1tm67_r0pliw3rwirpekzs0rop314n3njx94s2mmwnq19vmofxys_ghtssm_jwueabpmnxkp6d__pp4oa.c90p4g.yja29lcu7ln3k40olyna6cn9r8m"
    session_decoded = decode(session)
    print(session_decoded)
    loaded = json.loads(session_decoded)
    room = loaded['room']
    pykemons = room['pykemon']
    for pykemon in pykemons:
        desc = pykemon['description']
        print(base64.b64decode(desc.items()[0][1]))

main()
```

a tam znaleźliśmy: `pctf{n0t_4_sh1ny_m4g1k4rp}`
