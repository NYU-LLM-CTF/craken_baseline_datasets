# insomnihack teaser ctf 2018

team: c7f.m0d3, sasza, nazywam, akrasuski1, ppr, rodbert, hubert, borysp, rev, cr019283, psrok1, shalom

### table of contents

* [magichat (pwn)](pwn_magic_hat)
* [cool storage service (web)](web_css)
