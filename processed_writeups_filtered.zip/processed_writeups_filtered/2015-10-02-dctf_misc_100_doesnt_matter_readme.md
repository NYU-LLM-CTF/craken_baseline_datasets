## she said it doesn't matter (misc/stego, 100p)

### pl version
[eng](#eng-version)

w zadaniu dostajemy obrazek [png](./m100.png) z zepsutym nagłówkiem. rozpakowujemy zawartość pliku i za pomocą pozyskanych pikseli tworzymy obrazek, w którym ukryta jest flaga. musimy ustawić dobre wymiary obrazka, które różnią sie od odczytanych z nagłówka. po paru próbach odnajdujemy właściwe wartości.

```python
from pil import image
with open('zlibdec.bin','rb') as f:
	data=f.read()
im = image.frombytes('rgb',(891,550),data)
im.show()
```
i w wyniku otrzymujemy:


[image extracted text: flag: s1z3_do3s_rna7zan_baby]

### eng version
we get png picture with broken header checksum. with pixels extracted from file we make picture using them. we have to set good size of picture and mode, since data from broken header are misleading. after some trials we can easly find right values.
```python
from pil import image
with open('zlibdec.bin','rb') as f:
	data=f.read()
im = image.frombytes('rgb',(891,550),data)
im.show()
```
as a result we get:


[image extracted text: flag: s1z3_do3s_rna7zan_baby]

