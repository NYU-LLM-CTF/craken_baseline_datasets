##bonsai xss revolutions (web/network, 200p)

>what is your browser(user-agent)?  
>[hakoniwawebmail_20151124.zip](hakoniwawebmail_20151124.zip)  
>requirement:.net framework 4.5

###pl
[eng](#eng-version)

załączona do zadania była mocno zobfuskowana aplikacja .netowa. była to symulacja przeglądarki, w której użytkownik logował się do swojej poczty.


[image extracted text: xss bonsai revolutions
https /  tsurbor test /webmail
tsurbor webmai
subject
from
date
2015.12.08
[spam] save on car insurance
joe <joe@spam test>
02.28
2015.12.08
faceback account update
faceback <account @faceback test >
0232
receipt for your paypol payment
2015.12.08
service
@paypoltest
[transaction id
inseulkcez14o]
0230
2015.12.08
re: re: your order
president@somec ompany test
02.27
2015.12.08
amozan com order lc8270018
support <support@amozansupport test>
02.19
subject:
[spam] save on car insurance
from:
joe <joe@spam test >
to:
<undisclosed-recipient; >
date:
2015.12.08 02.28
are you planning to get and purchase some car insurance?
then do not waste any time and get
car or auto msurance now or
as soon as
possible_
but make sure that when you
car insurance
you have also save an enough amount of money by carefully choosing to
purchase the cheapest and the most affordable rates available_
start
02.39
"xss bonsai revolution:'
by keigoyamazaki; 2014.12,09
get a
buy]


z początku postanowiliśmy powalczyć z samą aplikacją. częściowo udało nam sie zdeobfuskować plik wykonywalny narzędziem `de4dot`. następnie utworzyliśmy nową aplikację .netową i załadowaliśmy oryginalny program za pomocą refleksji:

```csharp
var assembly = assembly.loadfile("hakoniwawebmail.exe");
```

to pozwoliło nam ręcznie tworzyć instancje klas i wywoływać metody. w głównej przestrzeni nazw były dwie formy: `flaggenerator` i `frmmain`. pierwsza dała nam flagę, ale była fejkowa. druga była faktycznie główną formą aplikacji i stworzenie jej instancji oraz pokazanie jej równało się wywołaniu całej naszej symulacji - z tą różnicą, że teraz mogliśmy się z nią pobawić:

```csharp
var form = (hakoniwawebmail.frmmain)activator.createinstance(assembly.gettypes()[7]);
var browser = (webbrowser)getcontrols(form)[7];
```

dzięki temu mogliśmy zrzucić zawartość wyświetlonej strony w zintegrowanej/symulowanej przeglądarce:

```csharp
console.writeline(browser.documenttext);
```

ale jedyne co dostaliśmy to:

```html
<html><style>.b{font-weight:bold;}(...)</style><body>
<script>var navigator=new object;navigator.useragent='this is not a flag. use xss to obtain it.';</script>
<table border=3 cellspacing=0 cellpadding=0 width=100% height=100%>(...)
```

jedną możliwością na tym etapie było zagłębienie się w zaobfuskowaną aplikację i zreverseengineerowanie jej, a drugą było przeczytanie jeszcze raz nazwy zadania, jej kategorii oraz punktów: xss, web, 200p. no więc, jeżeli aplikacja faktycznie była symulowanym webmailem to może da się wysłać tam maila. i faktycznie tak było: był to również serwer pocztowy działający na standardowym porcie 25:

```
tcp    127.0.0.1:25           0.0.0.0:0              listening       6512
[hakoniwawebmail.exe]
```

próbowaliśmy xss na kilku z nagłówków w wiadomości aż w końcu zadziałał z polem `date`.


[image extracted text: rcpt
io:keigo.yamazakietsuribori
test
komunikat ze strony sieci web
250
hail
froh:a@a.
250
seccon{tsuriboriwebbros/2015.12.17620}
data
354
anead
date:
<acriptzalert (navigator
u3eragent) ;<lacript>
250]


`seccon{tsuriboriwebbros/2015.12.17620}


### eng version

attached was a heavily obfuscated .net application. it was a simulated webbrowser in which a user logged in to his webmail.


[image extracted text: xss bonsai revolutions
https /  tsurbor test /webmail
tsurbor webmai
subject
from
date
2015.12.08
[spam] save on car insurance
joe <joe@spam test>
02.28
2015.12.08
faceback account update
faceback <account @faceback test >
0232
receipt for your paypol payment
2015.12.08
service
@paypoltest
[transaction id
inseulkcez14o]
0230
2015.12.08
re: re: your order
president@somec ompany test
02.27
2015.12.08
amozan com order lc8270018
support <support@amozansupport test>
02.19
subject:
[spam] save on car insurance
from:
joe <joe@spam test >
to:
<undisclosed-recipient; >
date:
2015.12.08 02.28
are you planning to get and purchase some car insurance?
then do not waste any time and get
car or auto msurance now or
as soon as
possible_
but make sure that when you
car insurance
you have also save an enough amount of money by carefully choosing to
purchase the cheapest and the most affordable rates available_
start
02.39
"xss bonsai revolution:'
by keigoyamazaki; 2014.12,09
get a
buy]


at first we tried to tacke the application itself. we partly managed to deobfuscate the binary with a `de4dot` tool. then we created another .net application and loaded the original program by reflection:

```csharp
var assembly = assembly.loadfile("hakoniwawebmail.exe");
```

that allows us to manually instantiate classes and invoke methods. there were two form classes in the main namespace: `flaggenerator` and `frmmain`. the former gave us a flag, but it was a fake. the former was indeed the main form of the app and instantiating the class and showing the form basically run the whole simulation but now we could interact with it:

```csharp
var form = (hakoniwawebmail.frmmain)activator.createinstance(assembly.gettypes()[7]);
var browser = (webbrowser)getcontrols(form)[7];
```

that way we could simply dump the contents of displayed page in the integrated/simulated webbrowser:

```csharp
console.writeline(browser.documenttext);
```

but all we got was:

```html
<html><style>.b{font-weight:bold;}(...)</style><body>
<script>var navigator=new object;navigator.useragent='this is not a flag. use xss to obtain it.';</script>
<table border=3 cellspacing=0 cellpadding=0 width=100% height=100%>(...)
```

one possibility at this point was to dig deep in the obfuscated application and reverse engineer it and another to read the task name, category and points again: xss, web, 200p. well then, if the application is a simulated webmail, maybe we can send an actual email. and there it was: it was also a mail server running on standard port 25:

```
tcp    127.0.0.1:25           0.0.0.0:0              listening       6512
[hakoniwawebmail.exe]
```

we tried several mail headers for the xss and it finally worked with the `date` header.


[image extracted text: rcpt
io:keigo.yamazakietsuribori
test
komunikat ze strony sieci web
250
hail
froh:a@a.
250
seccon{tsuriboriwebbros/2015.12.17620}
data
354
anead
date:
<acriptzalert (navigator
u3eragent) ;<lacript>
250]


`seccon{tsuriboriwebbros/2015.12.17620}
