﻿## seccoding (misc, 100p)

> you should fix vulnerabilities of the given source code, without changing its normal behaviour. link 

###eng
[pl](#pl-version)

we are given following code, and are tasked with repairing bugs and vulnerabilities in it:

```cpp
#include <vector>
#include <iostream>
#include <windows.h>

using namespace std;


int main()
{
	vector<char> str(max_path);
	
	cout << "enter your name: ";
	cin >> str.data();

	cout << "hello " << str.data() << " :)" << endl;

	return -14;
}
```

this code is so bad, that if anyone seriously wrote code like that, he should immediately give up on programming and become baker instead.

we don't even try to repair this program, we just scrap it and write everything from zero:

```cpp
#include <iostream>
#include <string>

using namespace std;

int main() {
	string str;

	cout << "enter your name: ";
	cin >> str;

	cout << "hello " << str << " :)" << endl;

	return -14;
}
```

challenge solved.

###pl version

dostajemy taki kod i mamy go poprawić:

```cpp
#include <vector>
#include <iostream>
#include <windows.h>

using namespace std;


int main()
{
	vector<char> str(max_path);
	
	cout << "enter your name: ";
	cin >> str.data();

	cout << "hello " << str.data() << " :)" << endl;

	return -14;
}
```

jest on tak dramatycznie napisany, że jeśli ktoś faktycznie napisał taki kod powinien prawdopodobnie zrezygnować z kariery programisty i przemyśleć karierę piekarza.

darujemy sobie poprawki i po prostu piszemy go od zera:

```cpp
#include <iostream>
#include <string>

using namespace std;

int main() {
	string str;

	cout << "enter your name: ";
	cin >> str;

	cout << "hello " << str << " :)" << endl;

	return -14;
}
```

zadanie rozwiązane.
