﻿##exploit 2 (pwn, 200p)

###pl
[eng](#eng-version)

###eng version
