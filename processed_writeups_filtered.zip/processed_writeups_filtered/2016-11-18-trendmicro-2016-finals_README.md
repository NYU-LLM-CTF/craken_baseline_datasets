# writeup trend micro ctf 2016 finals

team: msm, shalom, rev, c7f.m0d3

### disclaimer

since it is always hard to find info on on-site competitions, i will provide a short recap of the trend micro finals 2016.

* the competition lasted 2 days, about 8h each day.
* there were two types of tasks available - king-of-the-hill attack defence and jeopardy.
* jeopardy had diminishing returns - first team got 1000p, next one 900p and so on. jeopardy tasks were available only for the day they were released, so no chance on working through the night on those.
* attack-defense were king-of-the-hill style, so there was a single game server and everyone was pwning it, trying to get control and protect from the others. there were pwn and web servers to work with. 


### table of contents

* [j1 (forensics)](j1)
