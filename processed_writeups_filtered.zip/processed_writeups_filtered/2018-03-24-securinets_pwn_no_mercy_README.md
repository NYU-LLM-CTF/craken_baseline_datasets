# no mercy (pwn)

we get [elf binary](no_mercy) with canary and nx on.
there are two blatant buffer overflows in the code, since it's using `gets`:

```c
int main() {
    var_ac = *(ecx + 0x4);
    var_c = *0x14;
    eax = 0x0;
    var_70 = 'flag'; //  0x08048573
    var_6c = '{fla';
    var_68 = 'g_is';
    var_64 = '_on_';
    var_60 = 'serv';
    var_5c = 'er}';
    eax = &var_58;
    ecx = 0x0;
    ebx = 0x1a & 0xfffffffc;
    edx = 0x0;
    do {
            *(ebp + edx + 0xffffffa8) = 0x0;
            edx = edx + 0x4;
    } while (edx < ebx);
    var_70 = 'flag';
    *(int16_t *)(eax + edx) = 0x0;
    eax = 0x2 + eax + edx;
    eax = strcpy(&var_a2, &var_70);
    eax = printf("what's your name: ");
    eax = gets(&var_3e); // buffer overflow
    eax = printf("welcome %s\n", &var_3e);
    eax = printf("so tell me a joke: ");
    eax = gets(&var_70); // buffer overflow
    eax = printf("so silly , gtfo ==>[]");
    eax = dup2(0x1, 0x2);
    esp = ((((((((esp - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10 - 0x10) + 0x10;
    eax = *0x14 ^ *0x14;
    if (eax != 0x0) {
            eax = __stack_chk_fail();
    }
    else {
            ebx = stack[2046];
            esp = &var_8 + 0xc;
            ebp = stack[2047];
            esp = stack[2045] + 0xfffffffc;
    }
    return eax;
}
```

the trick here is that once you smash the stack, the server actually sends you the error message.
this message contains the name of the binary.
the idea is to overwrite the pointer which points to the binary name, and place there the pointer to flag contents.

the payload we send is: `'a' * 234 + '\x73\x85\x04\x08'`.
we need to go up 234 bytes to reach the pointer position with binary name and then we overwrite it with the flag address.
from this we get back: `flag{sm4ash_argv_sm4sh_env_sm4sh_ev3rything!}`
