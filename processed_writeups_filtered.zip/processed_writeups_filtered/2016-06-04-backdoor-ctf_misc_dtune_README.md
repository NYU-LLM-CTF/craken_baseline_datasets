## dtune (misc, 70p)

###eng
[pl](#pl-version)

we get an [audio file](dtune.wav) with recording of someone typing a password.
we recognized the sounds as phone dial tones, and therefore we used an audacity plugin to recognize which buttons were pressed:
`8 44 33 0 333 555 2 4 0 444 7777 0 7777 44 2 2 5 6 0 666 333 0 33 7 222 3 44 99 44 6 222 2 77 9`

initially we mistakingly merged the multiplied button presses and we thought we need to use t9 to recognize words.
only later we figured that it was plain old keyboard typing, which translated to:

`the flag is sha256 of epcdhxhmcaqw`

###pl version

dostaliśmy [plik audio](dtune.wav) z nagraniem wpisywania hasła.
rozpoznalismy dźwięki jako dźwięki wybierania tonowego na klawiaturze telefonicznej i wykorzystaliśmy plugin do audacity, aby rozpoznać które klawisze wybrano:
`8 44 33 0 333 555 2 4 0 444 7777 0 7777 44 2 2 5 6 0 666 333 0 33 7 222 3 44 99 44 6 222 2 77 9`

początkowo błędne skleiliśmy te same klawisze i próbowaliśmy dopasować słowa za pomocą t9.
dopiero później zorientowaliśmy się, że klawisze są wybierane w zwykły sposób i wpisany tekst tłumaczy się do:

`the flag is sha256 of epcdhxhmcaqw `
