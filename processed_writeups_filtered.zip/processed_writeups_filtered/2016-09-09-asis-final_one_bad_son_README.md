## one bad son (forensics, 127p)
	tl;dr get data from bson, concact flag png

supplied files:

[one_bad_son](one_bad_son)

it turns out that windbg formats binary data pretty well (cat/hexump/xxd output wasn't so clear):


[image extracted text: 0310343-
fname
flag
len
dat
pau=
crc
8d8d0d26
1 raw
mtime
w i
jd
0640
8919
fname
flag
len
dat
xe4xvyu=
crc
04a7b412
raw
aezl 62
mtime
9
162547413
fname
flag
len
dat
uyn3cra=
crc
7382eb1b
raw
ijzl 62
mtime
0920562004
fname
flag
len
dat
flaezvc=
crc
ec649927
raw
cazl oz
mtime
8
3
558-
fname
junk
33xhtgm=
crc
3db86e86
raw
a{@sl
mtime
fname
flag
len
dat
n6syjka=
crc
ofofd33c
raw
oazi 62
mtime
fname
dat
oxa=
crc
8odceda3
raw
ohz]
mtime
%05
fname
jiag
:
dat
ww=
crc
a4cfaltc
raw
girlcal
mtime
6d,
2
fname
flag
dat
khax
crc
c7513c88
1 raw
tcza z ruvsc
mtime
1
0085
fname
junk
4jbpsog=
crc
3ba93aed
raw
mtime
'8
0693
fname
junk
len
nkhsfo==
crc
5ac46b27
raw
a-ae,o
mtime
jid
fname
{nk
len
eay=
e278a59b
raw
x@zl 62
mtime   8h11
3
fname
30hxkje=
crc
e74dd754
raw
0 0 24t%]
mtime
'8
fname
hgvuey4=
crc
bc113642
raw
6gz] 62
mtime
jd
fname
fiax
ins
crc
934286c7
raw
}] swyl
mtime
0 p.
fname
{lag
1
dat
8hv4j4g=
crc
8617f160
1 raw
ujzl 62
mtime
"o1
_id
fname
dat
crc
ac1d4d30
1 raw
gbzl 62
mtime   vefl
fname
flag
len
dat
iexx aaafaaa=
cr79e3794c6223/1d ahzavz_
@z1 62 mtime
@tme
1
'61
1
id
fname
junk
len
q330
crc
cc21839f
raw i0.
mtime
[ns
569
fname
len
dat
ruy=
crc
53884d1a
1 raw
y@zl 62
mtime
u*fl
fname
jtag
xc20704=
crc
8045e86c
raw
lnzv
mtime
'8
jd
fname
junk
6
7kirdjm=
crc
5e0a6623
raw
-1 z
mtime
fname
dat
blk=
crc
67dd2f2f
raw
fczl
mtime
"81
fname
fiax
len
d+akrw==
crc
c2922353
raw
#qi iob
m%oa
462
fname
flag
len
bcl=
crc
49c44526
1 raw
@zl 62
mtime
1
fname
junk
len
tdoi
crc
5a4fc835
i raw "ued's
mtime
&+]
fname
junk
crc
5e38108b
1 raw
acpncs]
mtime du:
fname
junk
6
qjolzg==
crc
4866085e
raw
ahobag1
mtime
t
'8
jd
fname
flag
aaaaaa==
crc
2144df1c
raw
!@zl 6z
mtime
fname
flag
len
dat
f1uq
crc
7a974f0a
raw
azl
mtime
afl
3
fname
flag
len
dat
ycpz59m=
crc
63854399
raw
czl 62
mtime
'83
jd
0814820
fname
junk
xcaxizw=
crc
7283c397
raw
=sa]
mtime
49066
fname
junk
len
tx4fgg==
crc
c998310c
raw
"r_oal
mtime
"za
09093
8650
fname
junk
len
dat
q10=
crc
113366d3
raw
1 6 nwt
mtime
bi
8
2
58903
fname
flag
len
dat
rqs=
crc
5b057037
1 raw   qbzl 62
mtime
69
0858479580
fname
junk
len
dat
iqpf6q==
crc
e85a42e7
raw
van ]
mtime
bta
6,]
36944142
fname
iunk
dat
tb3k
crc
710f3115
raw
zel
o@zl]


after some googling, the data turned out to be a [bson](https://en.wikipedia.org/wiki/bson), a format that's used mainly in mongodb. 

our first guess was to try to load the dump into mongo using a recovery tool, but that turned out to be pointless.

taking a step back, we've decided to convert the file to a standard json structured file using a python script.
the file itself was broken and the parser would not work on it.
we used a debugger to see how the library is parsing bson files and we noticed that it first tries to read 4 big endian byte number as record length.
in our case there was only a single `0x0` byte instead.
therefore we checked how long is a single record (`0x72` bytes) and then attached the missing 3 bytes in the beginning of data so that the data starts with `0x72 0x00 0x00 0x00` (big endian!).
with this we could make a script to dump all the data:


``` python

import base64
import codecs
import bson

with codecs.open("./one_bad_son", "rb") as input_file:
    data = input_file.read()
    data = '\x72\x00\x00' + data
    loaded = bson.decode_all(data)
    with codecs.open("out.txt", "w") as output_file:
        output_file.write("[\n")
        for d in loaded:
            output_file.write(repr(d)+"\n")
        output_file.write("]\n")
```

this is how a single row looked like:

`{u'raw': 100000000000000l, u'len': 2, u'dat': u'iva=', u'crc': u'c0f36009', u'fname': u'flag', u'mtime': datetime.datetime(48652, 6, 24, 12, 40, 10, 460000), u'_id': u'0262404638'}`

in reality we could have just as well written a parser `by hand`, since the structure was rather clear, but it turned out to be faster this way.

what's interesting now, is that the base64 decoded `dat` data from first 2 rows (when data sorted by `raw` field) creates `png` string, so there's a png image encoded in that json!

however some values from the `raw` field are duplicated so we had to make sure we use each chunk only once.

we wrote a script to decode all unique `flag` rows sorted by their `raw` field:

``` python
used_id = set()
ordered = sorted(loaded, key=lambda di: int(di['raw']))

flag_data = []
for d in ordered:
    id = d['raw']
    if id not in used_id and d['fname'] == 'flag':
        base = d['dat']
        decoded = base64.b64decode(base)
        flag_data.append(decoded)
        used_id.add(id)
with codecs.open("out.png", "wb") as output_file:
    output_file.write("".join(flag_data))
```


and the output is:


[image extracted text: asis-
my_bad_son_lik3_bson_mongodb_flle_format]


