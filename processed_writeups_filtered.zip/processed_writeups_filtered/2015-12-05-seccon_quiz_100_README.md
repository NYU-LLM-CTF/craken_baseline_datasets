## command-line quiz (unknown, 100p)

    telnet caitsith.pwn.seccon.jp
    user:root
    password:seccon
    the goal is to find the flag word by "somehow" reading all *.txt files.

###pl
[eng](#eng-version)

łączymy się ze wskazanym serwerem: 

```
caitsith login: root
password:
$ ls
bin         flags.txt   linuxrc     stage1.txt  stage4.txt  usr
dev         init        proc        stage2.txt  stage5.txt
etc         lib         sbin        stage3.txt  tmp
$ cat flags.txt
cat: can't open 'flags.txt': operation not permitted
$ cat stage1.txt
what command do you use when you want to read only top lines of a text file?

set your answer to environment variable named stage1 and execute a shell.

  $ stage1=$your_answer_here sh

if your answer is what i meant, you will be able to access stage2.txt file.
$ cat stage2.txt
cat: can't open 'stage2.txt': operation not permitted
```

jesteśmy w stanie przeczytać tylko plik stage1.txt, kolejne są odblokowywane w momencie kiedy
rozwiążemy poprzednie zagadki. więc idziemy po kolei:

```
$ cat stage1.txt
what command do you use when you want to read only top lines of a text file?

set your answer to environment variable named stage1 and execute a shell.

  $ stage1=$your_answer_here sh

if your answer is what i meant, you will be able to access stage2.txt file.
$ stage1=head sh
$ cat stage2.txt
what command do you use when you want to read only bottom lines of a text file?

set your answer to environment variable named stage2 and execute a shell.

  $ stage2=$your_answer_here sh

if your answer is what i meant, you will be able to access stage3.txt file.
$ stage2=tail sh
$ cat stage3.txt
what command do you use when you want to pick up lines that match specific patterns?

set your answer to environment variable named stage3 and execute a shell.

  $ stage3=$your_answer_here sh

if your answer is what i meant, you will be able to access stage4.txt file.
$ stage3=grep sh
$ cat stage4.txt
what command do you use when you want to process a text file?

set your answer to environment variable named stage4 and execute a shell.

  $ stage4=$your_answer_here sh

if your answer is what i meant, you will be able to access stage5.txt file.
$ stage4=awk sh
$ cat stage5.txt
ok. you reached the final stage. the flag word is in flags.txt file.

flags.txt can be read by only one specific program which is available
in this server. the program for reading flags.txt is one of commands
you can use for processing a text file. please find it. good luck. ;-)
$ sed -e ''  flags.txt
ok. you have read all .txt files. the flag word is shown below.

seccon{caitsith@aqua}
```

### eng version

we connect to server pointed in description:

```
caitsith login: root
password:
$ ls
bin         flags.txt   linuxrc     stage1.txt  stage4.txt  usr
dev         init        proc        stage2.txt  stage5.txt
etc         lib         sbin        stage3.txt  tmp
$ cat flags.txt
cat: can't open 'flags.txt': operation not permitted
$ cat stage1.txt
what command do you use when you want to read only top lines of a text file?

set your answer to environment variable named stage1 and execute a shell.

  $ stage1=$your_answer_here sh

if your answer is what i meant, you will be able to access stage2.txt file.
$ cat stage2.txt
cat: can't open 'stage2.txt': operation not permitted
```

we can only read stage1.txt file, other files are locked untill we solve earlier challenges. so we proceed step by step:

```
$ cat stage1.txt
what command do you use when you want to read only top lines of a text file?

set your answer to environment variable named stage1 and execute a shell.

  $ stage1=$your_answer_here sh

if your answer is what i meant, you will be able to access stage2.txt file.
$ stage1=head sh
$ cat stage2.txt
what command do you use when you want to read only bottom lines of a text file?

set your answer to environment variable named stage2 and execute a shell.

  $ stage2=$your_answer_here sh

if your answer is what i meant, you will be able to access stage3.txt file.
$ stage2=tail sh
$ cat stage3.txt
what command do you use when you want to pick up lines that match specific patterns?

set your answer to environment variable named stage3 and execute a shell.

  $ stage3=$your_answer_here sh

if your answer is what i meant, you will be able to access stage4.txt file.
$ stage3=grep sh
$ cat stage4.txt
what command do you use when you want to process a text file?

set your answer to environment variable named stage4 and execute a shell.

  $ stage4=$your_answer_here sh

if your answer is what i meant, you will be able to access stage5.txt file.
$ stage4=awk sh
$ cat stage5.txt
ok. you reached the final stage. the flag word is in flags.txt file.

flags.txt can be read by only one specific program which is available
in this server. the program for reading flags.txt is one of commands
you can use for processing a text file. please find it. good luck. ;-)
$ sed -e ''  flags.txt
ok. you have read all .txt files. the flag word is shown below.

seccon{caitsith@aqua}
```

