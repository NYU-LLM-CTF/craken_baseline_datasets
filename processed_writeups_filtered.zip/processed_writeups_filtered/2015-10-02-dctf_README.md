# writeup defcamp ctf 2015

uczestniczyliśmy (msm, rev, other019, nazywam i shalom) w defcamp ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:
większość zadań wymagała łączenia się przez vpn aby uzyskać dostęp do infrastruktury organizatora. było to o tyle problematyczne, że vpn lubił zrywać połączenie i działać bardzo wolno, co mocno utrudniało pracę nad niektórymi zadaniami.

a teraz opisy zadań po kolei.

# spis treści:
* [warm up (web 100)](web_100)
* [the hylian dude (web 200)]()
* [rocket science admin panel (web 300)]()
* [css engineer (web 400)]()
* [custom function engineering (crypto 300)](crypto_300_custom_function)
* [11 (crypto 50)](crypto_50)
* [password encrypting tool (pwn 100)]()
* [no crypto (pwn 200)]()
* [entry language (reverse 100)](re_100_entry)
* [link & switch (reverse 200)](re_200_link)
* [lbs checker (reverse 300)](re_300_lbs_checker) 
* [such exploit, much random (pwn 300)]()
* [master of reversing (reverse 400)](re_400_master_of_reversing)
* [she said it doesn't matter (misc/stego 100)](misc_100_doesnt_matter)
* [try harder! (misc/stego 200)](misc_200_try_harder)
* [can you read pacifico? (misc/ppc 400+1)](misc_400_captcha)

# wykres


[image extracted text: 5000
oct 04 11.00
4750
ppp
4656
4500
balalaikacr3w
4510
4250
tokyowesterns
4201
4000
hackingforsoju
4200
3750
hertz
4106
3500
scryptos
4100
3250
tasteless
4015
3000
more smoked
eet chicken
4007
2750
dcua
4003
2500
dragon sector
4000
2250
ispamandhex 
4000
2000
fluxfingers
3906
1750
ox8f
3901
1500
shellphish
3855
1250
vulturii
3803
1000
clgt
3800
750
3651
500
khack4o
3500
250
bushwhackers
3406
skt t1
3352
3 8
3
3
play4fun
3303
8 3
negg
3200
toxic
3200
8
j
j
7
7
j
j
j
j
7
8
8
8
8
8
8
8
8
8
8
8
8
8
j
j
j
j
8
3
8
8
8
3
3
3
8
8
8
8
8
8
8
3
8
8
3]


# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
