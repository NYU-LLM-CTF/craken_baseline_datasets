# angel (re, 468 points, 20 solves)
  
we're given a password-checking binary:


``` c++
int __cdecl sub_80485bf(char *input_str)
{
  int result; // eax@2
  char v2; // [sp+3h] [bp-15h]@1
  int v3; // [sp+4h] [bp-14h]@1
  size_t i; // [sp+8h] [bp-10h]@3

  v2 = *input_str;
  v3 = 0;
  if ( strlen(input_str) > 2 )
  {
    for ( i = 1; strlen(input_str) - 1 > i; ++i )
    {
      some_dark_magic(dword_804d148, &off_804c140 + 4 * (unsigned __int8)v2);
      if ( dword_804c060[v3] != dword_804d148((unsigned __int8)input_str[i]) )
        return puts("wrong!");
      if ( ++v3 == 200 )
        break;
      v2 = input_str[i];
    }
    result = puts("well done!");
  }
  else
  {
    result = puts("wrong!");
  }
  return result;
}
```

there is some lookup-table stuff going on with `off_804c140` and some dark magic with `some_dark_magic` function ;)

we could reverse the whole program but we're lazy and the encryption has a cool property - the passwords nth check relies only on input bytes we've already analyzed.

this means that we could brute the correct input one byte at a time - we try to append every possible byte to the last successfull input and when we find a match we move one byte forward.

we came up with a nifty little gdb python script:

``` python
import os
import string
from subprocess import popen, pipe, stdout
import gdb
import codecs
import string
good_characters = 0

class mybreakpoint(gdb.breakpoint):

    def __init__(self, spec):
        super(mybreakpoint, self).__init__(spec, gdb.bp_breakpoint, internal = false)
        self.silent = true
 
    def stop (self):
        eax = int(gdb.parse_and_eval("$eax"))
        edx = int(gdb.parse_and_eval("$edx"))

        if eax == edx:
            global matches         
            matches += 1

        return false

mybreakpoint('*0x08048656')

matches = 0
starting_piece = "you"

while true:
    for i in string.printable:

        potential_flag = starting_piece + i + "a"*30

        matches = 0

        with codecs.open("input.txt","w") as output_file:
            output_file.write(potential_flag)

        gdb.execute("r < input.txt > /tmp/a")

        if matches == len(starting_piece):
            starting_piece += i
            break;

    f = open("output", "wb")
    f.write(starting_piece)
```

we had to brute-force two first letters and then try about 4 different starting inputs but once we got overt that the script ran smoothly.

`you are looking for this eko{4ngr_d1dn't_like_th1s}`

