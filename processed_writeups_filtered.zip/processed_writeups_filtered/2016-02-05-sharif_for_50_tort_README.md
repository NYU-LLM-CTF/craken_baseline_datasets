##kick tort teen (forensics, 50p)
	anagram, anyone?
[download](data.xls)

###eng
[pl](#pl-version)


we start by converting the xls file to csv. then we load up the values into a python script that counts the number occurences:

```python
occurences = []
for i in range(1000):
	occurences.append(0)

for y in data:
	for x in y:
		occurences[x]=occurences[x]+1

for i in range(len(occurences)):
	print(i, occurences[i])`
```

it turns out that there are 256 different numbers in the file, let's try swapping each number with its index in the list of all numbers that appear in the file. [decode.cpp](decode.cpp)

we get a elf file that prints out the flag:

`sharifctf{5bd74def27ce149fe1b63f2aa92331ab}`


###pl version

pierwsze co zrobimy to przekonwertujemy spredsheeta do csv. wartości wczytamy do prostego programu w pythonie zwracającego wystąpienia poszczególnych liczb: 

```python
occurences = []
for i in range(1000):
	occurences.append(0)

for y in data:
	for x in y:
		occurences[x]=occurences[x]+1

for i in range(len(occurences)):
	print(i, occurences[i])`
```

okazuje się, że w pliku znajduje się 256 różnych liczb, spróbujmy zatem zastąpić każdą liczbę jej pozycją w liście wszystkich liczb które występują w tekście. [decode.cpp](decode.cpp)

dostajemy plik elf który po uruchomieniu wypisuje nam flagę: 

`sharifctf{5bd74def27ce149fe1b63f2aa92331ab}`
