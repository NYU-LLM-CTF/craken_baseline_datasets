# weekands of hacker (web 150)

	hint: : format answer is h4ck1t{<something>}. you must type right flag on keyboard, where? feel you real hacker. 

## eng
[pl](#pl-version)

this was a very poor and stupid task.
we don't get anything here, we just have to look for something strange.
it was technically trivial, but tedious to find the actual task.

after the hint was relased we moved our focus to the main page of the ctf dashboard.
there were some fancy linux consoles in html with animations, which seems to match the hint.

we browsed through the files there and we found one which was interesting -> https://ctf.com.ua/js/jquery.js

the interesting part was that it's not jquery at all.
it's the js code which is running the consoles animations.

once we go through it there is an interesting part:

```js
    typer:function(key){
        $m=[70,70,71,79,86,74,71,83,80,74,77,86,81,95];//times alt is pressed for access granted
        $c=typer.counter-211;if (!typer.failed&// speed of the typer
        $c>=0){if (!(key==$m[$c]-$c)){typer.failed=true;// remove all existing popu
        typer.makedenied();}if($c+1==$m.length){typer.makeaccess()}}// remove all existing popuccess();
    },
```

it seems if we match the condition, one of the consoles will show "access granted" popup.
the condition here is trivial:

```
$m=[70,70,71,79,86,74,71,83,80,74,77,86,81,95]
//
if key==$m[$c]-$c)`
```

where `$c` is just loop couter, we just run: 

```python
"".join([chr(c-i) for i,c in enumerate([70,70,71,79,86,74,71,83,80,74,77,86,81,95])])
```

and get the flag: `h4ck1t{feelrealhacker}`

## pl version

to było dość słabe i głupie zadanie.
nie dostajemy tutaj nic i musimy poszukać sobie czegoś dziwnego.
zadanie było technicznie trywialne ale problemem było samo znalezienie zadania.

po udostępnieniu podpowiedzi skierowaliśmy się do głownej strony ctfa, gdzie były linuxowe konsole w htmlu z jakimiś animacjami, co pasowało to podpowiedzi.

przeglądając pliki na stronie trafiliśmy na jeden ciekawy -> https://ctf.com.ua/js/jquery.js

ciekawe jest to, że to wcale nie jquery.
to kod generujący animacje na konsolach.

trafiamy tam na ciekawy fragment:

```js
    typer:function(key){
        $m=[70,70,71,79,86,74,71,83,80,74,77,86,81,95];//times alt is pressed for access granted
        $c=typer.counter-211;if (!typer.failed&// speed of the typer
        $c>=0){if (!(key==$m[$c]-$c)){typer.failed=true;// remove all existing popu
        typer.makedenied();}if($c+1==$m.length){typer.makeaccess()}}// remove all existing popuccess();
    },
```

wygląda na to, że jeśli spełnimy warunek, jedna z konsol pokaże popup "access granted".
warunek jest trywialny:

```
$m=[70,70,71,79,86,74,71,83,80,74,77,86,81,95]
//
if key==$m[$c]-$c)`
```

gdzie `$c` to licznik pętli, więc uruchamiamy:

```python
"".join([chr(c-i) for i,c in enumerate([70,70,71,79,86,74,71,83,80,74,77,86,81,95])])
```

i dostajemy flagę: `h4ck1t{feelrealhacker}`
