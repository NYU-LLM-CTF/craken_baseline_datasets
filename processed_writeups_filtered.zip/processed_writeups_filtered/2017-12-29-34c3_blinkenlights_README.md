# blinkenlights (rev, 242p, 15 solves)

> i built something that prints the flag. but i lost the flag :(
>
> difficulty: medium

in this task we got a binary firmware for arm architecture, and a 400mb csv containing oscilloscope traces
of a channel. initially i wasted a couple hours trying to reverse engineer the binary, but it turned out that
i was able to solve the challenge using just the csv, i.e. in a black box way.

the csv had two integer columns: `sample` and `channel 1`, but the second column seemed to alternate between 0 and 1,
so it did not contain any information for us.
probably it's because the oscilloscope was compressing the signal using algorithm similar to run length encoding.
this means we are only interested in the first column. i've preprocessed it to calculate the difference between two
consecutive times and noticed that the times corresponding to "1" state are always quite short compared to
the other ones - and the "0" times are varying in length. so there's probably some kind of message encoded in 
time between pulses.

after excluding several very long (~100 times longer than average) times - they seem to be some kind of synchronization,
not needed for us - i've multiplied every sample by ten and stored as greyscale imaage, hoping to notice some pattern.
it turned out that setting width to 6144 (guessed) we can notice some barely readable text - a flag!


[image extracted text: [image processing failed]]

