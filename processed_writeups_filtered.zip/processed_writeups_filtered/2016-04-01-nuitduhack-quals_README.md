# writeup nuit du hack ctf 2016 quals

team: akrasuski1, c7f.m0d3, cr019283, mnmd21891, msm, nazywam, shalom

### table of contents

 * [catch me if you can (forensics)](catch_me_if_you_can)
 * [invest (forensics)](invest)
 * [matryoshka (crackme)](matryoshka)
 * secure file reader (exploit me)
 * toil33t (crypto)
 * trolololo (forensics)
