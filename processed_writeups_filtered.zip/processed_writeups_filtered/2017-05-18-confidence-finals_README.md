# writeup confidence ctf finals 2017

team: akrasuski1, msm, nazywam, rev


[image extracted text: [image processing failed]]


### table of contents

* [random (crypto 100)](random)
* [starbyte (misc 200)](starbyte)
* [keygenme (reverse 400)](keygenme)
* [??? (crypto 300)](crypto)
