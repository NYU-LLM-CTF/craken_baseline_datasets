# starbyte (misc, 200p)

this challenge was supposed to be misc, but we all agreed that this is more like stegano. "better kind" of stegano (as always from gynvael!) but still.

so we were given strange sound file - [starbyte](starbyte). you can easily see "bits" in the transmission:


[image extracted text: 0.0-
1.0]


my teammate quickly wrote parser for this, and converted it to bytes. unfortunatelly, we became stuck at this point for some time - for some reason we thought that data was in 5-bit-chunks, when in fact we should look at data in 10-bit-chunks. after acknowledging that, parsing was easy:


```python
import wave, array

f = wave.open('starbyte')

new_wave = true

sum = 0
num = 0

tmp_out = ""
out = ""

f_out = ""

binary = open("binary", "w")

tot = 0
out = []
nnn = 10
for s in array.array('h', f.readframes(f.getnframes())):
    if s < 5000:
        if not new_wave:

            if sum/num > 20000:
                tmp_out += "1"
                binary.write("1")
            else:
                tmp_out += "0"
                binary.write("0")

            #if len(tmp_out) == 5:
            #    f_out += chr(int(tmp_out, 2))
            #    tmp_out = ""

            tot += 1
            if len(tmp_out) == nnn:
                #f_out += chr(int(tmp_out, 2))
                out.append(int(tmp_out, 2))
                tmp_out = ""

        sum = 0
        num = 0
        new_wave = true
    else:
        sum += s
        num += 1
        new_wave = false

import string
charset = string.digits + string.lowercase
x = ''
outd = out
k = ''
for o in out:
    kek = ('000000000000000' + bin(o)[2:])[-10:][:-2]
    i = kek[::-1]
    i = int(i, 2)
    k += chr(i)

print k
```

data was just ascii, but in 10-bit-chunks and reversed. you could guess that, because 3 last bits of every chunk was always zero. if you assume that these are in fact wrapped bytes, then you have bytes with last bit always equal to zero - and this strongly suggests reversed ascii characters.


but this was only stage 1. after that we get a long text file - [cmds.txt](cmds.txt). snippet:

```
line 612 437 612 425
line 650 211 650 223
crcl 437 312 3
line 779 355 779 393
line 783 355 795 355
line 612 501 612 489
line 454 308 454 299
line 589 311 587 320
line 811 393 799 393
line 472 501 456 501
line 612 441 650 441
line 612 629 612 617
line 960 720 0 720
line 368 314 368 308
line 650 243 650 255
```

it was quite obvious what to do with this (just draw), but coding python script took dozen of precious minutes (google found nothing, so i guess this was custom format?):

```python
from pil import image, imagedraw

im = image.new("rgb", (1000, 1000), "black")
draw = imagedraw.draw(im)

data = open('cmds.txt').read()
data = data.split('\n')

for l in data:
    print l
    cmd = l.split(' ')
    if cmd[0] == 'line':
        a, b, c, d = cmd[1:]
        a, b, c, d = int(a), int(b), int(c), int(d)
        draw.line([(a, b), (c, d)], 'white')
    elif cmd[0] == 'crcl':
        a, b, c = cmd[1:]
        a, b, c = int(a), int(b), int(c)
        draw.arc([(a-c, b-c), (a+c, b+c)], 0, 360, 'white')
    elif cmd[0] == 'rect':
        a, b, c, d = cmd[1:]
        a, b, c, d = int(a), int(b), int(c), int(d)
        draw.rectangle([(a, b), (c, d)], 'white')

im.save('out.png')
```

after that, we were quite pleased with the result:


[image extracted text: drg"sisecrzttazie n}]

