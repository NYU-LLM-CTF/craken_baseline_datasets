﻿## puzzleng (forensic, 150p, 24 solves)

> next generation of puzzle!

> [puzzleng-edb16f6134bafb9e8b856b441480c117.tgz](puzzleng.tgz)

### pl
[eng](#eng-version)

z dołączonego do zadania pliku tgz wypakowujemy dwa kolejne - [encrypt](encrypt) (to binarka, elf) oraz [flag.puzzle](flag.puzzle) (nieznany typ pliku).
łatwo domyślić się że jeden to kod którym zostały zaszyfrowane dane, a drugi to same zaszyfrowane dane.

przepisujemy kod szyfrujący do c żeby móc go dokładniej przeanalizować:

```c
int main(int argc, char *argv[]) {
    char hash[20];
    assert(argc == 3);
    int password_len = strlen(argv[1]);
    sha1(argv[1], password_len, hash);
    stream = fopen(argv[2], "r");
    assert(stream);
    fseek(stream, 0ll, 2);
    int data_len = ftell(stream);
    rewind(stream);
    for (int i = 0; i <= 19; ++i) {
        for (int j = 0; j < (data_len + 19) / 20; ++j) {
            int chr = fgetc(stream);
            if (chr == -1) break;
            putchar(chr ^ hash[i]);
        }
    }
}
```

jak widać działanie jest bardzo proste - dzieli plik wejściowy na 20 bloków, i każdy z nich xoruje z innym bajtem.
bajty z którymi szyfruje są losowe (wynik sha1) więc ich nie zgadniemy.

ale wydaje się to być banalne, albo wręcz trywialne zadanie. w końcu xorowanie po bajcie to jedna z najsłabszych
metod szyfrowania jaką można wymyślić. zakładamy więc że dane które zostały zaszyfrowane to plaintext, i piszemy
na szybko dekryptor (źródło już nie istnieje, ale pomysł był prosty - dla każdego bloku sprawdzenie, z jakim bajtem
go trzeba xorować żeby po xorowaniu wszystkie bajty były plaintekstem). bardzo się zawiedliśmy - nie ma takich 
bajtów, więc dane które zostały zaszyfrowane nie są plaintextem.

w przypływie natchnienie sprawdzamy co innego - czy da się znaleźć taki bajt, że po xor-owaniu go z pierwszym blokiem
w wyniku będzie gdzieś "ihdr". i nie myliliśmy się - dane które otrzymaliśmy to zaszyfrowany plik .png:

```python
s = open('flag.puzzle', 'rb').read()

chunk_len = (1135+19)/20
chunks = [s[chunk_len*i:chunk_len*(i+1)] for i in range(20)]

def xor(a, b):
    return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

for i in range(len(chunks)):
    c = chunks[i]
    for b in range(256):
        xx = xor(c, chr(b)*10000)
        if 'ihdr' in xx:
            print i, b, xx, xx.encode('hex')
```

co teraz? wiemy już z jakim bajtem był xorowany pierwszy blok, ale mamy 19 do zgadnięcia. zrobiliśmy to samo dla 'idat' i 'iend',
zgadując kolejne dwa bajty. niestety to ślepa uliczka - pikseli obrazka w ten sposób nie zgadniemy (a przynajmniej nie mieliśmy pomysłu żadnego).

dlatego poszliśmy inną drogą - wiemy jak zaczynają się dane chunka idat (to stream zlibowy), bo mamy ich fragment:  

```python
start = '789cedcf418ae4300c05d0dcffd2358bc6485f76'.decode('hex')
```

stream zlibowy prawdopodobnie nie zadziała dla wszystkich danych - możemy próbować deszyfrować drugi blok, i patrzeć kiedy będzie leciał wyjątek podczas dekompresji:

```python
known = {
    0: 101,
    1: 48
}

curr = start
for ndx in range(2, 20):
    c = chunks[ndx]
    if not known.has_key(ndx):
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            known[ndx] = i
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

był to bardzo obiecujący sposób, ale niestety skończył się niepowodzeniem - o ile zawartość trzeciego bloku 
odzyskaliśmy (był tylko jeden bajt który nie powodował wyjątku), przy czwartym i dalej bloku za wiele danych dekompresowało się poprawnie.

więc wykorzystaliśmy to co wiedzieliśmy o obrazku (wyciągniętą z rozszyfrowanej sekcji idat) - miał szerokość 912 pikseli oraz 
jednobitową paletę (czyli prawdopodobnie czarno-biały). i teraz cechą plików png, jest to że na początku każdego wiersza danych znajduje
się filtr którym są one traktowane. mniejsza o technikalia, wynika z tego że co 115 bajt w zdekompresowanych danych powinien być równy
'\x00' (tzn. nie musiał jeśli byłyby użyte inne filtry, ale po analizie fragmentów danych które mieliśmy zauważyliśmy że tutaj używany
wszędize jest filtr 0, jak zazwyczaj w png).


```python
def testraw(raw):
    for i in range(len(raw) / 115):
        if raw[i*115] != '\0':
            return false
    return true
```

nowa wersja:

```python
curr = start
for ndx in range(2, 20):
    c = chunks[ndx]
    if not known.has_key(ndx):
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            if testraw(zl):
                known[ndx] = i
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

niestety, było to dalej niewystarczające - ciągle więcej niż jeden bajt spełniał nasze warunki, więc musieliśmy je jakoś oceniać.
jako że zauważyliśmy że w błędnie zdekompresowanych plikach na końcu znajdywały się głównie zera (czarne piksele), wartościowaliśmy po ilości
nieczarnych pikseli w wyniku po dekompresji. ostateczna wersja:

```python
curr = start
for ndx in range(2, 20):
    clean()
    c = chunks[ndx]
    if not known.has_key(ndx):
        mingap = 0
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            if testraw(zl):
                gap = len([true for x in zl[-500:] if x != '\x00'])
                if gap > mingap:
                    known[ndx] = i
                    mingap = gap
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

udało się, dostaliśmy jakieś dane. po zapisaniu ich do pliku otrzymaliśmy piękny qr code:


[image extracted text: 87]


po dekodowaniu:

`hitcon{qrencode -s 16 -o flag.png -l h --foreground 8f77b5 --background 8f77b4}`

### eng version

we unpacked two files from tgz attached to task: [encrypt](encrypt) (elf binary) and [flag.puzzle](flag.puzzle) (unknown file).
it was obvious to us that first file is binary used to encrypt some data, and second file is result of that encryption.

we disassembled and rewritten binary to c to simplify analysis:

```c
int main(int argc, char *argv[]) {
    char hash[20];
    assert(argc == 3);
    int password_len = strlen(argv[1]);
    sha1(argv[1], password_len, hash);
    stream = fopen(argv[2], "r");
    assert(stream);
    fseek(stream, 0ll, 2);
    int data_len = ftell(stream);
    rewind(stream);
    for (int i = 0; i <= 19; ++i) {
        for (int j = 0; j < (data_len + 19) / 20; ++j) {
            int chr = fgetc(stream);
            if (chr == -1) break;
            putchar(chr ^ hash[i]);
        }
    }
}
```

encryption method is really simple - program splits input file to 20 blocks of equal length, than xors each of them with another byte.

at this moment challenge seems to be very easy, almost trivial - after all xoring data with single byte is one of weakest existing methods of encryption.
we assumed that encrypted data was plain text, and tried to bruteforce bytes in sha1 that was used to xor them. if our assumption was true, we could
find byte such that ciphertext_byte ^ byte is printable ascii for each byte in ciphetext - but it was not possible. that means, data that was encrypted is not textual.

so we checked another possiblity - we tried bruteforcing bytes for first block, but this time we hoped for 'ihdr' in decrypted string. and we were right -
our encrypted data used to be .png file.

```python
s = open('flag.puzzle', 'rb').read()

chunk_len = (1135+19)/20
chunks = [s[chunk_len*i:chunk_len*(i+1)] for i in range(20)]

def xor(a, b):
    return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

for i in range(len(chunks)):
    c = chunks[i]
    for b in range(256):
        xx = xor(c, chr(b)*10000)
        if 'ihdr' in xx:
            print i, b, xx, xx.encode('hex')
```

now what? we know byte that was used to encrypt first block, but we have 19 more to go. we used the same method to find 'idat' and 'iend', leaving us
with 17 unknown bytes.

that turned out to be dead end, so we tried something completely different. we know first few bytes of idat section (because we decrypted block with idat)

```python
start = '789cedcf418ae4300c05d0dcffd2358bc6485f76'.decode('hex')
```

we know that this is zlib stream, and that next block, after decrypting and appending to this fragment, should form correct zlib stream
as well (otherwise it will probably throw some exception)

```python
known = {
    0: 101,
    1: 48
}

curr = start
for ndx in range(2, 20):
    c = chunks[ndx]
    if not known.has_key(ndx):
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            known[ndx] = i
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

this method was really promising, but we didn't get very far with it. we decrypted third block with ease (only one byte didn't throw exception),
but fourth and later blocks decompression threw exceptions much sparser and left us with too much posibilities to bruteforce.

so we used our knowledge about image (that we acquired after decrypting idat section) - it's 912 pixels wide, 912 pixels height, and have 1bit palette
(black and white probably). we remembered that each row in decompressed raw png data starts with 'filter byte' (this byte allows encoders/decoders to preprocess
raw pixel data, potentially reducing final file size). after analysing blocks that we managed to decompress, we concluded that all filter bytes are equal to 0, 
so every 115-th byte in decompressed data should be equal to '\x00'. using this knowledge we updated our decryptor:

```python
def testraw(raw):
    for i in range(len(raw) / 115):
        if raw[i*115] != '\0':
            return false
    return true
```

new version:

```python
curr = start
for ndx in range(2, 20):
    c = chunks[ndx]
    if not known.has_key(ndx):
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            if testraw(zl):
                known[ndx] = i
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

alas, that still wasn't it - too many bytes passed this test. we noticed that incorrectly decompressed data contained a lot of zeroes at the end.
so we decided to grade possible solutions according to number of '\x00' bytes at the end (the less the better). final version:

```python
curr = start
for ndx in range(2, 20):
    clean()
    c = chunks[ndx]
    if not known.has_key(ndx):
        mingap = 0
        for i in range(256):
            xx = xor(c, chr(i)*10000)
            try:
                zl = zlib.decompressobj().decompress(curr+xx)
            except:
                continue
            if testraw(zl):
                gap = len([true for x in zl[-500:] if x != '\x00'])
                if gap > mingap:
                    known[ndx] = i
                    mingap = gap
    print known[ndx]
    xxok = xor(c, chr(known[ndx])*10000)
    curr = curr + xxok
```

we did it, that method gave us correct byte that each block was xored with (stored in `known` dictionary). after saving decrypted data to file, we get
beautiful qr code:


[image extracted text: 87]


after decoding:

`hitcon{qrencode -s 16 -o flag.png -l h --foreground 8f77b5 --background 8f77b4}`
