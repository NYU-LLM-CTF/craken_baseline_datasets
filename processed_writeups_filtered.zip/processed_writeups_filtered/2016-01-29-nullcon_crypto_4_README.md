﻿##md5 (crypto, 200p)

	he is influential, he is powerful. 
	he is your next contact you can get you out of this situation. 
	you must reach him soon. 
	who is he? the few pointers intrecpted by kgb are in the file. 
	once we know him, we can find his most valuable possession, his pride.

###pl
[eng](#eng-version)

dostajemy plik z hashami md5:

	d80517c8069d7702d8fdd89b64b4ed3b 
	088aed904b5a278342bba6ff55d0b3a8 
	56cdd7e9e3cef1974f4075c03a80332d 
	0a6de9d8668281593bbd349ef75c1f49 
	972e73b7a882d0802a4e3a16946a2f94 
	1cc84619677de81ee6e44149845270a3 
	b95086a92ffcac73f9c828876a8366f0 
	b068931cc450442b63f5b3d276ea4297 

złamanie tych hashy (np. za pomocą http://md5cracker.org/decrypted-md5-hash/b068931cc450442b63f5b3d276ea4297) daje nam słowa: `carrie`, `grease`, `perfect`, `shout`, `basic`, `actor`, `aircraft`, `name`.

można wynioskować, że chodzi tutaj o johna travoltę oraz o nazwę jego samolotu.
z pomocą przychodzi google i mówi, że samolot nazywa się `jett clipper ella` co też jest flagą.

###eng version

we get a file with md5 hashes:

	d80517c8069d7702d8fdd89b64b4ed3b 
	088aed904b5a278342bba6ff55d0b3a8 
	56cdd7e9e3cef1974f4075c03a80332d 
	0a6de9d8668281593bbd349ef75c1f49 
	972e73b7a882d0802a4e3a16946a2f94 
	1cc84619677de81ee6e44149845270a3 
	b95086a92ffcac73f9c828876a8366f0 
	b068931cc450442b63f5b3d276ea4297 

breaking them (eg. with http://md5cracker.org/decrypted-md5-hash/b068931cc450442b63f5b3d276ea4297) gives us words: `carrie`, `grease`, `perfect`, `shout`, `basic`, `actor`, `aircraft`, `name`.

we figure out they are about john travolta and out task is to find his airplane name.
google says it's `jett clipper ella` and it's the flag.
