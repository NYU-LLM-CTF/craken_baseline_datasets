# memory (forensics 100)

###eng
[pl](#pl-version)

in the task we get a memdump (quite large so we won't add it here).
we proceed with the analysis using volatility.

if we check connections we can see that there is only one:

```
$ ./volatility-2.5.standalone.exe connections -f forensic_100.raw
volatility foundation volatility framework 2.5
offset(v)  local address             remote address            pid
---------- ------------------------- ------------------------- ---
0x8213bbe8 192.168.88.131:1034       153.127.200.178:80        1080
```

no we can still play with volatility or we can just check this ip directly in the memdump strings and we can find:

```
# copyright (c) 1993-1999 microsoft corp.
# this is a sample hosts file used by microsoft tcp/ip for windows.
# this file contains the mappings of ip addresses to host names. each
# entry should be kept on an individual line. the ip address should
# be placed in the first column followed by the corresponding host name.
# the ip address and the host name should be separated by at least one
# space.
# additionally, comments (such as these) may be inserted on individual
# lines or following the machine name denoted by a '#' symbol.
# for example:
#      102.54.94.97     rhino.acme.com          # source server
#       38.25.63.10     x.acme.com              # x client host
127.0.0.1       localhost
153.127.200.178    crattack.tistory.com 
```

so it seems someone added this ip manually for host `crattack.tistory.com`.

if we now look for the host `crattack.tistory.com` we can find:


```
c:\program files\internet explorer\iexplore.exe http://crattack.tistory.com/entry/data-science-import-pandas-as-pd
```

this matches what we've seen - someone was accessing this ip on port 80, so it was ie.
but this ip does not match the actual ip of this host.
so we check what did the user see under `http://crattack.tistory.com/entry/data-science-import-pandas-as-pd` -> `http://153.127.200.178/entry/data-science-import-pandas-as-pd` and it turnes out to be the flag:

`seccon{_h3110_w3_h4ve_fun_w4rg4m3_}`

###pl version

w zadaniu dostajemy memdump (duży więc go nie wrzucamy).
rozpoczynamy analizę z volatility.

jeśli sprawdzimy połączenia to widzimy tylko jedno:

```
$ ./volatility-2.5.standalone.exe connections -f forensic_100.raw
volatility foundation volatility framework 2.5
offset(v)  local address             remote address            pid
---------- ------------------------- ------------------------- ---
0x8213bbe8 192.168.88.131:1034       153.127.200.178:80        1080
```

moglibyśmy dalej bawić się z volatility ale szybciej będzie poszukać tego ip w stringach z memdumpa:

```
# copyright (c) 1993-1999 microsoft corp.
# this is a sample hosts file used by microsoft tcp/ip for windows.
# this file contains the mappings of ip addresses to host names. each
# entry should be kept on an individual line. the ip address should
# be placed in the first column followed by the corresponding host name.
# the ip address and the host name should be separated by at least one
# space.
# additionally, comments (such as these) may be inserted on individual
# lines or following the machine name denoted by a '#' symbol.
# for example:
#      102.54.94.97     rhino.acme.com          # source server
#       38.25.63.10     x.acme.com              # x client host
127.0.0.1       localhost
153.127.200.178    crattack.tistory.com 
```

jak widać ktoś ręcznie dodał ten ip dla hosta `crattack.tistory.com`.

jeśli teraz poszukamy hosta `crattack.tistory.com` znajdziemy:

```
c:\program files\internet explorer\iexplore.exe http://crattack.tistory.com/entry/data-science-import-pandas-as-pd
```

co pasuje do tego co obserwowaliśmy - ktoś łączył się z tym adresem na porcie 80, więc było to ie.
ale ten ip nie pasuje do faktycznego adresu tego hosta.
sprawwdźmy więc co użytkownik widział pod `http://crattack.tistory.com/entry/data-science-import-pandas-as-pd` -> `http://153.127.200.178/entry/data-science-import-pandas-as-pd` a okazuje się to być flagą:

`seccon{_h3110_w3_h4ve_fun_w4rg4m3_}`
