## mindblown (crypto)

###eng
[pl](#pl-version)

we are given authentication logic running on the server:

```
var express = require('express');
var app = express();
var port = process.env.port || 9898;
var crypto = require('crypto');
var bodyparser = require('body-parser')
var salt = 'somestring';
var iteration = /// some number here;
var keylength = // some number here;

app.post('/login', function (req, res) {
	var username = req.body.username;
	var password = req.body.password;
	if (username !== 'chintu') {
		res.send('username is wrong');
		return;
	}
	if (crypto.pbkdf2sync(password, salt, iteration, keylength).tostring() === hashofpassword) {
		if (password === 'complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg') {
			// some logic here and return something
		} else {
			// return flag here
		}
	} else {
		res.send('password is wrong');
	}
});
```

it seems straightforward: we need to login as user `chintu` and our password hash has to match the hash value for `complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg` while at the same time it has to be a different string.

initially we thought it will require time-consuming hash collision generation, almost impossible since we don't know the number of iterations and keylen.

however, we found this: https://mathiasbynens.be/notes/pbkdf2-hmac which describes vulnerability of `pbkdf2sync` function in case password is longer than the size of hash function used. 
in our case the default `sha1` hash is used and we notice that the user password is longer than 64 bytes.
this means that `pbkdf2sync` will actually use `sha1(password)` instead of actual passsword value, and therefore we can use `sha1(password)` as `password` itself -> `sha1('complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg') = e6~n22k81<[p"k5hhv6*`

we therefore login using
`username: chintu`
`password: e6~n22k81<[p"k5hhv6*`

and we get the flag.

###pl version

dostajemy kod autentykacji działającej na serwerze:

```
var express = require('express');
var app = express();
var port = process.env.port || 9898;
var crypto = require('crypto');
var bodyparser = require('body-parser')
var salt = 'somestring';
var iteration = /// some number here;
var keylength = // some number here;

app.post('/login', function (req, res) {
	var username = req.body.username;
	var password = req.body.password;
	if (username !== 'chintu') {
		res.send('username is wrong');
		return;
	}
	if (crypto.pbkdf2sync(password, salt, iteration, keylength).tostring() === hashofpassword) {
		if (password === 'complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg') {
			// some logic here and return something
		} else {
			// return flag here
		}
	} else {
		res.send('password is wrong');
	}
});
```

zadanie wydaje się dość proste koncepcyjnie: mamy zalogować się jako użytkownik `chintu` a hash podanego hasła musi zgodzić się z hashem dla hasła `complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg`, jednocześnie będąc innym stringiem.

początkowo myśleliśmy, że będzie wymagało to czasochłonnego liczenia kolizji hashy, praktycznie niemożliwego przy braku znajomości liczby iteracji oraz długości klucza.

niemniej jednak znaleźliśmy artykuł: https://mathiasbynens.be/notes/pbkdf2-hmac opisujący podatność funkcji `pbkdf2sync` w sytuacji gdy podane hasło jest dłuższe niż rozmiar hasha używanej funkcji.

w naszym przypadku używana jest domyślna funkcja `sha1` i widzimy że hasło ma wiecej niż 64 bajty.
to oznacza, że `pbkdf2sync` w praktyce użyje wartości `sha1(password)` zamiast wartości hasła a co za tym idzie możemy z powodzeniem użyć wartości `sha1(password)` jako `password` -> `sha1('complexpasswordwhichcontainsmanycharacterswithrandomsuffixeghjrjg') = e6~n22k81<[p"k5hhv6*`


dzięki temu logujemy się za pomocą:
`username: chintu`
`password: e6~n22k81<[p"k5hhv6*`

i dostajemy flagę.
