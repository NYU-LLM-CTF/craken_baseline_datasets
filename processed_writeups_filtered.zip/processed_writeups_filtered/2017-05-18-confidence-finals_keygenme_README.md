# keygenme (re, 400p)

this challenge took me a lot of time, but it was worth it (both because it was fun, and because it was worth a lot of points). it was created by redford (personally i'm fan of his challenges, but of course ymmv).

so we had a binary with simple key checking. entered key was simply treated as number in base36, and converted to usual base 256 (bytes). after that, we saw a big handcrafted assembly function.

it was one of the rare cases when assembly code was **much** more readable than hexrays decompiler results, so we sticked to asm (refreshing!). i added a lot of comments to assembly, resulting with [rawasm.asm](rawasm.asm).

reversing this step was fun, but rather easy (but quite time consuming). for example:

```asm
  ;; cf = shl([ggg; hhh])
shl     dword ptr [edi], 1
rcl     dword ptr [edi+4], 1
rcl     dword ptr [edi+8], 1
rcl     dword ptr [edi+0ch], 1
rcl     dword ptr [edi+10h], 1
rcl     dword ptr [edi+14h], 1
rcl     dword ptr [edi+18h], 1
rcl     dword ptr [edi+1ch], 1
```

as comment says, this all instructions is simple shl of two concatenated registers.

another popular operation was of course zeroing 128bit int:


```asm
  ;; [eee] = 0
mov     edx, [ebp+mag_consts]
xor     eax, eax
mov     [esi], eax
mov     [esi+4], eax
mov     [esi+8], eax
mov     [esi+0ch], eax
```

and adding them:


```asm
  ;; [ggg; hhh] += [0; ddd]
mov     eax, [edx]
add     [edi], eax
mov     eax, [edx+4]
adc     [edi+4], eax
mov     eax, [edx+8]
adc     [edi+8], eax
mov     eax, [edx+0ch]
adc     [edi+0ch], eax
adc     dword ptr [edi+10h], 0
adc     dword ptr [edi+14h], 0
adc     dword ptr [edi+18h], 0
adc     dword ptr [edi+1ch], 0
```

and maybe assignment:

```asm
  ;; [ggg] = [ddd]
mov     eax, [esi]
mov     [edi+10h], eax
mov     eax, [esi+4]
mov     [edi+14h], eax
mov     eax, [esi+8]
mov     [edi+18h], eax
mov     eax, [esi+0ch]
mov     [edi+1ch], eax
```

and maybe comparsion:

```asm
  ;; cf = [ddd] < [*mag]
mov     eax, [esi]
sub     eax, [edx]
mov     eax, [esi+4]
sbb     eax, [edx+4]
mov     eax, [esi+8]
sbb     eax, [edx+8]
mov     eax, [esi+0ch]
sbb     eax, [edx+0ch]

  ;; if cf goto loc_f41247
jb      short loc_f41247
```

(proving that these are really equivalent is of course left as an exercise to reader)

after finishing with adding all that comments, i executed:

```
cat rawasm.asm  | grep ";;" | cut -c 6-
```

and get quite readable pseudo-asm code (where most instructions was performed on 128bit integers). it looked like this:


```
[bbb] == [arg]
loc_f4102f:
[ddd] = [bbb]
[eee] = 0
[fff] = [mag[1]]
loc_f41081:
zf = test [fff] & 1
if zf goto loc_f4116a
[hhh] = 0
[ggg] = [eee]
 ecx = 0x80
loc_f410bd:
cf = shl([ggg; hhh])
if not cf goto loc_f410fc
 [ggg; hhh] += [0; ddd]
loc_f410fc:
loop loc_f410bd
[eee] = 0
 ecx = 0x100
loc_f41116:
 cf = shl [eee; ggg; hhh]
if cf goto      loc_f41152
cf = carry [eee] - [*mag]
if cf goto loc_f41168
loc_f41152;
[eee] -= [*mag]
loc_f41168
loop    loc_f41116
loc_f4116a:
[hhh] = 0
[ggg] = [ddd]
ecx = 0x80
loc_f4119c:
cf = shl [ggg; hhh]
if not cf goto loc_f411db
[ggg; hhh] += [0; ddd]
loc_f411db
loop    loc_f4119c
[ddd] = 0
ecx = 0x100
loc_f411f5:
cf = shl [ddd; ggg; hhh]
if cf goto loc_f41231
cf = [ddd] - [*mag]
if cf goto loc_f41247
loc_f41231
[ddd] -= [*mag]
loc_f41247:
loop loc_f411f5
shr [fff]
zf = [fff] == 0
if not zf goto loc_f41081
[bbb] = [eee]
mag++
cf = mag < drg
if cf goto loc_f4102f
[aaa] = 0
[aaa; bbb] += 0x31337
[ccc] = 0
ecx = 0x100
loc_f412e9:
cf = shl [ccc; aaa; bbb]
if cf goto loc_f41325
cf = [ccc] - [drg]
if cf goto loc_f4133b
loc_f41325:
[ccc] -= [drg]
loc_f4133b:
loop    loc_f412e9
return [ccc] == 0
```

this may not look really pretty, but in fact we are only 5-10 minutes from getting quite readable code. when we change gotos to structural loops, we end up with this reasonable piece of pseudocode:

```
[bbb] == [arg]

for mag, mmm in consts:
    [ddd] = [bbb]
    [eee] = 0
    [fff] = [mmm]

    while [fff] != 0:
        if [fff] & 1:
            [hhh] = 0
            [ggg] = [eee]
            for ecx in range(0x80):
                cf = shl([ggg; hhh])
                if cf:
                    continue
                [ggg; hhh] += [0; ddd]

            [eee] = 0
            for ecx in range(0x100):
                cf = shl [eee; ggg; hhh]
                if not cf:
                    if [eee] < [mag]:
                        continue
                [eee] -= [mag]

        [hhh] = 0
        [ggg] = [ddd]
        for ecx in range(0x80):
            cf = shl [ggg; hhh]
            if cf:
                continue
            [ggg; hhh] += [0; ddd]

        [ddd] = 0
        for ecx in range(0x100):
            cf = shl [ddd; ggg; hhh]
            if not cf:
                if [ddd] < [mag]:
                    continue
            [ddd] -= [mag]

        shr [fff]

    [bbb] = [eee]

[aaa] = 0
[aaa; bbb] += 0x31337
[ccc] = 0

for ecx in range(0x100):
    cf = shl [ccc; aaa; bbb]
    if not cf:
        if [ccc] < [drg]:
            continue
    [ccc] -= [drg]

return [ccc] == 0
```

but this is not over yet. we can see that few pieces of code are repeating themselves. for example:

```
for ecx in range(0x100):
    cf = shl [ccc; aaa; bbb]
    if not cf:
        if [ccc] < [drg]:
            continue
    [ccc] -= [drg]
```

haven't i seen this one before? hmm... wait, this is just binary long division (throwing away quotient, so in fact it's modulo).

and this one:?

```
[hhh] = 0
[ggg] = [ddd]
for ecx in range(0x80):
    cf = shl [ggg; hhh]
    if cf:
        continue
    [ggg; hhh] += [0; ddd]
```

hmm, adding, dividing/multiplying by 2 and checking outermost bit. almost like multiplication? in fact, exactly like binary multiplication.

after recognising all those idioms, i ended up with this:

```
[bbb] == [arg]

for mag, mmm in consts:
    [ddd] = [bbb]
    [eee] = 0
    [fff] = [mmm]

    while [fff] != 0:
        if [fff] & 1:
            [eee] = ([ddd] * [eee]) % [mag]
        [ddd] = ([ddd] * ddd]) % [mag]

        shr [fff]

    [bbb] = [eee]

[aaa; bbb] = [0; bbb] + 0x31337
return [aaa; bbb] % drg == 0
```

so pretty! but wait, squaring and multiplying in loop? we have a name for that - `square and multiply`, fast exponentation algorithm. so... everything reduced to this in the end:

```
for mag, mmm in consts:
    print b, mmm, mag
    b = pow(b, mmm, mag)
assert (b + 0x31337) % drgns == 0
```

reversing it should be easy enough, right? well, not for me - i wasted around 40 minutes, because at first i forgot that `-1` inside modinv. but leaving small mishappens aside, this code finally worked:

```
def get_for(b):
    for mag, mmm in consts[::-1]:
        b1 = pow(b, modinv(mmm, mag-1), mag)
        if pow(b1, mmm, mag) != b:
            return
        b = b1
    return b
```

and after few tries gave us the key:

```
base = -0x31337
while true:
    base += drgns
    b = get_for(base)
    if b:
        print dump128(b).encode('hex')
        print int2base(b, 36)
        break
```

one of valid serial keys was
`2s6je-l492k-m8ii0-knu1m-xaxdv`

this re challenge was really interesting, because you were supposed to "go up" from meaningless operations on bits to higher understanding of what's going on, connecting smaller abstraction into bigger ones, finally ending up with 3 loc python script.
