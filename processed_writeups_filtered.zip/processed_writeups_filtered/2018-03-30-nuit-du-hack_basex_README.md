# basex, 300p, exploit

> basex stores datas from stdin into a buffer.

the binary was allowing us to write arbitrary data to arbitrary offset from
stack (simple buffer overflow). a complication was that we had no echo, which
made debugging the exploit harder. in the end, we rop-ped to gadgets, overwriting
`fread` got entry to `system`'s, then jumped there with crafted command string.
