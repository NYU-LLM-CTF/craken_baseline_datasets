# hevc (misc, 50pts, 217 solves)
	welcome to the future.

this task was pretty simple if you notice its title. it turns out `hevc` is the name
of a pretty new video file format. with some googling, i was able to find
command converting it to other, more standard ones:
```
ffmpeg -i out.raw asd.avi
```
the video turns out to contain hand-written flag.
