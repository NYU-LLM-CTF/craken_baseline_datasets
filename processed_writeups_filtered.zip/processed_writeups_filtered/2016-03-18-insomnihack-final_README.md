# writeup insomnihack ctf final 2016

team: mak, lympho, akrasuski1, msm, nazywam, other019, rev, shalom

### table of contents

* [smartcat0 (web)](web_smartcat0)
* secretsafe (web)
* [smartcat3 (web)](web_smartcat3)
* [robots (misc)](misc_robots)
* smartdoor (misc)
* greenbox (web)
* idea1 (web)
* idea2 (web)
* superpollute (shellcode)
* biotch (pwn)
* microwave (pwn)

