## rail fence cipher (crypto, 50p)

    decrypt and find the flag.

    aay--rpyfnejbeaax0n-,zzcs-uxeesvj-sh2tioaz}slrg,-cie-anfgt.-eciyss-tzprttfliora{gcouhqiadctm0ltt-fyluueztyorz-

###eng
[pl](#pl-version)

the name of this task was everything we needed to know to solve it. using
[this site](http://rumkin.com/tools/cipher/railfence.php) and trying all the possible keys (21 was the correct one), we
get the correct plaintext:
```
a-fence-is-a-structure-that-encloses-an-area,-sharifctf{qmfzzty0iglzigegz2vuzxjpyyb0zxjt},-typically-outdoors.
```

###pl version

nazwa tego zadania wystarczyła do zgadnięcia, o jaki szyfr tu chodzi. używając
[tej strony](http://rumkin.com/tools/cipher/railfence.php) i próbując wszystkich możliwych kluczy (21 to ten prawdziwy),
dostajemy poprawny tekst:
```
a-fence-is-a-structure-that-encloses-an-area,-sharifctf{qmfzzty0iglzigegz2vuzxjpyyb0zxjt},-typically-outdoors.
```
