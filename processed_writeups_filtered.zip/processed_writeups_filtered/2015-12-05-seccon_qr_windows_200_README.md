## qr puzzle (unknown, 200p)

    please solve a puzzle 300 times
    qrpuzzle.zip

###pl
[eng](#eng-version)

dostajemy program, który wyświetla poszatkowane qr cody po uruchomieniu:


[image extracted text: qrpuzzle for seccon 2015 (by keigoyamazaki)
ifi
answer:]


dość oczywisty jest cel zadania - należy napisać program który złoży taki qr code, rozwiąże go, oraz wyśle do programu.
moglibyśmy próbować go reversować, ale to wyraźnie co innego niż autorzy zadania zaplanowali dla nas, więc nie poszliśmy tą drogą.

napisaliśmy w tym celu pewien bardzo duży solver, który:
 - robił screena programu
 - wyciągał z niego poszczególne fragmenty
 - składał części w jedną (najtrudniejsza część oczywiśćie)
 - dekodował wynikowy qr code
 - wysyłał zdekodowany tekst do aplikacji
 - czekał 500 ms i powtarzał ten cykl.

kodu jest za dużo by omawiać go funkcja po funkcji, wklejona zostanie jedynie główna funkcja pokazująca te kroki ([pełen kod](form1.cs)]:

```csharp
while (true)
{
    using (var bmp = captureapplication("qrpuzzle"))
    {
        var chunks = split(
            18, 77,
            160, 167,
            6, 13,
            3,
            bmp);
        var result = bundle.reconstruct(chunks, 3);

        var reader = new barcodereader { possibleformats = new[] { barcodeformat.qr_code }, tryharder = true };

        result.save("test2.png");
        var code = reader.decode(result);

        sendkeys.send(code.text);
        thread.sleep(500);
    }
}
```

flaga:

    seccon{402b00f89dc8}



### eng version

we get a program that displays scrambled qr codes when run:


[image extracted text: qrpuzzle for seccon 2015 (by keigoyamazaki)
ifi
answer:]


it's obvious what task authors want from us - we have to write program that unscrambles given qr code and sends it to program.
of course we could try to reverse engineer given program, but clearly task authors wanted us to solve challenge different way.

we have written large solver, that:
 - captured program window to bitmap
 - cut all 9 qr code fragments to different bitmaps
 - put fragments in correct order (hardest part, by far)
 - decoded resulting qr code
 - sent decoded text to program
 - slept 500 ms and repeated that cycle

solver code is too large to be described function by function, so we will just paste main function here ([full code](form1.cs)):

```csharp
while (true)
{
    using (var bmp = captureapplication("qrpuzzle"))
    {
        var chunks = split(
            18, 77,
            160, 167,
            6, 13,
            3,
            bmp);
        var result = bundle.reconstruct(chunks, 3);

        var reader = new barcodereader { possibleformats = new[] { barcodeformat.qr_code }, tryharder = true };

        result.save("test2.png");
        var code = reader.decode(result);

        sendkeys.send(code.text);
        thread.sleep(500);
    }
}
```

flag:

    seccon{402b00f89dc8}
