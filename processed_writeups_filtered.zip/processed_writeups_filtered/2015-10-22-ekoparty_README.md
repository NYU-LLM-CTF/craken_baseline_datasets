# writeup ekoparty ctf 2015

uczestniczyliśmy (msm, rev, shalom, other019, nazywam i pp) w ekoparty ctf, i znowu spróbujemy opisać zadania z którymi walczyliśmy (a przynajmniej te, które pokonaliśmy).

ogólne wrażenia:

opisy zadań po kolei.

# spis treści/table of contents:

* slogans (trivia 50)
* banner (trivia 70)
* mr anderson (trivia 80)
* ssl attack (trivia 90)
* pass check (web 50)
* crazy json (web 200)
* rand doom (web 300)
* scytcrypto (crypto 50)
* [xor crypter (crypto 200)](crpto_200_xorcrypter)
* patch me (reverse 50)
* malware (reverse 200)
* olive (misc 50)


# zakończenie

zachęcamy do komentarzy/pytań/czegokolwiek.
