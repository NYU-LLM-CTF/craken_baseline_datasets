# hitcon 2017 quals

team: nazywam, ppr, msm, c7f.m0d3, akrasuski1, rev, shalom

### table of contents

* [secret server (crypto)](secret_server)
* [data & mining (forensics)](data_mining)
