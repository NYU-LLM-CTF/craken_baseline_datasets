# riskv and reward (reversing, 80p)

> open-source all the things!!!

we solved this task in a fun way. running `file` command on the supplied binary informed us that it's an elf for
risc-v architecture. we couldn't run it directly on our computer and installing an emulator was annoying (it didn't work
for some reason). so, we solved it in a blackbox way!

running `strings -n 20 riskv_and_reward` gave us only one string: 
```
tjb3csft0rrutrh_wiv5__fi}k_1ih`{xicrhsoybmyw1cyt3rvxstt_jq40_zrq(
```

although it seems quite messed up, we quickly noticed it has some resemblance to the flag format: it has two curly braces,
and all the capital letters from `bitsctf`. it seems it was permutated in some way. so, the only thing left to do was 
reversing the permutation. running `hexdump` on the binary, we found an interesting part right after the aforementioned
string:
```
00001080  28 00 00 00 21 00 00 00  2f 00 00 00 34 00 00 00  |(...!.../...4...|
00001090  2d 00 00 00 36 00 00 00  06 00 00 00 1f 00 00 00  |-...6...........|
000010a0  25 00 00 00 3b 00 00 00  29 00 00 00 03 00 00 00  |%...;...).......|
000010b0  37 00 00 00 3e 00 00 00  1b 00 00 00 05 00 00 00  |7...>...........|
000010c0  22 00 00 00 13 00 00 00  14 00 00 00 3a 00 00 00  |"...........:...|
000010d0  31 00 00 00 30 00 00 00  1a 00 00 00 10 00 00 00  |1...0...........|
000010e0  08 00 00 00 23 00 00 00  07 00 00 00 24 00 00 00  |....#.......$...|
000010f0  3c 00 00 00 2c 00 00 00  00 00 00 00 18 00 00 00  |<...,...........|
00001100  43 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |c...............|
```
we noticed every number appears just once, so this was probably a transposition table. from now on, we had to just write a 
simple script to apply the permutation to get the flag.
