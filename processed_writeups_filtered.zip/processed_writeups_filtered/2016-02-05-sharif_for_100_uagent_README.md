## uagent (forensics, 100p)

	we think we are really cool, are we?
[download](ragent.pcap)

###eng
[pl](#pl-version)

we start off with a pcap file, a file is begin downladed throughout some packets, let's export them by filtering them out and using file->export objects->http


[image extracted text: ragent pcap
[wireshark 1.8.4 (svn m
46250 from
trunk-1.8)]
edit
jiew
capture
analyze
statistics
telephony
iools
internals
help
@
8
4
6
filter:
http && ip.src
23.44.194.176
expression.
clear
apply
save
new column
itime
fsource
pdestination
protocol
length
info
uquua
44.194.176
213.233.186_
unknown
ox5o)
23.44.194.176
213.233.186_
368 unknown
oxd8_
wireshark: http object list
23.44.194 _
176
213.233.186_
365 unknown
23.44.194 _
176
213.233.186_
367
unknown
ox14_
ppacket numhhostname
content type
bbytes-filename
23.44.194 _
176
213.233.186_
345 unknown
(oxb6)
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
23.44.194 _
176
213.233.186_
353
connect
185,82.202.241 applicationloctet-stream 26
nrixqtvotfvyxkazbafz
23.44.194 _
176
213.233.186_
359
unknown
185,82.202.241
applicationloctet-stream 23
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
354 unknown
185,82.202.241 applicationloctet-stream 25
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
357
unknown
44.194 _
176
213.233.186_
366
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
373 keepa
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
349
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
362
unknown
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
142
44.194 _
176
213.233.186_
371
unknown
152
44.194 _
176
213.233.186_
351
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
360
unknown
185,82.202.241 applicationloctet-stream 22
nrixqtvotfvyxkazbafz
173
44.194 _
176
213.233.186_
355
unknown
185,82.202.241
applicationloctet-stream 29
nrixqtvotfvyxkazbafz
183
44.194 _
176
213.233.186_
355
unknown
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
372
unknown
103
44.194 _
176
213.233.186_
363
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
372
unknown
185,82.202.241 applicationloctet-stream 27
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
354
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
@
44.194 _
176
213.233.186_
371
unknown
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
44.194 _
176
213.233.186_
374
unknown
44.194 _
176
213.233.186_
371
unknown
185,82.202.241
applicationloctet-stream
nrixqtvotfvyxkazbafz
272
44.194 _
176
213.233.186_
356
unknown
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
282
44.194 _
176
213.233.186_
350
unknown
185,82.202.241
applicationloctet-stream 28
nrixqtvotfvyxkazbafz
292
44.194 _
176
213.233.186_
372
unknown
203
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
301
44.194 _
176
213.233.186_
357
unknown
313
44.194 _
176
213.233.186_
350
unknown
213
185,82.202.241 applicationloctet-stream 28
nrixqtvotfvyxkazbafz
323
44.194 _
176
213.233.186_
360
unknown
228
185,82.202.241 applicationloctet-stream
nrixqtvotfvyxkazbafz
333
23.44.194_
176
213.233.186_
348
unknown
241
185,82.202.241 applicationloctet-stream 27
nrixqtvotfvyxkazbafz
343
23.44.194_
176
213.233.186_
352 unknown
252
185,82.202.241 applicationloctet-stream 30
nrixqtvotfvyxkazbafz
352
23.44.194.176
213.233.186_
http _
370 unknown
0a
363
21258
23.44.194.176
213.233.186_
http _
365 unknown
374
0.215088
23.44.194.176
213.233.186.49
http _
375 unknown (ox84_
help
save as
save ali
cancel
frame
2074:
350
bytes
on wire
(2800 bits) ,
350 bytes
captured
(2800
bits)
ethernet
src: 4:se:oc:e8
6e:47
(4c:se:oc:e8
6e:47) ,
dst:
apple_ld:8a:a5
(c4:2:03:id:8a:a5)
internet
protoco]
version
src:
194.176
(23.44.194.176) _
dst:
213.233.186.49
(213.233.186.49)
tr ansmiss-
control
protoco]
src
port
http
(80) _
dst
port:
55217
(55217) _
seq:
1, ack:
268
len:
284
ng: . e
ej
:
78 2d
30 36
8 58
31i  2088
cit
c: sers michal desktop projektykctfi 201.
packets: 3144 displayed: 308 marked:
load time: 0;00.103
profile: default
rev
xii]


the packets are generally okay, though we need to delete the first byte from every (except first packet), (the content-ranges mesh with each other with 1 byte) and there are some unnecessary packets at the end. 

we solve the first problem with a quick script in bash:

```bash
for file in `ls extractedfiles` done
	tail -c +2 $file > ../output/$file;
done
```

the only thing that's left is merging the files together, we simply do that with `cat * > out`

we're left with a password-protected zip that has out flag.png in it.

another interesting thing is that requests for the zip are made with an interesting user-agent:


[image extracted text: frame 14:
329
bytes
on wire
(2632 bits)
329
bytes
captured
(2632
bits)
ethernet
src:
apple_id: 8a:a5
(c4:2c:03:id:8a:a5)
dst:
4c:se:oc:e8:6e:47
(4c:se:oc:e8:6e:47)
internet
protoco]
version
src:
213.233.186.49
(213.233.186.49).
dst: 23.44.194.176 (23.44
194.176)
tr ansmission
contro
protoco| .
src
port:
55019
(55019) ,
dst
port:
nttp
(80) ,
seq:
ack:
len:
263
hyper-
ext
tr ansfer
protoco
get
nrixqtvotfvyxkazbafz
http /1.11rin
host:
185.82
202.241lrin
accept-
encoding:
gzip,
deftatelrin
x-powered-by:
shar if
ctf |rin
connect
on:
keep-alivelrin
accept
user_
ent: sctf
app
chokaaaadu [ irfiaaagcaa,
trin
dnt : irin
range: bytes-15-4olrln
date:
mon
dec
21 18:00:29
20151rin
irin
[4ll
equest
uri:
http: l/185
82,202,241/nrixgtvotfvyxkazbafzl]


we extract the packets using the same techinque as in the first step and are left with a file of base64 encoded strings(be careful to ignore retransmissed packets)

finally, by writing our own script (or just using an online tool like [this one](http://www.motobit.com/util/base64-decoder-encoder.asp)) we convert our strings to an image:


[image extracted text: the password of archive file is: yathv9pyxgbeknpzy7ri]


using it to open the encrypted zip we get:


[image extracted text: ]


there you go!

bonus pic, guessing the flag was not a fun part of the challange:


[image extracted text: jl
ccmt (0
jfoq
fz df % @f 6
j9g 1xx4 f73843883
a
8bkpd,
r]





###pl version

