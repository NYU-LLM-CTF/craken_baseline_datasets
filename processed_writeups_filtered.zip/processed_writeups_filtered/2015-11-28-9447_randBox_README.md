##randbox (crypto, 120p)

###pl
[eng](#eng-version)

`nc randbox-iw8w3ae3.9447.plumbing 9447`

```
alphabet is '0123456789abcdef', max len is 64
you need to send a string that encrypts to '787fadc8d1944a35b3ed9d1433a9060f'
guess 0/21 (round 1/10)
```

zadanie polegało na połączeniu się z serwerem a następnie na złamaniu 10 szyfrów (w praktyce tylko 7 było unikalnych), przy użyciu nie więcej niż 21 prób.
złamanie każdego szyfru należało udowodnić poprzez wysłanie wiadomości, która po zakodowaniu da wylosowany przez serwer ciąg znaków.
kod całego rozwiązania znajduje sie [tutaj](randbox.py) a sesja rozwiązująca [tutaj](session.txt)

####szyfr 1

pierwszy szyfr to standardowy szyfr cezara, więc do jego złamania potrzeba nam informacji o `przesunięciu`. uzyskujemy ją, poprzez wysłanie na serwer pojedyńczego znaku `0`.

```python
def breaklevel1(ct, s):
    # caesar cipher
    send_via_nc(s, "0")
    data = s.recv(1024)[:-1]
    shift = int(data, 16)
    result = "".join([format((int(letter, 16) - shift) % 16, "x") for letter in ct])
    send_via_nc(s, result)
```

####szyfr 2

drugi szyfr to cykliczne przesunięcie wejściowego ciągu o losową liczbę pozycji, zależną od długości wejścia, więc do jego złamania potrzebujemy informacji o tym o ile pozycji nastąpi przeunięcie. informacje uzyskujemy poprzez wysłanie ciągu `0` oraz jednej `1` (o długości takiej jak oczekiwany ciphertext) a następnie policzenie o ile została przesunięta `1`.

```python
def breaklevel2(ct, s):
    # circular shifting input by some random number
    send_via_nc(s, "1" + ("0" * (len(ct) - 1)))
    data = s.recv(1024)[:-1]
    shift = data.index("1")
    result = ct[shift:] + ct[:shift]
    send_via_nc(s, result)
```

####szyfr 3,4,5

szyfry 3,4,5 to szyfry podstawieniowe i do ich złamania potrzebujemy pobrać z serwera informacje o tym, jak wygląda tablica zamian. robimy to poprzez wysłanie całego alfabetu i odczytanie jak zostały zamienione znaki.

```python
def breaklevel3(ct, s):
    # substitution cipher
    initial = "0123456789abcdef"
    send_via_nc(s, initial)
    data = s.recv(1024)[:-1]
    decoder = {data[i]: initial[i] for i in range(len(initial))}
    result = "".join([decoder[letter] for letter in ct])
    send_via_nc(s, result)
```

####szyfr 6

szyfr 6 przypomina szyfr cezara, ale przesunięcie jest liczone per znak a nie dla całego ciągu identycznie. więc np. pierwszy znak tekstu jest przesunięty o x, drugi o y, trzeci o z. przesunięcia uzyskujemy wysyłając ciąg 0 o długości ciphertextu i z niego odczytujemy przesuniecia dla każdej pozycji.

```python
def breaklevel6(ct, s):
    # shifting each number by some distance
    initial = "0" * len(ct)
    send_via_nc(s, initial)
    data = s.recv(1024)[:-1]
    shifts = [int(data[i], 16) for i in range(len(ct))]
    result = "".join([format((int(ct[i], 16) - shifts[i]) % 16, "x") for i in range(len(ct))])
    send_via_nc(s, result)
```

####szyfr 7

szyfr 7 został przez nas zwyczajnie zbrutowany, bo nie mieliśmy pomysłu na regułę. szyfr wyliczał kolejny element ciphertextu na podstawie dwóch poprzednich elementów plaintextu (z losowym elementem na pozycji -1), w większości sytuacji poprzez ich dodanie/odjęcie. niemniej zasada kiedy odejmować a kiedy dodawać nie była dla nas oczywista, więc wysłaliśmy do serwera zapytania postaci `000102030405...`, `10111213141516...`, `20212223242526...` i na podstawie wyników odczytaliśmy mapę wszystkich możliwych podstawień - tzn. dla każdej `poprzedniej` liczby wiedzieliśmy na co zostanie zamieniony każdy symbol. jedyna brakująca informacja to wartość losowa na pozycji -1 która jest wykorzystywana aby wyliczyć 1 znak ciphertextu. odzyskujemy ją poprzez wysłanie `0` a potem odczytanie na podstawie wyniku dla jakiego `poprzednika` mogliśmy uzyskać taki wynik.

```python
    initial = "0"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    current_number = find_start_number(cracking_map, data)
    result = ""
    for letter in ct:
        generator = find_generator(cracking_map, current_number, letter)
        result += generator
        current_number = generator
    send_via_nc(s, result)
```

####szyfr 8

szyfr 8 polegał na sumowaniu poprzednich wyrazów modulo 16, z losową wartością na pozycji -1. losową wartość odzyskujemy wysyłając 0 a następnie odczytując ją bezpośrednio z wyniku. następnie kodujemy dane licząc jakiej wartości `brakuje` nam aby uzyskać spodziewany znak ciphertextu po dodaniu jej do poprzedniej modulo 16.

```python
def breaklevel8(ct, s):
    # adding current number to previous modulo 16
    initial = "0"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    previous = int(data, 16)
    result = ""
    for number in ct:
        current = int(number, 16)
        missing = (current - previous) % 16
        result += format(missing, "x")
        previous = current
    send_via_nc(s, result)
```

####szyfr 9

szyfr 9 byl szyfrem podstawieniowym ze zmianą kolejności bajtów w słowie. jeśli np. x kodowany był przez 1 a y przez 0 to zakodowanie xy dawało 01. aby odczytać mapę podstawień wysyłaliśmy cały alfabet a następnie odczytywaliśmy podstawienia zamieniając pary miejscami.

```python
def breaklevel9(ct, s):
    # substitution with byte swap, x->1, y->2, xy -> 21
    initial = "0123456789abcdef"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    substitution = {}
    for i in range(0, len(initial) - 1, 2):
        substitution[initial[i + 1]] = data[i]
        substitution[initial[i]] = data[i + 1]
    result = ""
    for i in range(0, len(ct) - 1, 2):
        first = ct[i]
        second = ct[i + 1]
        result += substitution[second] + substitution[first]
    send_via_nc(s, result)
```

w trakcie trwania konkursu kolejność szyfrów w zadaniu uległa przemieszaniu a niektóre szyfry były użyte kilkukrotnie stąd unikalnych szyfrów jest tylko 7 a nie 10.

```
you need to send a string that encrypts to 'd689c1a78e419dc1043ff07a0afc01d8'
guess 18/21 (round 10/10)

ciphertext = d689c1a78e419dc1043ff07a0afc01d8
sending 0
sending 17f6ab16e045c1dcc8b4bbc66c3ffe3b
guess 19/21 (round 10/10)
d689c1a78e419dc1043ff07a0afc01d8
you got it!
9447{crypt0_m4y_n0t_be_s0_hard}
```
	
### eng version

`nc randbox-iw8w3ae3.9447.plumbing 9447`

```
alphabet is '0123456789abcdef', max len is 64
you need to send a string that encrypts to '787fadc8d1944a35b3ed9d1433a9060f'
guess 0/21 (round 1/10)
```

the task was to connect with the server and break 10 ciphers (in fact only 7 were unique), using no more than 21 tries.
breaking each cipher was proven by sending a message that would encode to the ciphertext selected by server.
whole solution is [here](randbox.py) and winning session [here](session.txt)

####cipher 1

first cipher was a standard caesar cipher, so we need only the information about the `shift`. we get is by sending a single `0` to the server and we get shift as an answer.

```python
def breaklevel1(ct, s):
    # caesar cipher
    send_via_nc(s, "0")
    data = s.recv(1024)[:-1]
    shift = int(data, 16)
    result = "".join([format((int(letter, 16) - shift) % 16, "x") for letter in ct])
    send_via_nc(s, result)
```

####cipher 2

second cipher was a cyclic shift of the input by a random number of positions, dependent on the length of input, so to break it we need to know how many places will the shift be. we get this by sending data with all `0` and a single `1` (with length the same as expected output ciphertext) and the couting how many places the `1` has moved.

```python
def breaklevel2(ct, s):
    # circular shifting input by some random number
    send_via_nc(s, "1" + ("0" * (len(ct) - 1)))
    data = s.recv(1024)[:-1]
    shift = data.index("1")
    result = ct[shift:] + ct[:shift]
    send_via_nc(s, result)
```

####cipher 3,4,5

ciphers 3,4,5 were all substitution ciphers and to break them we need to get the substitution table from the server. we do this by sending whole alphabet and reading how each character changed.

```python
def breaklevel3(ct, s):
    # substitution cipher
    initial = "0123456789abcdef"
    send_via_nc(s, initial)
    data = s.recv(1024)[:-1]
    decoder = {data[i]: initial[i] for i in range(len(initial))}
    result = "".join([decoder[letter] for letter in ct])
    send_via_nc(s, result)
```

####cipher 6

cipher 6 is similar to caesar cipher but the shifts are per position in the plaintext rather than constant for whole text. for example first character is shifted by x, second by y etc. to get the shifts information we send data with `0` (the same length as expected ciphertext) and we read the shifts on each position directly.

```python
def breaklevel6(ct, s):
    # shifting each number by some distance
    initial = "0" * len(ct)
    send_via_nc(s, initial)
    data = s.recv(1024)[:-1]
    shifts = [int(data[i], 16) for i in range(len(ct))]
    result = "".join([format((int(ct[i], 16) - shifts[i]) % 16, "x") for i in range(len(ct))])
    send_via_nc(s, result)
```

####cipher 7

cipher 7 was simply brute-forced by us, because we couldn't figure out the rule. the cipher was calculating next ciphertext element by last two plaintext elements (with random value at position -1), for the most part this was either by adding or subtracting them. however, we couldn't figure out when to add and when to subtract so we simply extracted this from server.
we sent requests `000102030405...`, `10111213141516...`, `20212223242526...` and from answers we created a substitution table - for each `previous` value, for each `current` value we knew what will be the ciphertext element. the only missing part was the random value at position -1, which we got by sending `0` and checking which `previous` value would give us the result we got.

```python
    initial = "0"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    current_number = find_start_number(cracking_map, data)
    result = ""
    for letter in ct:
        generator = find_generator(cracking_map, current_number, letter)
        result += generator
        current_number = generator
    send_via_nc(s, result)
```

####cipher 8

cipher 8 was adding all previous values of plaintext modulo 16, with random value at position -1. the random value we extract by sendind `0` and taking them directly from result. for the solution we simply encode data, couting how much we are `missing` to get the proper ciphertext value.

```python
def breaklevel8(ct, s):
    # adding current number to previous modulo 16
    initial = "0"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    previous = int(data, 16)
    result = ""
    for number in ct:
        current = int(number, 16)
        missing = (current - previous) % 16
        result += format(missing, "x")
        previous = current
    send_via_nc(s, result)
```

####cipher 9

cipher 9 was a substitution cipher with shifting bytes in two-byte words. if x was encoded by 1 and y by 0 then xy would give 01. to get the substitution map we sent whole alphabet and read the substitutions by shifting bytes in pairs.

```python
def breaklevel9(ct, s):
    # substitution with byte swap, x->1, y->2, xy -> 21
    initial = "0123456789abcdef"
    send_via_nc(s, initial)
    data = s.recv(1024)
    data = data[:data.index("\n")]
    substitution = {}
    for i in range(0, len(initial) - 1, 2):
        substitution[initial[i + 1]] = data[i]
        substitution[initial[i]] = data[i + 1]
    result = ""
    for i in range(0, len(ct) - 1, 2):
        first = ct[i]
        second = ct[i + 1]
        result += substitution[second] + substitution[first]
    send_via_nc(s, result)
```

during the competition the ordering of ciphers was changed and some ciphers were used multiple times, hence there were only 7 unique ciphers, not 10.

```
you need to send a string that encrypts to 'd689c1a78e419dc1043ff07a0afc01d8'
guess 18/21 (round 10/10)

ciphertext = d689c1a78e419dc1043ff07a0afc01d8
sending 0
sending 17f6ab16e045c1dcc8b4bbc66c3ffe3b
guess 19/21 (round 10/10)
d689c1a78e419dc1043ff07a0afc01d8
you got it!
9447{crypt0_m4y_n0t_be_s0_hard}
```