﻿## reverse 400 (re, 400p)

### pl
[eng](#eng-version)

najtrudniejsze zadanie z re na tym ctfie. dostajemy [program](./r400) (znowu elf), który pobiera od usera hasło. domyślamy się że to hasło jest flagą.

tutaj niespodzianka, bo hasło nie jest sprawdzane nigdzie w programie. po chwili grzebania/debugowania, okazuje się, że hasło jest zamieniane na dword (cztery znaki) i pewna tablica bajtów jest "deszyfrowana" (tzn. xorowana) z nim, a następnie wykonywana. xorowane dane wyglądają tak:

    5e 68 0e 59 46 06 47 5e 55 11 15 41 5c 0a 03 16
    44 0a 08 52 14 16 0e 16 52 0d 13 5e 14 3b 09 43
    5c 0d 08 45 15 0a 0a 57 40 0b 0e 44 55 16 13 5e
    77 0d 08 51 8e 48 66 36 34 eb 87 8d 35 62 66 36
    8c 66 66 36 34 af e6 8e 35 62 66 36 f9 e2 f6 a6

pierwsze próby zgadnięcia hasła nie udały się (myśleliśmy że może ten fragment to funkcja, i zacznie się jakimś klasycznym prologiem). ale szybko wpadliśmy na lepszy pomysł. otóż jaki jest najczęściej spotykany bajt w kodzie? oczywiście zero. więc jeśli znajdziemy najczęściej występujący bajt w zaszyfrowanym fragmencie, będziemy wiedzieli że prawdopodobnie były to oryginalnie zera. kod wyszukujący najczęstsze bajty:

    source = '5e680e594606475e551115415c0a0316440a085214160e16520d135e143b09435c0d0845150a0a57400b0e445516135e770d08518e48663634eb878d356266368c66663634afe68e35626636f9e2f6a6'.decode('hex')
    prologue = '554889e5'.decode('hex')

    def xor(a, b):
        return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

    print xor(source, prologue).encode('hex')

    a0 = source[0::4]
    a1 = source[1::4]
    a2 = source[2::4]
    a3 = source[3::4]

    def most_common(x):
        import collections
        s = collections.counter(x).most_common(1)[0]
        return (s[0].encode('hex'), s[1])

    print most_common(a0),
    print most_common(a1),
    print most_common(a2),
    print most_common(a3),

okazało się to być strzałem w dziesiątkę! (jeśli dobrze pamiętamy, jeden z czterech fragmentów źle trafił, ale udało się to już ręcznie poprawić trywialnie).

w ten sposób rozwiązaliśmy najtrudniejsze zadanie re na ctfie i zdobyliśmy kolejną flagę, wartą 400 punktów.

### eng version

the most difficult re task on this ctf. we get a [binary](./r400) (elf again) which takes password as input. we expect the password to be the flag.

here we have a surprise, because the password is not checked anywhere in the binary. after a while of debugging we realise that the password is casted into a dword (four characters) and a byte table is decoded (via xor) with this dword and the executed as code. the xored data are:

    5e 68 0e 59 46 06 47 5e 55 11 15 41 5c 0a 03 16
    44 0a 08 52 14 16 0e 16 52 0d 13 5e 14 3b 09 43
    5c 0d 08 45 15 0a 0a 57 40 0b 0e 44 55 16 13 5e
    77 0d 08 51 8e 48 66 36 34 eb 87 8d 35 62 66 36
    8c 66 66 36 34 af e6 8e 35 62 66 36 f9 e2 f6 a6

first attempts to get the password failed (we assumed this code block is a function nad has some standard prolog). soon we got a better idea. what is the most common byte value in the code? zero of course. so if we find the most common byte in the encoded block we can expect those to be zeroes in the decoded verson. we use the code to measure byte frequency:

    source = '5e680e594606475e551115415c0a0316440a085214160e16520d135e143b09435c0d0845150a0a57400b0e445516135e770d08518e48663634eb878d356266368c66663634afe68e35626636f9e2f6a6'.decode('hex')
    prologue = '554889e5'.decode('hex')

    def xor(a, b):
        return ''.join(chr(ord(ac) ^ ord(bc)) for ac, bc in zip(a, b))

    print xor(source, prologue).encode('hex')

    a0 = source[0::4]
    a1 = source[1::4]
    a2 = source[2::4]
    a3 = source[3::4]

    def most_common(x):
        import collections
        s = collections.counter(x).most_common(1)[0]
        return (s[0].encode('hex'), s[1])

    print most_common(a0),
    print most_common(a1),
    print most_common(a2),
    print most_common(a3),

and this was a bull's-eye! (if we remeber correctly one of the four fragments were wrong but we could fix those by hand)
this way we solved the hardest re task on the ctf and got another flag worth 400 points.