## unholy (reversing, 4 points, 68 solves)
	python or ruby? why not both! 

in this task we got a ruby program, refering to shared library unholy.so. the program
mixed ruby and python code (and native code from the library).

quick analysis of `main.rb` file showed that the program had a basic structure of typical
keygenme: get flag, tell if flag is good. we had to reverse the `is_key_correct` function.

starting at the end, we noticed that it calls python interpreter with the following code:
```
exec """
import struct
e=range
i=len
import sys
f=sys.exit
x=[[%d,%d,%d], [%d,%d,%d], [%d,%d,%d]]
y = [[383212,38297,8201833], [382494 ,348234985,3492834886], [3842947 ,984328,38423942839]]
n=[5034563854941868,252734795015555591,55088063485350767967, -2770438152229037,142904135684288795,-33469734302639376803, -3633507310795117,195138776204250759,-34639402662163370450]
y=[[0,0,0],[0,0,0],[0,0,0]]
a=[0,0,0,0,0,0,0,0,0]
for i in e(i(x)):
 for j in e(i(y[0])):
  for k in e(i(y)):
   y[i][j]+=x[i][k]*y[k][j]
c=0
for r in y:
 for x in r:
  if x!=n[c]:
   print "dang..."
   f(47)
  c=c+1
print ":)"
"""
```
it seems that we need to solve for x - it had `%d`'s in it, and assembly code called 
`sprintf` before, so it's probably our input, possibly after some processing.

the above python code was simply multiplying `x` with `y` and then comparing 
with `n` - all three being 3x3 matrices. using numpy we quickly solved the `x*y=n` equation
through tranforming it to equivalent equation `x=n*inv(y)`.

ok, so now we got x. it did not look as ascii or anything, so we had to look into unholy.so
to see what it really was. the most of the code was just parsing and changing internal number
representations - nothing really interesting. at some point, there was a lot of xors and shifts
with some constants - something that looked like a cipher of some kind. googling one of the
constants (0xc6ef3720) revealed that it was xtea algorithm. we found the decryption function
implementation and wrote a c++ code (`decrypt.cpp`) to decrypt what we had (the key was hidden 
as constant too). running it yields the correct flag.
in the assembly too).
