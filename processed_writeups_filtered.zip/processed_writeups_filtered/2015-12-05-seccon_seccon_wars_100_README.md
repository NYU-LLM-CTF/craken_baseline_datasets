## seccon wars (stegano, 100p)

    https://youtu.be/8sfsln4vyek

###pl
[eng](#eng-version)

na filmie wideo zalinkowanym w zadaniu wyraźnie widać zarysy qr code, ale jest on zbyt rozmazany by odczytać go bezpośrednio.

po chwili zastanowienia (jednym z pomysłów było ręczne naprawianie qr kodu "w paincie") wpadliśmy na pomysł uśrednienia wartości piksela dla wielu screenów i odczytania qr codu z takiego uśrednionego obrazu (powinien być czytelniejszy wtedy)

najpierw napisaliśmy program w c# robiący screeny przeglądarki, żeby mieć co uśredniać:

```csharp
private class user32 {
    [structlayout(layoutkind.sequential)]
    public struct rect {
        public int left;
        public int top;
        public int right;
        public int bottom;
    }

    [dllimport("user32.dll")]
    public static extern intptr getwindowrect(intptr hwnd, ref rect rect);
}

public void captureapplication(string procname, int i) {
    var proc = process.getprocessesbyname(procname)[0];
    var rect = new user32.rect();
    user32.getwindowrect(proc.mainwindowhandle, ref rect);

    int width = rect.right - rect.left;
    int height = rect.bottom - rect.top;

    var bmp = new bitmap(width, height, pixelformat.format32bppargb);
    graphics graphics = graphics.fromimage(bmp);
    graphics.copyfromscreen(rect.left, rect.top, 0, 0, new size(width, height), copypixeloperation.sourcecopy);

    bmp.save("frame" + i + ".png", imageformat.png);
}

protected override void onload(eventargs e) {
    int i = 0;
    while (true) {
        i++;
        captureapplication("firefox", i);
        thread.sleep(100);
    }
    base.onload(e);
}
```

a następnie niewielki skrypt uśredniający obrazy z folderu (szczerze mówiąc, to tak naprawdę to skopiowaliśmy go z so):

```python
import os, numpy, pil
from pil import image

# access all png files in directory
allfiles=os.listdir(os.getcwd())
imlist=[filename for filename in allfiles if  filename[-4:] in [".png",".png"]]

# assuming all images are the same size, get dimensions of first image
w,h=image.open(imlist[0]).size
n=len(imlist)

# create a numpy array of floats to store the average (assume rgb images)
arr=numpy.zeros((h,w,3),numpy.float)

# build up average pixel intensities, casting each image as an array of floats
for im in imlist:
    imarr=numpy.array(image.open(im).convert("rgb"),dtype=numpy.float)
    arr=arr+imarr/n

# round values in array and cast as 8-bit integer
arr=numpy.array(numpy.round(arr),dtype=numpy.uint8)

# generate, save and preview final image
out=image.fromarray(arr,mode="rgb")
out.save("average.png")
out.show()
```

wynik działania:


[image extracted text: di
3]


po poprawieniu kontrastu, odczytujemy wynik:

    seccon{th3f0rc3avvak3n53p7}

### eng version

in video linked in the description we can clearly see outline of qr code, but it's too dark to be read directly

after a while (one of our first ideas was to draw qr code by hand in mspaint), we decided to capture a lot of video frames and average all pixels.

first, we have written c# script to take browser screenshot every 0.1s:

```csharp
private class user32 {
    [structlayout(layoutkind.sequential)]
    public struct rect {
        public int left;
        public int top;
        public int right;
        public int bottom;
    }

    [dllimport("user32.dll")]
    public static extern intptr getwindowrect(intptr hwnd, ref rect rect);
}

public void captureapplication(string procname, int i) {
    var proc = process.getprocessesbyname(procname)[0];
    var rect = new user32.rect();
    user32.getwindowrect(proc.mainwindowhandle, ref rect);

    int width = rect.right - rect.left;
    int height = rect.bottom - rect.top;

    var bmp = new bitmap(width, height, pixelformat.format32bppargb);
    graphics graphics = graphics.fromimage(bmp);
    graphics.copyfromscreen(rect.left, rect.top, 0, 0, new size(width, height), copypixeloperation.sourcecopy);

    bmp.save("frame" + i + ".png", imageformat.png);
}

protected override void onload(eventargs e) {
    int i = 0;
    while (true) {
        i++;
        captureapplication("firefox", i);
        thread.sleep(100);
    }
    base.onload(e);
}
```

and then tiny script to average every pixel and save result (to be honest, we just stole it from so):

```python
import os, numpy, pil
from pil import image

# access all png files in directory
allfiles=os.listdir(os.getcwd())
imlist=[filename for filename in allfiles if  filename[-4:] in [".png",".png"]]

# assuming all images are the same size, get dimensions of first image
w,h=image.open(imlist[0]).size
n=len(imlist)

# create a numpy array of floats to store the average (assume rgb images)
arr=numpy.zeros((h,w,3),numpy.float)

# build up average pixel intensities, casting each image as an array of floats
for im in imlist:
    imarr=numpy.array(image.open(im).convert("rgb"),dtype=numpy.float)
    arr=arr+imarr/n

# round values in array and cast as 8-bit integer
arr=numpy.array(numpy.round(arr),dtype=numpy.uint8)

# generate, save and preview final image
out=image.fromarray(arr,mode="rgb")
out.save("average.png")
out.show()
```

and the result is:


[image extracted text: di
3]


after improving contrast and decoding qr code:

    seccon{th3f0rc3avvak3n53p7}
