## free web access (web)

###eng
[pl](#pl-version)

in the task we get access to a proxy-gate service.
the task description states that this gate is not really anonymous and that it stores some data.
however there is no registration nor accounts.
there is `/admin` subpage but it says that we're not the admin so we can't access it.
this implies that the page somehow checks who is the admin, and we need to fool this mechanism.

the website prints in a visible way our ip address and since it's a proxy service we come up with the idea to check how it will consider `x-forwarded-for` header.
as we expected, the page prints the specified address as our ip.
we assumed that we just need to use localhost as our ip and this will get us past the admin check, but it didn't.

then we figured that maybe we can put some code in our spoofed ip address and this way exploit the page.
we started with a standard php exploit: `<? echo "test"; ?>` which didn't work, since the page was running on python.
but it did crash the page, showing us a very verbose error trace:


[image extracted text: <class 'xml etree elementtree parseerror' > at /
not well-formed (invalid token): line 1, column 15
python
fusrlliblpython2 7ixmletree/elementtree py in _raiseerror; line 1505
web
get http ilfreewebaccess_pwnzwin-party-8080/
traceback (innermost first)
{u3r/lib/python2
7 /xnl_
etzee
elerentiree
py in
zai3eerror
1505
zai3e
ez
local vars
{uar/lib/python2
7 /xnl_
etzee
elerentiree
py in feed
1641 _
3elf._rai3eerrcr(v)
local vars
{uar/lib/python2
7 {=
etree
elerentiree.py in xml
1299
par3er
feed(tert)
local vars
variable
value
par3er
<xml
etree
elerentiree
xulfar3ez
cbject
0x7ic3260cleso>
text
<3e33icnx<ipx<?
echc
te3t"
2x/ipx<adnin fal3e</ adninx<
36331007
{hcre
ireevebacce33 vebapp
py in gei
105
3e33icn3tring
createuaersea3icn (}
106
107
el3e:
103
newae33icnatring
createsea3icnstring ()
109
getuserse33ion (requeatccckies['id
110
3e33icn3tring
updateuzerse33icn (newae33icnatring,
requeatccckie3
id']}
111
112
36331c07l
ei.ircnatring(3e33icn3tring)
113
114
1f 3e33icnxl
find
admin
text
true
115 
raibe
keb
3eecther
{admin
116
117
return
render.index (u3erip-3e33icnxnl
find
text
active3e33icn3-getactivese33icna () )
113,]


the interesting part was what crashed the xml parser:

`<session><ip><? echo "test"; ?></ip><admin>false</admin></session>`

it seems that the page creates a session string based on our data and then parses it via xml.

therefore we can simply pass xml as our ip: `1.2.3.4</ip><admin>true</admin><ip>4.3.2.1`

which in result will generate session xml:

`<session><ip>1.2.3.4</ip><admin>true</admin><ip>4.3.2.1</ip><admin>false</admin></session>`

and we expect this will be enough to get past the admin check. and it did:


[image extracted text: ctf-br{is_priv4cy
dr34m_?}
admin dashboard
wellcome admin!
monitor users activity:]


`ctf-br{1s_pr1v4cy_4_dr34m_?}`

###pl version

w zadaniu dostajemy dostęp do bramki-proxy.
w opisie zadania jest informacja że bramka nie jest wcale anonimowa i że agreguje dane.
nie ma tam jednak żadej rejestracji ani logowania.
jest coś pod adresem `/admin` ale pojawia sie informacja że nie jesteśmy administratorem.
to oznacza że istnieje mechanizm sprawdzania czy ktoś jest adminem i musimy go jakoś oszukać.

strona w widocznym miejscu pokazuje nasz adres ip oraz jest to serwis proxy więc przychodzi nam na myśl sprawdzenie co się stanie jeśli podamy nagłówek `x-forwarded-for`.
zgodnie z naszymi oczekiwaniami strona pokazuje nasz zmieniony adres w miejscu adresu ip.
początkowo liczyliśmy na to, że wystarczy udawać że nasze ip to localhost aby przejść test na admina, ale nie powiodło się to.

następnie pomyśleliśmy, że może jesteśmy w stanie przemycić jakiś kod w naszym spoofowanym ip i w ten sposób exploitować stronę.
zaczęliśmy od standardowego exploita na php: `<? echo "test"; ?>` który nie zadziałał, bo strona była w pythonie.
niemniej przypadkiem ten kod wysypał parser xml pokazując nam dość ładny trace:


[image extracted text: <class 'xml etree elementtree parseerror' > at /
not well-formed (invalid token): line 1, column 15
python
fusrlliblpython2 7ixmletree/elementtree py in _raiseerror; line 1505
web
get http ilfreewebaccess_pwnzwin-party-8080/
traceback (innermost first)
{u3r/lib/python2
7 /xnl_
etzee
elerentiree
py in
zai3eerror
1505
zai3e
ez
local vars
{uar/lib/python2
7 /xnl_
etzee
elerentiree
py in feed
1641 _
3elf._rai3eerrcr(v)
local vars
{uar/lib/python2
7 {=
etree
elerentiree.py in xml
1299
par3er
feed(tert)
local vars
variable
value
par3er
<xml
etree
elerentiree
xulfar3ez
cbject
0x7ic3260cleso>
text
<3e33icnx<ipx<?
echc
te3t"
2x/ipx<adnin fal3e</ adninx<
36331007
{hcre
ireevebacce33 vebapp
py in gei
105
3e33icn3tring
createuaersea3icn (}
106
107
el3e:
103
newae33icnatring
createsea3icnstring ()
109
getuserse33ion (requeatccckies['id
110
3e33icn3tring
updateuzerse33icn (newae33icnatring,
requeatccckie3
id']}
111
112
36331c07l
ei.ircnatring(3e33icn3tring)
113
114
1f 3e33icnxl
find
admin
text
true
115 
raibe
keb
3eecther
{admin
116
117
return
render.index (u3erip-3e33icnxnl
find
text
active3e33icn3-getactivese33icna () )
113,]


interesujące jest to co wysypało parser xml:

`<session><ip><? echo "test"; ?></ip><admin>false</admin></session>`

wygląda na to, że strona tworzy sobie string sesji na podstawie naszych danych a następnie parsuje go jako xml.

to oznacza że możeym jako ip podać: `1.2.3.4</ip><admin>true</admin><ip>4.3.2.1`

co utworzy string sesji:

`<session><ip>1.2.3.4</ip><admin>true</admin><ip>4.3.2.1</ip><admin>false</admin></session>`

oczekiwaliśmy że taki string wystarczy do przejścia sprawdzenia uprawnień admina i się udało:


[image extracted text: ctf-br{is_priv4cy
dr34m_?}
admin dashboard
wellcome admin!
monitor users activity:]


`ctf-br{1s_pr1v4cy_4_dr34m_?}`
