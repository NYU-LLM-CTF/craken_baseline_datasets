﻿##smashthestate (web, 400p)

	this beautiful website for testing zip files contains a replica of a vulnerability found in a well known bug bounty site.
	log in with rob:smashthestate then exploit the vulnerability to gain access to the 'admin' account and the flag.
	automated tools and bruteforcing will not help you solve this challenge.

###pl
[eng](#eng-version)

###eng version
