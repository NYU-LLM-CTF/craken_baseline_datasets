# super duper advanced attack (web 100)


###eng
[pl](#pl-version)

in this task we get access to a web page with some table displayed.
there is also input box and `search` button.
with this we can search through the contents of the table.

very quickly we notice `sqlinjection` in where condition.
the query is something like: 

```sql
select x,y from z where y like '%input%'
```

so we can easily send as input: `fer%' union select 1,2 #` to get `1,2` as result row.
from here we check what database this is - mysql.
there is `information_schema` table in mysql so we proceed with listing all tables:

`fer%' union select table_name, table_schema from information_schema.tables #`

and columns:

`fer%' union select column_name, table_name from information_schema.columns #`

there was only a single normal table - `users` and it contained some md5 hashed passwords, but no flag.

we spent long time checking everything in the db (triggers, indexes, constraints, procedures...), we tried also to load external files, but to no avail.
in the end we decided it's time to `hack` our way through this task and check how other teams are trying to work this out.
this was possible since we had access to `information_schema.processlist` table.
this table can list all operations that db is performing at the moment.
so sending:

`fer%' union select state,info from information_schema.processlist #`

would print queries and operations that were currently performed.
we've seen some boring queries from sqlmap or some other scanner but then, not so long after we got a hit - there was information that database was sending `@flag` session variable to someone.
so we knew what has to be done - we just need to do `select @flag` to get: `eko{do_not_forget_session_variables}`.

this was a badly designed task - the hardest part was "guessing" where can the flag be, not exploiting the application.

###pl version

w zadaniu dostajemy adres strony internetowej wyświetlającej tabelkę z danymi.
jest tam też input box i `search` button.
za ich pomocą możemy wyszukać dane z tabelki.

dość szybko zauważamy, że formularz jest podatny na `sqlinjection` w warunku where.
zapytanie wyglądało mniej więcej tak:

```sql
select x,y from z where y like '%input%'
```

możemy więc wysłać jako input: `fer%' union select 1,2 #` aby dostać `1,2` jako jeden z wierszy wyniku.
następnie sprawdziliśmy z jaką bazą mamy do czynienia - mysql.
w tej bazie mamy tabelę `information_schema` więc korzystamy z niej żeby wylistować wszystkie tabele:

`fer%' union select table_name, table_schema from information_schema.tables #`

i kolumny:

`fer%' union select column_name, table_name from information_schema.columns #`

była tam tylko jedna zwykła tabela - `users` i zawierała kilka hasełm hashowanych md5, ale nie flagę.

spędziliśmy sporo czasu sprawdzając wszystko w bazie (triggery, indeksy, ograniczenia, procedury...), próbowaliśmy także ładować pliki z dysku, ale wszystko to na nic.
finalnie zdecydowaliśmy, że czas `shackować` to zadanie i sprawdzić jak inne drużyny podchodzą do tego zadania.
było to możliwe, ponieważ mieliśmy dostęp do tabeli `information_schema.processlist`.
ta tabela może listować wszystkie operacje które w danej chwili wykonuje baza.
więc wysłanie:

`fer%' union select state,info from information_schema.processlist #`

wypisuje zapytania i operacje które są wykonywane.
widzieliśmy trochę nudnych zapytań ewidentnie z sqlmapa albo innego skanera, aż w końcu po krótkim czasie pojawia się informacja, że baza wysłała komuś zmienną sesyjną `@flag`.
teraz było już oczywiste, że należy wykonać `select @flag` aby dostać: `eko{do_not_forget_session_variables}`

to jest przykład źle zaprojektowanego zadania gdzie najtrudniejszym elementem jest "zgadnięcie" gdzie autor schował flagę, a nie samo exploitowanie podatności.
