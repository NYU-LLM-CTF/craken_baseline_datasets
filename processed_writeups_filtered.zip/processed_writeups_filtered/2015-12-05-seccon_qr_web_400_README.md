## qr puzzle: web (unknown, 400p)

    solve the slide puzzle and decode the qr code.
    http://puzzle.quals.seccon.jp:42213/slidepuzzle

###pl
[eng](#eng-version)

podobnie jak w poprzednich qr puzzle dostajemy qr code i mamy go rozwiązać. tym razem problemem jest to, że brakuje fragmentu kodu.


[image extracted text: no.
1 of 50
level: easy
decode:
submit]


z czasem zadania robią się coraz trudniejsze - na początku brakuje zawsze prawego dolnego rogu kodu, później również krawędzi, później środka, a na końcu może brakować również innego rogu (co okazało się problematyczne).
dość oczywisty jest cel zadania - należy napisać program który złoży taki qr code, rozwiąże go, oraz wyśle do programu.

wykorzystaliśmy do tego solver z poprzedniego zadania qr puzzle, jedynie nieznacznie musieliśmy przerobić funkcje pobierającą obrazki z ekranu, oraz nie wysyłaliśmy rozwiązań a przeklejaliśmy ręcznie.

kodu jest za dużo by omawiać go funkcja po funkcji, ale działa prawie identycznie jak w zadaniu [qr puzzle: windows](https://github.com/p4-team/ctf/tree/master/2015-12-05-seccon/qr_windows_200) - ma jedynie kilka poprawek.

flaga:

    seccon{u_r_4_6r347_pr06r4mm3r!}



### eng version

we are given qr code, and we have to unscramble it - just like in earlier qr puzzle challenge. it's harder now, because there is much more fragments, and one piece is missing.


[image extracted text: no.
1 of 50
level: easy
decode:
submit]


qr codes are getting harder with time - at the beggining missing piece is always lower right corner, but later we can expect also missing edge, missing central piece, or even missing another corner (worst case scenario).
it's obvious what task authors are expecting from us - we kave to write program that assembles such qr code, solve it, and then sends it to server.

we used our solver from previons challenge - we only had to slightly rework function that captured qr code, and we didn't sent solutions automatically (it had to be done manually).

there is too much code to go through it function by function, but it is almost identical as in [qr puzzle: windows](https://github.com/p4-team/ctf/tree/master/2015-12-05-seccon/qr_windows_200) challenge - we only fixed few minor things.

flag:

    seccon{u_r_4_6r347_pr06r4mm3r!}
