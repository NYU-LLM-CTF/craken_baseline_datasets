﻿## for2 (forensics, 200 points)
	tl;dr plot mouse movements from pcap

the given [pcap file](capture.pcap) contains usb mouse traffic, knowing that certain bytes in leftovercapturedata contain relative mouse movement, we can easily export the needed data and plot the movements: [plotmouse.py](plotmouse.py)

after running it we get a nice graph that has our upside down flag ;)


[image extracted text: 600
400
200
snrbkll }
!7+p6
~200
cll {#e-svl
-400
600
-1000
800
600
-400
200
200]


if our leftovercapturedata is "01234567", then

```
"01" = button pressed (0 = nothing, 1 = rpm, etc...)

"23" = signed x movement

"45" = signed y movement
```

we used python+bokeh for plotting, the unsigned to signed conversion was kinda tricky: `if x >= 1<<7: x -= 1<<8` 
