﻿##pseudorandom (re, 300p)

###pl
[eng](#eng-version)

###eng version
