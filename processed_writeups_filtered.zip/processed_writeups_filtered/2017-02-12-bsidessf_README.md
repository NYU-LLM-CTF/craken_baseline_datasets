# writeup bsidessf 2017

team: c7f.m0d3, cr01283, msm, shalom, akrasuski1, nazywam

### table of contents

* [vhash fixed (crypto)](vhash)
* [sensors (pwn)](sensors)
* [delphi (web/crypto)](delphi)
