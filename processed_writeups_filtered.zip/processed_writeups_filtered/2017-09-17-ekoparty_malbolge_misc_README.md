# malbolge (misc, 238p, 153 solved)

we can connect to a service which asks us for a malbolge code which will print `welcome to ekoparty!`:

```
$ nc6 malbolge.ctf.site 40111
nc6: using stream socket
send a malbolge code that print: 'welcome to ekoparty!' (without single quotes)
```

a bit of googling and we find http://www.matthias-ernst.eu/malbolge.html where author created [a program](finder.c) for generating malbolge programs printing out desired output.
we used it and got:

```
bcba@?>=<;:9876543210/.-,+*)('&%$#"!~}|{zyxwvutsrqponmlkjihgfedcba`_^]\[zyxwvutsrqponmlkjihgfedcba@?>=<;:9y765432+o/.-,+*)i'&}c{"!~w={zyxwyutsrqponmlkjiha'hdcba`_^]\[zyxwvutsrqponmlkjihgfed=a;@?>7[|:981u543s10/.',+*#g'&%$#"!~`|u;yxqvun4rqprhmf,mchgfedcba`_^]vzzyxwvutsrqjnnm/kdibffedcba#?>=<54x810t4321q/.-,+$h('&%$#"bx>|{tyxwvutsrqponmlkd*kafedc\"m
```

which in turn gave us the flag: `eko{0nly4nother3soteric1anguage}`
