## what's example flag? (triv, 1p)

### pl
[eng](#eng-version)

przykładowa flaga znajduje się tutaj http://asis-ctf.ir/rules/ :

    asis{476f20676f6f2e676c2f67776a625466}

ale nie o nią chodzi. hexy przypominające hash md5 są tak naprawdę tekstem zakodowanym w ascii.

	bytes.fromhex('476f20676f6f2e676c2f67776a625466').decode('ascii')

rozwiązuje się do:

    go goo.gl/gwjbtf

pod tym linkiem znajduje się prawdziwa flaga:

    hi all, the flag is: asis{c0966ad97f120b58299cf2a727f9ca59}

### eng version

there is an example flag in http://asis-ctf.ir/rules/ :

    asis{476f20676f6f2e676c2f67776a625466}

however, that's not the flag we are looking for. this supposed md5 hash is actually hex encoded ascii.

	bytes.fromhex('476f20676f6f2e676c2f67776a625466').decode('ascii')

evaluates to:

    go goo.gl/gwjbtf

where we can find the real flag:

    hi all, the flag is: asis{c0966ad97f120b58299cf2a727f9ca59}