# f#ck (re 50)


###eng
[pl](#pl-version)

in the task we get a [binary](flaggenerator.exe) which is written in f#.
like every other .net binary it can be nicely decompiled by ilspy.

with this we didn't even need to reverse the algorithm at all.
we simply modified the decompiled code we got so that we could compile it again:

```csharp
using system;
using system.globalization;
 
class x
{
	public string str;

	public int[] ccindices;

	internal x(string str, int[] ccindices)
	{
		this.str = str;
		this.ccindices = ccindices;
	}

	public string invoke(int i)
	{
		if (i == this.ccindices.length - 1)
		{
			return this.str.substring(i);
		}
		int num = this.ccindices[i];
		return this.str.substring(num, this.ccindices[i + 1] - num);
	}
}
 
public class test
{
	public static string get_flag(string str)
	{
		int[] array = stringinfo.parsecombiningcharacters(str);
		int num = array.length;
		x fsharpfunc = new x(str, array);
		string[] array2 = new string[num];
		int num2 = 0;
		int num3 = num - 1;
		if (num3 >= num2)
		{
			do
			{
				array2[num2] = fsharpfunc.invoke(num2);
				num2++;
			}
			while (num2 != num3 + 1);
		}
		string[] array3 = array2;
		array.reverse(array3);
		return string.join("", array3);
	}
 
	public static void main()
	{
		console.writeline(get_flag("t#hs_siht_kc#f"));
	}
}
```

and we got `eko{f#ck_this_sh#t}`.

###pl version

w zadaniu dostajemy [program](flaggenerator.exe) napisany w f#.
jak każda inna binarka .net można go ładnie zdekompilować za pomocą ilspy.

uzyskujemy w ten sposób dość ładny kod i nie było potrzeby nawet reversować algorytmu.
zmodyfikowaliśmy uzyskany kod tak, żeby dało się go skompilować i uruchomić:


```csharp
using system;
using system.globalization;
 
class x
{
	public string str;

	public int[] ccindices;

	internal x(string str, int[] ccindices)
	{
		this.str = str;
		this.ccindices = ccindices;
	}

	public string invoke(int i)
	{
		if (i == this.ccindices.length - 1)
		{
			return this.str.substring(i);
		}
		int num = this.ccindices[i];
		return this.str.substring(num, this.ccindices[i + 1] - num);
	}
}
 
public class test
{
	public static string get_flag(string str)
	{
		int[] array = stringinfo.parsecombiningcharacters(str);
		int num = array.length;
		x fsharpfunc = new x(str, array);
		string[] array2 = new string[num];
		int num2 = 0;
		int num3 = num - 1;
		if (num3 >= num2)
		{
			do
			{
				array2[num2] = fsharpfunc.invoke(num2);
				num2++;
			}
			while (num2 != num3 + 1);
		}
		string[] array3 = array2;
		array.reverse(array3);
		return string.join("", array3);
	}
 
	public static void main()
	{
		console.writeline(get_flag("t#hs_siht_kc#f"));
	}
}
```

i dostaliśmy: `eko{f#ck_this_sh#t}`.
