# patience (re, 769p)

this was a haskell reversing challenge. if this doesn't fill you with dread, this means that probably either:

- you are most 1338 pr0 xakep r3v3rse engineer ever living
- you don't comprehend the amount of horror that you're going to witness.

either way, you're in for some serious fun. in fact, i've never seen anyone actually reverse engineer (non-trivial) haskell binary before - most challenges are actually solved with black-box workarounds or other side channels. this task is no different - we are given .cmm file along with compiled binary.

cmm files are dump of late-stage intermediate language from ghc. this is going to make our life way easier - we don't have to reverse haskell thunks, we have everything in plain text... well, sort of.

## how to be lazy

a word of introduction to the beautiful world of functional programming. haskell is a lazy language. but not just your average slightly-procrastinating kind - everything is delayed as long as it possibly can be, and i mean it. for example, consider this function:

```haskell
integers n = n : integers (n+1)
```

if you don't speak haskell, this is conceptually equivalent to following python code:

```python
def integers(n):
    return [n] + integers(n + 1)
```

do you see anything wrong with this code? exactly, this is not a terribly useful function - it'll recurse forever, or rather eat all your available stack space and explode. not in haskell though - you can call this function, take first 100 elements of the result, and get perfectly useful result - haskell is *lazy*, so only necessary elements will be evaulated.

but this still doesn't explain just how lazy haskell is. consider this:

```haskell
foo (2 + 2)
```

this is just invoaction of function `foo` with parameter `4`. wait, wrong, i lied to you. the parameter is `2 + 2`, and it's not actually evaluated until it's needed. hell, you could've passed `1 / 0` and nothing bad would happen, at least until something actually evaulates the parameter.

## reversing

so, why the introduction? well, this is how `main` function looks like in dump:

```
==================== output cmm ====================
[section ""data" . :main.main_closure" {
     :main.main_closure:
         const :main.main_info;
         const 0;
         const 0;
         const 0;
 },
 :main.main_entry() //  [r1]
         { info_tbl: [(c3bb,
                       label: :main.main_info
                       rep:heaprep static { thunk })]
           stack_info: arg_space: 8 updfr_space: just 8
         }
     {offset
       c3bb:
           _01d::p64 = r1;
           if ((sp + 8) - 24 < splim) goto c3bc; else goto c3bd;
       c3bc:
           r1 = _01d::p64;
           call (stg_gc_enter_1)(r1) args: 8, res: 0, upd: 8;
       c3bd:
           (_c3b8::i64) = call "ccall" arg hints:  [ptrhint,
                                                    ptrhint]  result hints:  [ptrhint] newcaf(basereg, _01d::p64);
           if (_c3b8::i64 == 0) goto c3ba; else goto c3b9;
       c3ba:
           call (i64[_01d::p64])() args: 8, res: 0, upd: 8;
       c3b9:
           i64[sp - 16] = stg_bh_upd_frame_info;
           i64[sp - 8] = _c3b8::i64;
           r2 = main.main_closure;
           r1 = ghc.tophandler.runmainio_closure;
           sp = sp - 16;
           call stg_ap_p_fast(r2, r1) args: 24, res: 0, upd: 24;
     }
 }]
```

beautiful, isn't it? what's going on here? nothing, actually. all this code does is:

```haskell
runmainio (main_closure)
```

where `main_closure` is well, closure from main. let's dig deeper - what's inside this `main_closure`?

```haskell
main.main_entry() //  [r1]
        { info_tbl: [(c3aw,
                      label: main.main_info
                      rep:heaprep static { thunk })]
          stack_info: arg_space: 8 updfr_space: just 8
        }
    {offset
      c3aw:
          _rfg::p64 = r1;
          if ((sp + 8) - 24 < splim) goto c3ax; else goto c3ay;
      c3ax:
          r1 = _rfg::p64;
          call (stg_gc_enter_1)(r1) args: 8, res: 0, upd: 8;
      c3ay:
          (_c3at::i64) = call "ccall" arg hints:  [ptrhint,
                                                   ptrhint]  result hints:  [ptrhint] newcaf(basereg, _rfg::p64);
          if (_c3at::i64 == 0) goto c3av; else goto c3au;
      c3av:
          call (i64[_rfg::p64])() args: 8, res: 0, upd: 8;
      c3au:
          i64[sp - 16] = stg_bh_upd_frame_info;
          i64[sp - 8] = _c3at::i64;
          r5 = sat_s2rj_closure+1;
          r4 = sat_s2rf_closure;
          r3 = ghc.base.$fmonadio_closure;
          r2 = data.foldable.$ffoldable[]_closure;
          r1 = data.foldable.form__closure;
          sp = sp - 16;
          call stg_ap_pppp_fast(r5,
                                r4,
                                r3,
                                r2,
                                r1) args: 24, res: 0, upd: 24;
    }                                               
}                                                   
```

again, a lot of code. and again, this is equivalent to:

```haskell
form (s2rj_closure) (s2rf_closure)
```

so, invocation of single function with two closures.

and again...

```haskell
==================== cmm produced by new codegen ====================
[section ""data" . sat_s2rf_closure" {
     sat_s2rf_closure:
         const sat_s2rf_info;
         const 0;
         const 0;
         const 0;
 },
 sat_s2rf_entry() //  [r1]
         { info_tbl: [(c3ah,
                       label: sat_s2rf_info
                       rep:heaprep static { thunk })]
           stack_info: arg_space: 8 updfr_space: just 8
         }
     {offset
       c3ah:
           _s2rf::p64 = r1;
           goto c3ac;
       c3ac:
           if ((old + 0) - <highsp> < splim) goto c3ai; else goto c3aj;
       c3ai:
           r1 = _s2rf::p64;
           call (stg_gc_enter_1)(r1) args: 8, res: 0, upd: 8;
       c3aj:
           (_c3ae::i64) = call "ccall" arg hints:  [ptrhint,
                                                    ptrhint]  result hints:  [ptrhint] newcaf(basereg, _s2rf::p64);
           if (_c3ae::i64 == 0) goto c3ag; else goto c3af;
       c3ag:
           call (i64[_s2rf::p64])() args: 8, res: 0, upd: 8;
       c3af:
           i64[(old + 24)] = stg_bh_upd_frame_info;
           i64[(old + 16)] = _c3ae::i64;
           r3 = main.flags_closure+2;
           r2 = main.idx'_closure+1;
           r1 = ghc.base.map_closure;
           call stg_ap_pp_fast(r3, r2, r1) args: 24, res: 0, upd: 24;
     }
 }]
```

which basically means (closure names by me):

```haskell
map (idx_closure) (flags_closure)
```

so again, single function invocation, with closure parameters, and a lot of junk.

i'll spare you the details - when you know what to expect (i.e. a lot of thunks), reversing is quite straightforward (except you need a lot of, well, *patience*).

this is the reversed code, which should be **very** similar to the original:

```haskell
module main where

import data.bits
import data.char
import control.monad
import system.io
import data.function.memoize

s0 = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz0123456789!#$%&'\"()*+,-./:;<=>?@[\\]^_`{|}~"
s1 = "1vi{e[8td]-nq.7o\"bl(jq@<0vy&z3~\\ps,ad^;bn9juoh|ce2_6!g'rhuf>$s%mxgzky4`c+wxa5f)mr}#ptl?*=i/:wk"
s2 = "bp}i{xu%f$dr\\0<lx=o\"sl`bz)-e62|&jqft!(c5yh;@u*.waz#qv,?cr8wem4_t19ph:j]>[nvmn7ygkk'^/~oidsa+3g"
s3 = "_r+#yh[y)s8axjwv&jv\"o=i(6>pg,f-m]qbn4'edkf\\t<3g%|$cspqm}~0@r;uu2z9iwb./hck!{:od^zt7`anl1e5l*x?"

data index = index int int

f :: int -> [char]
f 0 = s0
f arg = s1 ++ f (subtract 1 arg) ++ s2 ++ f (subtract 1 arg) ++ s3

idx :: index -> char
idx (index i j) = (f i !! j)

flags = [index 0 39,
     index 5 282,
     index 6 16240,
     index 9 162889,
     index 14 523151,
     index 17 5536393,
     index 7616 133142712,
     index 8799 122076774,
     index 8656 370998818,
     index 9835 12169334,
     index 9023 316222630,
     index 9402 20517998,
     index 9509 206287754,
     index 5656 439741488,
     index 9020 254692819,
     index 5337 505473338,
     index 7860 66985734,
     index 5342 343561367,
     index 7797 237439774,
     index 6145 303374550,
     index 5842 469397741,
     index 6262 125811292,
     index 8861 285489743,
     index 9917 203482576,
     index 6210 65894981,
     index 5807 160395306,
     index 6950 411117612,
     index 9261 130413308,
     index 6224 532384558,
     index 5304 107223978,
     index 6533 292707045,
     index 8303 284494291,
     index 9948 119890013,
     index 8254 430252526,
     index 8249 142828351,
     index 8799 452127715,
     index 6071 491307991,
     index 8803 154654024,
     index 9328 181393976,
     index 6253 103923077,
     index 7886 450071326,
     index 7721 342235485,
     index 6802 429438438,
     index 6391 504612462,
     index 5300 23633538,
     index 9418 315942207,
     index 9873 228342978,
     index 6361 510000394,
     index 5816 485654100,
     index 8533 347840847,
     index 9931 517634651,
     index 8209 122749414,
     index 9873 484029647,
     index 9346 273221045]

main = do
  form_ (map idx flags) $ \i -> do
    putchar i
    hflush stdout
```

not a lot of code, for huge binary that it produced, eh?

the problem is simple - `idx` function is very slow. but we can make it faster. i was too *lazy* to rewrite everything to my usual language of choice (python), so i just implemented faster version of `idx` straight in haskell:

```haskell
fsize' :: int -> integer
fsize' 0 = fromintegral $ length s0
fsize' i = 2 * fsize (i - 1) + 3 * fsize 0

fsize :: int -> integer
fsize = memoize fsize'

idx' :: index -> char
idx' (index i j) =
    if i == 0 then s0 !! j
    else if fromintegral j < fsize0 then s1 !! j
    else if fromintegral j < fsize1 then idx' $ index (i - 1) (j - frominteger fsize0)
    else if fromintegral j < fsize2 then s2 !! (j - frominteger fsize1)
    else if fromintegral j < fsize3 then idx' $ index (i - 1) (j - frominteger fsize2)
    else s3 !! (j - frominteger fsize3)
    where fsize0 = fsize 0
          fsize1 = fsize0 + fsize (i - 1)
          fsize2 = fsize1 + fsize0
          fsize3 = fsize2 + fsize (i - 1)
```

and that's basically it - after running reversed version, correct flag is produced in seconds:

```
n1ctf{did_cmm_helped?1109ef6af4b2c6fc274ddc16ff8365d1}
```

ps. yes, it did.
