# hacker in disguise(for, 100 points, solved by 27)


```
r2c +17 d17 
rf0 r2c -17 u17 
r33 +0b d0b 
r43 +0c d0c 
rf0 r33 -0b u0b 
rf0 r43 -0c u0c 
r1b +16 d16 
rf0 r1b -16 u16 r29 +2c d2c 
r43 +0c d0c rf0 r29 -2c u2c 
rf0 r43 -0c u0c r1b +16 d16 
rf0 r1b -16 u16 r29 +2c d2c 
rf0 r29 -2c u2c 
r35 +1c d1c 
rf0 r35 -1c u1c r44 +12 d12 
r3c +18 d18 
rf0 r44 -12 u12 
rf0 r3c -18 u18 r2d +15 d15 
r29 +2c d2c rf0 r2d -15 u15 
rf0 r29 -2c u2c r2b +09 d09 
rf0 r2b -09 u09 r4b +0f d0f 
rf0 r4b -0f u0f r1c +04 d04 
r34 +0a d0a rf0 r1c -04 u04 
rf0 r34 -0a u0a 
r29 +2c d2c 
rf0 r29 -2c u2c 
r59 +e5 de5 
r24 +08 d08 
rf0 r24 -08 u08 
r42 +0e d0e 
r44 +12 d12 rf0 r42 -0e u0e 
rf0 r44 -12 u12 
rf0 r59 -e5 ue5 
r12 +e1 de1 
r54 +2f d2f 
rf0 r54 -2f u2f 
rf0 r12 -e1 ue1 
r33 +0b d0b 
r44 +12 d12 rf0 r33 -0b u0b 
rf0 r44 -12 u12 
r4b +0f d0f 
rf0 r4b -0f u0f r1c +04 d04 
rf0 r1c -04 u04 
r4d +13 d13 
r43 +0c d0c 
rf0 r4d -13 u13 rf0 r43 -0c u0c r1c +04 d04 
rf0 r1c -04 u04 r31 +11 d11 r44 +12 d12 
rf0 r31 -11 u11 rf0 r44 -12 u12 
r4b +0f d0f 
r1c +04 d04 rf0 r4b -0f u0f 
rf0 r1c -04 u04 
r12 +e1 de1 
r5b +30 d30 
rf0 r5b -30 u30 
rf0 r12 -e1 ue1 
r11 +e0 de0 
r21 +06 d06
```


the key element in solving this task is obtainting a hid keyboard mapping like [this one](https://github.com/nazywam/ctf-stuff/blob/master/usb-pcap/hidkeyboardmappings.py)

the flag format `eko{`, encoded, looks like this: `08 0e 12 2f` after a quick investigation we find a part of the ciphertext that corresponds to it:

```
rf0 r24 -08 u08  //e
r42 +0e d0e //k
r44 +12 d12 rf0 r42 -0e u0e  //k
rf0 r44 -12 u12  //o
rf0 r59 -e5 ue5 //shift
r12 +e1 de1  //
r54 +2f d2f  //{
rf0 r54 -2f u2f 

```

using some trivial deduction, we can figure out that `dhex` signals a key-down and a `uhex` key-up

we were able to get the flag using a simple script in python

`eko{holapianola}`
