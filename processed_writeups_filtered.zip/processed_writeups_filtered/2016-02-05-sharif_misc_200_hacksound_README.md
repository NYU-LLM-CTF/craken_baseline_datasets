## hack by the sound (misc, 200p)

    a well known blogger has came to a hotel that we had good relationships with its staffs. we tried to capture the sound of his room by placing a microphone inside the desk.

    we have recorded the sound about the time that he has typed a text in his blogg. you could find the text he typed in "blog text.txt".
    
    we reduce noises somehow and found that many characters may have the same keysound. also we know that he use meaningful username and password.
    
    could you extract the username and password of his blog?
    
    flag is concatenation of his username and password as usernamepassword.
    
    download sound.tar.gz

###eng
[pl](#pl-version)

the attached .wav file had no sound loud enough for our ears, but amplifying it using audacity we were able to notice
that it was sound of a person typing. words were pretty noticeable - space always meant that typing stops for a split
second. by ear, all the key sounds were identical though.

however, we checked out audacity's wave representation of keys and overlaid some of them in gimp. here is the result:

[image extracted text: [image not found]]


the first image is two "s" sounds overlaid - there were almost no changes. the second one - "o" and "i" - had minor
differences, and the last one - "n" and "a" - showed noticeable changes. apparently, the further the keys are on the
keyboard, the more differences they have. 

the task now was obvious, but still hard. in the end, we did the following:
- read raw data from the wav
- found the sound peaks, corresponding to individual key presses
- cut about 0.05s worth of sound around each peak
- repair blog text - there were some extra characters in a couple of places, which made keysound-to-character
  correspondence wrong
- for each unknown keypress, iterate over known keypresses and try to find best fit

unfortunately, some characters had the same sound, so we were unable to find the password in plaintext - instead, we
got a range of characters for each position:

```
[] [] [ced] [frv] [ced] [ikl] [hny] [sw] [bgt] [ced] [il] [hny] [,.] [ced] [op] [mu] [] [
] [ ] [
] [ ] [] [a] [ced] [jmu] [ikl] [hny] [] [-sw] [op] [jmu] [ced] [bgt] [hny] [ikl] [hny] [bgt] [] [
] [ ] [
] [ ] [] 
```
the first word was probably website (look at the end - ".com"), so we were not interested in that. the remaining
two words were somewhat challenging to guess, but eventually we found them: `admin` and `something`. concatenated
togather, they were the flag.

###pl version

załączony plik .wav był zbyt cichy, żeby cokolwiek usłyszec, ale wzmacniając go przy użyciu audacity, zauważyliśmy, że
było to nagranie osoby piszącej na klawiaturze. słowa były rozróżnialne - spacja była znacznie dłuższym dźwiękiem od
pozostałych klawiszy. te niestety były dla ludzkiego ucha nierozróżnialne.

sprawdziliśmy jednak reprezentację tych dźwięków w audacity i nałożyliśmy niektóre z nich na siebie w gimpie. rezultat:

[image extracted text: [image not found]]


pierwszy obrazek, to dwa dźwięki "s" nałożone na siebie - wyglądają jak jedna fala. drugi - to "o" i "i" - miał niewielkie,
pikselowe wręcz różnice. ostatni zaś - "n" i "a" - ujawnił znaczące różnice w dźwiękach. najwyraźniej im dalej klawisze
się od siebie znajdują na klawiaturze, tym większa jest różnica w ich dźwiękach.

w tym momencie doskonale wiedzieliśmy, o co chodzi w zadaniu - należy dopasować nieznane dźwięki z początku do znanych
z końca nagrania. łatwo powiedzieć, trudniej zrobić. ostatecznie, zrobiliśmy to następująco:
- wczytalliśmy surowe dane z pliku i je sparsowaliśmy
- znaleźliśmy górki odpowiadające uderzeniom klawisza
- wycięliśmy około 0.05-sekundowe kawałki wokół każdej górki
- naprawiliśmy podany tekst z bloga - niektóre litery pojawiły się w tekście, ale nie w dźwięku, co psuło dopasowywanie
- dla każdego nieznanego dźwięku, znajdowaliśmy znany o najlepszym dopasowaniu

w praktyce jednak, musliśmy poprzestać na kilku możliwościach dla każdego uderzenia - niektóre klawisze miały bowiem
identyczny dźwięk, co inne, nie pozwalając tym samym na jednoznaczny odczyt. wynik działania programu:
```
[] [] [ced] [frv] [ced] [ikl] [hny] [sw] [bgt] [ced] [il] [hny] [,.] [ced] [op] [mu] [] [
] [ ] [
] [ ] [] [a] [ced] [jmu] [ikl] [hny] [] [-sw] [op] [jmu] [ced] [bgt] [hny] [ikl] [hny] [bgt] [] [
] [ ] [
] [ ] [] 
```
pierwsze słowo to prawdopodobnie nazwa strony internetowej (świadczy o tym końcówka ".com"), więc nie jesteśmy tym
fragmentem zainteresowani. pozostałe dwa słowa to login i hasło - po dłuższej chwili, zauważyliśmy, że pasują do
nich słowa: `admin` i `something`. połączone razem, były one flagą.
