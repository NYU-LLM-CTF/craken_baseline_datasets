## secu prim (ppc, 65p)

###eng
[pl](#pl-version)

after connecting to the server we get a pow to solve, and then the task is to provide number of primes and perfect powers in given range.

the ranges are rather small (less than 2000 numbers in between) so we simply iterate over the given range and use `gmpy` to tell us if the number if a probable prime or a perfect power:

```python
def solve_task(start, end):
    print("range size = " + str(end - start))
    counter = 0
    for i in range(start, end + 1):
        if gmpy2.is_prime(i):
            counter += 1
        elif gmpy2.is_power(i):
            counter += 1
    print("counted " + str(counter))
    return counter
```

and the whole script with pow:

```python
import hashlib
import re
import socket

import itertools
import string
import gmpy2


def recvuntil(s, tails):
    data = ""
    while true:
        for tail in tails:
            if tail in data:
                return data
        data += s.recv(1)


def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha256(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c


def get_task(s):
    sentence = recvuntil(s, ["that: "])
    sentence += recvuntil(s, ["\n"])
    return sentence


def solve_task(start, end):
    print("range size = " + str(end - start))
    counter = 0
    for i in range(start, end + 1):
        if gmpy2.is_prime(i):
            counter += 1
        elif gmpy2.is_power(i):
            counter += 1
    print("counted " + str(counter))
    return counter


def main():
    url = "secuprim.asis-ctf.ir"
    port = 42738
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    x = proof_of_work(s)
    print(x)
    s.sendall(x + "\n")
    data = recvuntil(s, "---\n")
    print(data)
    while true:
        data = recvuntil(s, ["like n such", "corret!", "}"])
        print(data)
        if "asis" in data:
            print(data)
        if "corret" in data:
            print("failed")
            break
        else:
            task = get_task(s)
            print(task)
            b, e = re.findall("that: (\d+) <= n <= (\d+)", task)[0]
            start = int(b)
            end = int(e)
            counter = solve_task(start, end)
            s.sendall(str(counter) + "\n")


main()
```

###pl version

po połączeniu do serwera dostajemy pow do rozwiązania a następnie zadaniem jest policzyć ile liczb pierwszych oraz doskonałych potęg jest w zadanym przedziale.

przedziały są dość małe (nie więcej niż 2000 liczb) więc po prostu iterujemy po każdej liczbie i za pomocą `gmpy` sprawdzamy czy liczba jest pierwsza lub czy jest doskonałą potęgą:

```python
def solve_task(start, end):
    print("range size = " + str(end - start))
    counter = 0
    for i in range(start, end + 1):
        if gmpy2.is_prime(i):
            counter += 1
        elif gmpy2.is_power(i):
            counter += 1
    print("counted " + str(counter))
    return counter
```

a cały skrypt razem z pow:

```python
import hashlib
import re
import socket

import itertools
import string
import gmpy2


def recvuntil(s, tails):
    data = ""
    while true:
        for tail in tails:
            if tail in data:
                return data
        data += s.recv(1)


def proof_of_work(s):
    data = recvuntil(s, ["enter x:"])
    x_suffix, hash_prefix = re.findall("x \+ \"(.*)\"\)\.hexdigest\(\) = \"(.*)\.\.\.\"", data)[0]
    len = int(re.findall("\|x\| = (.*)", data)[0])
    print(data)
    print(x_suffix, hash_prefix, len)
    for x in itertools.product(string.ascii_letters + string.digits, repeat=len):
        c = "".join(list(x))
        h = hashlib.sha256(c + x_suffix).hexdigest()
        if h.startswith(hash_prefix):
            return c


def get_task(s):
    sentence = recvuntil(s, ["that: "])
    sentence += recvuntil(s, ["\n"])
    return sentence


def solve_task(start, end):
    print("range size = " + str(end - start))
    counter = 0
    for i in range(start, end + 1):
        if gmpy2.is_prime(i):
            counter += 1
        elif gmpy2.is_power(i):
            counter += 1
    print("counted " + str(counter))
    return counter


def main():
    url = "secuprim.asis-ctf.ir"
    port = 42738
    s = socket.socket(socket.af_inet, socket.sock_stream)
    s.connect((url, port))
    x = proof_of_work(s)
    print(x)
    s.sendall(x + "\n")
    data = recvuntil(s, "---\n")
    print(data)
    while true:
        data = recvuntil(s, ["like n such", "corret!", "}"])
        print(data)
        if "asis" in data:
            print(data)
        if "corret" in data:
            print("failed")
            break
        else:
            task = get_task(s)
            print(task)
            b, e = re.findall("that: (\d+) <= n <= (\d+)", task)[0]
            start = int(b)
            end = int(e)
            counter = solve_task(start, end)
            s.sendall(str(counter) + "\n")


main()
```
