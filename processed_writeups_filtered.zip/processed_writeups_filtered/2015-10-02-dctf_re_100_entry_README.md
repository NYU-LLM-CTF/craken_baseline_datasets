﻿## reverse 100 (re, 100p)

### pl
[eng](#eng-version)

dostajemy [program](./r100) (elf konkretnie), który wykonuje bardzo proste sprawdzenie hasła i odpowiada czy hasło jest poprawne czy nie.

domyślamy się że poprawne hasło jest flagą.

cały program to coś w rodzaju:

    int main() {
        printf("enter the password: ");
        if (fgets(&password, 255, stdin)) {
            if (check_password(password)) {
              puts("incorrect password!");
            } else {
              puts("nice!");
            }
        }
    }

patrzymy więc w funkcję check_password (oczywiście nie nazywała się tak w binarce, nie dostaliśmy symboli):

    bool check_password(char *password) {
        char* arr[3] = { "dufhbmf", "pg`imos", "ewuglpt" };
        for (i = 0; i <= 11; ++i) {
            if (v3[8 * (i % 3)][2 * (i / 3)] - password[i] != 1) {
                return true;
            }
        }
        return false;
    }

z równania `v3[8 * (i % 3)][2 * (i / 3)] - password[i] != 1` od razu wynika co trzeba zrobić (coś - hasło ma być równe 1, czyli hasło = coś + 1).

wyliczyliśmy hasło na podstawie podanych stałych i zdobyliśmy flagę.

### eng version

we get a [binary](./r100) (elf to be exact), which performs a simple password check and returns if the password was correct or not.

we expect the password to be the flag.

whole code is something like: 

    int main() {
        printf("enter the password: ");
        if (fgets(&password, 255, stdin)) {
            if (check_password(password)) {
              puts("incorrect password!");
            } else {
              puts("nice!");
            }
        }
    }

we go into the check_password function (of course it was not called like that in the binary, there was no symbol table):

    bool check_password(char *password) {
        char* arr[3] = { "dufhbmf", "pg`imos", "ewuglpt" };
        for (i = 0; i <= 11; ++i) {
            if (v3[8 * (i % 3)][2 * (i / 3)] - password[i] != 1) {
                return true;
            }
        }
        return false;
    }

from the equation `v3[8 * (i % 3)][2 * (i / 3)] - password[i] != 1` we can see right away what we need to do (something - password has to be equal to 1 so therefore password+something = 1)

we simply calculated the password based on the constant values and got the flag.
