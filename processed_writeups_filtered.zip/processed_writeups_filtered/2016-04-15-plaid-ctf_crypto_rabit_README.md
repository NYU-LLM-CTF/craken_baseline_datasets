## rabit (crypto, 175 points, 71 solves)

	just give me a bit, the least significant's enough. just a second we’re not broken, just very, very insecure. 
	running at rabit.pwning.xxx:7763

###eng
[pl](#pl-version)

we get the [server files](server) so we can analyse the cryptosystem.
it turns out that the flag is encrypted with rabin cryptosystem so if encodes the data as `message^2 mod n`.
the server provides us with the `n` modulus value and with the encrypted flag `ct`.
we would like to get the value of `pt = sqrt_mod(ct, n)`
the server lets us to ask for the least-significant-bit (lsb) of selected decrypted ciphertexts of our choosing.
this means that the server acts a `least significant bit oracle` and we need to use this to our advantage.

if we send the encrypted flag as input the server will tell us the lowest bit for the plaintext flag, now we just need all the rest.
we can exploit this oracle using a binary-search algorithm.

it is quite obvious that if we multiply a number by 2 it will become an even number.
this means that the lsb will have to be 0 as it's always for even numbers.
now if we perform a modular division by an odd number we can get two possible results:

- the number was smaller than the modulus and therefore it is still even and the lsb is 0
- the number was greater than the modulus and therefore it is now odd and the lsb is 1

the n modulus in our case is an odd number, since it's a product of two large primes.
this means that if we ask the oracle for the lsb of `2*pt mod n` we will get one of the two possible results:

- if lsb is 0 then the number was smaller than modulus and therefore `2*pt < n` which means `pt < n/2`
- if lsb is 1 then the number was greater than modulus and therefore `2*pt > n` which means `pt > n/2`

now if we ask for lsb of `4*pt mod n` we can again get one of two possible results

- if lsb is 0 then either `4*pt < n` which means `pt < n/4` if `pt < n/2` or `pt < 3*n/4` if `pt > n/2`
- if lsb is 1 then either `4*pt > n` which means `pt > n/4` if `pt < n/2` or `pt > 3*n/4` if `pt > n/2`

this means that we can get lower and upper bounds for `pt` simply by asking for lsb for pt multiplied by powers of 2.
this is exactly binary search algorithm - we are looking for the `pt` value and the oracle tells us if it's bigger or smaller than given number.

the server first performs decryption of our input, which means it performs a modular square root on it.
so if we want the server to tell us lsb of `2*pt mod n` we need to provide `4*ct` as input since: 

`sqrt_mod(4*ct, n) = sqrt_mod(4,n)*sqrt_mod(ct,n) = 2*pt mod n` 

we automate it with a simple script:

```python
def oracle(ciphertext, s):
    print("sent ciphertext " + str(ciphertext))
    s.sendall(str(ciphertext) + "\n")
    data = recvline(s)
    print("oracle response: " + data)
    lsb = int(re.findall("lsb is (.*)", data)[0])
    return lsb


def brute_flag(encrypted_flag, n, socket):
    flag_lower_bound = 0
    flag_upper_bound = n
    mult = 0
    ciphertext = (encrypted_flag * pow(4, mult)) % n
    while flag_upper_bound > flag_lower_bound:
        data = s.recv(512)
        ciphertext = (ciphertext * 4) % n
        mult += 1
        print("main loop: " + data)
        print("upper = %d" % flag_upper_bound)
        print("upper flag = %s" % long_to_bytes(flag_upper_bound))
        print("lower = %d" % flag_lower_bound)
        print("lower flag = %s" % long_to_bytes(flag_lower_bound))
        print("multiplier = %d" % mult)
        if oracle(ciphertext, socket) == 0:
            flag_upper_bound = (flag_upper_bound + flag_lower_bound) / 2
        else:
            flag_lower_bound = (flag_upper_bound + flag_lower_bound) / 2
    return flag_upper_bound
```

the script updates the upper and lower bounds for the `pt` value depending on server responses.
this way we finally get:

```
main loop: give a ciphertext: 
upper = 220166400929873038171224043083387335590015857856801737690673880396419795615547577312678070179481369128029264724566861040868992922377738134245284720456363270069895363821431128690061826490011022637831305626391095236981088399616123236780868219333517868946867381881069203811100413120301449973114417385114578488
upper flag = pctf{lsb_is_4ll_y0u_ne3d}�mt�ҵņ�|o�a�.gȵ�j~r���rڟ��nl�����o��z�l����)�a�8{����mm�q1fܛ�h�[���"7���rɭei�h9��f�.8
lower = 220166400929873038171224043083387335590015857856801737690673855617979183125104747088116187584366205351152315709323988324491729476435566167017734911926070078152771437195128495335458854458923475782666648931612841151096923643810580803048301608534266786867097762790952153653675570921913681095277174947521916134
lower flag = pctf{lsb_is_4ll_y0u_ne3d}��p6�x�����ꕎ81���e�3�~��ę���4$pz9��� ���0en"��̥�o�cȣ���.*z��?n�ƨ>6�o���#���)g�jl�
multiplier = 212
sent ciphertext 50250755854349060273600748058347492460054410259628835643065315292422667886974689433086807089032905814811219345716171958732300878077805295946155889286309957357352555060432038801287412773647082525563214208397848831588353216532718958889969188087964218777646467718967423926109023022887010446083219487280951409895
oracle response: lsb is 0
```

at which point we can stop since we don't really need the rest 800 bits of padding and the flag is: `pctf{lsb_is_4ll_y0u_ne3d}`

###pl version

dostajemy [pliki serwera](server) więc możemy rozpocząc od analizy kryptosystemu.
okazuje się, że flaga jest szyfrowana kryptosystemem rabina, czyli szyfruje się poprzez `message^2 mod n`.
serwer podaje nam wartość modulusa `n` oraz wartość zaszyfrowanej flagi `ct`.
chcemy uzyskać wartość `pt = sqrt_mod(ct, n)`
serwer pozwala nam pytać o wartość najniższego bitu plaintextu dla wybranych przez nas ciphertextów.
to oznacza że serwer działa jako `wyroczna najniższego bitu` a my mamy to wykorzystać.

jeśli wyślemy zaszyfrowaną flagę jako dane do serwera, serwer powie nam jaki jest najniższy bit odszyfrownej flagi, a teraz potrzebujemy tylko pozostałe bity.
możemy exploitować wyrocznie za pomocą algorytmu poszukiwania binarnego.

jest dość oczywistym, że liczba pomnożona przez 2 będzie zawsze liczbą przystą.
to oznacza że lsb będzie zawsze 0.
teraz jeśli wykonamy dzielenie modulo przez liczbe nieparzystą to możemy uzyskać dwa wyniki:

- liczba jest mniejsza niż modulus więc jest nadal parzysta i lsb jest 0
- liczba jest większa niż modulus więc jest teraz nieparzysta i lsb wynosi 1

modulus n w naszym przypadku jest nieparzysty bo jest iloczynem dwóch dużych liczb pierwszych.
to oznacza że możemy spytać wyrocznie o lsb dla `2*pt mod n` i dostaniemy jedną z dwóch możliwości:

- jeśli lsb jest 0 to znaczy że liczba była mniejsza niż modulus więc `2*pt < n` z czego wynika `pt < n/2`
- jeśli lsb jest 1 to znaczy że liczba była większa niż modulus więc `2*pt > n` z czego wynika `pt > n/2`

jeśli etraz zapytamy o lsb dla `4*pt mod n` znów możemy uzyskać dwie możliwości:

- jeśli lsb jest 0 to albo `4*pt < n` z czego wynika `pt < n/4` jeśli `pt < n/2` lub `pt < 3*n/4` jeśli `pt > n/2`
- jeśli lsb jest 1 to albo `4*pt > n` z czego wynika `pt > n/4` jeśli `pt < n/2` lub `pt > 3*n/4` jeśli `pt > n/2`

to oznacza że możemy wyliczyć górne oraz dolne ograniczenie na `pt` pytając wyrocznie o lsb dla pt pomnożonego przez kolejne potęgi 2.
to jest dokładnie wyszukiwanie binarne - szukamy liczby `pt` a wyrocznia mówi nam czy jest ona większa czy mniejsza od pewnej liczby.

serwer wykonuje deszyfrowanie danych które wysyłamy, co oznacza że dokonuje na nich pierwiastkowania modularnego.
więc jeśli chcemy aby serwer podał nam lsb `2*pt mod n` to musimy podać jako dane `4*ct` ponieważ:

`sqrt_mod(4*ct, n) = sqrt_mod(4,n)*sqrt_mod(ct,n) = 2*pt mod n` 

automatyzujemy to prostym skryptem:

```python
def oracle(ciphertext, s):
    print("sent ciphertext " + str(ciphertext))
    s.sendall(str(ciphertext) + "\n")
    data = recvline(s)
    print("oracle response: " + data)
    lsb = int(re.findall("lsb is (.*)", data)[0])
    return lsb


def brute_flag(encrypted_flag, n, socket):
    flag_lower_bound = 0
    flag_upper_bound = n
    mult = 0
    ciphertext = (encrypted_flag * pow(4, mult)) % n
    while flag_upper_bound > flag_lower_bound:
        data = s.recv(512)
        ciphertext = (ciphertext * 4) % n
        mult += 1
        print("main loop: " + data)
        print("upper = %d" % flag_upper_bound)
        print("upper flag = %s" % long_to_bytes(flag_upper_bound))
        print("lower = %d" % flag_lower_bound)
        print("lower flag = %s" % long_to_bytes(flag_lower_bound))
        print("multiplier = %d" % mult)
        if oracle(ciphertext, socket) == 0:
            flag_upper_bound = (flag_upper_bound + flag_lower_bound) / 2
        else:
            flag_lower_bound = (flag_upper_bound + flag_lower_bound) / 2
    return flag_upper_bound
```

skrypt aktualizuje górne oraz dolne ograniczenie dla `pt` w zależności od odpowiedzi serwera
w efekcie dostajemy wreszcie:

```
main loop: give a ciphertext: 
upper = 220166400929873038171224043083387335590015857856801737690673880396419795615547577312678070179481369128029264724566861040868992922377738134245284720456363270069895363821431128690061826490011022637831305626391095236981088399616123236780868219333517868946867381881069203811100413120301449973114417385114578488
upper flag = pctf{lsb_is_4ll_y0u_ne3d}�mt�ҵņ�|o�a�.gȵ�j~r���rڟ��nl�����o��z�l����)�a�8{����mm�q1fܛ�h�[���"7���rɭei�h9��f�.8
lower = 220166400929873038171224043083387335590015857856801737690673855617979183125104747088116187584366205351152315709323988324491729476435566167017734911926070078152771437195128495335458854458923475782666648931612841151096923643810580803048301608534266786867097762790952153653675570921913681095277174947521916134
lower flag = pctf{lsb_is_4ll_y0u_ne3d}��p6�x�����ꕎ81���e�3�~��ę���4$pz9��� ���0en"��̥�o�cȣ���.*z��?n�ƨ>6�o���#���)g�jl�
multiplier = 212
sent ciphertext 50250755854349060273600748058347492460054410259628835643065315292422667886974689433086807089032905814811219345716171958732300878077805295946155889286309957357352555060432038801287412773647082525563214208397848831588353216532718958889969188087964218777646467718967423926109023022887010446083219487280951409895
oracle response: lsb is 0
```

i możemy tutaj przerwać obliczenia ponieważ nie potrzebujmemy pozostałych 800 bitów paddingu a flaga to: `pctf{lsb_is_4ll_y0u_ne3d}`
