##web 100 (web, 100p)

###pl
[eng](#eng-version)

w zadaniu dostajemy prostą stronę wyświetlającą ilość pieniędzy na koncie oraz okienko do aktywacji kodów. zostaje nam udostępniony jednorazowy kod doładowujący 10$.

po użyciu kodu dostajemy komunikat, że ciągle mamy za mało pieniędzy, zatem musimy znaleźć jakiś sposób na wielokrotne użycie tego samego kodu lub rozgryźć jak program weryfikuje kody. zaczęliśmy od łatwiejszego.

z kodami rabatowymi kojarzy się szczególnie jeden powszechny exploit: [race condtition](https://www.owasp.org/index.php/race_conditions).

usuwamy ciasteczka żeby pozbyć się sesji i wysyłamy parę zapytań z tym samym kodem jednocześnie, po odświeżeniu strony pokazują nam się najszybciej zarobione pieniądze w życiu, oraz flagę.

### eng version

we get a link to a webpage displaying the amount of money on our account and a form for submitting codes. we have a single-use code for 10$.

after we use this code we get an information that we still don't have enough money for the flag, so we assume we need to find a way to use the code multiple times or figure out how the system verifies the codes. we started with the simpler one.

there is a very common error with discount codes: [race condtition](https://www.owasp.org/index.php/race_conditions).

we remove cookies to get rid of current session (with already used code) and we send multiple requests at the same time. after the page loads we can see the fastest earned money in out lifes, and the flag.