##sanutf8y_check (web, 1p)

###pl
[eng](#eng-version)

po wejściu na stronę ukazuje nam się:


[image extracted text: 9447{thi8_
swhat_a
looks
like}_
fag]


nie możemy skopiować tego tekstu ze strony ponieważ są to jedynie dziwne unicodowe znaki wyglądające jak litery. musimy więc przepisać flagę:

9447{this_is_what_a_flag_looks_like}

### eng version

when we enter given website we see:


[image extracted text: 9447{thi8_
swhat_a
looks
like}_
fag]


we can't simply copy this text from webpage since those are strange unicode symbols resembling ascii characters. we need to type down the flag:

9447{this_is_what_a_flag_looks_like}
