# writeup backdoor ctf 2016

team: c7f.m0d3, akrasuski1, cr019283, nazywam, msm, shalom

### table of contents

* [dtune (misc)](misc_dtune)
* [mindblown (crypto)](crypto_mindblown)
* [worst-pwn-ever (pwn)](pwn_worst)
* [isolve (ppc)](ppc_isolve)
* busybee (forensics)
* [collision-course (crypto)](crypto_collision_course)
* [crc (crypto)](crypto_crc)
* enter-the-matrix
* [incomplete (forensics)](for_incomplete)
* debug (re)
* imagelover (web)
* [forge (crypto)](crypto_forge)
* lossless
* [infinite paths (web)](web_infinite_paths)
* [jigsaw (misc)](misc_jigsaw)
* [television (stegano)](stegano_television)