# writeup sharif ctf 2016

team: c7f.m0d3, msm, other019, nazywam, shalom, akrasuski1

### table of contents
* [rail dence cipher (crypto) 50](crypto_50_railfence)
* [ure (crypto) 100](crypto_100_ure)
* [high-speed rsa keygen (crypto) 150](crypto_150_keygen)
* [hail zeus (crypto) 300](crypto_300_zeus)
* [dmd (reverse) 50](re_50_dmd)
* [srm (reverse) 50](re_50_srm)
* [android app (reverse) 100](re_100_android)
* [interpolation (reverse) 200](re_200_interpolation)
* [serial (reverse) 150](re_150_serial)
* [hackme (web) 400](web_400_hackme)
* login to system (pwn) 200
* [sql (pwn) 150](pwn_150_sql)
* [kiuar (pwn) 200](pwn_200_kiuar)
* [kick tort teen (forensics) 50](for_50_tort)
* [dumped (forensics) 100](for_100_dumped)
* [we lost the fashion flag (forensics) 100](for_100_fashion)
* [uagent (forensics) 100](for_100_uagent)
* network forensics (forensics) 200
* [blocks (forensics) 400](for_400_blocks)
* [asian cheetah (misc) 50](misc_50_cheetah)
* [hack by the sound (misc) 200](misc_200_hacksound)
* [impossible game (misc) 300](misc_300_impossible)
* [seccoding 1 (misc) 100](misc_100_seccoding1)
* [seccoding 2 (misc) 300](misc_300_seccoding2)
