# seccon 2017 quals

team: c7f.m0d3, cr019283, akrasuski1, nazywam, shalom, rev

### table of contents

* [sqlsrf (web)](web_sqlsrf)
* [ps and qs (crypto)](crypto_ps_and_qs)
* [vigenere 3d(crypto)](crypto_vigenere)
* [simon and speck block ciphers (crypto)](crypto_simon)
* [jpeg file (misc)](misc_jpeg)
* [very smooth (crypto)](crypto_smooth)
* [automatic door (web)](web_automatic)
