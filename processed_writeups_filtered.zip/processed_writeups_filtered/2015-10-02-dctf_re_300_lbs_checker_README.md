﻿## reverse 300 (re, 300p)

### pl
[eng](#eng-version)

dostajemy [program](./r300.exe) (tym razem pe windowsowe), który pobiera od usera parę username:hasło. mamy zdobyć hasło dla użytkownika "administrator".

okazuje się dodatkowo że są zabezpieczenia przed bezpośrednim zapytaniem o hasło dla usera "administrator".

program po kolei:
 - pyta o username
 - pyta o hasło
 - sprawdza czy w username występuje litera "a" - jeśli tak, to hasło nie będzie poprawnie generowane.
 - następnie sprawdza czy hasło ma odpowiednią długość (zależną od nicka - chyba zależność to długość_nicka - 1, ale nie sprawdzaliśmy). jeśli nie, znowu, nie będzie błędu ale sprawdzenie wykona się niepoprawnie.
 - następnie następuje sprawdzenie hasła:

```
for (int i = 0; i < strlen(password) - 1; i++) {
    if (!cbc_password_check(dużo obliczeń matematycznych na i, password[i])) {
        return false;
    }
}
```

 - poszliśmy na łatwiznę (a raczej, wybraliśmy optymalne rozwiązanie) - nie reversowaliśmy algorytmu, tylko śledziliśmy co robi funkcja cbc_password_check w każdej iteracji. robiła ona dużo obliczeń na username, i na podstawie tego sprawdzała jaka powinna być kolejna litera hasła i wykonywała porównanie. wystarczyło "prześledzić" raz przebieg tej funkcji, w debuggerze pominąć returny, i mieliśmy gotowe hasło.

z tego odczytaliśmy wymagane hasło dla administratora: `#y1y3#y1y3##` i zdobyliśmy flagę.

### eng version

we get a [binary](./r300.exe) (this time a windows pe), which takes user:password pair as input. we need a password for "administrator" user.

there are some additional protection against directly asking for password for "administrator" user.

the binary:
 - asks for username
 - asks for password
 - checks if there is letter "a" in the useraname - if so, the password will not be generated correctly.
 - then it checks is the password has a proper length (depending on the usernaem - something like username_length -1, but we didn't check). if no, again it will not show any errors byt password check will fail.
 - then there is the actual password check:

```
for (int i = 0; i < strlen(password) - 1; i++) {
    if (!cbc_password_check(a lot of mathematical compuations over i, password[i])) {
        return false;
    }
}
```

- we took the easy path (or the optmimal solution) - we didn't try to reverse the algorithm, but we tracked what the cbc_password_check function was doing in each iteration. it was doing a lot fo computations on username and then it was using this to check what should be the next password letter and was doing the comparison. we only had to "track" this function once in a debugger, skip returns and we had the password.

with this approach we got the password for administrator: `#y1y3#y1y3##` and we got the flag.