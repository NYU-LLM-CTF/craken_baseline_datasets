## bodu (crypto, 175p)

###pl
[eng](#eng-version)

zostają nam dane [klucz publiczny](pub.key) i [zaszyfrowana wiadomość](flag.enc), zacznijmy od spojrzenia jak wygląda klucz publiczny:


[image extracted text: bodu
bash
80x27
michas-macbook-air:bodu michals
openssl
~pubin -inform
pem
text
noout
moculus
(1018
03:a6:16:08:48:fb:17
cb:co: fa:22:ce:f5:82:
28.40
c0:45=
c5:15:02:55:6b:64:76:00
73:97:f0:
87:c6:f3:53:
61:
23332
c9:=
35:3f:12:a0:
8e:c6: ze:
:3c:47
b8:
444884
73:15:
:01:4b:80:a6:93:02:e5:8b:12:3f:
25:-
56:b1:eb:a0:37:a4:dc:ac:80:8d:e8:09:
16:7a:6f:cc:30:c5:c7:85
exponent=
03:65:96:ze: 8d:
ba:92:fc:08:76:8a:5f:73:
63:85:4f:4c:79:96:90:55.18.a0:78.a0:34:43:7c:
46:69:bd:b7:05:be: 40:8b:8b:ab:f4:fd:al:a6:e7
15:26
ec:
e0: 27:26:a2:7f:b8:
72:18:63
;:z6:82:20:
:20:f5:83:68: 8e:55:67:eb:10:72:
9b:b0:
e4:0c:57:19:80:76:
4f:10:63:3e:se:27:7d:a3:03:28:le:ce:zc:ez:eb:
f9:45
be: sa:fc:3e
78:49
be:c0: 48:9b:24:59:
96:64:fe:15:c8:8a:33
michas-ma
book-air:bocu
michals
key
bit)]


od razu rzuca się w oczy dosyć spory exponent (najczęściej widzi się należące do liczb pierwszy fermata, a więc `3, 5, 17, 256, 65536`)

czyli szukamy jakiegoś ataku na rsa(możliwe, że exponent), z pomocą przychodzi nam [boneh durfee attack](https://github.com/mimoo/rsa-and-lll-attacks/blob/master/boneh_durfee.sage)

użycie sprowadza się do podstawienia naszego n i e, po chwili dostajemy:

`=== solutions found ===
x: 166655144474518261230652989223296290941028672984834812738633465334956148666716172
y: -1620506135779940147224760304039194820968390775056928694397695557680267582618799089782283100396517871978055320094445221632538028739201519514071704255517645
d: 89508186630638564513494386415865407147609702392949250864642625401059935751367507

=== 0.260915994644 seconds ===`

[podstawiamy](solve.py) do `pow(ciphertext, d, n)` iiiii....


[image extracted text: desktop
pash
box13
michas-mac
book-ilrdes
ktop
michals
python
solve.yp
traceback
(mo;-
cent
call
last)
file
solve.yp
line
rmooue 
print
(hex( e
leartext) [2:] [:-1]
:cecoce
hex"
file
{system/library/
rameworks python.
mework/versions/2.t/lib/python2
7/e
ncodings/hex
cocec
line
hex_cecoce
output
binas
a2b_hex( input)
typeerror:
odd-length string
michas-macbook-air:desktop michals]


to nie dobrze, może spróbujemy dodać `0` na początku?

`)ò~ðãüéûaû¨0jàîr|¹â|ú÷û5ù° r'{§¯0âëúj4þ¤<úô!eþx}êïî³ë?g/óf>gá}þ74|ú(¾¶hasis{b472266d4dd916a23a7b0deb5bc5e63f}`

### eng version

in this task, we're given a [public key](pub.key) and a [encrypted message](flag.enc), let's start by looking inside the public key:


[image extracted text: bodu
bash
80x27
michas-macbook-air:bodu michals
openssl
~pubin -inform
pem
text
noout
moculus
(1018
03:a6:16:08:48:fb:17
cb:co: fa:22:ce:f5:82:
28.40
c0:45=
c5:15:02:55:6b:64:76:00
73:97:f0:
87:c6:f3:53:
61:
23332
c9:=
35:3f:12:a0:
8e:c6: ze:
:3c:47
b8:
444884
73:15:
:01:4b:80:a6:93:02:e5:8b:12:3f:
25:-
56:b1:eb:a0:37:a4:dc:ac:80:8d:e8:09:
16:7a:6f:cc:30:c5:c7:85
exponent=
03:65:96:ze: 8d:
ba:92:fc:08:76:8a:5f:73:
63:85:4f:4c:79:96:90:55.18.a0:78.a0:34:43:7c:
46:69:bd:b7:05:be: 40:8b:8b:ab:f4:fd:al:a6:e7
15:26
ec:
e0: 27:26:a2:7f:b8:
72:18:63
;:z6:82:20:
:20:f5:83:68: 8e:55:67:eb:10:72:
9b:b0:
e4:0c:57:19:80:76:
4f:10:63:3e:se:27:7d:a3:03:28:le:ce:zc:ez:eb:
f9:45
be: sa:fc:3e
78:49
be:c0: 48:9b:24:59:
96:64:fe:15:c8:8a:33
michas-ma
book-air:bocu
michals
key
bit)]


the exponent seems quite high(you usually see exponents from the set of fermat primes, `3, 5, 17, 256, 65536`)

so we're looking for an rsa attack(possibly including the high exponent), after some googling we come across a [boneh durfee attack](https://github.com/mimoo/rsa-and-lll-attacks/blob/master/boneh_durfee.sage)

using it comes down to just entering our n and e, after a while of computing the program outputs:

`=== solutions found ===
x: 166655144474518261230652989223296290941028672984834812738633465334956148666716172
y: -1620506135779940147224760304039194820968390775056928694397695557680267582618799089782283100396517871978055320094445221632538028739201519514071704255517645
d: 89508186630638564513494386415865407147609702392949250864642625401059935751367507

=== 0.260915994644 seconds ===`

great, let's try to decipher the message using that d by [calculating](solve.py) the value of pow(ciphertext, d, n)


[image extracted text: desktop
pash
box13
michas-mac
book-ilrdes
ktop
michals
python
solve.yp
traceback
(mo;-
cent
call
last)
file
solve.yp
line
rmooue 
print
(hex( e
leartext) [2:] [:-1]
:cecoce
hex"
file
{system/library/
rameworks python.
mework/versions/2.t/lib/python2
7/e
ncodings/hex
cocec
line
hex_cecoce
output
binas
a2b_hex( input)
typeerror:
odd-length string
michas-macbook-air:desktop michals]


that's weird, maybe a 0 at the beginning will help?

`)ò~ðãüéûaû¨0jàîr|¹â|ú÷û5ù° r'{§¯0âëúj4þ¤<úô!eþx}êïî³ë?g/óf>gá}þ74|ú(¾¶hasis{b472266d4dd916a23a7b0deb5bc5e63f}`
