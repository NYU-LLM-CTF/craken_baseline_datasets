# very smooth (crypto, 300p)

in the task we get a [pcap](s.pcap) with rsa encrypted ssl traffic.
the task name suggests that maybe the rsa modulus or primes are a smooth number and modulus can be factored in some simple way.

first we open the pcap in network miner in order to recover the [server certificate](srl.cer).
next we use openssl to dump just the rsa key from the certificate `openssl x509 -inform der -pubkey -noout -in srl.cer > public_key.pem` which gives us [public key](public_key.pem).

now we can proceed with factoring the key.
it turns out the williams p+1 method works because one of the primes is of form `11807485231629132025602991324007150366908229752508016230400000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001` so `prime-1` is a smooth number.

once we factored the modulus we can generate a fake server private key:

```python
from crypto.publickey import rsa
from primefac import williams_pp1, modinv


def main():
    pub = """-----begin public key-----
migfma0gcsqgsib3dqebaquaa4gnadcbiqkbgqdvrqqcxpyd6xdl9gt7/kijryvy
8lohddasi28qwmxce2cdwuwzkzdb3r9nenuxshqweuugjbwjwifjnmnvwurhjcyj
duddp+4x8c9jtvcaltgd+basjo2eb0f+uisl/9/4nn+vr3flirm2mbyefcjpptql
yioxcqbxyimxgo4ncqidaqab
-----end public key-----
"""
    pub = rsa.importkey(pub)
    print(pub.e, pub.n)
    p = long(williams_pp1(pub.n))
    q = pub.n / p
    print(p,q)
    assert pub.n == p * q
    priv = rsa.construct((pub.n, pub.e, modinv(pub.e, (p - 1) * (q - 1))))
    print(priv.exportkey('pem'))


main()
```

we then use this key in wireshark (edit -> preferences -> protocols -> ssl -> rsa key list) and it decrypts the ssl traffic for us.
we can see the webpage:

```html
<html>
<head><title>very smooth</title></head>
<body>
<h1>
answer: one of these primes is very smooth.
</h1>
</body>
</html>
```

and the flag is: `seccon{one of these primes is very smooth.}`
