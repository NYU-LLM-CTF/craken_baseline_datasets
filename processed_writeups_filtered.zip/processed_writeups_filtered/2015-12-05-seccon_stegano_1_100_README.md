## steganography 1 (stegano, 100p)

    find image files in the file
    
[image extracted text: [image processing failed]]

    please input flag like this format-->seccon{*** ** **** ****}

###pl
[eng](#eng-version)

dostajemy plik o rozszerzeniu .gpjb. polecenie `file` rozpoznaje go jako gif:


[image extracted text: [image processing failed]]


ale po otworzeniu tego pliku w hexedytorze okazuje się że plik ten składa się w rzeczywistości z dużej liczby obrazów sklejonych w jeden.
domyślamy się że "gpjb" pochodzi od rozszerzeń .gif, .png, .jpg oraz .bmp.

piszemy na szybko skrypt w pythonie który dzieli te pliki na fragmenty (szukając odpowiednich headerów formatów):

```python
import re

data = open('mrfusion.gpjb', 'rb').read()

def findndx(str, data):
    return [m.start() for m in re.finditer(str, data)]

ext = {
    '.gif': 'gif89a',
    '.png': '\x89png',
    '.bmp': 'bm',
    '.jpg': '\xff\xd8\xff\xe0'
}

for ext, pat in ext.iteritems():
    for n in findndx(pat, data):
        open('out.' + str(n) + ext, 'wb').write(data[n:])
```

następnie uruchamiamy go i otrzymujemy sporo obrazów, z których każdy odpowiada jednemu znakowi:


[image extracted text: secconi
mrfusion gpjb
out,ogif
out;
6943 png
out.9727jpg
out,26632.
0ut,2791486.gif
out,2794240.png
out.2796217jpg
out.2813627.bmp
0ut.5578481,gif
out,5580896.png
0ut,5583378jpg
out.5601221,bmp
out.8366075,gif
out.8368830 png
out.8371932jpg
solver;py
bmp]


po przepisaniu:

    seccon{oct2120150728}

z powodu błedu w zadaniu flaga nie przechodziła sprawdzenia, więc do opisu zadania doszła informacja o wymaganym formacie flagi, więc ostateczna flaga:

    seccon{oct 21 2015 0728}


### eng version

we are given a file with .gpjb extension. `file` command recognises it as a gif:


[image extracted text: [image processing failed]]


but after checking the file in hexeditor it turns out that the file is composed of large number of concantenated images.
we guess that "gpjb" extension stands for gif, png, jpg and bmp file formats.

we have written quick and dirty script to split file into fragments (according to format headers):

```python
import re

data = open('mrfusion.gpjb', 'rb').read()

def findndx(str, data):
    return [m.start() for m in re.finditer(str, data)]

ext = {
    '.gif': 'gif89a',
    '.png': '\x89png',
    '.bmp': 'bm',
    '.jpg': '\xff\xd8\xff\xe0'
}

for ext, pat in ext.iteritems():
    for n in findndx(pat, data):
        open('out.' + str(n) + ext, 'wb').write(data[n:])
```

after execution, script generated a lot of images, each of which represented single flag character:


[image extracted text: secconi
mrfusion gpjb
out,ogif
out;
6943 png
out.9727jpg
out,26632.
0ut,2791486.gif
out,2794240.png
out.2796217jpg
out.2813627.bmp
0ut.5578481,gif
out,5580896.png
0ut,5583378jpg
out.5601221,bmp
out.8366075,gif
out.8368830 png
out.8371932jpg
solver;py
bmp]


after rewrite:

    seccon{oct2120150728}

but because of bug in challenge checker, flag was not accepted by server. after that, description of challenge was changed, and final, accepted flag is:

    seccon{oct 21 2015 0728}
