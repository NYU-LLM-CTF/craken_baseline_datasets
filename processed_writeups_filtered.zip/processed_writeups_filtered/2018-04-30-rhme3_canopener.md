# can opener, can, 150pts

> our operatives have recovered a delorean in the ruins of an old mid-west us town. it appears to be locked, but we have successfully accessed its internal communications channels. according to the little data we have, the delorean internally uses an archaic technology called can bus. we need you to analyze the communications and find a way to unlock the vehicle; once unlocked, recover the secret flag stored inside. we have reason to believe that vehicle entry should be a fairly easy challenge, but to aid you in this, we have restored and reconnected the vehicle dashboard.

> best of luck.

> the dashboard app is available here.

> challenge developed by argus cyber security.

this was first of the challenges related to can bus. the board we got
has two can controllers, connected to each other, allowing the avr
chip to talk to itself (in a loopback mode, so to say). apparently
it was sending messages through one interface to the other, to simulate
full, car-wide can bus. connecting
logic analyzer to the can bus we could sniff the sent messages. 

one of those was particularly interesting - `lock\x00\x00\x00\x00`.
we could only think that the opposite of it would be `unlock\x00\x00`...
at this point of time, i had no can hardware, but i had... arduino.
so i wrote a software implementation of can bus:
https://gist.github.com/akrasuski1/b1904966c4de0b50672e6fc1fd116d3e
it's not very efficient, does absolutely no error-checking, and the
code quality is quite poor, but it was enough to send the unlock message.
after the board received it, it sent the flag through uart interface to the
dashboard.