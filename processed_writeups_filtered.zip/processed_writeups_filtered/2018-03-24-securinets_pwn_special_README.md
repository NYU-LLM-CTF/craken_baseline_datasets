# special (pwn)

a classic restricted shell jailbreak task.
we can ssh to a server and we get access via some kind of restricted shell.
it's all blackbox, so we need to poke around a bit to figure out what we can and can't do.

we get only messages from stderr, which makes things a bit harder.
sending some random payloads tells us that our commands are executed via `bash -c "cmd"`.
there is also some input filtration applied.

we can send as command `$pwd` which shows error `bash: /home/special: is a directory`.
this is very useful, because we can send for example `$pwdabcdefg....` and in the error log we get back the string without the filtrated characters.
from this we know that we can use `{}|;:<>$'#^_+-` and all uppercase letters.

next we proceed with testing bash special variables, and from this we get an interesting result for `$_`:

```
declare -x a="t"
declare -x ab="hi"
declare -x abc="isn"
declare -x abcd="otth"
declare -x abcde="eflag"
declare -x abcdef="butmay"
declare -x abcdefg="beitcan"
declare -x abcdefgh="helpgett"
declare -x abcdefghi="ingflag:d"
declare -x oldpwd
declare -x pwd="/home/special"
declare -x shell=""
declare -x shlvl="1"
declare -x _="export"
```

now what we want to do, is to create some meanigful command.
sadly we don't have `()` so we can't do any `calculations` and therefore create numbers.
the intended solution was to use `${#variable_name}` to get length of the variable, and thus get some numbers, but we didn't know that...

what we can do is to use `${variable:k:n}` which is a substring from index `k` with length `n`.
we have only `$shlvl` which has value `1` and `$#` with value `0`, and with those we can get:

```
slash -> ${pwd::$shlvl}
h -> ${-::$shlvl}
a -> ${pwd:$shlvl$shlvl:$shlvl}
i -> ${pwd:$shlvl$#:$shlvl}
e -> ${_:$#:$shlvl}
x -> ${_:$shlvl:$shlvl}
```

again, the intended solution was to get `s` and `h` and spawn a shell, but we didn't have `s`.
fortunately we figured out that we can run `ex` command, which spawns `vim`!

from `vim` we can simply run `:!sh` to spawn a shell, and read the flag: `flag{b4sh_subst1tut1on_is_gud!}`
