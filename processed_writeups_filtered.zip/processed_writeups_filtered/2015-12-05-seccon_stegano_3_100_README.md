##steganography 3 (stegano, 100p)

```
we can get desktop capture!
read the secret message.
```

###pl
[eng](#eng-version)

dostajemy obraz:


[image extracted text: bz
(mem)
j74jl(f)
he(e)
r(v)
#m(j)
v-jlt)
vvt(h)
2 ? &
+1 +2 +3 +4 +5 +6 +7 +8 +9 +4 +b +c +d +e +f
0123456789abcdef
45 4c 46
elf
this problem can be sol.
wrmxv
sbaokmre_
w-jt)
nvj(h)
ews
sports
finance
weather
games
answers
screen
bafn
search answers
search web
#ut2lzzl etu3k0032367
4oa-fmnyrouv?
2 28t2.44r77171
#ovn-f9a
3 #pzt_"piti3
ainment & music
jokes & riddles
next
this problem can be solved by pre-school
children:
who knows the answer?
cantt
figure it out !l?
this problem can be solved by pre-school children in 5-10 minutes
by pro-
gramer
hour; by people with higher education
well, check it yourselfl
show more
following
10 answers
cocoboolh
ccount
sian
join for froo tadaul
mr8
atyk
jr(jl
t-h
rt
d19s
enjju
1501j6
jr
js>
ae
#or
2o
swhw3
jibjt
eie
bz
flag (mem)
7741l(f)
re(e)
br(v)
'e(j)
j-jt)
nvj(h)
+2 +3
+b +c +0 + +
0123456789abcdef
qooooo
45 4c 46 01
03-q0
00 00 q0 q0 00 00
elf _
000010
02 00 03 00 01
00 00 00-35
80 04
20 03 q0 00
qqquzu
uu  qu
000030
00 00 00 q0
04 08
ready
oooooo: ox7f (127)
832 bvtes
000040
eb q0
-80
ozwrm
flag]


na podstawie którego chcemy uzyskać flagę. pierwszym krokiem jest odtworzenie binarki otwartej w hexedytorze. zrobiliśmy to za pomocą ocra a następnie ręcznego poprawiania błędów. wynikiem jest program [elf](elf.bin).
uruchomienie go daje w wyniku wiadomość `flood fill` zakodowaną jako base64. po pewnym czasie wpadliśmy wreszcie na rozwiązanie, które polegało na użyciu "wypłeniania kolorem" na początkowym obrazie:


[image extracted text: bz
(mem)
j74jl(f)
#a(e)
r(v)
#e(j)
v-jlt)
vvt(h)
+=
9 ? %
+0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +4 + +c + +e +f
0123456789abcdef
this problem can be sol.
w-jt)
nvj(h)
ews
sports
finance
weather
games
answers
screen
search answers
search web
#ut2lzzl etu3k0032367
4oa-fmnyrouv?
2 28t2.44r77171
#ovn-f9a
3 #pzt_"piti3
ainment & music
jokes & riddles
next
this problem can be solved by pre-school
children:
who knows the answer?
cantt
figure it out !l?
this problem can be solved by pre-school children in 5-10 minutes
by pro-
gramer
hour; by people with higher education
well, check it yourselfl
show more
following
10 answers
cocoboolh
ccount
sian
join for froo tadaul
mr8
atyk
jr(jl
t-h
rt
0z
d19s
enjju
1501j6
jr
js>
ae
#or
2o
jibjt
eie
bz
flag (mem)
7741l(f)
re(e)
#r()
'e(j)
j-jt)
nvj(h)
+2 +3
+b +c +0 + +
0123456789abcdef
qooooo
45 4c 46 01
03-q0
00 00 q0 q0 00 00
elf _
000010
02 00 03 00 01
00 00 00-35
80 04
20 03 q0 00
000020
00 u0 u0
000030
00 00 00 q0
04 08
ready
oooooo: oxzf (127)
832 bvtes
000040
eb q0
-80
ozwrm
flag]


co daje nam flage:

`seccon{the_hidden_message_ever}`

### eng version

we get a picture:


[image extracted text: bz
(mem)
j74jl(f)
he(e)
r(v)
#m(j)
v-jlt)
vvt(h)
2 ? &
+1 +2 +3 +4 +5 +6 +7 +8 +9 +4 +b +c +d +e +f
0123456789abcdef
45 4c 46
elf
this problem can be sol.
wrmxv
sbaokmre_
w-jt)
nvj(h)
ews
sports
finance
weather
games
answers
screen
bafn
search answers
search web
#ut2lzzl etu3k0032367
4oa-fmnyrouv?
2 28t2.44r77171
#ovn-f9a
3 #pzt_"piti3
ainment & music
jokes & riddles
next
this problem can be solved by pre-school
children:
who knows the answer?
cantt
figure it out !l?
this problem can be solved by pre-school children in 5-10 minutes
by pro-
gramer
hour; by people with higher education
well, check it yourselfl
show more
following
10 answers
cocoboolh
ccount
sian
join for froo tadaul
mr8
atyk
jr(jl
t-h
rt
d19s
enjju
1501j6
jr
js>
ae
#or
2o
swhw3
jibjt
eie
bz
flag (mem)
7741l(f)
re(e)
br(v)
'e(j)
j-jt)
nvj(h)
+2 +3
+b +c +0 + +
0123456789abcdef
qooooo
45 4c 46 01
03-q0
00 00 q0 q0 00 00
elf _
000010
02 00 03 00 01
00 00 00-35
80 04
20 03 q0 00
qqquzu
uu  qu
000030
00 00 00 q0
04 08
ready
oooooo: ox7f (127)
832 bvtes
000040
eb q0
-80
ozwrm
flag]


and we want to get a flag based on this. first step is to recreate the binary open in hexeditor. we used ocr and then fixed defects by hand. this way we got [elf binary](elf.bin).
running it give a message `flood fill` encoded as base64. after a while we finally figured the solution, which was to use "flood fill" on the initial picture:


[image extracted text: bz
(mem)
j74jl(f)
#a(e)
r(v)
#e(j)
v-jlt)
vvt(h)
+=
9 ? %
+0 +1 +2 +3 +4 +5 +6 +7 +8 +9 +4 + +c + +e +f
0123456789abcdef
this problem can be sol.
w-jt)
nvj(h)
ews
sports
finance
weather
games
answers
screen
search answers
search web
#ut2lzzl etu3k0032367
4oa-fmnyrouv?
2 28t2.44r77171
#ovn-f9a
3 #pzt_"piti3
ainment & music
jokes & riddles
next
this problem can be solved by pre-school
children:
who knows the answer?
cantt
figure it out !l?
this problem can be solved by pre-school children in 5-10 minutes
by pro-
gramer
hour; by people with higher education
well, check it yourselfl
show more
following
10 answers
cocoboolh
ccount
sian
join for froo tadaul
mr8
atyk
jr(jl
t-h
rt
0z
d19s
enjju
1501j6
jr
js>
ae
#or
2o
jibjt
eie
bz
flag (mem)
7741l(f)
re(e)
#r()
'e(j)
j-jt)
nvj(h)
+2 +3
+b +c +0 + +
0123456789abcdef
qooooo
45 4c 46 01
03-q0
00 00 q0 q0 00 00
elf _
000010
02 00 03 00 01
00 00 00-35
80 04
20 03 q0 00
000020
00 u0 u0
000030
00 00 00 q0
04 08
ready
oooooo: oxzf (127)
832 bvtes
000040
eb q0
-80
ozwrm
flag]


which gives us a flag:

`seccon{the_hidden_message_ever}`