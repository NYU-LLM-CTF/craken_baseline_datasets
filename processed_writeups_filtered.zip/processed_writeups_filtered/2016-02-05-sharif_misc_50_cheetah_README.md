## asian cheetah (misc, 50p)

    we have hidden a message in png file using jar file. flag is hidden message. flag is in this format:

    sharifctf{flag}

    download cheetah.tar.gz

###eng
[pl](#pl-version)

in this task we had an image and a java program used to hide flag in it. decompiling the program allows us to notice
that least significant bits are used to hide the message. we can easliy get the flag using the following script:
```
from pil import image

im=image.open("asiancheetah1.png")
l=list(im.getdata())
b=[]
for x in l:
    b.append(x[2]&1)

s=[]
for i in range(100):
    c=0
    for j in range(8):
        c*=2
        c+=b[i*8+j]
    s.append(chr(c))
print repr("".join(s))
```

###pl version

w zadaniu dostaliśmy obrazek i program w javie, którego użyto do ukrycia w nim flagi. dekompilacja programu pozwala
nam dostrzec fakt użycia najmłodszych bitów do zakodowania wiadomości. flagę możemy otrzymać używając tego skryptu:
```
from pil import image

im=image.open("asiancheetah1.png")
l=list(im.getdata())
b=[]
for x in l:
    b.append(x[2]&1)

s=[]
for i in range(100):
    c=0
    for j in range(8):
        c*=2
        c+=b[i*8+j]
    s.append(chr(c))
print repr("".join(s))
```
