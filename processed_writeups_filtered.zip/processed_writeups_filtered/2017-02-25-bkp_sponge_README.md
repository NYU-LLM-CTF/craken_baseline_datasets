# sponge (crypto, 200)

> i've written a hash function. come up with a string that collides with "i love
> using sponges for crypto".

the hash function we were given in this task, was simply xoring the 16-byte state with 10-byte input block, and then
encrypting with aes. if the blocks were 16-byte, the collision would be trivial to find, as we know the aes key:
```
result = state2 = aes(block1 xor aes(block0 xor state0)) = aes(block1 xor aes(block0))
aesd(result) = block1 xor aes(block0)
block1 = aesd(result) xor aes(block0)
```
so, we would be able to choose any `block0` other than original, and xor it with aes-decrypted final state to get needed
block1 for collision.

unfortunately, the blocks were 10-byte long, which meant we did not control the top 6 bytes supplied to the aes.
while the attack above would still work in some cases, we would have to calculate approximately `2**48` aes en- or decryptions.
this is not unreasonable, but we would probably run out of time during the ctf anyway. so, we wrote the state
of the hash after three blocks: (`a`, `b` and `c` are first three blocks, `d` is the final state)
```
aes(aes(a) xor b) xor c = d
aes(aes(a) xor b) =       d xor c
    aes(a) xor b  = aesd( d xor c )
               b  = aesd( d xor c ) xor aes(a)
```
so the middle block is a xor of two pseudorandom values. we control most of `a` and `c`, so we can generate a lot of values
of `aesd(d xor c)` and `aes(a)`. if they somehow end up with the same last 6 bytes, their xor with have 6 zeroes at the
end, so we will find colliding `b`.

naive random generation of `c` and `a` would still take too long (no speed improvement in fact), but we can use 
*meet in the middle* technique. we precalculate `2**24` values of `aesd(d xor c)` and remember them in an efficient
data structure, such as hashmap, and then proceed to randomly genrating `aes(a)`, checking for each value (in constant time!)
if there is any corresponding element in the map that ends with the same 6 bytes. this takes reasonable amount of time
(although implemented in python, only around a minute or so). finally, we paste together `a`, `b`, `c` and `'o'` (the last
character of the original text) to get a final collision to submit.
