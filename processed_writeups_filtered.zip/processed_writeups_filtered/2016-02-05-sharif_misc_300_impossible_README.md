## impossible game (misc, 300p)

    imposible game http://ctf.sharif.edu:38455/chal/img/impossiblegame.html

    download server.py

###eng
[pl](#pl-version)

we were given source code of server and had to play a game with it to get the flag. reading the source code immediately
reminded me an old riddle, available 
[here](http://robertheaton.com/2014/01/13/mathematicians-hate-civil-liberties-100-prisoners-100-boxes/).
solution is also given on that webpage - i recommend everyone to read it, it's really surprising.

source of our solution is in `doit.py`.

###pl version

dostaliśmy kod źródłowy serwera i mieliśmy z nim wygrać w grę, by otrzymać flagę. przeczytanie kodu natychmiast przypomniało
mi starą zagadkę logiczną, dostępną 
[tutaj (po angielsku)](http://robertheaton.com/2014/01/13/mathematicians-hate-civil-liberties-100-prisoners-100-boxes/).
rozwiązanie również jest w tym linkiem. polecam jego przeczytanie - rozwiazanie jest naprawdę zaskakujące i nieintuicyjne.

źródło naszego rozwiązania jest w `doit.py`.
