# star ctf 2018

team: c7f.m0d3, akrasuski1, ppr, shalom, nazywam, eternal

### table of contents

* [milktea (re)](milktea)
* [primitive (crypto)](primitive)
