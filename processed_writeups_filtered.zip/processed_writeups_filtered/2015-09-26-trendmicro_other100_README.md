# fix my pdf (misc, 100p)

## pl 
`for eng scroll down`

dostajemy [taki oto pdf](fix_my_pdf.pdf) od autorów zadania.

wszelkie próby załadowania go do jakiegoś czytnika pdf kończą się niepowodzeniem - wyraźnie wygląda na uszkodzony.

możemy jeszcze otworzyć go z ciekawości w notepadzie/vimie/emacsie żeby przyjrzeć sie jego wewnętrzenej strukturze - niestety wszystkie streamy w pdfie są skompresowane, co oznacza że ręcznie ich nie podejrzymy.

w tym momencie należy więc skorzystać z jakiegoś narzędzia do dumpowania streamów pdfa. do głowy przychodzi qpdf, ale jako dzieci windowsa wybieramy prostsze narzędzie - pdf stream dumper.

ładujemy pdf, i jeden ze streamów wydaje sie ciekawszy (dla oka ludzkiego) niż pozostałe - zawiera xml z metadanymi. szczególnie ciekawa jest zawartość `<xmpgimg:image>` - dekodujemy więc ją i zapisujemy do oddzielnego pliku (pamiętając żeby zamienić/usunąć wcześniej ciągi `&#xa;` z base64 - autor tego writeupa zapomniał o tym na początku i już myślał że jego pomysł na zadanie okazał się ślepą uliczką).

otrzymujemy taki oto obrazek:


[image extracted text: trend
seourng ycur journty
r 0"
to the cloud
mctf(tere i5 aubys light byidd the clolds }]


odczytujemy z niego flagę: tmctf{there is always light behind the clouds}.

## eng

we get [this pdf file](fix_my_pdf.pdf) from the task authors.

all attempts to open it with a pdf reader fail - it seems to be broken.

we can still open it with notepad/vim/emacs to look at the internal structure -  unfortunately all pdf streams are compressed so we can't easily read them.

we decided to use a pdf stream dump tool. we could have used qpdf but since we're on windows at the moment we chose a different tool - pdf stream dumper.

we load the pdf and one of the streams seems more interesting than the others (at least from human point of view) - it contains xml with metadata.
particularly insteresting is `<xmpgimg:image>` - we decode this and we save it to a different file (remembering to replace/remove `&#xa;` from base64 - author of this writeup forgot about this initially and almost assumed that his approach to solve the task was incorrect)

we finally get this picture:


[image extracted text: trend
seourng ycur journty
r 0"
to the cloud
mctf(tere i5 aubys light byidd the clolds }]


we read the flag from it: `tmctf{there is always light behind the clouds}.`
