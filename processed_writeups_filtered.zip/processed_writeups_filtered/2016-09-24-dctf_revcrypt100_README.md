#  bad otpxploited (revcrypt 100)

> security buzzwords are used by companies and individuals everywhere althought not all of them even follow good practices, some even provide closed source implementations. someone published his own otp library on a subreddit and claims it's unbeatable. is it? 10.13.37.41 

> https://dctf.def.camp/quals-2016/mypam.bin

the binary in the task was a shared library implementing a couple of functions, such as `pam_sm_authenticate`. googling
it revealed it's `pluggable authentication module`, used for example as ssh authentication extension. the algorithm was
simple: the user was compared to hardcoded `dctf`, and the password was also constant string concatenated with current date
and time, precise up to minute. after logging in to ssh server running on given ip with found credentials, we received the flag.
