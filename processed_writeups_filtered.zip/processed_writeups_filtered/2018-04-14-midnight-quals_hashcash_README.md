# hashcash - pwn (150 + 0), 13 solves

> shall we play a game? we need help beta testing our fancy new cryptocurrency themed lottery game. there may just be a bounty in it for you if you can pwn it.

in this task we were given a binary and `host:port` of the server. we actually solved the task withouth the binary, 
in a blackbox, probably unintended, way.

basic communication with the server was that it was sending us one byte nonce and difficulty level, then
we have to send input such that `md5(nonce | input)` starts with n leading zero bytes. the difficulty 
rises with level, from just one byte needed, all the way up to 8, thus requiring `2^64` md5 evaluations. this
is much too much, so we had to find another way.

a quick googling on the subject showed us this website: http://0xf.kr/md5/. it keeps track of the smallest
md5 outputs ever generated, and it looks like the record has exactly 8 zeros at the start. if there was
no nonce specified, we would be able to use that preimage. but since the nonce is just one byte, we can
just wait for the server to generate one that is the first byte of our found input. then we just send the rest,
and we're done.
