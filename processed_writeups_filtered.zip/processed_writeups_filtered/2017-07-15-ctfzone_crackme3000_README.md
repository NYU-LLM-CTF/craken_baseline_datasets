# crackme3000 (reverse, 724p)

> our opponents have set up a private email server to store their correspondence.
> we need to gain access to it. could you break their advanced authentication protocols?

> crackme3000

in this task we were given a single mips binary. it wasn't too big, but reversing it was still painful. architecture
is not widely supported by re tools, but task creators were actively trying to mislead us. for example,
the congratulations text was printed in two cases: either the input string was equal to some hardcoded
string formatted like a flag (which btw was not the flag), or when a series of checks were fulfilled.

the binary used rc4 cipher as a part of password checking. finding the key was tricky though - it turned out
to be the string `error: _ptr is not null` - yeah, seriously! i initially skipped that part of binary,
thinking it's just random compiler error checking subroutine. nice idea for delaying the reversing.

the binary then tried to open some file, but didn't seem to do anything with it. then it decrypted some data using
rc4 and xored it with `xor_key` buffer. the problem is, that buffer was set only if the operation of opening that file
did not succeed. the `xor_key` was then set to the result of `strerror` function call - as i guessed, 
linux-like `no such file or directory` error message. combining all this together, we wrote a quick script to get the flag.

this was a really cleverly annoying task. what a weird combination.
