﻿## which one is flag? (trivia, 75p, 89 solves)

> which one is [flag](flagbag.zip)?

### pl
[eng](#eng-version)

otrzymujemy plik tekstowy z prawie 300 tysiącami flag. jednak pierwsze co rzuca się w oczy to po jednym null byte na wiersz.


[image extracted text: asis{5148d9cb3d97d7d1e9d74dc50u0942393c}
asis{e9d89880e2cwu31co0ef8008e830ff5268}
asis{fcf88f318445bed04cc2fesq8dca9e65b}
asis{50480fe0160c98e7ela7cd1266cwul2d8el
asis{137dbonua81079449a5303d94e46cce011}
asis{6ecc4428eb9ed4bfe6ce9890960u62a43b}
10
asis{44dcl9a4af8a47470u0019394dcb58a4b8}
11
asis{2fa89f0ulc6b0a188b83448f6e9372830b4]


sprawdzamy ile tych null byte-ów jest: okazuje się, że o jeden mniej niż wszystkich flag. znajdźmy więc flagę bez niego - najpierw usuwamy wszystkie znaki w każdym z wierszy od nullbyte'a: `\x00.+`, a następnie szukamy znaku `}`. pozostał tylko jeden - we fladze:

`asis{dc99999733dd1f4ebf8c199753c05595}`

### eng version

we get a text file wiht almost 300,000 flags. however, first thing that we notice is that there is a single null byte per row.


[image extracted text: asis{5148d9cb3d97d7d1e9d74dc50u0942393c}
asis{e9d89880e2cwu31co0ef8008e830ff5268}
asis{fcf88f318445bed04cc2fesq8dca9e65b}
asis{50480fe0160c98e7ela7cd1266cwul2d8el
asis{137dbonua81079449a5303d94e46cce011}
asis{6ecc4428eb9ed4bfe6ce9890960u62a43b}
10
asis{44dcl9a4af8a47470u0019394dcb58a4b8}
11
asis{2fa89f0ulc6b0a188b83448f6e9372830b4]


we check the number of null bytes and it turns out it's the number of all flags -1. so we look for the flag without the null byte - first we remove all characters in every row starting from nullyte `\x00.+` and then we search for `}`. there is only one - in the flag:

`asis{dc99999733dd1f4ebf8c199753c05595}`