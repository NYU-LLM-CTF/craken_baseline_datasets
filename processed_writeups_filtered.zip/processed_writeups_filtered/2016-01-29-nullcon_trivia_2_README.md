﻿##trivia 2 (trivia/recon, 200p)

	i love this song. what is my project id?

###pl
[eng](#eng-version)

dostajemy plik mp3 (nie udostępnimy go bo był piracki...) oraz informacje, że flagą jest `project id`.
w pliku mp3 trafiamy na dość nietypowy dobór zdjęcia ustawionego jako okładka albumu.
po wyszukaniu tego zdjęcia przez tineye.com i google reverse image search trafiamy na githuba: https://github.com/uzitech którego właściciel ma to samo zdjecie w avatarze.

następnie spędziliśmy bardzo (!) dużo czasu testując różne możliwości dla flagi - nazwy projektów z githuba, id projektów pobrane przez api i wiele innych możliwości.

w końcu przeszukując zawartość plików w repozytorium w poszukiwaniu `project` oraz `id` trafiliśmy między innymi na plik:

https://github.com/uzitech/nsf2sql/blob/master/nsf2sql/nsf2sql.csproj

a flagą okazało się pole `<projectguid>` czyli `3ad3a009-fc65-4067-bff1-6ce1378ba75a`

###eng version

we get mp3 file (not included since it was pirated...) and information that the flag is `project id`.
inside the mp3 file we find a strange picture set as album cover.
we look for the picture with tineye.com and google reverse image search and we find github: https://github.com/uzitech whose owner has the same picture in avatar.

next we spend a lot (!) of time trying to figure out what could be the flag - project names, project ids taken from api, and many many more strange ideas.

finally while looking for `project` and `id` inside the files in repository we found the file:

https://github.com/uzitech/nsf2sql/blob/master/nsf2sql/nsf2sql.csproj

and the flag turned out to be the value of `<projectguid>` so `3ad3a009-fc65-4067-bff1-6ce1378ba75a`
