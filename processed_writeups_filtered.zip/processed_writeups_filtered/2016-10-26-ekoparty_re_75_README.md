# rreeggeexx (re 75)

###eng
[pl](#pl-version)

in the task we got a [binary](regexauth.exe) written in c#.
again as with the f# binary in re50, we can simply decompile the code with ilspy.
most of it is not important - the only important bit is flag verification:

```csharp
program.check_regex("^.{40}$", input) 
&& program.check_regex("\\w{3}\\{.*\\}", input) 
&& program.check_regex("_s.*e_", input) 
&& program.check_regex("\\{o{2}o{2}o{2}", input) 
&& program.check_regex("o{2}o{2}o{2}\\}", input) 
&& program.check_regex("sup3r_r3g3x_challenge", input)
```

it's quite clear that the flag has to match all expressions:

1. flag has to have exactly 40 characters
2. flag contains 3 random letters then `{` any number of random characters and `}` -> this is flag format so `eko{xx}`
3. flag has to contain `_s` then any number of random characters and then `e_`
4. flag has to contain `{oooooo` -> we can combine this with flag start
5. flag has to contain `oooooo}` -> we can combine this with flag end
6. flag has to contain `sup3r_r3g3x_challenge` -> we can combine this with 3.

this quite easily gives us: `eko{oooooo_sup3r_r3g3x_challenge_oooooo}`

###pl version

w zadaniu dostajemy [aplikacje](regexauth.exe) napisaną w c#.
podobnie jak w zadaniu z f# re50, możemy zdekompilować kod za pomocą ilspy.
większość kodu nie jest istotna - jedyny ważny fragment to weryfikacja flagi:

```csharp
program.check_regex("^.{40}$", input) 
&& program.check_regex("\\w{3}\\{.*\\}", input) 
&& program.check_regex("_s.*e_", input) 
&& program.check_regex("\\{o{2}o{2}o{2}", input) 
&& program.check_regex("o{2}o{2}o{2}\\}", input) 
&& program.check_regex("sup3r_r3g3x_challenge", input)
```

jak nie trudno zauważyć flaga musi spełniać wszystkie parametry:

1. flaga ma dokładnie 40 znaków
2. flaga zawiera 3 losowe litery, następnie `{`, dowolną liczbę znaków i na koniec `}` -> to jest format flagi więc `eko{xx}`
3. flaga musi zawierać `_s` następnie dowolną liczbę znaków i potem `e_`
4. flaga musi zawierać `{oooooo` -> możemy połączyć to z początkiem flagi
5. flaga musi zawierać `oooooo}` -> możemy połączyć to z końcem flagi
6. flaga musi zawierać `sup3r_r3g3x_challenge` -> możemy połączyć to z 3

to dość prosto daje nam: `eko{oooooo_sup3r_r3g3x_challenge_oooooo}`
