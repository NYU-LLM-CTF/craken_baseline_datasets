# writeup insomnihack ctf 2017

team: msm, rev, shalom, akrasuski1, nazywam, c7f.m0d3, cr01283

### table of contents

* [bender_safe](bender_safe)
* [internet_of_fail](internet_of_fail)
* [mindreader](mindreader)
* [cryptoquizz](cryptoquizz)
* [the_great_escape1](the_great_escape1)
* [the_great_escape2](the_great_escape2)