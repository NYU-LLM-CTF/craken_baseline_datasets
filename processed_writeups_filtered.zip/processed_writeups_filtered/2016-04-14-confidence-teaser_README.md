# writeups for confidence teaser 2016

team: c7f.m0d3, akrasuski1, cr019283, nazywam, shalom, mnmd21891, msm, rev

### table of contents

 * [amazeing](network_ppc_amazeing)
