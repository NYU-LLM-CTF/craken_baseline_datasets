# payloads all the things 

a list of useful payloads and bypasses for web application security.
feel free to improve with your payloads and techniques !    
i :heart: pull requests :)

you can also contribute with a :beers: irl, or using the sponsor button 

[
[image extracted text: [image not found]]
](https://github.com/sponsors/swisskyrepo)
[
[image extracted text: [image not found]]
](https://twitter.com/intent/tweet?text=payloads%20all%20the%20things,%20a%20list%20of%20useful%20payloads%20and%20bypasses%20for%20web%20application%20security%20-%20by%20@pentest_swissky&url=https://github.com/swisskyrepo/payloadsallthethings/)

an alternative display version is available at [payloadsallthethingsweb](https://swisskyrepo.github.io/payloadsallthethings/).

<p align="center">
  
[image extracted text: [image not found]]
>
</p>


:book: documentation
-----
every section contains the following files, you can use the `_template_vuln` folder to create a new chapter:

- readme.md - vulnerability description and how to exploit it, including several payloads
- intruder - a set of files to give to burp intruder
- images - pictures for the readme.md
- files - some files referenced in the readme.md

you might also like the other projects from the allthethings family :

- [internalallthethings](https://swisskyrepo.github.io/internalallthethings/) - active directory and internal pentest cheatsheets
- [hardwareallthethings](https://swisskyrepo.github.io/hardwareallthethings/) - hardware/iot pentesting wiki


you want more ? check the [books](https://github.com/swisskyrepo/payloadsallthethings/blob/master/_learning_and_socials/books.md) and [youtube channel](https://github.com/swisskyrepo/payloadsallthethings/blob/master/_learning_and_socials/youtube.md) selections.


:technologist: contributions
-----
be sure to read [contributing.md](https://github.com/swisskyrepo/payloadsallthethings/blob/master/contributing.md)

<p align="center">
<a href="https://github.com/swisskyrepo/payloadsallthethings/graphs/contributors">
  
[image extracted text: [image not found]]
>
</a>
</p>

thanks again for your contribution! :heart:


:beers: sponsors
-----

this project is proudly sponsored by these companies: 

[
[image extracted text: [image not found]]
>](https://www.vaadata.com/)
[
[image extracted text: [image not found]]
>](https://github.com/projectdiscovery)
