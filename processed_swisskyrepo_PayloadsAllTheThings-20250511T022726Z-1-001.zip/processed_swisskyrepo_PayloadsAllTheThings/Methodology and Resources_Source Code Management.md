# source code management & ci/cd compromise

:warning: content of this page has been moved to [internalallthethings/cheatsheets/source-code-management-ci](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/)

- [tools](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/#tools)
- [enumerate repositories files and secrets](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/#enumerate-repositories-files-and-secrets)
- [personal access token](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/#personal-access-token)
- [gitlab ci/github actions](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/#gitlab-cigithub-actions)
- [references](https://swisskyrepo.github.io/internalallthethings/cheatsheets/source-code-management-ci/#references)