# initial access

:warning: content of this page has been moved to [internalallthethings/redteam/access/initial-access](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/)

- [complex chains](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#complex-chains)
- [container](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#container)
- [payload](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#payload)
    - [binary files](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#binary-files)
    - [code execution files](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#code-execution-files)
    - [embedded files](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#embedded-files)
- [code signing](https://swisskyrepo.github.io/internalallthethings/redteam/access/initial-access/#code-signing)