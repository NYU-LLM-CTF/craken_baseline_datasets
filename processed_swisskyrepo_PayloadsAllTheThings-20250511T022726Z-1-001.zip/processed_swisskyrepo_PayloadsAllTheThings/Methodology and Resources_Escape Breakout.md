# application escape and breakout

:warning: content of this page has been moved to [internalallthethings/cheatsheets/escape-breakout](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/)

- [gaining a command shell](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#gaining-a-command-shell)
- [sticky keys](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#sticky-keys)
- [dialog boxes](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#dialog-boxes)
    - [creating new files](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#creating-new-files)
    - [open a new windows explorer instance](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#open-a-new-windows-explorer-instance)
    - [exploring context menus](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#exploring-context-menus)
    - [save as](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#save-as)
    - [input boxes](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#input-boxes)
    - [bypass file restrictions](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#bypass-file-restrictions)
- [internet explorer](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#internet-explorer)
- [shell uri handlers](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#shell-uri-handlers)
- [references](https://swisskyrepo.github.io/internalallthethings/cheatsheets/escape-breakout/#references)