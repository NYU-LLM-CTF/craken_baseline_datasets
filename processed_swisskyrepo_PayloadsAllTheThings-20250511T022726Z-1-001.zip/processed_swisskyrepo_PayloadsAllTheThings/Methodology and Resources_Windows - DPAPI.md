# windows - dpapi

:warning: content of this page has been moved to [internalallthethings/redteam/evasion/windows-dpapi](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/)

- [list credential files](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/#list-credential-files)
- [dpapi localmachine context](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/#dpapi-localmachine-context)
- [mimikatz - credential manager & dpapi](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/#mimikatz---credential-manager--dpapi)
- [hekatomb - steal all credentials on domain](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/#hekatomb---steal-all-credentials-on-domain)
- [donpapi - dumping dpapi credz remotely](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-dpapi/#donpapi---dumping-dpapi-credz-remotely)