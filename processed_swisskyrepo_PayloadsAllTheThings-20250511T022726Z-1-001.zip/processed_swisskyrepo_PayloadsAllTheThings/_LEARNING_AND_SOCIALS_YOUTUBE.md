# youtube

> discover the best youtube channels, must-watch conference talks, and handpicked videos on information security.

## channels

- [0xdf](https://www.youtube.com/@0xdf)
- [assetnote - surfacing security podcast](https://www.youtube.com/@assetnote2016)
- [bug bounty reports explained](https://www.youtube.com/@bugbountyreportsexplained)
- [codingo](https://www.youtube.com/@codingo)
- [critical thinking - bug bounty podcast](https://www.youtube.com/@criticalthinkingpodcast)
- [embrace the red - wunderwuzzi](https://www.youtube.com/@embracethered)
- [gynvaelen - podcasts about ctfs, computer security, programming and similar things.](https://www.youtube.com/channel/ucckvmojdbws-jth7tliwkvg)
- [hackerone](https://www.youtube.com/channel/ucsgzmecky2q9lqmwzdwmhyw)
- [hackersploit](https://www.youtube.com/channel/uc0ztpkdxlakf-v33tqxwi3q)
- [hacksplained - a beginner friendly guide to hacking](https://www.youtube.com/c/hacksplained)
- [hak5](https://www.youtube.com/channel/uc3s0btrbjpwndaflrsoiieq)
- [ippsec channel - hack the box writeups](https://www.youtube.com/channel/uca6eh7gckppo5xxudfygqqa)
- [jack rhysider - darknet diaries](https://www.youtube.com/@jackrhysider)
- [john hammond - wargames and ctf writeups](https://www.youtube.com/channel/ucvew9qkbjo3zosnqubg7cfw)
- [laluka - offenskill - sharing is caring](https://www.youtube.com/@thelaluka)
- [liveoverflow - explore weird machines...](https://www.youtube.com/channel/uclce-kvhqyihccjywcpfj9w)
- [murmus ctf - weekly live streamings](https://www.youtube.com/channel/ucub9vogeupw7ikjror4pk-a)
- [nahamsec](https://www.youtube.com/c/nahamsec)
- [networkchuck](https://www.youtube.com/@networkchuck)
- [oj reeves](https://www.youtube.com/channel/ucz2aqrqwmhj4wcjq3xneqrg)
- [pwnfunction](https://www.youtube.com/channel/ucw6mndosqv2e9ajqkv9we7a)
- [sloppyjoepirates ctf writeups](https://www.youtube.com/@sloppyjoepirates)
- [stacksmashing / ghidra ninja](https://www.youtube.com/channel/uc3s8vxwrfqlbdihgrldrvzw)
- [stök](https://www.youtube.com/c/stokfredrik)
- [the cyber mentor](https://www.youtube.com/channel/uc0arlfufympeewyrbzdlhiw)
- [the hated one](https://www.youtube.com/channel/ucjr2bpaypv7t35mvcgt3w8q)
- [xct hacks](https://www.youtube.com/@xct_de)

## conferences

- [blackalps cybersecurityconference](https://www.youtube.com/@blackalpscybersecurityconf8699)
- [defcon conference](https://www.youtube.com/user/defconconference/videos)
- [defcon paris](https://www.youtube.com/@defconparis)
- [hack in paris](https://www.youtube.com/user/hackinparis)
- [hexacon](https://www.youtube.com/@hexacon4091)
- [insomni'hack](https://www.youtube.com/@scrtinsomnihack)
- [lehack / hzv](https://www.youtube.com/user/hzvprod)
- [offensivecon](https://www.youtube.com/@offensivecon)
- [orangecon](https://www.youtube.com/@orangecon)
- [peertube esnhack](https://peertube.esnhack.fr/)
- [recon conference](https://www.youtube.com/@reconmtl)
- [recon village](https://www.youtube.com/@reconvillage)
- [x33fcon conference](https://www.youtube.com/c/x33fcon)

## curated videos

- [bsidessf 101 the tales of a bug bounty hunter - arne swinnen](https://www.youtube.com/watch?v=dsekkynlbbc)
- [how to become a hacker - alisa esage](https://www.youtube.com/watch?v=9ix3h7nqxfu&pp=yguwag93ihrvigjly29tzsbhighhy2tlcg%3d%3d)
- [hunting for top bounties - nicolas grégoire](https://www.youtube.com/watch?v=mqjtgdulsp4)
- [security fest 2016 the secret life of a bug bounty hunter - frans rosén](https://www.youtube.com/watch?v=kdo68laayh8)
- [the conscience of a hacker](https://www.youtube.com/watch?v=0tennvzbyek)
- [hacking google series](https://www.youtube.com/watch?v=aogfy1r4qq4)
    - [ep000: operation aurora | hacking google](https://youtu.be/przdcqe6n5o)
    - [ep001: threat analysis group | hacking google](https://youtu.be/n7n4ec20-cm)
    - [ep002: detection and response | hacking google](https://youtu.be/qz0cpbocl3c)
    - [ep003: red team | hacking google](https://youtu.be/tusqwn2tqxq)
    - [ep004: bug hunters | hacking google](https://youtu.be/ioxixlcnoxg)
    - [ep005: project zero | hacking google](https://youtu.be/my_13fxoddu)
