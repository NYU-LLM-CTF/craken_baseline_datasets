# bug hunting methodology and enumeration

:warning: content of this page has been moved to [internalallthethings/methodology/bug-hunting-methodology](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/)

## summary

- [passive recon](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/#passive-recon)
    - shodan
    - wayback machine
    - the harvester
    - github osint

- [active recon](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/#active-recon)
    - [network discovery](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/#network-discovery)
    - [web discovery](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/#web-discovery)

- [web vulnerabilities](https://swisskyrepo.github.io/internalallthethings/methodology/bug-hunting-methodology/#looking-for-web-vulnerabilities)