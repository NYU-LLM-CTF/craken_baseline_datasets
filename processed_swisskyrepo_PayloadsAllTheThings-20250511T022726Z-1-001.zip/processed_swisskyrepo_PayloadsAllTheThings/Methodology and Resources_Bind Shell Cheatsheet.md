# bind shell

:warning: content of this page has been moved to [internalallthethings/cheatsheets/shell-bind](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/)

- [perl](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#perl)
- [python](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#python)
- [php](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#php)
- [ruby](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#ruby)
- [netcat traditional](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#netcat-traditional)
- [netcat openbsd](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#netcat-openbsd)
- [ncat](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#ncat)
- [socat](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#socat)
- [powershell](https://swisskyrepo.github.io/internalallthethings/cheatsheets/shell-bind-cheatsheet/#powershell)