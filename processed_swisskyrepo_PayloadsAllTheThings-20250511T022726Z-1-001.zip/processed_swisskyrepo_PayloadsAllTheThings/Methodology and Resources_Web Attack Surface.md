# subdomains enumeration

:warning: content of this page has been moved to [internalallthethings/redteam/access/web-attack-surface](https://github.com/swisskyrepo/internalallthethings/redteam/access/web-attack-surface)

- [enumerate subdomains](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#enumerate-subdomains)
    - [subdomains databases](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#subdomains-databases)
    - [bruteforce subdomains](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#bruteforce-subdomains)
    - [certificate transparency logs](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#certificate-transparency-logs)
    - [dns resolution](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#dns-resolution)
    - [technology discovery](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#technology-discovery)
- [subdomain takeover](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#subdomain-takovers)
- [references](https://swisskyrepo.github.io/internalallthethings/redteam/access/web-attack-surface/#references)