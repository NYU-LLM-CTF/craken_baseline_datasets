# hash cracking

:warning: content of this page has been moved to [internalallthethings/cheatsheets/hash-cracking](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/)

- [hashcat](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#hashcat)
   - [hashcat example hashes](https://hashcat.net/wiki/doku.php?id=example_hashes)
   - [hashcat install](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#hashcat-install)
   - [mask attack](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#mask-attack)
   - [dictionary](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#dictionary)
- [john](https://github.com/openwall/john)
   - [usage](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#john-usage)
- [rainbow tables](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#rainbow-tables)
- [tips and tricks](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#tips-and-tricks)
- [online cracking resources](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#online-cracking-resources)
- [references](https://swisskyrepo.github.io/internalallthethings/cheatsheets/hash-cracking/#references)