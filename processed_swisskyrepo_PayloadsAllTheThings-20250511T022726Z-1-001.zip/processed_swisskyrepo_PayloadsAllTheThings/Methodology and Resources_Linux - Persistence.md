# linux - persistence

:warning: content of this page has been moved to [internalallthethings/redteam/persistence/linux-persistence](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/)

- [basic reverse shell](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#basic-reverse-shell)
- [add a root user](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#add-a-root-user)
- [suid binary](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#suid-binary)
- [crontab - reverse shell](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#crontab---reverse-shell)
- [backdooring a user's bash_rc](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-a-users-bash_rc)
- [backdooring a startup service](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-a-startup-service)
- [backdooring a user startup file](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-a-user-startup-file)
- [backdooring message of the day](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-message-of-the-day)
- [backdooring a driver](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-a-driver)
- [backdooring the apt](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-the-apt)
- [backdooring the ssh](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-the-ssh)
- [backdooring git](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#backdooring-git)
- [additional linux persistence options](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#additional-persistence-options)
- [references](https://swisskyrepo.github.io/internalallthethings/redteam/persistence/linux-persistence/#references)