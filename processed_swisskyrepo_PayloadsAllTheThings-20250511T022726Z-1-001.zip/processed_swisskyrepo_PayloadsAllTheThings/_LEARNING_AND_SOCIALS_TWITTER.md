# twitter

> twitter is very common in the infosec area. many advices and tips on bug hunting or ctf games are posted every day. it is worth following the feeds of some successful security researchers and hackers.

## accounts

- [@0xreconless - security research, blogs, and videos by filedescriptor, ngalongc & edoverflow](https://twitter.com/0xreconless)
- [@bugcrowd - another american bug bounty platform](https://twitter.com/bugcrowd)
- [@codingo_ - global head of security ops and researcher enablement bugcrowd, maintainer of some great pentesting tools like nosqlmap or vhostscan](https://twitter.com/codingo_)
- [@d0nutptr - part-time bug hunter, lead security engineer at graplsec](https://twitter.com/d0nutptr)
- [@dawgyg - bug bounty hunter, reformed blackhat, synack red team member](https://twitter.com/thedawgyg)
- [@edoverflow - web developer, security researcher and triager for numerous vulnerability disclosure programs](https://twitter.com/edoverflow)
- [@filedescriptor - security researcher, bug hunter and content creator at 0xreconless](https://twitter.com/filedescriptor)
- [@gentilkiwi - author of mimikatz & kekeo](https://twitter.com/gentilkiwi)
- [@hacker0x01 - american bug bounty platform](https://twitter.com/hacker0x01)
- [@hakluke - bug bounty hunter, content creator, creator of some great pentesting tools like hakrawler](https://twitter.com/hakluke)
- [@insiderphd - phd student, occasional bug bounty hunter & educational cyber security youtuber](https://twitter.com/insiderphd)
- [@intigriti - european ethical hacking & bug bounty platform](https://twitter.com/intigriti)
- [@jobertabma - co-founder of hackerone, security researcher](https://twitter.com/jobertabma)
- [@liveoverflow - content creator and hacker producing videos on various it security topics and participating in hacking contests](https://twitter.com/liveoverflow)
- [@nahamsec - hacker & content creator & co-founder bugbountyforum and http://recon.dev](https://twitter.com/nahamsec)
- [@orange_8361 - bug bounty hunter and security researcher, specialized on rce bugs](https://twitter.com/orange_8361)
- [@pentest_swissky - author of payloadsallthethings & ssrfmap](https://twitter.com/pentest_swissky)
- [@r0bre - bug hunter for web- and systemsecurity, ios security researcher](https://twitter.com/r0bre)
- [@samwcyo - full time bug bounty hunter](https://twitter.com/samwcyo)
- [@securinti - dutch bug bounty hunter & head of hackers and bord member @ intigriti](https://twitter.com/securinti)
- [@spaceraccoon - security researcher and white hat hacker. has worked on several bug bounty programs](https://twitter.com/spaceraccoonsec)
- [@stök - bug bounty hunter, cybersecurity educational content creator](https://twitter.com/stokfredrik)
- [@th3g3nt3lman - security research & bug bounty hunter](https://twitter.com/th3g3nt3lman)
- [@thecybermentor - offers cybersecurity and hacking courses](https://twitter.com/thecybermentor)
- [@tomnomnom - security researcher, maintainer of many very useful pentesting tools](https://twitter.com/tomnomnom)
