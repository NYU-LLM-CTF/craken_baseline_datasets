# powershell

:warning: content of this page has been moved to [internalallthethings/cheatsheets/powershell](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/)

- [execution policy](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#execution-policy)
- [encoded commands](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#encoded-commands)
- [constrained mode](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#constrained-mode)
- [encoded commands](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#encoded-commands)
- [download file](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#download-file)
- [load powershell scripts](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#load-powershell-scripts)
- [load chttps://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/# assembly reflectively](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#load-c-assembly-reflectively)
- [call win api using delegate functions with reflection](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#call-win-api-using-delegate-functions-with-reflection)
    - [resolve address functions](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#resolve-address-functions)
    - [delegatetype reflection](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#delegatetype-reflection)
    - [example with a simple shellcode runner](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#example-with-a-simple-shellcode-runner)
- [secure string to plaintext](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#secure-string-to-plaintext)
- [references](https://swisskyrepo.github.io/internalallthethings/cheatsheets/powershell-cheatsheet/#references)