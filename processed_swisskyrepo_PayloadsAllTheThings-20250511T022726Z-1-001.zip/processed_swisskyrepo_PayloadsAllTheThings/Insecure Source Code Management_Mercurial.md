# mercurial

> mercurial  (also known as hg  from the chemical symbol for mercury) is a distributed version control system (dvcs) designed for efficiency and scalability. developed by matt mackall and first released in 2005, mercurial is known for its speed, simplicity, and ability to handle large codebases.


## summary

* [tools](#tools)
    * [rip-hg.pl](#rip-hgpl)
* [references](#references)


## tools

### rip-hg.pl

* [kost/dvcs-ripper/master/rip-hg.pl](https://raw.githubusercontent.com/kost/dvcs-ripper/master/rip-hg.pl) - rip web accessible (distributed) version control systems: svn/git/hg...
    ```powershell
    docker run --rm -it -v /path/to/host/work:/work:rw k0st/alpine-dvcs-ripper rip-hg.pl -v -u
    ```


## references

* [my-chemical-romance - siunam - feb 13, 2023](https://siunam321.github.io/ctf/la-ctf-2023/web/my-chemical-romance/)