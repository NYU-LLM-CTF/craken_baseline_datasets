# vulnerability title

> vulnerability description - reference

## summary

* [tools](#tools)
* [methodology](#methodology)
    * [subentry 1](#subentry-1)
    * [subentry 2](#subentry-2)
* [labs](#labs)
* [references](#references)

## tools

* [username/tool1](https://github.com/username/tool1) - description of the tool
* [username/tool2](https://github.com/username/tool2) - description of the tool

## methodology

quick explanation

```powershell
exploit
```

### subentry 1

### subentry 2

## labs

* [root me - lab 1](https://root-me.org)
* [portswigger - lab 2](https://portswigger.net)
* [hackthebox - lab 3](https://www.hackthebox.com)

## references

* [blog title - author (@handle) - month xx, 202x](https://example.com)
