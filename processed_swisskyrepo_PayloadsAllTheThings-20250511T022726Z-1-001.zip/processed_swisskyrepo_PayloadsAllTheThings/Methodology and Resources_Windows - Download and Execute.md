# windows - download and execute methods

:warning: content of this page has been moved to [internalallthethings/redteam/access/windows-download-execute](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/)

- [downloaded files location](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#downloaded-files-location)
- [powershell](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#powershell)
- [cmd](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#cmd)
- [cscript / wscript](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#cscript-wscript)
- [mshta](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#mshta)
- [rundll32](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#rundll32)
- [regasm / regsvc](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#regasm-regsvc-subtee)
- [regsvr32](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#regsvr32)
- [odbcconf](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#odbcconf)
- [msbuild](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#msbuild)
- [certutil](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#certutil)
- [bitsadmin](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#bitsadmin)
- [references](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-download-execute/#references)