# html smuggling

:warning: content of this page has been moved to [internalallthethings/redteam/access/html-smuggling](https://swisskyrepo.github.io/internalallthethings/redteam/access/html-smuggling/)

- [description](https://swisskyrepo.github.io/internalallthethings/redteam/access/html-smuggling/#description)
- [executable storage](https://swisskyrepo.github.io/internalallthethings/redteam/access/html-smuggling/#executable-storage)