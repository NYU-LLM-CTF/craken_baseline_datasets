# windows - defenses

:warning: content of this page has been moved to [internalallthethings/redteam/evasion/windows-defenses](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/)

- [applocker](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#applocker)
- [user account control](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#user-account-control)
- [dpapi](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#dpapi)
- [powershell](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#powershell)
    - [anti malware scan interface](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#anti-malware-scan-interface)
    - [just enough administration](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#just-enough-administration)
    - [contrained language mode](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#constrained-language-mode)
    - [script block logging](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#script-block-logging)
- [protected process light](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#protected-process-light)
- [credential guard](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#credential-guard)
- [event tracing for windows](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#event-tracing-for-windows)
- [windows defender antivirus](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#windows-defender-antivirus)
- [windows defender application control](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#windows-defender-application-control)
- [windows defender firewall](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#windows-defender-firewall)
- [windows information protection](https://swisskyrepo.github.io/internalallthethings/redteam/evasion/windows-defenses/#windows-information-protection)