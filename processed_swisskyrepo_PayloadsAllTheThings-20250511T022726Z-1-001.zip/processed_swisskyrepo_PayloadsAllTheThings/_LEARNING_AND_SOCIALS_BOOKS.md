# books

> grab a book and relax. some of the best books in the industry.


**wiley**:

- [advanced penetration testing: hacking the world's most secure networks by wil allsopp (2017)](https://www.goodreads.com/book/show/32027337-advanced-penetration-testing)
- [android hacker's handbook by joshua j. drake et al. (2014)](http://www.wiley.com/wileycda/wileytitle/productcd-111860864x.html)
- [ios hacker's handbook by charlie miller et al. (2012)](http://www.wiley.com/wileycda/wileytitle/productcd-1118204123.html)
- [the browser hacker's handbook by wade alcorn et al. (2014)](http://www.wiley.com/wileycda/wileytitle/productcd-1118662091.html)
- [the database hacker's handbook, david litchfield et al. (2005)](http://www.wiley.com/wileycda/wileytitle/productcd-0764578014.html)
- [the mac hacker's handbook by charlie miller & dino dai zovi (2009)](http://www.wiley.com/wileycda/wileytitle/productcd-0470395362.html)
- [the mobile application hacker's handbook by dominic chell et al. (2015)](http://www.wiley.com/wileycda/wileytitle/productcd-1118958500.html)
- [the shellcoders handbook by chris anley et al. (2007)](http://www.wiley.com/wileycda/wileytitle/productcd-047008023x.html)
- [the web application hackers handbook by d. stuttard, m. pinto (2011)](http://www.wiley.com/wileycda/wileytitle/productcd-1118026470.html)

**leanpub**:

- [breaking into information security: learning the ropes 101 - andrew gill](https://leanpub.com/ltr101-breaking-into-infosec)
- [web hacking 101 - how to make money hacking ethically by peter yaworski (2018)](https://leanpub.com/web-hacking-101)

**other**:

- [black hat rust: applied offensive security with the rust programming language by sylvain kerkour](https://kerkour.com/black-hat-rust)
- [hacking: the art of exploitation by jon erickson (2004)](https://www.goodreads.com/book/show/61619.hacking)
- [owasp testing guide: stable](https://owasp.org/www-project-web-security-testing-guide/stable/)
- [the hacker playbook 1: practical guide to penetration testing by peter kim (2014)](https://www.goodreads.com/book/show/21846565-the-hacker-playbook)
- [the hacker playbook 2: practical guide to penetration testing by peter kim (2015)](https://www.goodreads.com/book/show/25791488-the-hacker-playbook-2)
- [the hacker playbook 3: practical guide to penetration testing (red team edition) by peter kim (2018)](https://www.goodreads.com/book/show/40028366-the-hacker-playbook-3)
- [violent python: a cookbook for hackers, forensic analysts, penetration testers and security engineers by t.j. o'connor (2012)](https://www.goodreads.com/book/show/16192263-violent-python)

**no starch press**:

- [a bug hunter's diary by tobias klein (2011)](https://nostarch.com/bughunter)
- [android security internals: an in-depth guide to android's security architecture by nikolay elenkov (2015)](https://nostarch.com/androidsecurity)
- [attacking network protocols: a hacker's guide to capture, analysis, and exploitation by james forshaw (2018)](https://nostarch.com/networkprotocols)
- [black hat go: go programming for hackers and pentesters by tom steele, chris patten, and dan kottmann (2020)](https://nostarch.com/blackhatgo)
- [black hat graphql by dolev farhi, nick aleks (2023)](https://nostarch.com/black-hat-graphql)
- [black hat python: python programming for hackers and pentesters by justin seitz (2014)](https://nostarch.com/black-hat-python2e)
- [bug bounty bootcamp by vickie li (2021)](https://nostarch.com/bug-bounty-bootcamp)
- [car hacker's handbook by craig smith (2016)](https://www.nostarch.com/carhacking)
- [cyberjutsu: cybersecurity for the modern ninja by ben mccarty (2021)](https://nostarch.com/cyberjutsu)
- [evading edr by matt hand (2023)](https://nostarch.com/evading-edr)
- [foundations of information security: a straightforward introduction by jason andress (2019)](https://nostarch.com/foundationsinfosec)
- [game hacking: developing autonomous bots for online games by nick cano (2016)](https://nostarch.com/gamehacking)
- [gray hat python: python programming for hackers and reverse engineers by justin seitz (2009)](https://nostarch.com/ghpython.htm)
- [hacking apis by corey ball (2022)](https://nostarch.com/hacking-apis)
- [metasploit: the penetration tester's guide by david kennedy (2011)](https://www.nostarch.com/metasploit)
- [penetration testing: a hands-on introduction to hacking by georgia weidman (2014)](https://nostarch.com/pentesting)
- [pentesting azure applications: the definitive guide to testing and securing  deployments by matt burrough (2018)](https://nostarch.com/azure)
- [poc||gtfo, volume 1 by manul laphroaig (2017)](https://nostarch.com/gtfo)
- [poc||gtfo, volume 2 by manul laphroaig (2018)](https://nostarch.com/gtfo2)
- [poc||gtfo, volume 3 by manul laphroaig (2021)](https://nostarch.com/gtfo3)
- [practical binary analysis: build your own linux tools for binary instrumentation, analysis, and disassembly by dennis andriesse (2019)](https://nostarch.com/binaryanalysis)
- [practical doomsday: a user's guide to the end of the world by michal zalewski (2022)](https://nostarch.com/practical-doomsday)
- [practical forensic imaging: securing digital evidence with linux tools by bruce nikkel (2016)](https://nostarch.com/forensicimaging)
- [practical iot hacking: the definitive guide to attacking the internet of things by fotios chantzis, ioannis stais, paulino calderon, evangelos deirmentzoglou and beau woods (2021)](https://nostarch.com/practical-iot-hacking)
- [practical social engineering: a primer for the ethical hacker by joe gray (2022)](https://nostarch.com/practical-social-engineering)
- [real-world bug hunting: a field guide to web hacking by peter yaworski (2019)](https://nostarch.com/bughunting)
- [rootkits and bootkits: reversing modern malware and next generation threats by alex matrosov, eugene rodionov, and sergey bratus (2019)](https://nostarch.com/rootkits)
- [the art of cyberwarfare: an investigator's guide to espionage, ransomware, and organized cybercrime by jon dimaggio (2022)](https://nostarch.com/art-cyberwarfare)
- [the car hacker's handbook: a guide for the penetration tester by craig smith (2016)](https://nostarch.com/carhacking)
- [the hardware hacking handbook by jasper van woudenberg & colin o'flynn (2022)](https://nostarch.com/hardwarehacking)
- [windows security internals with powershell by james forshaw (2024)](https://nostarch.com/windows-security-internals-powershell)