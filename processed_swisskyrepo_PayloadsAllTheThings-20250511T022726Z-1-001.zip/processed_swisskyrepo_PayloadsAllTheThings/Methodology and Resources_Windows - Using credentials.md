# windows - using credentials

:warning: content of this page has been moved to [internalallthethings/redteam/access/windows-using-credentials](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/)

- [get credentials](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#get-credentials)
    - [create your credential](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#create-your-credential)
    - [guest credential](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#guest-credential)
    - [retail credential](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#retail-credential)
    - [sandbox credential](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#sandbox-credential)
- [netexec](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#netexec)
- [impacket](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#impacket)
    - [psexec](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#psexec)
    - [wmiexec](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#wmiexec)
    - [smbexec](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#smbexec)

- [rdp remote desktop protocol](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#rdp-remote-desktop-protocol)
- [powershell remoting protocol](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#powershell-remoting-protocol)
    - [powershell credentials](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#powershell-credentials)
    - [powershell pssession](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#powershell-pssession)
    - [powershell secure string](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#powershell-secure-strings)
- [ssh protocol](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#ssh-protocol)
- [winrm protocol](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#winrm-protocol)
- [wmi protocol](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#wmi-protocol)

- [other methods](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#other-methods)
    - [psexec - sysinternal](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#psexec-sysinternal)
    - [mount a remote share](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#mount-a-remote-share)
    - [run as another user](https://swisskyrepo.github.io/internalallthethings/redteam/access/windows-using-credentials/#run-as-another-user)